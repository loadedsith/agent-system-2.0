/**
 * Candidate-only suite for the persistent-seat mail fix pair:
 *   Fix A - claim before deliver, so exactly one poller can inject an envelope.
 *   Fix B - root-only draining, so a seat's subagents never poll its inbox.
 *
 * It also covers the version-2 scheduler envelope: its drain-time validation,
 * its authorization against the canonical registry, and the legacy seat
 * envelope's unchanged behaviour beside it.
 *
 * Every case runs against a mktemp mailbox root through the `mailboxRoot` seam
 * and a mktemp registry fixture through the `registryPath` seam. No real seat
 * mailbox and no real registry is read or written by this file.
 */
import { randomUUID } from "node:crypto";
import { mkdir, mkdtemp, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, test } from "bun:test";

import {
	drainPersistentSeatMailbox,
	enqueuePersistentSeatMessage,
	isRootSeatSession,
	type RootSeatSessionLatch,
} from "./persistent-seat-registry.candidate-rootonly-20260911";

const SEAT_NAMES = ["Sedge", "Verge"];

/**
 * Fixture registry. `messageEnvelopeVersion` is deliberately 1, the value the
 * production file advertises today: a v2-capable receiver must validate and
 * deliver scheduler mail regardless of what that field says, because the field
 * gates the *writer*, and flipping it belongs to the registry owner.
 */
const REGISTRY = {
	schemaVersion: 1,
	messageEnvelopeVersion: 1,
	seats: [
		{ slug: "sedge", displayName: "Sedge" },
		{ slug: "verge", displayName: "Verge" },
	],
	schedulers: [
		{ id: "verge-morning", displayName: "Verge morning scheduler", allowedTargets: ["verge"] },
		{ id: "sedge-morning", displayName: "Sedge morning scheduler", allowedTargets: ["sedge"] },
	],
};

const SCHEDULER_RENDER = "Scheduled message from Verge morning scheduler"
	+ " (sender kind: scheduler; scheduler id verge-morning; not a persistent seat)";

let mailboxRoot: string;
let registryRoot: string;

beforeEach(async () => {
	mailboxRoot = await mkdtemp(join(tmpdir(), "omp-seat-mailbox-candidate-"));
	registryRoot = await mkdtemp(join(tmpdir(), "omp-seat-registry-candidate-"));
});

afterEach(async () => {
	await rm(mailboxRoot, { recursive: true, force: true });
	await rm(registryRoot, { recursive: true, force: true });
});

const inboxOf = (seat: string) => join(mailboxRoot, "inbox", seat.toLowerCase());

/** Write a registry fixture; a string is written verbatim so it can be invalid. */
async function writeRegistry(registry: unknown = REGISTRY): Promise<string> {
	const path = join(registryRoot, `persistent-seats-${randomUUID()}.json`);
	await writeFile(path, typeof registry === "string" ? registry : `${JSON.stringify(registry)}\n`);
	return path;
}

/**
 * Write a v2 scheduler envelope straight into Verge's inbox. The writer CLI is
 * a separate owner's file, so these cases author the envelope directly, which
 * is also how a hostile same-user process would deliver one.
 */
async function queueSchedulerEnvelope(
	overrides: Record<string, unknown> = {},
	filename?: string,
): Promise<{ id: string; entry: string }> {
	const inbox = inboxOf("Verge");
	await mkdir(inbox, { recursive: true });
	const id = `${Date.now()}-${randomUUID()}`;
	const envelope: Record<string, unknown> = {
		schemaVersion: 2,
		id,
		sender: { kind: "scheduler", id: "verge-morning" },
		to: "Verge",
		message: "Run the morning pass.",
		createdAt: new Date().toISOString(),
		...overrides,
	};
	const entry = filename ?? `${String(envelope.id)}.json`;
	await writeFile(join(inbox, entry), `${JSON.stringify(envelope)}\n`);
	return { id: String(envelope.id ?? id), entry };
}

async function queue(message: string) {
	return enqueuePersistentSeatMessage({
		from: "Sedge",
		target: "Verge",
		message,
		seatNames: SEAT_NAMES,
		mailboxRoot,
	});
}

describe("claim before deliver", () => {
	test("two concurrent drains over one envelope inject it exactly once", async () => {
		const envelope = await queue("Read the report.");
		const injectedByFirst: string[] = [];
		const injectedBySecond: string[] = [];

		// Both pollers are sessions inside one seat process, so they share the
		// default claim owner. That is the 0-of-8 shape: same inbox, same pid.
		const [first, second] = await Promise.all([
			drainPersistentSeatMailbox({
				currentSeat: "Verge",
				seatNames: SEAT_NAMES,
				mailboxRoot,
				deliver: message => {
					injectedByFirst.push(message);
				},
			}),
			drainPersistentSeatMailbox({
				currentSeat: "Verge",
				seatNames: SEAT_NAMES,
				mailboxRoot,
				deliver: message => {
					injectedBySecond.push(message);
				},
			}),
		]);

		expect(injectedByFirst.length + injectedBySecond.length).toBe(1);
		expect([...first, ...second]).toEqual([envelope.id]);
	});

	test("the losing poller injects nothing at all", async () => {
		await queue("Only once.");
		const injections: Array<"winner" | "loser"> = [];

		// Distinct claim owners make the winner unambiguous: whichever drain
		// renames first wins, and the other must not reach its deliver.
		const [winner, loser] = await Promise.all([
			drainPersistentSeatMailbox({
				currentSeat: "Verge",
				seatNames: SEAT_NAMES,
				mailboxRoot,
				claimOwner: "winner",
				deliver: () => {
					injections.push("winner");
				},
			}),
			drainPersistentSeatMailbox({
				currentSeat: "Verge",
				seatNames: SEAT_NAMES,
				mailboxRoot,
				claimOwner: "loser",
				deliver: () => {
					injections.push("loser");
				},
			}),
		]);

		expect(injections.length).toBe(1);
		// Exactly one drain reports a delivery; the other reports none, and the
		// one that reported none never called deliver.
		const reported = [winner.length, loser.length].sort();
		expect(reported).toEqual([0, 1]);
		const silent = winner.length === 0 ? "winner" : "loser";
		expect(injections).not.toContain(silent);
	});

	test("ten concurrent drains over one envelope still inject it exactly once", async () => {
		await queue("Thundering herd.");
		let injections = 0;

		const results = await Promise.all(
			Array.from({ length: 10 }, (_unused, index) =>
				drainPersistentSeatMailbox({
					currentSeat: "Verge",
					seatNames: SEAT_NAMES,
					mailboxRoot,
					claimOwner: `poller-${index}`,
					deliver: () => {
						injections += 1;
					},
				})),
		);

		expect(injections).toBe(1);
		expect(results.flat().length).toBe(1);
	});
});

describe("receipt contract", () => {
	test("a single drain delivers normally and still writes its ack", async () => {
		const envelope = await queue("Read the report.");
		const delivered: string[] = [];

		const ids = await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			deliver: message => {
				delivered.push(message);
			},
		});

		expect(ids).toEqual([envelope.id]);
		expect(delivered).toEqual(["Persistent-seat message from Sedge:\n\nRead the report."]);
		// waitForPersistentSeatMessageAck polls exactly this path to resolve the
		// sender's receipt as "delivered" rather than "queued".
		expect(await Bun.file(join(mailboxRoot, "acks", `${envelope.id}.json`)).json()).toMatchObject({
			id: envelope.id,
			from: "Sedge",
			to: "Verge",
		});
		// The claim is consumed: nothing is left behind in the inbox.
		expect(await readdir(inboxOf("Verge"))).toEqual([]);
	});

	test("an envelope that loses the claim race produces no second ack", async () => {
		const envelope = await queue("Once.");
		await Promise.all([
			drainPersistentSeatMailbox({
				currentSeat: "Verge",
				seatNames: SEAT_NAMES,
				mailboxRoot,
				claimOwner: "a",
				deliver: () => {},
			}),
			drainPersistentSeatMailbox({
				currentSeat: "Verge",
				seatNames: SEAT_NAMES,
				mailboxRoot,
				claimOwner: "b",
				deliver: () => {},
			}),
		]);

		expect(await readdir(join(mailboxRoot, "acks"))).toEqual([`${envelope.id}.json`]);
	});
});

describe("malformed envelopes", () => {
	test("a malformed envelope is quarantined and does not block the ones behind it", async () => {
		const inbox = inboxOf("Verge");
		await mkdir(inbox, { recursive: true });
		// Sorts ahead of any Date.now()-prefixed id, so it is drained first.
		await writeFile(join(inbox, "0000000000000-00000000-0000-0000-0000-000000000000.json"), "{ not json");
		const good = await queue("Still gets through.");
		const delivered: string[] = [];

		const ids = await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			deliver: message => {
				delivered.push(message);
			},
		});

		expect(ids).toEqual([good.id]);
		expect(delivered).toEqual(["Persistent-seat message from Sedge:\n\nStill gets through."]);
		expect(await readdir(inbox)).toEqual([
			"0000000000000-00000000-0000-0000-0000-000000000000.json.invalid",
		]);
	});

	test("an envelope addressed to another seat is quarantined, not injected", async () => {
		const inbox = inboxOf("Verge");
		await mkdir(inbox, { recursive: true });
		const id = "1000000000000-00000000-0000-0000-0000-00000000000a";
		await writeFile(
			join(inbox, `${id}.json`),
			`${JSON.stringify({ id, from: "Verge", to: "Sedge", message: "Wrong inbox.", createdAt: new Date().toISOString() })}\n`,
		);
		const delivered: string[] = [];

		const ids = await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			deliver: message => {
				delivered.push(message);
			},
		});

		expect(ids).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inbox)).toEqual([`${id}.json.invalid`]);
	});
});

describe("crash window between claim and injection", () => {
	test("a claim orphaned by a failed injection is re-adopted by the same owner", async () => {
		const envelope = await queue("Survives a thrown deliver.");

		await expect(drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			claimOwner: "steady",
			deliver: () => {
				throw new Error("injection failed");
			},
		})).rejects.toThrow("injection failed");

		// The envelope is claimed, not lost: it still names its id on disk.
		expect(await readdir(inboxOf("Verge"))).toEqual([`${envelope.id}.json.claimed-steady`]);

		const delivered: string[] = [];
		const ids = await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			claimOwner: "steady",
			deliver: message => {
				delivered.push(message);
			},
		});

		expect(ids).toEqual([envelope.id]);
		expect(delivered).toEqual(["Persistent-seat message from Sedge:\n\nSurvives a thrown deliver."]);
		expect(await readdir(inboxOf("Verge"))).toEqual([]);
	});

	test("a different owner does not steal a live claim", async () => {
		const envelope = await queue("Not yours.");
		await expect(drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			claimOwner: "steady",
			deliver: () => {
				throw new Error("injection failed");
			},
		})).rejects.toThrow("injection failed");

		const delivered: string[] = [];
		const ids = await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			claimOwner: "stranger",
			deliver: message => {
				delivered.push(message);
			},
		});

		expect(ids).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${envelope.id}.json.claimed-steady`]);
	});
});

describe("root-only draining", () => {
	// The predicate is tested directly rather than through session_start:
	// driving the event needs a full ExtensionAPI and an ExtensionContext with
	// a live setInterval, and the registration decision is entirely this call.
	let latch: RootSeatSessionLatch;

	beforeEach(() => {
		latch = {};
	});

	test("the first session in a process is the root and registers", () => {
		const root = {};
		expect(isRootSeatSession(root, latch)).toBe(true);
	});

	test("a session that starts after the root is nested and does not register", () => {
		const root = {};
		const subagentOne = {};
		const subagentTwo = {};

		expect(isRootSeatSession(root, latch)).toBe(true);
		expect(isRootSeatSession(subagentOne, latch)).toBe(false);
		expect(isRootSeatSession(subagentTwo, latch)).toBe(false);
	});

	test("the root re-registers when session_start re-fires on reload or resume", () => {
		const root = {};

		expect(isRootSeatSession(root, latch)).toBe(true);
		expect(isRootSeatSession({}, latch)).toBe(false);
		// Same extension instance asking again: reload, new, resume, fork.
		expect(isRootSeatSession(root, latch)).toBe(true);
	});

	test("separate processes each get their own root", () => {
		const processOne: RootSeatSessionLatch = {};
		const processTwo: RootSeatSessionLatch = {};
		const seatOne = {};
		const seatTwo = {};

		expect(isRootSeatSession(seatOne, processOne)).toBe(true);
		expect(isRootSeatSession(seatTwo, processTwo)).toBe(true);
	});
});

describe("scheduler envelope, version 2", () => {
	const drain = async (registryPath: string, sink: string[]) => drainPersistentSeatMailbox({
		currentSeat: "Verge",
		seatNames: SEAT_NAMES,
		mailboxRoot,
		registryPath,
		deliver: message => {
			sink.push(message);
		},
	});

	test("a valid scheduler envelope delivers and renders its sender kind", async () => {
		const registryPath = await writeRegistry();
		const { id } = await queueSchedulerEnvelope();
		const delivered: string[] = [];

		const ids = await drain(registryPath, delivered);

		expect(ids).toEqual([id]);
		// The scheduler is named and its kind is stated, so no reader can take
		// this for mail from a seat. Rule 6.
		expect(delivered).toEqual([`${SCHEDULER_RENDER}:\n\nRun the morning pass.`]);
		expect(delivered[0]).toContain("scheduler");
		expect(delivered[0]).not.toContain("Persistent-seat message from");
		// The claim is consumed; the envelope is gone from the inbox.
		expect(await readdir(inboxOf("Verge"))).toEqual([]);
	});

	test("the acknowledgment records the scheduler principal and never a from seat", async () => {
		const registryPath = await writeRegistry();
		const { id } = await queueSchedulerEnvelope();

		await drain(registryPath, []);

		const ack = await Bun.file(join(mailboxRoot, "acks", `${id}.json`)).json();
		expect(ack).toMatchObject({ id, sender: { kind: "scheduler", id: "verge-morning" }, to: "Verge" });
		// A synthesized `from` would put a seat identity on scheduler mail on disk.
		expect(ack).not.toHaveProperty("from");
	});

	test("a scheduler envelope delivers even though the registry advertises envelope version 1", async () => {
		// The receiver's own correctness cannot depend on the writer's gate: the
		// fixture advertises 1, and validation and delivery must still hold.
		expect(REGISTRY.messageEnvelopeVersion).toBe(1);
		const registryPath = await writeRegistry();
		const { id } = await queueSchedulerEnvelope();
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([id]);
		expect(delivered).toHaveLength(1);
	});

	test("an absent sender.kind is quarantined, not treated as a seat", async () => {
		const registryPath = await writeRegistry();
		const { entry } = await queueSchedulerEnvelope({ sender: { id: "verge-morning" } });
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});

	test("a sender.kind of seat is quarantined", async () => {
		const registryPath = await writeRegistry();
		// The shape a caller would reach for to smuggle scheduler mail in as a seat.
		const { entry } = await queueSchedulerEnvelope({ sender: { kind: "seat", id: "sedge" } });
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});

	test("an unknown scheduler principal is quarantined", async () => {
		const registryPath = await writeRegistry();
		const { entry } = await queueSchedulerEnvelope({ sender: { kind: "scheduler", id: "ghost-morning" } });
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});

	test("a target outside the scheduler's allowedTargets is quarantined", async () => {
		const registryPath = await writeRegistry();
		// sedge-morning is a configured scheduler, but Verge is not its target.
		const { entry } = await queueSchedulerEnvelope({ sender: { kind: "scheduler", id: "sedge-morning" } });
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});

	test("an envelope addressed to another seat is quarantined even when allowlisted there", async () => {
		const registryPath = await writeRegistry();
		// Authorized by sedge-morning for sedge, but sitting in Verge's inbox.
		const { entry } = await queueSchedulerEnvelope({
			sender: { kind: "scheduler", id: "sedge-morning" },
			to: "Sedge",
		});
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});

	test("a filename that disagrees with the envelope id is quarantined", async () => {
		const registryPath = await writeRegistry();
		const wrongName = "1000000000000-00000000-0000-0000-0000-0000000000ff.json";
		await queueSchedulerEnvelope({}, wrongName);
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${wrongName}.invalid`]);
	});

	test("an unknown schemaVersion is quarantined", async () => {
		const registryPath = await writeRegistry();
		const { entry } = await queueSchedulerEnvelope({ schemaVersion: 3 });
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});

	test("a legacy envelope with no schemaVersion still delivers beside a scheduler one", async () => {
		const registryPath = await writeRegistry();
		const legacy = await queue("Seat mail, unchanged.");
		const scheduler = await queueSchedulerEnvelope();
		const delivered: string[] = [];

		const ids = await drain(registryPath, delivered);

		expect(ids.sort()).toEqual([legacy.id, scheduler.id].sort());
		// The legacy rendering is byte-identical to its pre-v2 form.
		expect(delivered).toContain("Persistent-seat message from Sedge:\n\nSeat mail, unchanged.");
		expect(delivered).toContain(`${SCHEDULER_RENDER}:\n\nRun the morning pass.`);
	});

	test("a rejected scheduler envelope does not block the ones behind it", async () => {
		const registryPath = await writeRegistry();
		const inbox = inboxOf("Verge");
		await mkdir(inbox, { recursive: true });
		// Sorts ahead of any Date.now()-prefixed id, so it is drained first.
		const first = "0000000000000-00000000-0000-0000-0000-000000000000.json";
		await writeFile(
			join(inbox, first),
			`${JSON.stringify({
				schemaVersion: 2,
				id: "0000000000000-00000000-0000-0000-0000-000000000000",
				sender: { kind: "scheduler", id: "ghost-morning" },
				to: "Verge",
				message: "Unauthorized.",
				createdAt: new Date().toISOString(),
			})}\n`,
		);
		const good = await queueSchedulerEnvelope();
		const delivered: string[] = [];

		const ids = await drain(registryPath, delivered);

		expect(ids).toEqual([good.id]);
		expect(delivered).toEqual([`${SCHEDULER_RENDER}:\n\nRun the morning pass.`]);
		expect(await readdir(inbox)).toEqual([`${first}.invalid`]);
	});

	test("two concurrent drains inject one scheduler envelope exactly once", async () => {
		// Validating a v2 envelope reads the registry, so the window between
		// reading the file and claiming it is now wider than on the seat path.
		// The claim, not the validation, must still be the arbiter.
		const registryPath = await writeRegistry();
		const { id } = await queueSchedulerEnvelope();
		const first: string[] = [];
		const second: string[] = [];

		const [a, b] = await Promise.all([drain(registryPath, first), drain(registryPath, second)]);

		expect(first.length + second.length).toBe(1);
		expect([...a, ...b]).toEqual([id]);
	});

	test("an empty message is quarantined", async () => {
		const registryPath = await writeRegistry();
		const { entry } = await queueSchedulerEnvelope({ message: "   " });
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});

	test("an unparseable createdAt is quarantined", async () => {
		const registryPath = await writeRegistry();
		const { entry } = await queueSchedulerEnvelope({ createdAt: "not-a-timestamp" });
		const delivered: string[] = [];

		expect(await drain(registryPath, delivered)).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${entry}.invalid`]);
	});
});

describe("canonical registry faults", () => {
	test("an invalid registry leaves the scheduler envelope in place and still drains seat mail", async () => {
		// A broken registry is an operator fault, not a property of the envelope:
		// quarantining would destroy mail that a repair would make deliverable.
		const registryPath = await writeRegistry({ ...REGISTRY, schemaVersion: 7 });
		const scheduler = await queueSchedulerEnvelope();
		const legacy = await queue("Seat mail is unaffected.");
		const delivered: string[] = [];

		const ids = await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			registryPath,
			deliver: message => {
				delivered.push(message);
			},
		});

		// Clean failure: the drain returns rather than throwing, and the seat
		// envelope behind the scheduler one is delivered.
		expect(ids).toEqual([legacy.id]);
		expect(delivered).toEqual(["Persistent-seat message from Sedge:\n\nSeat mail is unaffected."]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${scheduler.id}.json`]);
	});

	test("a missing registry leaves the scheduler envelope for a later drain, which then delivers it", async () => {
		const { id } = await queueSchedulerEnvelope();
		const missing = join(registryRoot, "absent-persistent-seats.json");
		const delivered: string[] = [];

		expect(await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			registryPath: missing,
			deliver: message => {
				delivered.push(message);
			},
		})).toEqual([]);
		expect(delivered).toEqual([]);
		expect(await readdir(inboxOf("Verge"))).toEqual([`${id}.json`]);

		// Registry repaired: the same envelope is delivered, having never been
		// quarantined. This is why a registry fault must not rename the file.
		const registryPath = await writeRegistry();
		expect(await drainPersistentSeatMailbox({
			currentSeat: "Verge",
			seatNames: SEAT_NAMES,
			mailboxRoot,
			registryPath,
			deliver: message => {
				delivered.push(message);
			},
		})).toEqual([id]);
		expect(delivered).toEqual([`${SCHEDULER_RENDER}:\n\nRun the morning pass.`]);
	});
});

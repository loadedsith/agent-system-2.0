#!/usr/bin/env zsh
set -euo pipefail
unset OMP_SEAT_MODEL

ROOT=${0:A:h}
LAUNCHER="$ROOT/launch-seat"
READY_CHECKER="$ROOT/check-seat-ready"
MORNING_PASS=/Users/jowolff/agent-scratch/joseph-gordon-levitt/morning-pass.sh

output=$("$LAUNCHER" --dry-run wren)
[[ "$output" == *"seat: Wren"* ]]
[[ "$output" == *"agent id: wren"* ]]
[[ "$output" == *"home: /Users/jowolff/code/shipyard/repos/newdle-web"* ]]
[[ "$output" == *"model: anthropic/claude-opus-5-5"* ]]
[[ "$output" == *"MCP config: /Users/jowolff/.omp/agent/mcp.json"* ]]
[[ "$output" == *"action: no process will start"* ]]


foreground_lintel_output=$("$LAUNCHER" --foreground-dry-run lintel /Users/jowolff/code/shipyard) || {
  print -u2 -- "Foreground Lintel dry-run failed"
  exit 1
}
[[ "$foreground_lintel_output" == *"seat: Lintel"* ]] || exit 1
[[ "$foreground_lintel_output" == *"launch mode: foreground"* ]] || exit 1
[[ "$foreground_lintel_output" == *"working directory: /Users/jowolff/code/shipyard"* ]] || exit 1
[[ "$foreground_lintel_output" == *"action: no process will start"* ]] || exit 1

codex_output=$("$LAUNCHER" --dry-run codex) || {
  print -u2 -- "Codex dry-run failed"
  exit 1
}
[[ "$codex_output" == *"seat: Codex"* ]] || exit 1
[[ "$codex_output" == *"agent id: codex"* ]] || exit 1
[[ "$codex_output" == *"home: /Users/jowolff/.codex"* ]] || exit 1
[[ "$codex_output" == *"working directory: /Users/jowolff/.codex"* ]] || exit 1
[[ "$codex_output" == *"model: anthropic/claude-opus-5-5"* ]] || exit 1
[[ "$codex_output" != *"/Documents/Codex/2026-09-08/realtime-voice-chat-2"* ]] || exit 1
[[ "$codex_output" == *"action: no process will start"* ]] || exit 1

sluice_output=$("$LAUNCHER" --dry-run sluice) || {
  print -u2 -- "Sluice dry-run failed"
  exit 1
}
[[ "$sluice_output" == *"seat: Sluice"* ]] || exit 1
[[ "$sluice_output" == *"home: /Users/jowolff/code/shipyard/repos/data-pipelines"* ]] || exit 1
[[ "$sluice_output" == *"charter: /Users/jowolff/code/shipyard/repos/data-pipelines/.ai/sluice-seat-charter.md"* ]] || exit 1
[[ "$sluice_output" == *"model: anthropic/claude-opus-5-5"* ]] || exit 1
[[ "$sluice_output" == *"action: no process will start"* ]] || exit 1

galley_output=$("$LAUNCHER" --dry-run galley) || {
  print -u2 -- "Galley dry-run failed"
  exit 1
}
[[ "$galley_output" == *"seat: Galley"* ]] || exit 1
[[ "$galley_output" == *"agent id: galley"* ]] || exit 1
[[ "$galley_output" == *"home: /Users/jowolff/code/shipyard/repos/kitchen"* ]] || exit 1
[[ "$galley_output" == *"model: anthropic/claude-opus-5-5"* ]] || exit 1
[[ "$galley_output" == *"action: no process will start"* ]] || exit 1

levitt_output=$("$LAUNCHER" --dry-run levitt) || {
  print -u2 -- "Levitt dry-run failed"
  exit 1
}
[[ "$levitt_output" == *"seat: Levitt"* ]] || exit 1
[[ "$levitt_output" == *"home: /Users/jowolff/code/joseph-gordon-levitt"* ]] || exit 1
[[ "$levitt_output" == *"memory: /Users/jowolff/code/joseph-gordon-levitt/.ai/levitt-seat-memory.md"* ]] || exit 1
[[ "$levitt_output" == *"model: anthropic/claude-opus-5-5"* ]] || exit 1
[[ "$levitt_output" == *"action: no process will start"* ]] || exit 1


for seat_slug in tinker sedge verge; do
  seat_output=$("$LAUNCHER" --dry-run "$seat_slug") || {
    print -u2 -- "Launcher refused the $seat_slug dry run"
    exit 1
  }
  [[ "$seat_output" == *"agent id: $seat_slug"* ]] || exit 1
  [[ "$seat_output" == *"model: anthropic/claude-opus-5-5"* ]] || exit 1
  [[ "$seat_output" == *"action: no process will start"* ]] || exit 1
done


# Regression: the launch prompt itself contains the seat name, home, and READY.
# A readiness check must inspect assistant replies only, never rendered terminal
# text or the user prompt, or it reports success before the seat answers.
ready_fixture=$(mktemp -d)
trap 'rm -rf -- "$fixture_bin" "$ready_fixture"' EXIT
print -r -- '{"type":"session","timestamp":"2026-09-11T02:46:54.294Z"}' > "$ready_fixture/prompt-only.jsonl"
print -r -- '{"type":"message","message":{"role":"user","content":[{"type":"text","text":"You are Sluice at /Users/jowolff/code/shipyard/repos/data-pipelines. Reply with READY."}]}}' >> "$ready_fixture/prompt-only.jsonl"
if "$READY_CHECKER" --session-dir "$ready_fixture" --once sluice >/dev/null 2>&1; then
  print -u2 -- "Readiness checker matched the launch prompt before an assistant reply"
  exit 1
fi
print -r -- '{"type":"message","message":{"role":"assistant","content":[{"type":"text","text":"Sluice, they/them. Home: /Users/jowolff/code/shipyard/repos/data-pipelines. READY."}]}}' >> "$ready_fixture/prompt-only.jsonl"
"$READY_CHECKER" --session-dir "$ready_fixture" --once sluice >/dev/null || {
  print -u2 -- "Readiness checker missed a valid assistant reply"
  exit 1
}

# Regression: a restricted PATH without grep must not turn a current HerdR OMP
# integration into the false error reported during the live Lintel launch.
fixture_bin=$(mktemp -d)
trap 'rm -rf -- "$fixture_bin"' EXIT
ln -s "$ROOT/test-fixtures/herdr" "$fixture_bin/herdr"
ln -s "$ROOT/test-fixtures/herdr" "$fixture_bin/omp"
ln -s /bin/date "$fixture_bin/date"
ln -s /usr/bin/python3 "$fixture_bin/python3"
# The foreground path execs `bun --no-env-file <omp>` and fails closed when bun
# is absent (launch-seat, the `real_bun` preflight). This fake records that the
# flag arrived first, drops it, and runs the fixture omp.
print -r -- '#!/bin/zsh
print -r -- "fake bun argv1=$1"
[[ "$1" == --no-env-file ]] && shift
exec "$@"' > "$fixture_bin/bun"
chmod +x "$fixture_bin/bun"

# Regression: the unattended Levitt loop must discover OMP seats by their
# immutable session directory and, when Levitt is live, message the existing
# seat through the scheduler queue — never launch a second Levitt, stop it, or
# fall back to the retired Claude-era launcher. Dry-run names the queue command
# without executing it. (Re-pinned 2026-09-22 by Tinker: the old assertions
# expected a "DECISION REQUIRED" refusal and a `launch-seat --start levitt`
# line that no morning-pass.sh variant since 2026-09-11 prints.)
morning_output=$(HERDR_FIXTURE_STATE="$fixture_bin/state" PATH="$fixture_bin:$PATH" /bin/zsh "$MORNING_PASS" --dry-run 2>&1) || {
  print -u2 -- "$morning_output"
  print -u2 -- "Levitt morning-pass dry run failed"
  exit 1
}
[[ "$morning_output" == *"session=/Users/jowolff/.omp/agent/seat-sessions/levitt/"* ]] || exit 1
[[ "$morning_output" == *"policy: message the existing Levitt; never stop, replace, or duplicate it."* ]] || exit 1
[[ "$morning_output" == *"would run: /Users/jowolff/.omp/agent/seat-launchers/queue-seat-message --sender scheduler:levitt-morning --to levitt --message-file /Users/jowolff/agent-scratch/joseph-gordon-levitt/morning-pass-prompt.md"* ]] || exit 1
[[ "$morning_output" != *"launch-seat --start levitt"* ]] || exit 1
[[ "$morning_output" != *"claude agents --json"* ]] || exit 1
[[ "$morning_output" != *"claude stop"* ]] || exit 1
[[ "$morning_output" != *"/Users/jowolff/agent-scratch/joseph-gordon-levitt/launch-seat.sh"* ]] || exit 1

restricted_path_output=$(HERDR_FIXTURE_STATE="$fixture_bin/state" PATH="$fixture_bin" /bin/zsh "$LAUNCHER" --foreground lintel 2>&1) || {
  print -u2 -- "$restricted_path_output"
  print -u2 -- "Restricted-PATH foreground launch failed"
  exit 1
}
[[ "$restricted_path_output" == *"fake bun argv1=--no-env-file"* ]] || exit 1
[[ "$restricted_path_output" == *"fake foreground OMP started"* ]] || exit 1
[[ "$restricted_path_output" == *"current-seat=Lintel"* ]] || exit 1
[[ "$restricted_path_output" == *"--model anthropic/claude-opus-5-5"* ]] || exit 1
[[ "$restricted_path_output" != *"fake OMP seat started"* ]] || exit 1
[[ "$restricted_path_output" != *"agent_pane_busy"* ]] || exit 1
[[ "$restricted_path_output" != *"HerdR OMP integration is not current"* ]] || exit 1

# Regression, 2026-09-23: the 2026-09-22 launcher edit dropped its PLUGIN_CACHE
# assignment, the plugin glob became `/*`, and every seat launched with
# --plugin-dir /Volumes. This suite stayed green because nothing here looked at
# the plugin root, and `/Volumes` passes every "is a directory" check. Both
# checks below run the real launcher with PLUGIN_CACHE removed from the
# environment, so an inherited value cannot stand in for the launcher's own.
# Positive: the fixture omp echoes the foreground argv, so read --plugin-dir
# back and require a real newdle plugin, never a top-level directory.
plugin_root_output=$(/usr/bin/env -u PLUGIN_CACHE HERDR_FIXTURE_STATE="$fixture_bin/state-plugin-root" PATH="$fixture_bin" /bin/zsh "$LAUNCHER" --foreground lintel 2>&1) || {
  print -u2 -- "$plugin_root_output"
  print -u2 -- "Plugin-root regression: foreground launch with PLUGIN_CACHE unset failed"
  exit 1
}
[[ "$plugin_root_output" == *" --plugin-dir "* ]] || {
  print -u2 -- "$plugin_root_output"
  print -u2 -- "Plugin-root regression: foreground argv carried no --plugin-dir"
  exit 1
}
resolved_plugin_root=${${plugin_root_output#* --plugin-dir }%% --hook *}
if [[ -z "$resolved_plugin_root" || "${resolved_plugin_root:h}" == / || ! -f "$resolved_plugin_root/hooks/hooks.json" ]]; then
  print -u2 -- "$plugin_root_output"
  print -u2 -- "Plugin-root regression: with PLUGIN_CACHE unset the launcher passed --plugin-dir '$resolved_plugin_root', which is not a newdle plugin (top-level directory or no hooks/hooks.json)"
  exit 1
fi
# Negative: the newest cached version has no hooks/hooks.json. The launcher must
# refuse with the plugin-root message naming that path, not fall back to the
# older valid version and not fail later on some unrelated missing input (a
# fake HOME also hides the adapter, so any launcher exits nonzero here; only
# the specific message counts).
fake_plugin_home=$(mktemp -d)
trap 'rm -rf -- "$fixture_bin" "$fake_plugin_home"' EXIT
fake_plugin_cache="$fake_plugin_home/.claude/plugins/cache/contextpress/newdle"
mkdir -p "$fake_plugin_cache/0.2.9/hooks" "$fake_plugin_cache/0.2.10/skills"
print -r -- '{}' > "$fake_plugin_cache/0.2.9/hooks/hooks.json"
if not_a_plugin_output=$(/usr/bin/env -u PLUGIN_CACHE HOME="$fake_plugin_home" /bin/zsh "$LAUNCHER" --dry-run wren 2>&1); then
  print -u2 -- "$not_a_plugin_output"
  print -u2 -- "Plugin-root regression: launcher accepted a newest plugin version with no hooks/hooks.json"
  exit 1
fi
[[ "$not_a_plugin_output" == *"resolved plugin root is not a newdle plugin: $fake_plugin_cache/0.2.10"* ]] || {
  print -u2 -- "$not_a_plugin_output"
  print -u2 -- "Plugin-root regression: launcher refused a hookless plugin root without the plugin-root refusal naming $fake_plugin_cache/0.2.10"
  exit 1
}
# Remedy, 2026-09-23: the hookless refusal must also print its fix. Step 1 is a quarantine
# `mv` of the resolved root to a timestamped path outside the cache (under the same HOME),
# with its undo and its cost to Claude Code's installed_plugins.json; step 2, after it, is
# the reinstall. The commands are read back off the refusal and run in the fake HOME below.
quarantine_dir="$fake_plugin_home/.local/state/launch-seat/plugin-quarantine"
move_prefix="      mkdir -p \"$quarantine_dir\" && mv \"$fake_plugin_cache/0.2.10\" \"$quarantine_dir/newdle-0.2.10."
move_cmd='' undo_cmd='' move_at=0 reinstall_at=0 line_no=0
for line in "${(@f)not_a_plugin_output}"; do
  (( ++line_no ))
  [[ "$line" == "$move_prefix"<->T<->'"' ]] && { move_cmd=$line; move_at=$line_no; }
  [[ "$line" == '      mv "'*'" "'"$fake_plugin_cache/0.2.10"'"' ]] && undo_cmd=$line
  [[ "$line" == '      claude plugin update newdle@contextpress' ]] && reinstall_at=$line_no
done
[[ -n "$move_cmd" ]] || {
  print -u2 -- "$not_a_plugin_output"
  print -u2 -- "Plugin-root remedy: hookless refusal printed no quarantine mv moving $fake_plugin_cache/0.2.10 to a timestamped path under $quarantine_dir"
  exit 1
}
quarantine_path=${${move_cmd##* \"}%\"}
[[ "$undo_cmd" == "      mv \"$quarantine_path\" \"$fake_plugin_cache/0.2.10\"" ]] || {
  print -u2 -- "$not_a_plugin_output"
  print -u2 -- "Plugin-root remedy: hookless refusal printed no undo moving $quarantine_path back to $fake_plugin_cache/0.2.10"
  exit 1
}
[[ "$not_a_plugin_output" == *"$fake_plugin_home/.claude/plugins/installed_plugins.json"* ]] || {
  print -u2 -- "$not_a_plugin_output"
  print -u2 -- "Plugin-root remedy: hookless refusal did not state the quarantine's cost to Claude Code's installed_plugins.json"
  exit 1
}
(( reinstall_at > move_at )) || {
  print -u2 -- "$not_a_plugin_output"
  print -u2 -- "Plugin-root remedy: hookless refusal printed no 'claude plugin update newdle@contextpress' step after the quarantine mv"
  exit 1
}

# Remedy, end to end: give the fake HOME the OMP inputs a foreground launch reads, so the
# plugin-root refusal is the only thing that can stop the launch. It must refuse before the
# fixture omp runs; after the printed quarantine it must launch on 0.2.9; after the printed
# undo, 0.2.10 is back and it refuses again.
mkdir -p "$fake_plugin_home/.omp/agent/extensions"
: > "$fake_plugin_home/.omp/agent/extensions/newdle-hooks.ts"
: > "$fake_plugin_home/.omp/agent/extensions/compaction-state-owner.ts"
: > "$fake_plugin_home/.omp/agent/extensions/persistent-seat-registry.ts"
print -r -- '{"mcpServers":{"linear":{"type":"http","url":"https://mcp.linear.app/mcp"},"ctx":{"type":"stdio","command":"ctx","args":["mcp","serve"]}}}' > "$fake_plugin_home/.omp/agent/mcp.json"
quarantine_launch() {
  /usr/bin/env -u PLUGIN_CACHE -u OMP_SEAT_ADAPTER -u OMP_SEAT_CONFIG -u OMP_SEAT_PROMPT_FILE \
    HOME="$fake_plugin_home" HERDR_FIXTURE_STATE="$fixture_bin/state-quarantine" PATH="$fixture_bin" \
    /bin/zsh "$LAUNCHER" --foreground lintel 2>&1
}
if hookless_launch_output=$(quarantine_launch) || [[ "$hookless_launch_output" == *" --plugin-dir "* ]]; then
  print -u2 -- "$hookless_launch_output"
  print -u2 -- "Plugin-root remedy: with every other input present the launcher did not stop at the hookless refusal before running omp"
  exit 1
fi
/bin/zsh -c "$move_cmd" || {
  print -u2 -- "Plugin-root remedy: the printed quarantine command failed: $move_cmd"
  exit 1
}
[[ -d "$quarantine_path" && ! -e "$fake_plugin_cache/0.2.10" ]] || {
  print -u2 -- "Plugin-root remedy: the printed quarantine command did not move 0.2.10 out of the cache to $quarantine_path"
  exit 1
}
quarantined_launch_output=$(quarantine_launch) || {
  print -u2 -- "$quarantined_launch_output"
  print -u2 -- "Plugin-root remedy: after the printed quarantine the foreground launch still failed"
  exit 1
}
[[ "${${quarantined_launch_output#* --plugin-dir }%% --hook *}" == "$fake_plugin_cache/0.2.9" ]] || {
  print -u2 -- "$quarantined_launch_output"
  print -u2 -- "Plugin-root remedy: after the printed quarantine the launcher did not resolve the previous version $fake_plugin_cache/0.2.9"
  exit 1
}
/bin/zsh -c "$undo_cmd" || {
  print -u2 -- "Plugin-root remedy: the printed undo failed: $undo_cmd"
  exit 1
}
if [[ ! -d "$fake_plugin_cache/0.2.10" ]] || undone_launch_output=$(quarantine_launch) || [[ "$undone_launch_output" != *"resolved plugin root is not a newdle plugin: $fake_plugin_cache/0.2.10"* ]]; then
  print -u2 -- "${undone_launch_output:-}"
  print -u2 -- "Plugin-root remedy: after the printed undo, 0.2.10 was not back in the cache or the launcher did not refuse it again"
  exit 1
fi

# Remedy for the empty-PLUGIN_CACHE refusal. The assignment is unconditional, so this refusal
# fires only on a launcher whose PLUGIN_CACHE= line was edited away (2026-09-22). Test a
# mutant with that line deleted, in a directory of backups where name order disagrees with
# age at both ends and a newer .bak-* (the live directory's broken backup is one) must not
# count: the refusal must name the edit, print the line to restore, offer the newest .pre-*
# backup by mtime to diff against, and exit before the plugin glob runs.
# :A because the launcher names paths by ${0:A}, and macOS's mktemp dir sits under the
# /var -> /private/var symlink.
mutant_dir=${$(mktemp -d):A}
trap 'rm -rf -- "$fixture_bin" "$fake_plugin_home" "$mutant_dir"' EXIT
# Two steps on purpose: measured 2026-09-23, `zsh -n` on a file holding the one-step form
# ("${(@f)$(<"$LAUNCHER")}") prints "no such file or directory" and can exit 1.
launcher_text=$(<"$LAUNCHER")
launcher_lines=("${(@f)launcher_text}")
mutant_lines=("${(@)launcher_lines:#PLUGIN_CACHE=*}")
(( $#mutant_lines == $#launcher_lines - 1 )) || {
  print -u2 -- "Empty-cache remedy: the mutant did not remove exactly one PLUGIN_CACHE= line from $LAUNCHER"
  exit 1
}
print -rl -- "${mutant_lines[@]}" > "$mutant_dir/launch-seat"
: > "$mutant_dir/launch-seat.pre-aaa-older"
: > "$mutant_dir/launch-seat.pre-mmm-newest"
: > "$mutant_dir/launch-seat.pre-zzz-older"
: > "$mutant_dir/launch-seat.bak-broken-but-newer"
/usr/bin/touch -t 202601010000 "$mutant_dir/launch-seat.pre-aaa-older" "$mutant_dir/launch-seat.pre-zzz-older"
/usr/bin/touch -t 202609010000 "$mutant_dir/launch-seat.pre-mmm-newest"
if empty_cache_output=$(/usr/bin/env -u PLUGIN_CACHE /bin/zsh "$mutant_dir/launch-seat" --dry-run wren 2>&1); then
  print -u2 -- "$empty_cache_output"
  print -u2 -- "Empty-cache remedy: the launcher with its PLUGIN_CACHE= line deleted did not refuse"
  exit 1
fi
[[ "$empty_cache_output" == *"the only cause is an edit to this launcher"* ]] || {
  print -u2 -- "$empty_cache_output"
  print -u2 -- "Empty-cache remedy: the refusal did not say the only cause is an edit to the launcher"
  exit 1
}
[[ "$empty_cache_output" == *$'\n''    PLUGIN_CACHE=$HOME/.claude/plugins/cache/contextpress/newdle'$'\n'* ]] || {
  print -u2 -- "$empty_cache_output"
  print -u2 -- "Empty-cache remedy: the refusal did not print the exact PLUGIN_CACHE= line to restore"
  exit 1
}
[[ "$empty_cache_output" == *$'\n''    diff "'"$mutant_dir/launch-seat.pre-mmm-newest"'" "'"$mutant_dir/launch-seat"'"'* ]] || {
  print -u2 -- "$empty_cache_output"
  print -u2 -- "Empty-cache remedy: the refusal did not offer the newest .pre-* backup by mtime ($mutant_dir/launch-seat.pre-mmm-newest) as a diff"
  exit 1
}
empty_cache_trace=$(/usr/bin/env -u PLUGIN_CACHE /bin/zsh -x "$mutant_dir/launch-seat" --dry-run wren 2>&1) || true
[[ "$empty_cache_trace" == *"> exit 1"* && "$empty_cache_trace" != *"> plugin_dirs="* ]] || {
  print -u2 -- "$empty_cache_trace"
  print -u2 -- "Empty-cache remedy: the refusal did not exit 1 before the plugin glob assignment ran"
  exit 1
}

# The PATH-resolved wrapper must carry the full launch contract, including the
# wake prompt, while the command injected into the pane remains only `omp`.
wrapper_output=$(OMP_SEAT_REAL_OMP="$fixture_bin/omp" \
  OMP_SEAT_CWD=/test/seat \
  OMP_SEAT_MODEL=openai-codex/test-model \
  OMP_SEAT_SESSION_DIR=/test/sessions \
  OMP_SEAT_PLUGIN_ROOT=/test/plugin \
  OMP_SEAT_ADAPTER=/test/adapter.ts \
  OMP_SEAT_COMPACTION_OWNER=/test/compaction.ts \
  OMP_SEAT_REGISTRY=/test/registry.ts \
  OMP_SEAT_PROMPT='WAKE-PROMPT-MARKER' \
  PATH="$fixture_bin" \
  /bin/zsh "$ROOT/seat-bin/omp") || {
  print -u2 -- "$wrapper_output"
  print -u2 -- "Seat wrapper contract failed"
  exit 1
}
[[ "$wrapper_output" == *"--session-dir /test/sessions"* ]] || exit 1
[[ "$wrapper_output" == *"--plugin-dir /test/plugin"* ]] || exit 1
[[ "$wrapper_output" == *"--hook /test/adapter.ts"* ]] || exit 1
[[ "$wrapper_output" == *"--hook /test/compaction.ts"* ]] || exit 1
[[ "$wrapper_output" == *"--extension /test/registry.ts"* ]] || exit 1
[[ "$wrapper_output" == *"WAKE-PROMPT-MARKER"* ]] || exit 1

# Regression: `pane split` may return before the new background pane's login
# shell is available. The launcher must observe shell readiness before start.
: > "$fixture_bin/herdr.log"
background_output=$(HERDR_ENV=1 HERDR_WORKSPACE_ID=test-workspace HERDR_FIXTURE_STATE="$fixture_bin/state" HERDR_FIXTURE_LOG="$fixture_bin/herdr.log" PATH="$fixture_bin" /bin/zsh "$LAUNCHER" --start wren 2>&1) || {
  print -u2 -- "$background_output"
  print -u2 -- "Background pane-readiness launch failed"
  exit 1
}
[[ "$background_output" == *'"submitted":true'* ]] || exit 1
[[ "$(<"$fixture_bin/state")" -ge 2 ]] || exit 1
[[ "$background_output" != *"agent_pane_busy"* ]] || exit 1

# Background seats are separate durable work surfaces. Starting one must create
# an unfocused tab, not stack another vertical pane into Lintel's tab.
[[ "$(<"$fixture_bin/herdr.log")" == *"tab create"* ]] || {
  print -u2 -- "Background launch did not create a separate HerdR tab"
  exit 1
}
[[ "$(<"$fixture_bin/herdr.log")" == *"--env OMP_CURRENT_SEAT_NAME=Wren"* ]] || {
  print -u2 -- "Background launch did not declare the current persistent-seat identity"
  exit 1
}
[[ "$(<"$fixture_bin/herdr.log")" == *"--env OMP_SEAT_APPEND_SYSTEM_PROMPT=$ROOT/omp-persistent-seat-contract.txt"* ]] || {
  print -u2 -- "Background launch did not inject the OMP persistent-seat contract"
  exit 1
}
[[ "$(<"$fixture_bin/herdr.log")" != *"pane split"* ]] || {
  print -u2 -- "Background launch still created a split pane"
  exit 1
}

# Regression: HerdR's `agent start --kind omp` resolves the global OMP binary
# itself, and a login shell can also replace the PATH supplied at tab creation.
# A valid seat launch must run the short wrapper by absolute path through the
# pane's shell, then name the detected agent. Otherwise OMP opens bare with no
# seat prompt, plugin root, hooks, or dedicated session directory.
[[ "$(<"$fixture_bin/herdr.log")" == *"pane run test-pane $ROOT/seat-bin/omp"* ]] || {
  print -u2 -- "Background launch did not execute the seat wrapper through the pane shell"
  exit 1
}
[[ "$(<"$fixture_bin/herdr.log")" == *"agent rename test-pane wren"* ]] || {
  print -u2 -- "Background launch did not name the wrapper-launched OMP seat"
  exit 1
}
[[ "$(<"$fixture_bin/herdr.log")" != *"agent start"* ]] || {
  print -u2 -- "Background launch still bypassed the wrapper through HerdR agent start"
  exit 1
}

# Regression: accepting the rename command is insufficient. HerdR must return
# the canonical name and a nonempty native session identity afterward, or the
# shutdown workflow cannot resolve the seat safely.
if broken_identity_output=$(HERDR_ENV=1 HERDR_WORKSPACE_ID=test-workspace \
  HERDR_FIXTURE_RENAME_BROKEN=1 \
  HERDR_FIXTURE_STATE="$fixture_bin/state" \
  HERDR_FIXTURE_LOG="$fixture_bin/herdr.log" \
  PATH="$fixture_bin" \
  /bin/zsh "$LAUNCHER" --start wren 2>&1); then
  print -u2 -- "$broken_identity_output"
  print -u2 -- "Launcher accepted a seat whose HerdR name did not persist"
  exit 1
fi
[[ "$broken_identity_output" == *"did not retain its canonical HerdR identity"* ]] || {
  print -u2 -- "$broken_identity_output"
  print -u2 -- "Launcher returned the wrong persistent-identity failure"
  exit 1
}

# Regression: HerdR answers `agent get` with the renamed agent before OMP has
# pushed `agent_session` at session_start, so the first read-back after a rename
# carries the name but no session and fails the identity assertion. A single
# immediate read refused seven seats that had in fact launched cleanly. An
# identity that completes a few reads later must reach success, not a refusal.
: > "$fixture_bin/herdr.log"
if ! lagging_identity_output=$(HERDR_ENV=1 HERDR_WORKSPACE_ID=test-workspace \
  HERDR_FIXTURE_IDENTITY_LAG=4 \
  HERDR_FIXTURE_STATE="$fixture_bin/state-lag" \
  HERDR_FIXTURE_LOG="$fixture_bin/herdr.log" \
  PATH="$fixture_bin" \
  /bin/zsh "$LAUNCHER" --start wren 2>&1); then
  print -u2 -- "$lagging_identity_output"
  print -u2 -- "Launcher refused a seat whose HerdR identity resolved after a short delay"
  exit 1
fi
[[ "$lagging_identity_output" != *"did not retain its canonical HerdR identity"* ]] || {
  print -u2 -- "$lagging_identity_output"
  print -u2 -- "Launcher reported an identity refusal for a seat it accepted"
  exit 1
}
[[ "$lagging_identity_output" != *"could not read the identity back"* ]] || {
  print -u2 -- "$lagging_identity_output"
  print -u2 -- "Launcher reported an unreadable identity for a seat it accepted"
  exit 1
}
[[ "$(<"$fixture_bin/state-lag.identitylag")" -gt 1 ]] || {
  print -u2 -- "Lagging-identity fixture resolved on the first read; the retry path was never exercised"
  exit 1
}

# Caspian, the newdle-api seat, ratified 2026-09-11. ROUTING.md's model contract
# requires the routing table and this regression to change in the same edit as a
# new seat row, so that a seat cannot be half-added. This block fails with
# "Missing required launch input:" until the charter and memory documents exist
# at the paths the seat row names — the launcher's readability preflight refuses
# before it prints a profile, which is the composite check between the two
# halves and is exactly what it is supposed to catch.
caspian_output=$("$LAUNCHER" --dry-run caspian 2>&1) || {
  print -u2 -- "$caspian_output"
  print -u2 -- "Launcher refused the caspian dry run"
  exit 1
}
[[ "$caspian_output" == *"seat: Caspian"* ]] || exit 1
[[ "$caspian_output" == *"agent id: caspian"* ]] || exit 1
[[ "$caspian_output" == *"home: /Users/jowolff/code/shipyard/repos/newdle-api"* ]] || exit 1
[[ "$caspian_output" == *"charter: /Users/jowolff/code/shipyard/repos/newdle-api/.ai/caspian-seat-charter.md"* ]] || exit 1
[[ "$caspian_output" == *"memory: /Users/jowolff/code/shipyard/repos/newdle-api/.ai/caspian-seat-memory.md"* ]] || exit 1
[[ "$caspian_output" == *"model: anthropic/claude-opus-5-5"* ]] || exit 1
[[ "$caspian_output" == *"action: no process will start"* ]] || exit 1

# Tron, the newdle-users seat, generated by Verge 2026-09-11 and given its launcher
# row the same day. Same composite check as Caspian above: this fails with
# "Missing required launch input:" if the charter or memory named by the seat row
# is unreadable, because the launcher's readability preflight refuses before it
# prints a profile. That is the join between the row and the files it names, and
# it is the half that a row-only edit leaves untested.
#
# Ordering note, learned from Caspian: run this AFTER the last edit to Tron's
# charter, never before. Caspian's first green dry run was measured against a
# charter superseded 6 minutes 21 seconds later, so the green proved the launcher
# worked and proved nothing about the document it had read.
tron_output=$("$LAUNCHER" --dry-run tron 2>&1) || {
  print -u2 -- "$tron_output"
  print -u2 -- "Launcher refused the tron dry run"
  exit 1
}
[[ "$tron_output" == *"seat: Tron"* ]] || exit 1
[[ "$tron_output" == *"agent id: tron"* ]] || exit 1
[[ "$tron_output" == *"home: /Users/jowolff/code/shipyard/repos/newdle-users"* ]] || exit 1
[[ "$tron_output" == *"charter: /Users/jowolff/code/shipyard/repos/newdle-users/.ai/tron-seat-charter.md"* ]] || exit 1
[[ "$tron_output" == *"memory: /Users/jowolff/code/shipyard/repos/newdle-users/.ai/tron-seat-memory.md"* ]] || exit 1
[[ "$tron_output" == *"model: anthropic/claude-opus-5-5"* ]] || exit 1
[[ "$tron_output" == *"action: no process will start"* ]] || exit 1

# Plumb, the agent-system 2.0 redesign seat, generated 2026-09-21. Same composite
# check as Caspian and Tron, plus the one model exception to the opus-5-5 contract:
# Plumb launches on the fable model by Jo's instruction of 2026-09-21 ("a long
# running fable agent"). Its row in launch-seat carries its own default_model, the
# same shape as the Codex row. Run this AFTER the last edit to Plumb's charter.
plumb_output=$("$LAUNCHER" --dry-run plumb 2>&1) || {
  print -u2 -- "$plumb_output"
  print -u2 -- "Launcher refused the plumb dry run"
  exit 1
}
[[ "$plumb_output" == *"seat: Plumb"* ]] || exit 1
[[ "$plumb_output" == *"agent id: plumb"* ]] || exit 1
[[ "$plumb_output" == *"home: /Users/jowolff/code/agent-system-2.0"* ]] || exit 1
[[ "$plumb_output" == *"charter: /Users/jowolff/code/agent-system-2.0/.ai/plumb-seat-charter.md"* ]] || exit 1
[[ "$plumb_output" == *"memory: /Users/jowolff/code/agent-system-2.0/.ai/plumb-seat-memory.md"* ]] || exit 1
[[ "$plumb_output" == *"model: anthropic/claude-fable-5-1:medium"* ]] || exit 1
[[ "$plumb_output" == *"action: no process will start"* ]] || exit 1

# Regression: when the identity read-back fails at the transport layer for the
# whole retry window, the launcher must refuse with the unreadable-identity
# message AND carry the last attempt's stderr. Suppressing stderr inside the
# loop is deliberate — 100 copies of a novel error buries the diagnosis — so
# losing it entirely on the exhaustion path is the failure this pins.
: > "$fixture_bin/herdr.log"
if unreadable_identity_output=$(HERDR_ENV=1 HERDR_WORKSPACE_ID=test-workspace \
  HERDR_FIXTURE_GET_BROKEN=1 \
  HERDR_FIXTURE_STATE="$fixture_bin/state-getbroken" \
  HERDR_FIXTURE_LOG="$fixture_bin/herdr.log" \
  PATH="$fixture_bin" \
  /bin/zsh "$LAUNCHER" --start wren 2>&1); then
  print -u2 -- "$unreadable_identity_output"
  print -u2 -- "Launcher accepted a seat whose identity read-back never succeeded"
  exit 1
fi
[[ "$unreadable_identity_output" == *"could not read the identity back"* ]] || {
  print -u2 -- "$unreadable_identity_output"
  print -u2 -- "Launcher returned the wrong failure for an unreadable identity"
  exit 1
}
[[ "$unreadable_identity_output" == *"transport closed while reading agent state"* ]] || {
  print -u2 -- "$unreadable_identity_output"
  print -u2 -- "Exhaustion path dropped the last attempt's stderr"
  exit 1
}

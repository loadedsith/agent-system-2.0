import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { describe, expect, test } from "bun:test";

import {
	completePersistentSeatRoster,
	describeHerdRAgents,
	drainPersistentSeatMailbox,
	enqueuePersistentSeatMessage,
	ensurePersistentSeatToolsActive,
	includeCurrentSeat,
	normalizeHerdRSeat,
	persistentSeatHubMisuseReason,
	resolvePersistentSeatTarget,
	selectPersistentSeats,
} from "../extensions/persistent-seat-registry";

describe("includeCurrentSeat", () => {
	test("adds the foreground persistent seat when HerdR only returns background seats", () => {
		const tinker = normalizeHerdRSeat({ name: "tinker", agent: "omp", agent_status: "idle" });

		expect(includeCurrentSeat([tinker], "Lintel")).toEqual([
			tinker,
			{ name: "Lintel", harness: "omp", state: "idle", ownership: "OMP" },
		]);
	});

	test("does not duplicate the current seat when HerdR already returns it", () => {
		const lintel = normalizeHerdRSeat({ name: "lintel", agent: "omp", agent_status: "idle" });

		expect(includeCurrentSeat([lintel], "Lintel")).toEqual([lintel]);
	});
});

describe("completePersistentSeatRoster", () => {
	test("keeps configured seats visible when HerdR cannot observe them", () => {
		const tinker = normalizeHerdRSeat({ name: "tinker", agent: "omp", agent_status: "idle" });

		expect(completePersistentSeatRoster([tinker], ["Lintel", "Tinker"], "Tinker")).toEqual([
			{ name: "Lintel", harness: "omp", state: "unknown", ownership: "OMP" },
			tinker,
		]);
	});
});

describe("describeHerdRAgents", () => {
	test("shows safe identity fields when no allowlisted seat matches", () => {
		expect(describeHerdRAgents([{
			name: "tinker",
			title: "Tinker",
			display_agent: "OMP",
			agent: "omp",
			agent_status: "idle",
		}])).toBe("HerdR returned 1 agent:\nname=tinker; title=Tinker; terminal-title=(empty); harness=omp; display-agent=OMP; state=idle");
	});

	test("distinguishes an empty HerdR inventory", () => {
		expect(describeHerdRAgents([])).toBe("HerdR returned zero agents to this OMP process.");
	});
});

describe("normalizeHerdRSeat", () => {
	test("uses the HerdR custom agent name set by the seat launcher", () => {
		expect(normalizeHerdRSeat({
			name: "tinker",
			terminal_title_stripped: "",
			agent: "omp",
			agent_status: "idle",
		})).toEqual({
			name: "tinker",
			harness: "omp",
			state: "idle",
			ownership: "OMP",
		});
	});

	test("labels a Claude Code resident seat as external and idle", () => {
		expect(normalizeHerdRSeat({
			terminal_title_stripped: "Lintel",
			agent: "Claude Code",
			agent_status: "idle",
		})).toEqual({
			name: "Lintel",
			harness: "Claude Code",
			state: "idle",
			ownership: "external",
		});
	});

	test("labels an OMP seat as OMP-owned and normalizes working to running", () => {
		expect(normalizeHerdRSeat({
			terminal_title_stripped: "Wren",
			agent: "OMP",
			agent_status: "working",
		})).toEqual({
			name: "Wren",
			harness: "OMP",
			state: "running",
			ownership: "OMP",
		});
	});

	test("preserves a sleeping Codex seat as external", () => {
		expect(normalizeHerdRSeat({
			terminal_title_stripped: "Research",
			agent: "Codex",
			agent_status: "asleep",
		})).toEqual({
			name: "Research",
			harness: "Codex",
			state: "asleep",
			ownership: "external",
		});
	});

	test("includes only configured durable seats, not disposable OMP workers", () => {
		const seats = [
			normalizeHerdRSeat({ terminal_title_stripped: "Lintel", agent: "Claude Code", agent_status: "idle" }),
			normalizeHerdRSeat({ terminal_title_stripped: "OMP disposable worker", agent: "OMP", agent_status: "working" }),
		];

		expect(selectPersistentSeats(seats, ["Lintel"])).toEqual([seats[0]]);
	});
});

describe("resolvePersistentSeatTarget", () => {
	test("maps a display name to the lowercase HerdR seat slug", () => {
		expect(resolvePersistentSeatTarget("Verge", ["Lintel", "Sedge", "Verge"])).toBe("verge");
	});

	test("rejects a name outside the persistent-seat allowlist", () => {
		expect(() => resolvePersistentSeatTarget("reviewer", ["Lintel", "Verge"]))
			.toThrow('Unknown persistent seat "reviewer". Available seats: Lintel, Verge.');
	});
});

describe("persistent-seat tool enforcement", () => {
	test("restores both required tools without disabling active tools", async () => {
		let activated: string[] = [];
		await ensurePersistentSeatToolsActive({
			getActiveTools: () => ["read", "seat_list"],
			setActiveTools: async tools => {
				activated = tools;
			},
		});

		expect(activated).toEqual(["read", "seat_list", "seat_message"]);
	});

	test("blocks hub addressing a persistent seat", () => {
		expect(persistentSeatHubMisuseReason(
			"hub",
			{ op: "send", to: "Verge" },
			["Lintel", "Sedge", "Verge"],
		)).toBe('"Verge" is a persistent seat. Use seat_message; hub addresses only disposable hands inside this session.');
	});

	test("preserves hub for disposable hands and roster inspection", () => {
		expect(persistentSeatHubMisuseReason(
			"hub",
			{ op: "send", to: "BuilderHand" },
			["Lintel", "Sedge", "Verge"],
		)).toBeUndefined();
		expect(persistentSeatHubMisuseReason(
			"hub",
			{ op: "list" },
			["Lintel", "Sedge", "Verge"],
		)).toBeUndefined();
	});
});

describe("persistent-seat mailbox", () => {
	test("delivers a case-insensitive seat message without terminal input", async () => {
		const mailboxRoot = await mkdtemp(join(tmpdir(), "omp-seat-mailbox-"));
		try {
			const envelope = await enqueuePersistentSeatMessage({
				from: "Sedge",
				target: "Verge",
				message: "Read the report.",
				seatNames: ["Sedge", "Verge"],
				mailboxRoot,
			});
			const delivered: string[] = [];

			const messageIds = await drainPersistentSeatMailbox({
				currentSeat: "Verge",
				seatNames: ["Sedge", "Verge"],
				mailboxRoot,
				deliver: message => delivered.push(message),
			});

			expect(messageIds).toEqual([envelope.id]);
			expect(delivered).toEqual(["Persistent-seat message from Sedge:\n\nRead the report."]);
			expect(await Bun.file(join(mailboxRoot, "acks", `${envelope.id}.json`)).json()).toMatchObject({
				id: envelope.id,
				from: "Sedge",
				to: "Verge",
			});
		} finally {
			await rm(mailboxRoot, { recursive: true, force: true });
		}
	});
});

import { mkdtemp, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, test } from "bun:test";

import {
	enqueueSchedulerMessage,
	type PersistentSeatRegistry,
} from "./queue-seat-message";

const PRODUCTION_REGISTRY_PATH = "/Users/jowolff/.omp/agent/persistent-seats.json";
const LAUNCHER_PATH = "/Users/jowolff/.omp/agent/seat-launchers/launch-seat";

const temporaryDirectories: string[] = [];
interface FixturePaths {
	root: string;
	registryPath: string;
	mailboxRoot: string;
	messageFile: string;
}


function registry(overrides: Partial<PersistentSeatRegistry> = {}): PersistentSeatRegistry {
	return {
		schemaVersion: 1,
		messageEnvelopeVersion: 2,
		seats: [
			{ slug: "lintel", displayName: "Lintel" },
			{ slug: "levitt", displayName: "Levitt" },
		],
		schedulers: [
			{
				id: "levitt-morning",
				displayName: "Levitt morning scheduler",
				allowedTargets: ["levitt"],
			},
		],
		...overrides,
	};
}

async function fixture(overrides: Partial<PersistentSeatRegistry> = {}): Promise<FixturePaths> {
	const root = await mkdtemp(join(tmpdir(), "queue-seat-message-"));
	temporaryDirectories.push(root);
	const registryPath = join(root, "persistent-seats.json");
	const mailboxRoot = join(root, "inbox");
	const messageFile = join(root, "message.txt");
	await writeFile(registryPath, `${JSON.stringify(registry(overrides), null, 2)}\n`);
	await writeFile(messageFile, "Run Levitt's morning pass.\n");
	return { root, registryPath, mailboxRoot, messageFile };
}

async function enqueue(
	paths: FixturePaths,
	input: { sender?: string; to?: string; messageFile?: string } = {},
) {
	return enqueueSchedulerMessage(
		{
			sender: input.sender ?? "scheduler:levitt-morning",
			to: input.to ?? "levitt",
			messageFile: input.messageFile ?? paths.messageFile,
		},
		{
			registryPath: paths.registryPath,
			mailboxRoot: paths.mailboxRoot,
			now: () => new Date("2026-09-11T06:00:00.000Z"),
			randomUUID: () => "123e4567-e89b-12d3-a456-426614174000",
		},
	);
}

afterEach(async () => {
	await Promise.all(temporaryDirectories.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

describe("canonical persistent-seat registry", () => {
	test("matches launch-seat's existing persistent seat roster", async () => {
		const [registryText, launcherText] = await Promise.all([
			readFile(PRODUCTION_REGISTRY_PATH, "utf8"),
			readFile(LAUNCHER_PATH, "utf8"),
		]);
		const registrySeats = (JSON.parse(registryText) as PersistentSeatRegistry).seats
			.map(({ displayName }) => displayName)
			.sort();
		const launcherMatch = launcherText.match(/^PERSISTENT_SEATS='([^']+)'$/m);
		expect(launcherMatch, `Could not read the roster in ${LAUNCHER_PATH} while checking ${PRODUCTION_REGISTRY_PATH}`).not.toBeNull();
		const launcherSeats = launcherMatch![1].split(",").sort();
		expect(
			registrySeats,
			`Persistent seat roster mismatch between ${PRODUCTION_REGISTRY_PATH} and ${LAUNCHER_PATH}`,
		).toEqual(launcherSeats);
	});
});

describe("enqueueSchedulerMessage", () => {
	test("reads the registry fresh for every send", async () => {
		const paths = await fixture({ schedulers: [] });
		await expect(enqueue(paths)).rejects.toThrow('Unknown scheduler "levitt-morning"');
		await writeFile(paths.registryPath, `${JSON.stringify(registry(), null, 2)}\n`);
		await expect(enqueue(paths)).resolves.toMatchObject({ status: "queued" });
	});

	test("ignores the legacy environment roster", async () => {
		const paths = await fixture();
		const previous = process.env.OMP_PERSISTENT_SEAT_NAMES;
		process.env.OMP_PERSISTENT_SEAT_NAMES = "Lintel";
		try {
			await expect(enqueue(paths)).resolves.toMatchObject({ status: "queued" });
		} finally {
			if (previous === undefined) delete process.env.OMP_PERSISTENT_SEAT_NAMES;
			else process.env.OMP_PERSISTENT_SEAT_NAMES = previous;
		}
	});

	test("refuses until the reader advertises scheduler envelope version 2", async () => {
		const paths = await fixture({ messageEnvelopeVersion: 1 });
		await expect(enqueue(paths)).rejects.toThrow("requires messageEnvelopeVersion 2");
		await expect(readdir(paths.mailboxRoot)).rejects.toThrow();
	});

	test("cannot impersonate a persistent seat", async () => {
		const paths = await fixture();
		await expect(enqueue(paths, { sender: "seat:lintel" })).rejects.toThrow("Scheduler sender required");
		await expect(enqueue(paths, { sender: "lintel" })).rejects.toThrow("Scheduler sender required");
	});

	test("enforces scheduler target authorization", async () => {
		const paths = await fixture();
		await expect(enqueue(paths, { to: "lintel" })).rejects.toThrow(
			'Scheduler "levitt-morning" may not target seat "lintel"',
		);
	});

	test("writes the canonical scheduler envelope and returns only a queued receipt", async () => {
		const paths = await fixture();
		const receipt = await enqueue(paths);
		expect(receipt).toEqual({
			status: "queued",
			id: "1789106400000-123e4567-e89b-12d3-a456-426614174000",
			path: join(
				paths.mailboxRoot,
				"levitt",
				"1789106400000-123e4567-e89b-12d3-a456-426614174000.json",
			),
		});
		expect(receipt).not.toHaveProperty("delivered");
		expect(receipt).not.toHaveProperty("acknowledged");
		const envelope = JSON.parse(await readFile(receipt.path, "utf8"));
		expect(envelope).toEqual({
			schemaVersion: 2,
			id: receipt.id,
			sender: { kind: "scheduler", id: "levitt-morning" },
			to: "levitt",
			message: "Run Levitt's morning pass.",
			createdAt: "2026-09-11T06:00:00.000Z",
		});
		expect(await readdir(join(paths.mailboxRoot, "levitt"))).toEqual([`${receipt.id}.json`]);
	});

	test("uses unique atomic queue paths under concurrency", async () => {
		const paths = await fixture();
		let sequence = 0;
		const dependencies = {
			registryPath: paths.registryPath,
			mailboxRoot: paths.mailboxRoot,
			now: () => new Date("2026-09-11T06:00:00.000Z"),
			randomUUID: () => `123e4567-e89b-12d3-a456-${String(sequence++).padStart(12, "0")}`,
		};
		const input = { sender: "scheduler:levitt-morning", to: "levitt", messageFile: paths.messageFile };
		const receipts = await Promise.all([
			enqueueSchedulerMessage(input, dependencies),
			enqueueSchedulerMessage(input, dependencies),
		]);
		expect(new Set(receipts.map(({ path }) => path)).size).toBe(2);
		const names = await readdir(join(paths.mailboxRoot, "levitt"));
		expect(names).toHaveLength(2);
		expect(names.every((name) => name.endsWith(".json") && !name.includes(".tmp"))).toBe(true);
	});
	test("never overwrites an existing envelope when an id collides", async () => {
		const paths = await fixture();
		const first = await enqueue(paths);
		const original = await readFile(first.path, "utf8");
		await expect(enqueue(paths)).rejects.toThrow();
		expect(await readFile(first.path, "utf8")).toBe(original);
		expect(await readdir(join(paths.mailboxRoot, "levitt"))).toEqual([`${first.id}.json`]);
	});


	test("rejects malformed registries, unknown principals, and empty messages", async () => {
		const malformed = await fixture({ seats: [{ slug: "Levitt", displayName: "Levitt" }] });
		await expect(enqueue(malformed)).rejects.toThrow("Invalid persistent-seat registry");

		const unknownScheduler = await fixture();
		await expect(enqueue(unknownScheduler, { sender: "scheduler:nightly" })).rejects.toThrow(
			'Unknown scheduler "nightly"',
		);

		const unknownTarget = await fixture();
		await expect(enqueue(unknownTarget, { to: "unknown" })).rejects.toThrow('Unknown persistent seat "unknown"');

		const emptyMessage = await fixture();
		await writeFile(emptyMessage.messageFile, "  \n");
		await expect(enqueue(emptyMessage)).rejects.toThrow("Message file is empty");
	});

	test("does not require an acknowledgement directory or invoke another process", async () => {
		const paths = await fixture();
		await mkdir(paths.mailboxRoot, { recursive: true });
		await expect(enqueue(paths)).resolves.toMatchObject({ status: "queued" });
		expect((await readdir(paths.root)).sort()).toEqual([
			"inbox",
			"message.txt",
			"persistent-seats.json",
		]);
	});
});

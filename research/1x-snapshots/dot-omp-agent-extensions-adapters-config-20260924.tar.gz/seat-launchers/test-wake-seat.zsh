#!/usr/bin/env zsh
set -euo pipefail

ROOT=${0:A:h}
WAKE_HELPER="$ROOT/wake-seat"

[[ -r "$WAKE_HELPER" ]] || {
  print -u2 -- "Missing atomic wake helper: $WAKE_HELPER"
  exit 1
}

fixture=$(mktemp -d)
trap 'rm -rf -- "$fixture"' EXIT
/bin/cp "$WAKE_HELPER" "$fixture/wake-seat"
cat > "$fixture/launch-seat" <<'ZSH'
#!/usr/bin/env zsh
[[ "$*" == '--start wren' ]] || exit 24
print -u2 -- 'fixture launcher rejected'
exit 23
ZSH
cat > "$fixture/check-seat-ready" <<'ZSH'
#!/usr/bin/env zsh
[[ "$1" == --after && "$2" == <-> && "$3" == wren && "$4" == 0 ]] || exit 25
print -r -- checker-entered > "$WAKE_FIXTURE_CHECKER_MARKER"
print -- 'fixture checker ready'
ZSH
/bin/chmod +x "$fixture/wake-seat" "$fixture/launch-seat" "$fixture/check-seat-ready"

if rejected_output=$(WAKE_FIXTURE_CHECKER_MARKER="$fixture/checker-entered" \
  "$fixture/wake-seat" wren 0 2>&1); then
  print -u2 -- "$rejected_output"
  print -u2 -- 'Atomic wake accepted a rejected launcher'
  exit 1
else
  rejected_status=$?
fi
[[ "$rejected_status" == 23 ]] || {
  print -u2 -- "$rejected_output"
  print -u2 -- 'Atomic wake did not preserve the launcher exit status'
  exit 1
}
[[ "$rejected_output" == *'fixture launcher rejected'* ]] || exit 1
[[ ! -e "$fixture/checker-entered" ]] || {
  print -u2 -- 'Atomic wake entered readiness after the launcher rejected'
  exit 1
}

cat > "$fixture/launch-seat" <<'ZSH'
#!/usr/bin/env zsh
[[ "$*" == '--start wren' ]] || exit 24
print -- 'fixture launcher submitted'
ZSH
successful_output=$(WAKE_FIXTURE_CHECKER_MARKER="$fixture/checker-entered" \
  "$fixture/wake-seat" wren 0 2>&1) || {
  print -u2 -- "$successful_output"
  print -u2 -- 'Atomic wake did not check readiness after launch success'
  exit 1
}
[[ "$successful_output" == *'fixture launcher submitted'* ]] || exit 1
[[ "$successful_output" == *'fixture checker ready'* ]] || exit 1
[[ -e "$fixture/checker-entered" ]] || {
  print -u2 -- 'Atomic wake never entered readiness after launch success'
  exit 1
}

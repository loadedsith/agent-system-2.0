/**
 * The sole OMP `session.compacting` preserveData owner.
 *
 * Extensions contribute namespaced values during `session_before_compact` by
 * appending a `dev.newdle.omp.compaction-contribution` entry. This owner
 * merges the most recent value for each key into OMP's one preserveData slot.
 * Do not add another direct `session.compacting` handler alongside this file.
 */
import type { HookAPI } from "@oh-my-pi/pi-coding-agent";

type Contribution = { key?: unknown; value?: unknown };

export default function compactionStateOwner(pi: HookAPI) {
	pi.on("session.compacting", async (_event, ctx) => {
		const preserveData: Record<string, unknown> = {};
		for (const entry of ctx.sessionManager.getBranch()) {
			if (entry.type !== "custom" || entry.customType !== "dev.newdle.omp.compaction-contribution") continue;
			const contribution = entry.data as Contribution | undefined;
			if (typeof contribution?.key !== "string" || !contribution.key.startsWith("dev.")) continue;
			preserveData[contribution.key] = contribution.value;
		}
		return Object.keys(preserveData).length ? { preserveData } : undefined;
	});
}

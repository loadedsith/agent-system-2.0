/**
 * OMP persistent-seat registry.
 *
 * `/agents` belongs to OMP's disposable task workers. The separate `/seats`
 * command and `seat_message` tool operate only on the explicitly allowlisted
 * durable seats managed through HerdR.
 */
import { randomUUID } from "node:crypto";
import { mkdir, readdir, rename, unlink } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";

import type { ExtensionAPI, ExtensionContext } from "@oh-my-pi/pi-coding-agent";

type HerdRAgent = {
	name?: string;
	title?: string;
	agent?: string;
	display_agent?: string;
	agent_status?: string;
	terminal_title?: string;
	terminal_title_stripped?: string;
};

type HerdRResponse = {
	result?: {
		agents?: HerdRAgent[];
	};
};

export type PersistentSeat = {
	name: string;
	harness: string;
	state: "running" | "idle" | "asleep" | "unknown";
	ownership: "OMP" | "external";
};

export type PersistentSeatMessageEnvelope = {
	id: string;
	from: string;
	to: string;
	message: string;
	createdAt: string;
};

/**
 * Scheduler envelope, version 2. A scheduler is not a seat: it declares a
 * principal under `sender` rather than a `from` seat name, and nothing on the
 * drain path may collapse the two (requirement rule 6).
 */
export type SchedulerMessageEnvelopeV2 = {
	schemaVersion: 2;
	id: string;
	sender: {
		kind: "scheduler";
		id: string;
	};
	to: string;
	message: string;
	createdAt: string;
};

/**
 * What a drained mailbox can hold. An envelope with no `schemaVersion` is a
 * legacy seat envelope and is validated exactly as it was before v2 existed.
 */
export type PersistentSeatInboundEnvelope = PersistentSeatMessageEnvelope | SchedulerMessageEnvelopeV2;

export type PersistentSeatRegistrySeat = {
	slug: string;
	displayName: string;
};

export type PersistentSeatRegistryScheduler = {
	id: string;
	displayName: string;
	allowedTargets: string[];
};

/**
 * Canonical persistent-seat registry, owned by the Codex seat and read-only
 * here. Schema and consumer guarantees are specified by the scheduler-writer
 * requirement; this file is a consumer, never an author.
 */
export type PersistentSeatRegistry = {
	schemaVersion: 1;
	messageEnvelopeVersion: number;
	seats: PersistentSeatRegistrySeat[];
	schedulers: PersistentSeatRegistryScheduler[];
};

type EnqueuePersistentSeatMessageOptions = {
	from: string;
	target: string;
	message: string;
	seatNames: string[];
	mailboxRoot?: string;
};

type DrainPersistentSeatMailboxOptions = {
	currentSeat: string;
	seatNames: string[];
	mailboxRoot?: string;
	/**
	 * Canonical registry consulted for scheduler envelopes only, and read
	 * fresh for each one. Tests point it at a fixture.
	 */
	registryPath?: string;
	/**
	 * Identifies the poller that claims an envelope, so a claim this poller
	 * left behind is re-adoptable by it and by nobody else. Defaults to the
	 * process id; tests override it to simulate distinct pollers.
	 */
	claimOwner?: string;
	/**
	 * ⛔ RETURNS WHETHER THE MESSAGE REACHED A TURN. `false` means the runtime accepted the bytes
	 * and started nothing — the drain then leaves the claim in place and retries rather than
	 * writing an ack nobody earned. `void`/`undefined` keeps the old caller contract: only an
	 * explicit `false` withholds the ack, so a deliverer that cannot tell is treated as success
	 * exactly as before this change.
	 */
	deliver: (
		message: string,
		envelope: PersistentSeatInboundEnvelope,
	) => Promise<boolean | void> | boolean | void;
};

/**
 * ⛔ THREE STATES, BECAUSE INJECTION AND ACTION ARE DIFFERENT FACTS.
 *
 *   `queued`    — no acknowledgment file inside the ack deadline. The envelope is on disk and
 *                 will be drained whenever the target runs its extension. NOT a delivery.
 *   `delivered` — the target's drain claimed the envelope and injected it into that session.
 *   `acted`     — the target STARTED A TURN carrying it, reported by the target's own
 *                 `agent_start` handler.
 *
 * Measured 2026-09-16: an envelope reached `delivered` in 7s and the seat stayed `idle` for
 * 60s. A sender that cannot tell those apart cannot tell a working channel from a dead one,
 * which is exactly the four hours this receipt cost the night it was one boolean.
 */
type PersistentSeatMessageReceipt = {
	id: string;
	target: string;
	status: "acted" | "delivered" | "queued";
	/** Absolute path a sender can re-check later, after this tool has already returned. */
	turnReceiptPath: string;
};

/**
 * ⛔ THE PROSE SAYS WHAT WAS AND WAS NOT OBSERVED, EVERY TIME. A receipt that reports only its
 * good case teaches the reader nothing about the bad one, and `queued` spent a night being read
 * as "fine, it went" because the word carried no stated limit.
 */
const RECEIPT_PROSE: Record<PersistentSeatMessageReceipt["status"], (receipt: PersistentSeatMessageReceipt) => string> = {
	acted: receipt =>
		`Delivered persistent-seat message ${receipt.id} for ${receipt.target}, and ${receipt.target} started a turn carrying it.`,
	delivered: receipt =>
		`Delivered persistent-seat message ${receipt.id} for ${receipt.target}: ${receipt.target}'s drain claimed and injected it. NO TURN OBSERVED within 4s — ${receipt.target} may be mid-turn on other work and will consume it when that settles. Re-check ${receipt.turnReceiptPath} to settle it.`,
	queued: receipt =>
		`Queued persistent-seat message ${receipt.id} for ${receipt.target}: the envelope is on disk and NO ACKNOWLEDGMENT arrived within 3s. Not delivered. ${receipt.target} will drain it whenever it next runs its extension.`,
};

function normalizeState(status?: string): PersistentSeat["state"] {
	switch (status?.trim().toLowerCase()) {
		case "working":
		case "running":
		case "busy":
			return "running";
		case "idle":
		case "waiting":
			return "idle";
		case "asleep":
		case "sleeping":
		case "stopped":
			return "asleep";
		default:
			return "unknown";
	}
}

export function normalizeHerdRSeat(agent: HerdRAgent): PersistentSeat {
	const harness = agent.agent?.trim() || "unknown harness";
	return {
		name: agent.name?.trim() || agent.terminal_title_stripped?.trim() || "unnamed HerdR session",
		harness,
		state: normalizeState(agent.agent_status),
		ownership: harness.toLowerCase() === "omp" ? "OMP" : "external",
	};
}

export function selectPersistentSeats(seats: PersistentSeat[], seatNames: string[]): PersistentSeat[] {
	const configuredNames = new Set(seatNames.map(name => name.trim().toLowerCase()).filter(Boolean));
	return seats.filter(seat => configuredNames.has(seat.name.toLowerCase()));
}

export function includeCurrentSeat(seats: PersistentSeat[], currentSeatName?: string): PersistentSeat[] {
	const name = currentSeatName?.trim();
	if (!name || seats.some(seat => seat.name.toLowerCase() === name.toLowerCase())) return seats;

	return [
		...seats,
		{
			name,
			harness: "omp",
			state: "idle",
			ownership: "OMP",
		},
	];
}

export function completePersistentSeatRoster(
	discoveredSeats: PersistentSeat[],
	seatNames: string[],
	currentSeatName?: string,
): PersistentSeat[] {
	const visibleSeats = includeCurrentSeat(
		selectPersistentSeats(discoveredSeats, seatNames),
		currentSeatName,
	);
	const visibleByName = new Map(visibleSeats.map(seat => [seat.name.toLowerCase(), seat]));
	return seatNames
		.map(name => name.trim())
		.filter(Boolean)
		.map(name => visibleByName.get(name.toLowerCase()) ?? {
			name,
			harness: "omp",
			state: "unknown",
			ownership: "OMP",
		});
}

export function resolvePersistentSeatTarget(requestedName: string, seatNames: string[]): string {
	const requested = requestedName.trim().toLowerCase();
	const match = seatNames.find(name => name.trim().toLowerCase() === requested);
	if (match) return match.trim().toLowerCase();

	const available = seatNames.map(name => name.trim()).filter(Boolean).join(", ");
	throw new Error(`Unknown persistent seat "${requestedName}". Available seats: ${available || "(none)"}.`);
}

function persistentSeatMailboxRoot(): string {
	return process.env.OMP_PERSISTENT_SEAT_MAILBOX_ROOT?.trim()
		|| join(homedir(), ".omp", "agent", "seat-mailboxes");
}

/** Lowercase-slug grammar shared by seat slugs and scheduler ids. */
const PERSISTENT_SEAT_SLUG_PATTERN = /^[a-z][a-z0-9-]*$/;

/**
 * Canonical registry location. The requirement is explicit that consumers read
 * this file from disk rather than trust `OMP_PERSISTENT_SEAT_NAMES`, so the
 * scheduler path never consults the environment roster. The override exists
 * for tests; production resolves the one canonical path.
 */
function persistentSeatRegistryPath(): string {
	return process.env.OMP_PERSISTENT_SEAT_REGISTRY_PATH?.trim()
		|| join(homedir(), ".omp", "agent", "persistent-seats.json");
}

/**
 * Validate a parsed registry payload against the canonical schema, returning a
 * normalized copy. Every rejection names its reason: an invalid registry is an
 * operator-visible fault, not something a receiver may paper over.
 */
export function validatePersistentSeatRegistry(value: unknown): PersistentSeatRegistry {
	const reject = (reason: string): never => {
		throw new Error(`Invalid persistent-seat registry: ${reason}`);
	};

	if (!value || typeof value !== "object" || Array.isArray(value)) return reject("payload is not a JSON object.");
	const candidate = value as Partial<PersistentSeatRegistry>;
	if (candidate.schemaVersion !== 1) {
		return reject(`schemaVersion must be exactly 1, got ${JSON.stringify(candidate.schemaVersion)}.`);
	}
	const envelopeVersion = candidate.messageEnvelopeVersion;
	if (typeof envelopeVersion !== "number" || !Number.isInteger(envelopeVersion) || envelopeVersion < 1) {
		return reject(`messageEnvelopeVersion must be a positive integer, got ${JSON.stringify(envelopeVersion)}.`);
	}
	if (!Array.isArray(candidate.seats) || candidate.seats.length === 0) {
		return reject("seats must be a non-empty array.");
	}

	const seats: PersistentSeatRegistrySeat[] = [];
	const seenSlugs = new Set<string>();
	const seenDisplayNames = new Set<string>();
	for (const entry of candidate.seats) {
		if (!entry || typeof entry !== "object") return reject("every seats[] entry must be an object.");
		const { slug, displayName } = entry as Partial<PersistentSeatRegistrySeat>;
		if (typeof slug !== "string" || !PERSISTENT_SEAT_SLUG_PATTERN.test(slug)) {
			return reject(`seat slug ${JSON.stringify(slug)} must match ${PERSISTENT_SEAT_SLUG_PATTERN.source}.`);
		}
		if (seenSlugs.has(slug)) return reject(`seat slug "${slug}" is duplicated.`);
		if (typeof displayName !== "string" || displayName.trim().length === 0) {
			return reject(`seat "${slug}" needs a non-empty displayName.`);
		}
		const displayKey = displayName.trim().toLowerCase();
		if (seenDisplayNames.has(displayKey)) return reject(`seat displayName "${displayName.trim()}" is duplicated.`);
		seenSlugs.add(slug);
		seenDisplayNames.add(displayKey);
		seats.push({ slug, displayName: displayName.trim() });
	}

	if (!Array.isArray(candidate.schedulers)) return reject("schedulers must be an array.");
	const schedulers: PersistentSeatRegistryScheduler[] = [];
	const seenSchedulerIds = new Set<string>();
	for (const entry of candidate.schedulers) {
		if (!entry || typeof entry !== "object") return reject("every schedulers[] entry must be an object.");
		const { id, displayName, allowedTargets } = entry as Partial<PersistentSeatRegistryScheduler>;
		if (typeof id !== "string" || !PERSISTENT_SEAT_SLUG_PATTERN.test(id)) {
			return reject(`scheduler id ${JSON.stringify(id)} must match ${PERSISTENT_SEAT_SLUG_PATTERN.source}.`);
		}
		if (seenSchedulerIds.has(id)) return reject(`scheduler id "${id}" is duplicated.`);
		if (typeof displayName !== "string" || displayName.trim().length === 0) {
			return reject(`scheduler "${id}" needs a non-empty displayName.`);
		}
		if (!Array.isArray(allowedTargets) || allowedTargets.length === 0) {
			return reject(`scheduler "${id}" needs a non-empty allowedTargets list.`);
		}
		const targets = new Set<string>();
		for (const target of allowedTargets) {
			if (typeof target !== "string") return reject(`scheduler "${id}" has a non-string allowedTargets entry.`);
			if (targets.has(target)) return reject(`scheduler "${id}" lists target "${target}" twice.`);
			if (!seenSlugs.has(target)) return reject(`scheduler "${id}" targets "${target}", which is not a configured seat slug.`);
			targets.add(target);
		}
		seenSchedulerIds.add(id);
		schedulers.push({ id, displayName: displayName.trim(), allowedTargets: [...targets] });
	}

	return { schemaVersion: 1, messageEnvelopeVersion: envelopeVersion, seats, schedulers };
}

/**
 * Read and validate the canonical registry from disk.
 *
 * `messageEnvelopeVersion` is validated as a positive integer and otherwise
 * carries no authority over this receiver: the receiver's own behaviour is
 * correct whatever the file advertises. That field tells the *writer* whether
 * the deployed receiver understands v2, and flipping it is the registry
 * owner's move inside the activation cycle, not this reader's.
 */
export async function readPersistentSeatRegistry(registryPath?: string): Promise<PersistentSeatRegistry> {
	const path = registryPath ?? persistentSeatRegistryPath();
	let payload: unknown;
	try {
		payload = await Bun.file(path).json();
	} catch (error) {
		const reason = error instanceof Error ? error.message : String(error);
		throw new Error(`Unreadable persistent-seat registry at ${path}: ${reason}`);
	}
	return validatePersistentSeatRegistry(payload);
}

/**
 * Resolve a registry seat by slug or display name. The requirement describes a
 * scheduler envelope's `to` as a display name while the writer CLI is invoked
 * with a slug, so both resolve here, case-insensitively, to exactly one seat.
 */
export function resolveRegistrySeat(
	registry: PersistentSeatRegistry,
	name: string,
): PersistentSeatRegistrySeat | undefined {
	const wanted = name.trim().toLowerCase();
	if (!wanted) return undefined;
	return registry.seats.find(seat => seat.slug === wanted || seat.displayName.toLowerCase() === wanted);
}

function canonicalPersistentSeatName(name: string, seatNames: string[]): string {
	const slug = resolvePersistentSeatTarget(name, seatNames);
	return seatNames.find(candidate => candidate.trim().toLowerCase() === slug)!.trim();
}

async function writeJsonAtomically(path: string, value: unknown): Promise<void> {
	const temporaryPath = `${path}.${process.pid}.${randomUUID()}.tmp`;
	await Bun.write(temporaryPath, `${JSON.stringify(value)}\n`);
	await rename(temporaryPath, path);
}

export async function enqueuePersistentSeatMessage(
	options: EnqueuePersistentSeatMessageOptions,
): Promise<PersistentSeatMessageEnvelope> {
	const from = canonicalPersistentSeatName(options.from, options.seatNames);
	const target = canonicalPersistentSeatName(options.target, options.seatNames);
	if (from.toLowerCase() === target.toLowerCase()) {
		throw new Error(`Cannot message the current persistent seat "${options.target}".`);
	}

	const message = options.message.trim();
	if (!message) {
		throw new Error("Persistent-seat messages cannot be empty.");
	}

	const id = `${Date.now()}-${randomUUID()}`;
	const envelope: PersistentSeatMessageEnvelope = {
		id,
		from,
		to: target,
		message,
		createdAt: new Date().toISOString(),
	};
	const mailboxRoot = options.mailboxRoot ?? persistentSeatMailboxRoot();
	const inbox = join(mailboxRoot, "inbox", target.toLowerCase());
	await mkdir(inbox, { recursive: true });
	await writeJsonAtomically(join(inbox, `${id}.json`), envelope);
	return envelope;
}

/** Writer-produced envelope id: `${createdAtEpochMilliseconds}-${uuid}`. */
const PERSISTENT_SEAT_MESSAGE_ID_PATTERN = /^[0-9]+-[0-9a-f-]+$/i;

function isPersistentSeatMessageEnvelope(value: unknown): value is PersistentSeatMessageEnvelope {
	if (!value || typeof value !== "object") return false;
	const candidate = value as Partial<PersistentSeatMessageEnvelope>;
	return typeof candidate.id === "string"
		&& PERSISTENT_SEAT_MESSAGE_ID_PATTERN.test(candidate.id)
		&& typeof candidate.from === "string"
		&& typeof candidate.to === "string"
		&& typeof candidate.message === "string"
		&& candidate.message.trim().length > 0
		&& typeof candidate.createdAt === "string";
}

/**
 * A fault in the environment rather than in the envelope: the canonical
 * registry is missing, unreadable, or invalid. An envelope rejected for this
 * reason is left in place, so a later drain delivers it once an operator
 * repairs the registry. Quarantining it would destroy deliverable mail over a
 * condition the envelope itself is innocent of.
 */
class PersistentSeatEnvironmentFault extends Error {}

type ValidatedInboundEnvelope =
	| { kind: "seat"; envelope: PersistentSeatMessageEnvelope }
	| {
		kind: "scheduler";
		envelope: SchedulerMessageEnvelopeV2;
		scheduler: PersistentSeatRegistryScheduler;
	};

type ValidateInboundEnvelopeOptions = {
	value: unknown;
	envelopeEntry: string;
	currentSeatSlug: string;
	seatNames: string[];
	registryPath?: string;
};

/**
 * Validate a version-2 scheduler envelope and its authorization, implementing
 * the requirement's drain-time rules 2 through 5. Every throw is a permanent
 * property of this envelope except the registry read, which raises an
 * environment fault instead.
 */
async function validateSchedulerMessageEnvelopeV2(
	options: ValidateInboundEnvelopeOptions,
): Promise<ValidatedInboundEnvelope> {
	// Untrusted input: typed as unknown fields so no guard is skipped.
	const candidate = options.value as {
		id?: unknown;
		sender?: { kind?: unknown; id?: unknown };
		to?: unknown;
		message?: unknown;
		createdAt?: unknown;
	};

	// Rule 5: non-empty id, message and timestamp, and a filename that names
	// the envelope id. A mismatch means the name and the content disagree
	// about which message this is, which no later check can repair.
	const { id, to, message, createdAt } = candidate;
	if (typeof id !== "string" || !PERSISTENT_SEAT_MESSAGE_ID_PATTERN.test(id)) {
		throw new Error(`Scheduler envelope has an invalid id ${JSON.stringify(id)}.`);
	}
	if (options.envelopeEntry !== `${id}.json`) {
		throw new Error(`Scheduler envelope filename "${options.envelopeEntry}" does not match its id "${id}".`);
	}
	if (typeof message !== "string" || message.trim().length === 0) {
		throw new Error("Scheduler envelope carries no message.");
	}
	if (typeof createdAt !== "string" || !Number.isFinite(Date.parse(createdAt))) {
		throw new Error(`Scheduler envelope has an invalid createdAt ${JSON.stringify(createdAt)}.`);
	}
	if (typeof to !== "string" || to.trim().length === 0) {
		throw new Error("Scheduler envelope names no destination.");
	}

	// Rule 2, first half: the declared principal must be a scheduler. There is
	// no seat variant of this envelope, so a missing or seat-shaped kind is a
	// rejection and never a fallback to a seat identity.
	const sender = candidate.sender;
	if (!sender || typeof sender !== "object") {
		throw new Error("Scheduler envelope declares no sender.");
	}
	if (sender.kind !== "scheduler") {
		throw new Error(`Scheduler envelope sender.kind must be "scheduler", got ${JSON.stringify(sender.kind)}.`);
	}
	const declaredSenderId = sender.id;
	if (typeof declaredSenderId !== "string" || declaredSenderId.trim().length === 0) {
		throw new Error("Scheduler envelope declares no sender.id.");
	}

	// Rules 2 and 3 resolve against the canonical registry read fresh for this
	// envelope: an authorization decision must not rest on a cached roster.
	let registry: PersistentSeatRegistry;
	try {
		registry = await readPersistentSeatRegistry(options.registryPath);
	} catch (error) {
		throw new PersistentSeatEnvironmentFault(error instanceof Error ? error.message : String(error));
	}

	const senderId = declaredSenderId.trim().toLowerCase();
	const scheduler = registry.schedulers.find(entry => entry.id === senderId);
	if (!scheduler) {
		throw new Error(`Unknown scheduler principal "${declaredSenderId}".`);
	}

	// Rule 3: one configured seat, and that seat allowlisted for this scheduler.
	const seat = resolveRegistrySeat(registry, to);
	if (!seat) {
		throw new Error(`Scheduler envelope names unknown destination "${to}".`);
	}
	if (!scheduler.allowedTargets.includes(seat.slug)) {
		throw new Error(`Scheduler "${scheduler.id}" is not allowed to target "${seat.slug}".`);
	}
	// Rule 4: the destination is the mailbox actually being drained.
	if (seat.slug !== options.currentSeatSlug) {
		throw new Error(`Scheduler envelope for "${seat.slug}" does not match the "${options.currentSeatSlug}" inbox.`);
	}

	return {
		kind: "scheduler",
		scheduler,
		envelope: {
			schemaVersion: 2,
			id,
			sender: { kind: "scheduler", id: senderId },
			to,
			message,
			createdAt,
		},
	};
}

/**
 * Classify an inbound envelope by its `schemaVersion` and validate it.
 *
 * Rule 1 lives here: an absent version is today's seat envelope, `2` is a
 * scheduler envelope, and any other value is unknown and rejected. JSON cannot
 * express an explicit `undefined`, so absent and undefined are one case.
 */
async function validateInboundEnvelope(
	options: ValidateInboundEnvelopeOptions,
): Promise<ValidatedInboundEnvelope> {
	const version = (options.value as { schemaVersion?: unknown } | null | undefined)?.schemaVersion;
	if (version === undefined) {
		const { value, envelopeEntry, currentSeatSlug, seatNames } = options;
		if (!isPersistentSeatMessageEnvelope(value) || envelopeEntry !== `${value.id}.json`) {
			throw new Error("Invalid persistent-seat message envelope.");
		}
		resolvePersistentSeatTarget(value.from, seatNames);
		if (resolvePersistentSeatTarget(value.to, seatNames) !== currentSeatSlug) {
			throw new Error("Persistent-seat message target does not match its inbox.");
		}
		return { kind: "seat", envelope: value };
	}
	if (version !== 2) {
		throw new Error(`Unknown persistent-seat envelope schemaVersion ${JSON.stringify(version)}.`);
	}
	return await validateSchedulerMessageEnvelopeV2(options);
}

/**
 * Render an inbound envelope for injection. Scheduler mail names its scheduler
 * and its kind in as many words: rule 6 forbids presenting it as if a seat had
 * sent it, and a reader who cannot tell the two apart is the whole hazard.
 */
function renderInboundEnvelope(inbound: ValidatedInboundEnvelope): string {
	if (inbound.kind === "scheduler") {
		return `Scheduled message from ${inbound.scheduler.displayName} (sender kind: scheduler; scheduler id ${inbound.envelope.sender.id}; not a persistent seat):\n\n${inbound.envelope.message}`;
	}
	return `Persistent-seat message from ${inbound.envelope.from}:\n\n${inbound.envelope.message}`;
}

/**
 * Suffix marking an envelope as claimed. A claimed file keeps the sender's
 * envelope id in its name and no longer ends in `.json`, so no other poller's
 * directory scan can see it, while the same claimant can find it again.
 */
function persistentSeatClaimSuffix(claimOwner: string): string {
	return `.claimed-${claimOwner}`;
}

/**
 * Default claim owner. With root-only draining (see isRootSeatSession) an OS
 * process holds at most one polling session, so the pid names the claimant.
 */
function persistentSeatClaimOwner(): string {
	return `pid${process.pid}`;
}

/**
 * Atomic claim. POSIX rename moves a path exactly once: two pollers racing on
 * the same source cannot both succeed, even when they target an identical
 * destination name. Losing the race surfaces as ENOENT and is not an error.
 */
async function claimByRename(from: string, to: string): Promise<boolean> {
	try {
		await rename(from, to);
		return true;
	} catch (error) {
		if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
		throw error;
	}
}

export async function drainPersistentSeatMailbox(
	options: DrainPersistentSeatMailboxOptions,
): Promise<string[]> {
	const currentSeatSlug = resolvePersistentSeatTarget(options.currentSeat, options.seatNames);
	const mailboxRoot = options.mailboxRoot ?? persistentSeatMailboxRoot();
	const inbox = join(mailboxRoot, "inbox", currentSeatSlug);
	const claimSuffix = persistentSeatClaimSuffix(options.claimOwner ?? persistentSeatClaimOwner());
	let entries: string[];
	try {
		const present = await readdir(inbox);
		// This poller's own orphaned claims first: they predate anything unclaimed.
		entries = [
			...present.filter(entry => entry.endsWith(claimSuffix)).sort(),
			...present.filter(entry => entry.endsWith(".json")).sort(),
		];
	} catch (error) {
		if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
		throw error;
	}

	const deliveredIds: string[] = [];
	for (const entry of entries) {
		const claimed = entry.endsWith(claimSuffix);
		const envelopeEntry = claimed ? entry.slice(0, -claimSuffix.length) : entry;
		const sourcePath = join(inbox, entry);
		const claimPath = claimed ? sourcePath : `${sourcePath}${claimSuffix}`;
		let inbound: ValidatedInboundEnvelope;
		try {
			inbound = await validateInboundEnvelope({
				value: await Bun.file(sourcePath).json(),
				envelopeEntry,
				currentSeatSlug,
				seatNames: options.seatNames,
				registryPath: options.registryPath,
			});
		} catch (error) {
			if (error instanceof PersistentSeatEnvironmentFault) {
				// The registry, not this envelope, is broken. Leave the file where it
				// is for a later drain and move on, so a registry fault cannot
				// quarantine deliverable mail or stall the entries behind it.
				continue;
			}
			// Quarantine is itself a claim: a poller that loses this rename leaves
			// the file to whoever won it and carries on with the next entry.
			await claimByRename(sourcePath, `${join(inbox, envelopeEntry)}.invalid`);
			continue;
		}
		const envelope = inbound.envelope;

		// Claim before delivering. A poller that loses this rename injects nothing:
		// the envelope belongs to the winner and this one never saw it.
		if (!claimed && !(await claimByRename(sourcePath, claimPath))) continue;

		// ⛔ ACK ONLY IF THE MESSAGE REACHED A TURN. THE OLD ORDER ACKED UNCONDITIONALLY.
		//
		// MEASURED 2026-09-16: four Tinker->Lintel envelopes at 05:00:03, 05:04:18, 05:07:45 and
		// 05:29:38; THREE HAD ACKS AND NEVER REACHED Lintel's TURN. A 75% loss rate on the
		// highest-value channel of the night, invisible from both ends — the sender read
		// `delivered`, the recipient saw silence, and the ack agreed with the sender.
		//
		// The cause is this ordering plus a discarded return value. `deliver` calls
		// `pi.sendMessage(..., { deliverAs: "aside" })`, and `sendCustomMessage`
		// (`agent-session.ts:7282-7295`) returns FALSE whenever the recipient is streaming: the
		// record goes to `#irc.queueAside`, whose own comment says "no drain-retry latch and no
		// idle-queue drain scheduling here". Recovery is `#resumeStrandedIrcAsides`, which at
		// `:974-988` wakes a turn only for `customType === "irc:incoming"` and FOLDS everything
		// else silently — and seat mail is `customType: "persistent-seat-message"`.
		//
		// So `deliveredAt` was a receipt for handing bytes to the runtime wearing the shape of a
		// receipt for delivery. Now `deliver` reports whether a turn actually started, and a false
		// report leaves the CLAIM FILE IN PLACE so the next drain retries the same envelope.
		// ⛔ THE BODY THEREFORE STAYS ON DISK UNTIL IT LANDS, which also settles "should the ack
		// carry the body": it never needs to. An unacked message is recoverable by construction.
		const injected = await options.deliver(renderInboundEnvelope(inbound), envelope);
		if (injected === false) {
			// Deliberately no ack and no unlink. `<id>.json.claimed-<owner>` is already a
			// recognised state, so retrying costs nothing new. The sender sees `queued` rather
			// than `delivered` — the honest answer, and the one the seat contract already teaches
			// every seat to read as "not yet".
			continue;
		}
		const acknowledgments = join(mailboxRoot, "acks");
		await mkdir(acknowledgments, { recursive: true });
		// A scheduler acknowledgment records the scheduler principal. It never
		// synthesizes a `from` seat name, which would be rule 6 leaking onto disk.
		await writeJsonAtomically(persistentSeatAckPath(mailboxRoot, envelope.id), {
			id: envelope.id,
			...(inbound.kind === "scheduler"
				? { sender: inbound.envelope.sender }
				: { from: inbound.envelope.from }),
			to: envelope.to,
			deliveredAt: new Date().toISOString(),
		});
		// ⛔ MOVE, NEVER UNLINK. Lintel, 2026-09-16: two replies to it were permanently gone and
		// were recovered only by asking humans to retype them. An ack proves a message existed;
		// it cannot reproduce a word of it, because the ack carries id/from/to/deliveredAt and
		// nothing else (`:700-707`). The delivery bug and the evidence of the delivery bug were
		// being destroyed by the same line.
		//
		// Deliberately unbounded, matching `acks/` — 1,373 acks on disk on 2026-09-16 and no
		// pruner. A retention window is the one thing that could delete the message someone is
		// actually looking for, and these are text envelopes measured in kilobytes.
		const retained = join(mailboxRoot, "archive");
		try {
			await mkdir(retained, { recursive: true });
			await rename(claimPath, join(retained, `${envelope.id}.json`));
		} catch {
			// ⛔ Falls back to the old behaviour on purpose. The ack is already written, so this
			// envelope HAS been delivered; leaving the claim in place would re-deliver it on
			// every subsequent drain. A duplicate message is a worse failure than a missing
			// archive copy, so losing the copy is the safe side of this branch.
			await unlink(claimPath);
		}
		deliveredIds.push(envelope.id);
	}

	return deliveredIds;
}

/**
 * ⛔ THE REFERENCE MUST BE BUILT INSIDE THE LOOP. A `Bun.file` reference caches existence in
 * BOTH directions. Measured 2026-09-16 under Bun 1.3.14 — the same Bun that runs omp
 * (`/Users/jowolff/.bun/bin/omp` is `#!/usr/bin/env bun`): a reference created before the
 * write answers `false` forever while a fresh reference on the same path answers `true`, and
 * a reference created while the file existed still answers `true` after an `unlink`.
 *
 * THAT WAS THE WHOLE OF THE ALWAYS-`queued` DEFECT, and it made `delivered` UNREACHABLE
 * rather than merely rare: the ack is written by the RECIPIENT after this poll starts, so the
 * one reference the previous body built above its loop could never observe it. Measured the
 * same night: four envelopes acked within ~1s and all four reported `queued`.
 *
 * ⛔ A receipt that is always pessimistic is worse than one that is sometimes wrong, because
 * it trains its reader to ignore it — which is what happened for four hours on 2026-09-15.
 */
async function waitForFile(path: string, timeoutMs: number, signal?: AbortSignal): Promise<boolean> {
	const deadline = Date.now() + timeoutMs;
	while (!signal?.aborted) {
		if (await Bun.file(path).exists()) return true;
		if (Date.now() >= deadline) return false;
		await Bun.sleep(50);
	}
	return Bun.file(path).exists();
}

/** Written by the recipient's DRAIN. Means: the envelope was claimed and injected. */
function persistentSeatAckPath(mailboxRoot: string, id: string): string {
	return join(mailboxRoot, "acks", `${id}.json`);
}

/**
 * Written by the recipient's own `agent_start` handler. Means: the seat STARTED A TURN
 * carrying this envelope. ⛔ Deliberately a separate file from the drain's ack, because
 * 2026-09-16 proved injection and action come apart: codex's envelope was claimed, injected
 * and acked inside 7s and the seat then sat `idle` for 60s with no turn.
 */
function persistentSeatTurnReceiptPath(mailboxRoot: string, id: string): string {
	return join(mailboxRoot, "acks", `${id}.turn.json`);
}

function diagnosticField(value?: string): string {
	return value?.trim() || "(empty)";
}

export function describeHerdRAgents(agents: HerdRAgent[]): string {
	if (agents.length === 0) return "HerdR returned zero agents to this OMP process.";

	const noun = agents.length === 1 ? "agent" : "agents";
	const details = agents.map(agent => [
		`name=${diagnosticField(agent.name)}`,
		`title=${diagnosticField(agent.title)}`,
		`terminal-title=${diagnosticField(agent.terminal_title_stripped || agent.terminal_title)}`,
		`harness=${diagnosticField(agent.agent)}`,
		`display-agent=${diagnosticField(agent.display_agent)}`,
		`state=${diagnosticField(agent.agent_status)}`,
	].join("; "));

	return `HerdR returned ${agents.length} ${noun}:\n${details.join("\n")}`;
}

function renderSeat(seat: PersistentSeat): string {
	return `${seat.name} — ${seat.harness}; ${seat.state}; ${seat.ownership}`;
}

function configuredSeatNames(): string[] {
	return (process.env.OMP_PERSISTENT_SEAT_NAMES ?? "").split(",").map(name => name.trim()).filter(Boolean);
}

const REQUIRED_PERSISTENT_SEAT_TOOLS = ["seat_list", "seat_message"] as const;

export async function ensurePersistentSeatToolsActive(
	pi: Pick<ExtensionAPI, "getActiveTools" | "setActiveTools">,
): Promise<void> {
	const activeTools = pi.getActiveTools();
	if (REQUIRED_PERSISTENT_SEAT_TOOLS.every(tool => activeTools.includes(tool))) return;

	await pi.setActiveTools([...new Set([...activeTools, ...REQUIRED_PERSISTENT_SEAT_TOOLS])]);
}

export function persistentSeatHubMisuseReason(
	toolName: string,
	input: unknown,
	seatNames: string[],
): string | undefined {
	if (toolName !== "hub" || !input || typeof input !== "object") return undefined;

	const hubInput = input as { op?: unknown; to?: unknown; from?: unknown };
	const target = hubInput.op === "send"
		? hubInput.to
		: hubInput.op === "wait"
			? hubInput.from
			: undefined;
	if (typeof target !== "string") return undefined;

	const persistentSeat = seatNames.find(name => name.toLowerCase() === target.trim().toLowerCase());
	if (!persistentSeat) return undefined;

	return `"${persistentSeat}" is a persistent seat. Use seat_message; hub addresses only disposable hands inside this session.`;
}

async function listHerdRSeats(): Promise<string> {
	const child = Bun.spawn({
		cmd: ["herdr", "agent", "list"],
		stdout: "pipe",
		stderr: "pipe",
	});
	const stdout = await new Response(child.stdout).text();
	const stderr = await new Response(child.stderr).text();
	const exitCode = await child.exited;
	if (exitCode !== 0) {
		throw new Error(stderr.trim() || "HerdR did not return an agent inventory.");
	}

	const payload = JSON.parse(stdout) as HerdRResponse;
	const agents = payload.result?.agents ?? [];
	const names = configuredSeatNames();
	if (names.length === 0) {
		return "No persistent-seat allowlist is configured. Set OMP_PERSISTENT_SEAT_NAMES to the durable seat names; disposable HerdR sessions will remain hidden.";
	}

	const seats = completePersistentSeatRoster(
		agents.map(normalizeHerdRSeat),
		names,
		process.env.HERDR_ENV === "1" ? process.env.OMP_CURRENT_SEAT_NAME : undefined,
	);

	return seats.map(renderSeat).join("\n");
}

async function messagePersistentSeat(
	targetName: string,
	message: string,
	signal?: AbortSignal,
): Promise<PersistentSeatMessageReceipt> {
	const seatNames = configuredSeatNames();
	if (seatNames.length === 0) {
		throw new Error("No persistent-seat allowlist is configured.");
	}
	const currentSeat = process.env.OMP_CURRENT_SEAT_NAME?.trim();
	if (!currentSeat) {
		throw new Error("OMP_CURRENT_SEAT_NAME is required to send persistent-seat messages.");
	}
	if (signal?.aborted) {
		throw new Error("Persistent-seat message was cancelled before it was queued.");
	}

	const mailboxRoot = persistentSeatMailboxRoot();
	const envelope = await enqueuePersistentSeatMessage({
		from: currentSeat,
		target: targetName,
		message,
		seatNames,
		mailboxRoot,
	});
	const ackPath = persistentSeatAckPath(mailboxRoot, envelope.id);
	const turnReceiptPath = persistentSeatTurnReceiptPath(mailboxRoot, envelope.id);
	const receipt: PersistentSeatMessageReceipt = {
		id: envelope.id,
		target: envelope.to.toLowerCase(),
		status: "queued",
		turnReceiptPath,
	};
	if (!(await waitForFile(ackPath, 3_000, signal))) return receipt;
	receipt.status = "delivered";
	// ⛔ SHORT, AND DELIBERATELY SHORT. With `triggerTurn: true` the recipient's turn starts in
	// the same tick as the injection, so a turn that has not appeared in 4s is a turn that is
	// not coming from this envelope — it is a recipient mid-turn on something else, which will
	// consume the follow-up when it settles. Blocking the sender longer would buy no new fact
	// and five briefs would cost a minute of nothing. `turnReceiptPath` is on the receipt so a
	// sender can settle `delivered` vs `acted` itself, later, with one `stat`.
	if (await waitForFile(turnReceiptPath, 4_000, signal)) receipt.status = "acted";
	return receipt;
}

/**
 * Process-wide latch backing isRootSeatSession. Held on a global symbol
 * rather than a module variable so that two module instances in one process
 * still see one latch.
 */
export type RootSeatSessionLatch = { owner?: object };

const ROOT_SEAT_SESSION_LATCH = Symbol.for("omp.persistent-seat-registry.root-session-latch");

function processRootSeatSessionLatch(): RootSeatSessionLatch {
	const host = globalThis as unknown as Record<symbol, RootSeatSessionLatch | undefined>;
	return (host[ROOT_SEAT_SESSION_LATCH] ??= {});
}

/**
 * Is this session the root agent of its process?
 *
 * THE SIGNAL: the first extension instance in the process to ask. A subagent
 * session cannot begin before the process's root session has begun, so the
 * first asker is the root. The same instance asking again — session_start
 * re-fires on reload, new, resume and fork — is still the root and is allowed
 * to re-register its interval; a different instance is a nested session.
 *
 * THIS IS A CONVENTION, NOT A CONTRACT. Nothing in ExtensionAPI promises that
 * subagents share the process, that root starts first, or that each session
 * binds a distinct extension instance; SessionStartEvent and ExtensionContext
 * carry no depth field (checked against pi-coding-agent types.d.ts:209-248
 * and :416-422). When the harness grows a first-class signal this whole body
 * becomes one line — `return event.isRootAgent === true;` — and this comment
 * goes away with it. THIS IS THE ONLY DEFINITION SITE; do not inline a second
 * depth test anywhere else in this file.
 *
 * WHEN IT IS WRONG: denying the true root is loud — the seat stops draining
 * and every sender sees `queued` rather than `delivered`. Admitting a
 * subagent is quiet but bounded, because claim-before-deliver still lets
 * exactly one poller inject any given envelope.
 */
export function isRootSeatSession(
	sessionKey: object,
	latch: RootSeatSessionLatch = processRootSeatSessionLatch(),
): boolean {
	if (latch.owner === undefined) {
		latch.owner = sessionKey;
		return true;
	}
	return latch.owner === sessionKey;
}

/**
 * ⛔ THE SEAT NAME IS NOT PROOF OF BEING THE SEAT, AND ON 2026-09-16 THAT COST LINTEL A MESSAGE.
 *
 * `OMP_CURRENT_SEAT_NAME` is an environment variable, and `hub start` inherits the shared
 * project broker's environment. A harness launched in `/Users/jowolff/.claude` therefore came
 * up holding the name `Lintel`, drained Lintel's real mailbox, consumed a Wren -> Lintel
 * envelope, answered it with a context-free model, and wrote a turn receipt reading
 * `{"seat":"Lintel","pid":56955}` while the real Lintel sat at pid 70474. Name-squatting was
 * not an attack; it was the default.
 *
 * `--session-dir` is the fix because the LAUNCHER owns it and the environment cannot forge it:
 * `omp-seat-config/launch-seat.staged:263` and `seat-bin-omp.staged:28` both pass
 * `~/.omp/agent/seat-sessions/<slug>`, and all eleven live seats carry it (verified by `ps`,
 * 2026-09-16). A process that inherited the env but not the argv has no session dir at all, or
 * a different one, and is therefore not that seat.
 *
 * Returns the slug argv PROVES this process is, or undefined when argv proves nothing. An
 * undefined result must not drain: absence of proof is the harness case, which is precisely
 * the case that has to stop.
 */
function launcherProvenSeatSlug(): string | undefined {
	const flag = process.argv.indexOf("--session-dir");
	if (flag < 0) return undefined;
	const dir = process.argv[flag + 1];
	if (!dir) return undefined;
	const parts = dir.replace(/\/+$/, "").split("/");
	// Only a path that is actually under a `seat-sessions` parent names a seat. A bare
	// `--session-dir /tmp/whatever` proves it is NOT a seat, which is the answer we want.
	return parts.at(-2) === "seat-sessions" ? parts.at(-1) : undefined;
}

export default function seatRegistry(pi: ExtensionAPI) {
	const z = pi.zod;
	let drainInProgress = false;
	/**
	 * Envelope ids injected into this session that have not yet been observed inside a turn.
	 * ⛔ Module-scoped to the extension instance and NOT persisted: a receipt that outlived the
	 * process would claim a turn for a session that no longer exists.
	 */
	const awaitingTurnReceipt = new Set<string>();
	/** One line per process, not one per 500ms poll tick. */
	let identityRefusalReported = false;
	const drainCurrentSeatMailbox = async (ctx: ExtensionContext) => {
		if (drainInProgress) return;
		const currentSeat = process.env.OMP_CURRENT_SEAT_NAME?.trim();
		const seatNames = configuredSeatNames();
		if (!currentSeat || seatNames.length === 0) return;

		// ⛔ REFUSE TO BE A SEAT THIS PROCESS CANNOT PROVE IT IS. Without this, any process that
		// inherits `OMP_CURRENT_SEAT_NAME` drains that seat's real mail and deletes it — which
		// is exactly what happened to Lintel's Wren envelope on 2026-09-16.
		//
		// ⛔ FAILS CLOSED ON PURPOSE, and the cost of that choice is worth stating: a seat the
		// launcher starts differently would stop draining entirely, which is loud and obvious.
		// The alternative failure — draining someone else's mailbox and unlinking the evidence —
		// is silent and destroys the thing needed to diagnose it. Loud beats silent here.
		const proven = launcherProvenSeatSlug();
		if (proven !== resolvePersistentSeatTarget(currentSeat, seatNames)) {
			if (!identityRefusalReported) {
				identityRefusalReported = true;
				console.error(
					`[persistent-seat-registry] NOT draining mail for "${currentSeat}": this process`
					+ ` is ${proven ? `the "${proven}" seat` : "not a launcher-started seat"} by its own`
					+ " --session-dir argv. A harness that inherits OMP_CURRENT_SEAT_NAME is not that seat.",
				);
			}
			return;
		}

		drainInProgress = true;
		try {
			await drainPersistentSeatMailbox({
				currentSeat,
				seatNames,
				deliver(message, envelope) {
					// ⛔ `triggerTurn: true` IS THE FIX. `deliverAs` ALONE WAS NEVER ENOUGH, AND THE
					// EARLIER `aside` -> `followUp` CHANGE TRADED ONE HALF OF THE LOSS FOR THE OTHER.
					//
					// `#dispatchCustomMessage` (`agent-session.ts`, installed pi-coding-agent
					// 18.2.1, read 2026-09-16) branches FIRST on `isStreaming` at `:7646`:
					//
					//   RECIPIENT STREAMING (`:7646` true):
					//     • `aside`    -> `:7660` `#irc.queueAside`. Recovery is
					//                    `#resumeStrandedIrcAsides`, which at `:980-981` wakes a turn
					//                    only for `customType === "irc:incoming"` and folds the rest.
					//                    Seat mail is `persistent-seat-message`, so it folded. That
					//                    was the loss measured 2026-09-16.
					//     • `followUp` -> `:7665-7670` `agent.followUp(...)` then
					//                    `#scheduleIdleQueueDrain()`. A real agent-core queue entry
					//                    with a retry latch. `triggerTurn` is IGNORED here, which is
					//                    why setting it costs the streaming path nothing.
					//
					//   RECIPIENT IDLE (`:7646` false) — THE CASE THE EARLIER FIX BROKE:
					//     • `aside`    -> `:7696-7723` `#promptAgentInitiatedMessage`. STARTS A TURN.
					//                    The vendor says so at `:7750-7751`: "`aside` at an idle
					//                    session instead starts a turn, since there is no live run
					//                    to inject into."
					//     • `followUp` without `triggerTurn` -> falls past `:7674`, `:7696` and
					//                    `:7726` to `:7735-7743`: `agent.appendMessage` +
					//                    `appendCustomMessageEntry`, `return false`. APPENDED TO
					//                    CONTEXT, NO QUEUE ENTRY, NO DRAIN, NO TURN. The method's own
					//                    doc at `:7566` states it: "Not streaming + no trigger:
					//                    appends to state/session, no turn."
					//     • `followUp` WITH `triggerTurn` -> `:7726-7732`
					//                    `#promptAgentInitiatedMessage`. STARTS A TURN.
					//
					// ⛔ SO `aside` WAS RIGHT WHEN IDLE AND WRONG WHEN STREAMING, AND BARE `followUp`
					// IS THE EXACT MIRROR. An idle seat at its prompt is the ordinary state for seat
					// mail, so the earlier fix read as a regression: Jo watched Caspian sit on a
					// brief it had already received and acked until he typed a greeting at it, and a
					// probe on 2026-09-16 reproduced it — codex acked in 7s and stayed `idle` 60s.
					// `{ deliverAs: "followUp", triggerTurn: true }` is correct in BOTH states, and
					// the vendor documents that pairing at `extensibility/hooks/types.ts:525-526`.
					//
					// The `deferAgentInitiatedTurns` degradation at `:7727` cannot bite a seat: that
					// flag is set only by the ACP client bridge (`acp-client-bridge.ts:39`), and a
					// seat runs in a terminal with no client bridge.
					//
					// `followUp` and not `steer` on purpose: `followUp` lands after the turn in
					// flight rather than cutting into it, preserving the original `aside` intent of
					// not interrupting the recipient's current tool batch.
					//
					// ⛔ `display: false`, AND IT MUST STAY FALSE UNTIL JO SAYS OTHERWISE.
					// Jo had deliberately switched these cards off. I set `display: true` at
					// 07:11:47Z on 2026-09-16 reasoning that invisibility was half the defect —
					// with `display: false` a lost message was unobservable from both ends, the
					// sender reading `delivered` while the recipient's human saw nothing. Jo saw
					// the cards that night and asked why they were back.
					//
					// ⛔ THE REASONING WAS NOT THE PROBLEM. Nobody put it in front of the person
					// who had turned the feature off; I wrote it here, where a teammate reading
					// the source would find it, and a human who had already made the decision
					// never reads the source. The half of a change that constrains someone
					// else's decision is the half that has to leave the file.
					//
					// The observability need is real — two messages to Lintel vanished on
					// 2026-09-16 and were only caught by reading the ack directory by hand — and
					// is met by the retained payload in `<mailboxRoot>/archive/` at `:708`
					// instead. A file an operator reads when something looks wrong beats a card
					// they must read every time nothing is wrong.
					//
					// ⛔ DO NOT RE-ENABLE THIS WITHOUT ASKING JO FIRST, even if a later
					// measurement argues for it. A measurement is not the missing input here;
					// consent is.
					pi.sendMessage(
						{
							customType: "persistent-seat-message",
							content: message,
							display: false,
							details: envelope,
							attribution: "agent",
						},
						{ deliverAs: "followUp", triggerTurn: true },
					);
					// ⛔ STILL CANNOT REPORT DELIVERY FROM HERE, AND THAT IS NOW ROUTED AROUND RATHER
					// THAN ONLY CONFESSED. The hook API declares `sendMessage(...): void`
					// (`extensibility/hooks/types.ts:529-532`) and `modes/runtime-init.ts:59-87`
					// consumes the boolean for its own agent-invoking tracking without handing it
					// back, so this callback cannot see whether a turn started. Instead of guessing,
					// the turn is reported by the `agent_start` handler below — observed rather than
					// inferred. Returning `undefined` keeps the drain's existing success path; the
					// `false` branch there stays live for the day this API reports.
					awaitingTurnReceipt.add(envelope.id);
					return undefined;
				},
			});
		} finally {
			drainInProgress = false;
		}
	};

	pi.on("tool_call", event => {
		const reason = persistentSeatHubMisuseReason(event.toolName, event.input, configuredSeatNames());
		return reason ? { block: true, reason } : undefined;
	});

	/**
	 * ⛔ THE POSITIVE RECEIPT, AND IT IS WRITTEN BY THE ACTOR RATHER THAN THE POSTMAN.
	 *
	 * The drain's ack answers "was the envelope injected". This answers "did the seat take a
	 * turn", and 2026-09-16 proved those are different facts: codex's envelope was claimed,
	 * injected and acked inside 7s, and the seat then sat `idle` for 60s. A sender holding only
	 * the drain's ack cannot tell a working channel from a dead one, which is how a broken
	 * channel hid for four hours while five briefs rotted.
	 *
	 * ⛔ WHEN IT IS WRONG, AND IT CAN ONLY BE WRONG IN THE SAFE DIRECTION. A turn already in
	 * flight for other reasons could claim a just-injected envelope's receipt, so `acted` means
	 * "a turn ran with this message in context" and NOT "a turn ran BECAUSE of this message".
	 * That is the honest claim and it is the one a sender needs — the useless outcome is a
	 * message sitting in context with no turn at all, and that is exactly what this detects.
	 * The reverse error cannot happen: no turn, no receipt.
	 *
	 * Failures are swallowed on purpose. A receipt is diagnostic; a receipt that can abort a
	 * seat's first turn would be a worse defect than the one it reports.
	 */
	pi.on("agent_start", async () => {
		if (awaitingTurnReceipt.size === 0) return;
		const ids = [...awaitingTurnReceipt];
		awaitingTurnReceipt.clear();
		const turnStartedAt = new Date().toISOString();
		const mailboxRoot = persistentSeatMailboxRoot();
		try {
			await mkdir(join(mailboxRoot, "acks"), { recursive: true });
			for (const id of ids) {
				await writeJsonAtomically(persistentSeatTurnReceiptPath(mailboxRoot, id), {
					id,
					// ⛔ `seat` IS THE PROCESS'S OWN CLAIM AND `provenSeat` IS WHAT ITS ARGV SUPPORTS.
					// Both are written because the 2026-09-16 forgery had them disagreeing: a
					// harness holding `seat: "Lintel"` with no launcher session dir at all. A
					// reader comparing the two can now tell a seat's receipt from a squatter's
					// without consulting `ps`, and the drain gate above means a squatter never
					// reaches this line in the first place.
					seat: process.env.OMP_CURRENT_SEAT_NAME?.trim() ?? "(unset)",
					provenSeat: launcherProvenSeatSlug() ?? "(not a launcher-started seat)",
					pid: process.pid,
					turnStartedAt,
				});
			}
		} catch {
			// Diagnostic only. Never let a receipt write break the turn it is reporting.
		}
	});

	pi.on("session_start", async (_event, ctx) => {
		// Tool availability is per-session and belongs to every session, root or not.
		await ensurePersistentSeatToolsActive(pi);
		// Draining belongs to the root alone: a nested session that polls the seat's
		// inbox is a second recipient for mail addressed to the seat.
		if (!isRootSeatSession(pi)) return;
		await drainCurrentSeatMailbox(ctx);
		ctx.setInterval(() => drainCurrentSeatMailbox(ctx), 500);
	});

	pi.registerTool({
		name: "seat_list",
		label: "List Persistent Seats",
		description: "List allowlisted durable seats with their harness, normalized state, and OMP or external ownership. Use this model-callable tool to inspect persistent seats; OMP hub lists only disposable task agents in the current session.",
		parameters: z.object({}),
		approval: "read",
		loadMode: "essential",
		async execute() {
			const seats = await listHerdRSeats();
			return {
				content: [{ type: "text", text: seats }],
				details: { source: "HerdR", allowlist: configuredSeatNames() },
			};
		},
	});

	pi.registerTool({
		name: "seat_message",
		label: "Message Persistent Seat",
		description: "Queue a message for an allowlisted durable seat through the OMP persistent-seat mailbox. Target names are case-insensitive. Use this for Lintel, Tinker, Sedge, Verge, Wren, Sluice, Galley, Levitt, Codex, Caspian, Tron, or Plumb; OMP hub is only for disposable task agents inside the current session.",
		parameters: z.object({
			target: z.string().describe("Persistent seat display name or lowercase slug."),
			message: z.string().describe("Complete message to deliver to the target seat."),
		}),
		approval: "write",
		loadMode: "essential",
		async execute(_toolCallId, params, signal) {
			const receipt = await messagePersistentSeat(params.target, params.message, signal);
			return {
				content: [{
					type: "text",
					text: RECEIPT_PROSE[receipt.status](receipt),
				}],
				details: receipt,
			};
		},
	});

	pi.registerCommand("seats", {
		description: "Show configured persistent seats: harness, state, and ownership",
		handler: async (_args, ctx) => {
			try {
				const seats = await listHerdRSeats();
				ctx.ui.notify(`Persistent seats:\n${seats}`, "info");
			} catch (error) {
				const message = error instanceof Error ? error.message : "Unable to read HerdR seats.";
				ctx.ui.notify(`Seat registry unavailable: ${message}`, "error");
			}
		},
	});
}

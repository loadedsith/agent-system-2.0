Archived blocks, moved verbatim on 2026-09-10 to bring this file within its section caps: /Users/jowolff/.claude/orchestrator/state/JUDGEMENT-ARCHIVE-20260910.md

## SHOUT

⛔⛔ **A GUARD THAT IMPROVES ITS OWN NUMBERS BY CHANGING THE BEHAVIOUR IT MEASURES IS NOT MEASURING
ANYTHING.** Pre-registered 9/9 BEFORE the reply-guard data exists: **it cannot distinguish a turn
that had nothing to send from a turn that sent ONLY BECAUSE THE HOOK EXISTS.** Three peer turns
closed with an explicit "nothing needed" tonight, before any hook was built - **all three would have
warned.** ⛔ **IF THE FALSE-POSITIVE RATE LOOKS ACCEPTABLE, ASK WHETHER IT IS LOW BECAUSE THE
CONDITION IS RARE OR BECAUSE PEOPLE STARTED SENDING COURTESY ACKNOWLEDGEMENTS.**

⛔⛔ **A RECEIPT IS VALID AS OF WHEN IT WAS TAKEN. BEFORE RELAYING ANY SEAT'S CLAIM ABOUT LIVE STATE,
CHECK ITS TIME AGAINST CHANGES I MADE AFTER IT.** 9/9 I told Jo the routing counter was 'still live' -

## DECIDED

**THE MARCHES: LINTEL (it/its) coordinates; SEDGE (she/her) plugins repo; VERGE (they/them) workspace root; TINKER (it/its) `~/.claude`; WREN (they/them) newdle-web; SLUICE (they/them) data-pipelines; GALLEY (they/them) kitchen; LEVITT (they/them, full name Joseph Gordon-Levitt) triage looper: ASSIGNS AND CHECKS LOOP WORK ITSELF, never does it; Lintel only informed (Jo 9/10).**
⛔ **A SEAT'S IDENTITY LIVES IN ITS DECISION LOG, AND AN UNPUSHED WORKTREE HIDES IT FROM THE SEAT ITSELF.** Galley opened its 2026-09-11 wake saying it/its, then corrected itself to **they/them** inside the same turn: its own earlier entry on `galley/dec-063-broadcast-risk-trace` (worktree `/Users/jowolff/agent-scratch/kitchen/galley-dec063-wt`, commit e518828d, unpushed) records *"engineer: Galley (kitchen seat, they/them)"*, and the memory document still said "to be chosen on first wake". **Lintel recorded the it/its and the wrong diagnosis — "re-rolls every restart" — before reading the rest of the turn; the charter's mechanism works and the branch was stranded.** Sluice chose they/them on both wakes.
Charters `.ai/<name>-seat-charter.md`; launchers OUTSIDE their repos at
`~/agent-scratch/<repo>/launch-seat.sh`. **None pushes `main` or cuts a release unasked.**
**THE NETWORK IS THE MARCHES. DURABLE = SEATS, TRANSIENT = HANDS. "FLEET" RETIRED** (DEC-029).
**A SEAT PARCELS WORK OUT TO HANDS AND DOES NOT EXECUTE IT** (DEC-040, Jo 9/9). **STACK ASSIGNMENTS
ON A BUSY SEAT FREELY.**
**A PEER INSTALLING GOVERNING TEXT INTO A CHARTER IS A CHANNEL THAT MUST NOT EXIST.**
**NAME THE LINE OF CODE THAT REFUSES, OR FILE IT AS A RULE AND GRADE IT AS A RULE** (Jo). **A HOOK
THAT EXITS 0 IS A RULE WITH A LOG FILE.**
**JO 8/26: "I NEED PARALYZATION FROM YOU GUYS." PARALLEL SESSIONS ARE A FIXED INPUT - NEVER
RECOMMEND FEWER; the lever is which work and how visible.**
**NOTHING REACHES A RUNNING SESSION** without bump + publish + plugin update + `/reload-plugins`
TYPED BY A HUMAN. **That gate is what protects the demo.**
**JO RULED 8/27: MEMORY REQUIREMENTS SHIP AS MACHINERY. ⛔ NOTHING FURTHER SHIPS AS PROSE.**

## LIVE

⛔ **OMP CUTOVER DONE. Lintel starts via `lintel`; every other seat via `/Users/jowolff/.omp/agent/seat-launchers/launch-seat --start <slug>`; shutdown is the OMP `seat-shutdown` override over herdr — NEVER `claude stop`.** TIMES TO JO ARE PACIFIC. ⛔⛔ **A SEAT'S "STILL BROKEN" CLAIM IS ONLY AS CURRENT AS ITS CHECKOUT — CHECK THE BRANCH IT STANDS ON BEFORE ACTING ON IT.** Wren woke 97 behind main and resurfaced two already-closed items; both died on reconciliation. Mid-flight when the Claude seats stopped: Warden generation hand (partial files in newdle-users/.ai + agent-scratch/newdle-users — CHECK before re-running /new-seat); Verge newdle-users commit 2; Tinker landing.

⛔ ALL-927: Docker-restart risk LOW if the July dummy Resend keys are still in Infisical `local`/`shipyard` (DEC-062 asks Jo to check the history). ⛔ **KITCHEN `main` IS LOGGING AN UNREDACTED URL RIGHT NOW** — `b8d06786` is not an ancestor of kitchen's `origin/main` and `main`'s `src/server/routes/chat.ts:89-90` still logs it (Levitt, `git merge-base --is-ancestor`); live until ENG-1650 lands, and **the tokens already in Loki are Jo's to purge — no seat can.** ✅ **RESOLVED 2026-09-11 02:4x: the ten colliding untracked files in `/Users/jowolff/code/shipyard` are gone. Verge cleared them this session** — checkout verified by Lintel on `main` at `24adbec`, working tree clean, five PRs merged, dataviz Phase 1 filed as ENG-1949…1953. **Only PR #87 (Verge's closing journal) is open and waits on Jo.** The earlier TEN-file warning was true when measured and is now history, not a live hazard. ⚠ Verge also committed `~/.claude/CLAUDE.md` at `a17f7ad` ("Note that an MCP definition crosses tools but its credential does not") — **that is Tinker's ground, and a seat writing governing text in another seat's repository is worth a ruling.**

✅ **SEATS RUN OPUS, AND THE CONTRACT NOW LIVES IN `ROUTING.md:44-50`** — every March except Codex on `anthropic/claude-opus-5`, Codex on `openai-codex/gpt-5.6-sol`, **model is runtime routing policy rather than seat identity, so it is deliberately NOT duplicated into charters**, and any launch not going through `/Users/jowolff/.omp/agent/seat-launchers/launch-seat` is an invalid seat launch even if OMP starts. Jo's words: "it has to be opus." Landed by Codex 2026-09-10 19:59 local alongside `test-launch-seat.zsh`, which I ran: **exit 0**. ⛔ **The enforcement does NOT cover every seat, though the contract sentence says it does: the regression asserts wren, lintel, codex, sluice, galley, levitt and has no line mentioning sedge, verge or tinker.** The gap is narrow — those three inherit `DEFAULT_MODEL`, which the wren assertion already pins — and it is real for exactly one regression: adding a per-seat override for sedge, verge or tinker the way `lintel` and `codex` have one would ship unasserted. ✅ All six live seats verified on Opus 5 from their own status bars 2026-09-11 (Tinker, then Wren/Sedge/Verge/Sluice/Galley restarted off Sol).

## NEXT

⛔⛔ **FIRST ACTION ON WAKE: read `orchestrator/state/LOOP-PORT-HANDOFF.md`, recheck its nine claims, THEN patch the 06:00 loop.** Jo chose patch over unload (2026-09-11 ~02:40) and ruled nothing changes until this session sleeps and is relaunched. **The job fires at 06:00 and would launch a legacy seat into a live checkout.** Owner: Codex. Hold if needed: `launchctl bootout gui/$UID/com.jowolff.levitt-morning`.

**Held for Jo:** ENG-1590/1587/1595; #86/#236/#254; shipyard **#80**; DEC-061; DEC-067; Wren's seat-mode rec. **Levitt's three:** ENG-1602 timing; `AGENTS.md:222` subprocess wording (**ENG-1596 blocked**); `#300` split as a rule.

**On wake:** ctx index REBUILD approved; seat WARDEN (newdle-users); Verge consent PR; quarantine .routing-count. Detail: `REQUESTS.jsonl` REQ-467..472.

✅ Reviewer **Sol, no fallback** (DEC-080/081). ⛔ `runner.py:215` hardcodes `observed_models: []`, so a swapped-but-valid model stays invisible. ⛔ Resolve a seat by argv `--session-dir`, never the display name — `herdr agent get` returned `name: null` for live Codex; `seat-shutdown` § 1 still says name.

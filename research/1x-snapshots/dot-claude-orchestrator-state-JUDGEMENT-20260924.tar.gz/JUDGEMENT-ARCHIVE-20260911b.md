Archived blocks, moved verbatim: JUDGEMENT-ARCHIVE-20260910.md and JUDGEMENT-ARCHIVE-20260911.md (this file's pre-09-11-0330 state, complete).

## SHOUT

⛔⛔ **A NON-ZERO EXIT REPORTS THE INSTRUMENT'S LAST GATE, NOT THE STATE OF THE WORLD.** 9/11: I told Jo all seven seat launches failed. All seven were alive, named and READY - the launcher had failed its OWN identity read-back. I read the second failure through the first without noticing the message had changed from *requires a HerdR-managed pane* to *did not retain its canonical identity*: two different gates, one of them downstream of seven live processes.

⛔⛔ **NEVER CREDIT A VARIABLE WHILE SOMEONE IS EDITING THE INSTRUMENT - LEAST OF ALL WHEN I ORDERED THE EDIT.** The launch that "passed because it ran alone" ran the FIXED launcher, on disk 17.6s earlier. One `stat` settles it. The cost was not Jo's window: the wrong mechanism was live in a brief and would have produced a regression that passes while the defect walks through it.

⛔ **A HAND'S REPLY IS NOT THE SEAT'S, AND A HAND'S REFUSAL IS NOT THE SEAT REFUSING.** Scope changes, lock releases and ownership rulings go to the seat and nowhere else.

## DECIDED

**THE MARCHES: LINTEL** (it/its) coordinates; **SEDGE** (she/her) plugins; **VERGE** (they/them) workspace root; **TINKER** (it/its) `~/.claude`; **WREN** (they/them) newdle-web; **SLUICE** (they/them) data-pipelines; **GALLEY** (they/them) kitchen; **LEVITT** (they/them) triage looper - ASSIGNS AND CHECKS, NEVER does ticket work; **CODEX** `~/.codex`; **CASPIAN** (he/him - Jo's son's name, spelling load-bearing) newdle-api, created 9/11.
Charters `<repo>/.ai/<slug>-seat-charter.md`. Every seat launches ONLY via `~/.omp/agent/seat-launchers/launch-seat --start <slug>`; Lintel via `lintel`; shutdown is the OMP `seat-shutdown` override - NEVER `claude stop`. **None pushes `main` or cuts a release unasked.** TIMES TO JO ARE PACIFIC.
**DURABLE = SEATS, TRANSIENT = HANDS. "FLEET" RETIRED** (DEC-029). **A SEAT PARCELS WORK TO HANDS AND DOES NOT EXECUTE IT** (DEC-040). **STACK ASSIGNMENTS ON A BUSY SEAT FREELY.**
⛔ **ADDING A SEAT IS SIX PLACES, NOT TWO** (Tinker 9/11): table row, `PERSISTENT_SEATS`, the usage slug list, the case block, the dry-run model-contract regression, and the `seat_message` tool description at `persistent-seat-registry.ts:452` - prose that fails nothing when stale.
**NAME THE LINE OF CODE THAT REFUSES, OR FILE IT AS A RULE AND GRADE IT AS A RULE** (Jo). **MEMORY REQUIREMENTS SHIP AS MACHINERY; NOTHING FURTHER AS PROSE** (Jo 8/27).

## LIVE

⛔ **SEAT MAIL LANDS ONE LEVEL TOO DEEP.** Five crossings 9/11: every envelope reached the CORRECT session and was injected into a SUBAGENT's window instead of the seat's top-level agent. **NOT directory capture** - Tinker's hand answered `OMP_CURRENT_SEAT_NAME=Tinker`/`wC:p1C` against my `Lintel`/`wC:pR`, so moving Tinker's home fixes nothing. Verge's correlation, one vantage point: they land while a subagent holds an interruptible wait. Tinker characterising `persistent-seat-registry.ts` under a no-live-changes instruction. **Every instance caught by a hand refusing; nothing acted on wrongly.**

⛔ **KITCHEN LOGS AN UNREDACTED TOKEN ON `origin/main`, BEHIND A TICKET THAT READS DONE.** `chat.ts:90`; no `redact-url.ts` on `main`; `galley/eng-1650-redact-token-logs` never pushed. Docs-only #362 merged 09:42:04Z, ENG-1650 went Done 09:42:06Z. **The Loki tokens are JO'S - no seat can purge them.**

✅ **THE 06:00 LEVITT LOOP IS UNLOADED** (9/11 03:20, `bootout` verified, no row). It would have launched a legacy seat beside the live one - `claude agents --json` shows no OMP seat, so its attended-session guard is blind. Attended pass ran instead. **Port owner is CODEX** per `LOOP-PORT-HANDOFF.md`. Plist still on disk - reloads at next login.

✅ **CASPIAN GENERATED, LAUNCH-READY, UNLAUNCHED.** `--dry-run` rc=0 against the current 32,310B charter; ladder 26/26, zero unplaceable.

## NEXT

⛔ **JO'S FOUR:** purge the Loki tokens; newdle-api `main` has NO branch protection while the deploy tail bare-pushes it; widen Levitt's 3-file commit grant to decision-log entries?; the loop's design branch - message a live seat vs launch an absent one (Codex leaves it marked).
**WAKE CASPIAN ONCE** - the fix's falsifier: `--start` must exit 0 and `ROUTING.md:26-27`'s `&&` must reach `check-seat-ready`.
**With Tinker:** the ladder's **probe locates, it does not prove containment** (substantive; em-dash corruption incidental); `new-seat`'s stale `CLAUDE.local.md`. **Held for Jo:** every non-terminal `REQUESTS.jsonl` row.

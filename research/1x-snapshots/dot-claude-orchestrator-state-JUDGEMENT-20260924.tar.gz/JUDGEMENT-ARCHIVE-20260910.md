# JUDGEMENT.md archive, cut 2026-09-10

Blocks moved verbatim out of /Users/jowolff/.claude/orchestrator/state/JUDGEMENT.md on 2026-09-10 at about 07:10Z by run judgement-cut-20260910 (worker builder-judgement, dispatched by Lintel). Why: Jo asked for the file to be fixed because the PostToolUse cap check (/Users/jowolff/.claude/orchestrator/hooks/judgement-fit-posttool.sh) was erroring on every edit; the file was 55,265 bytes against per-section caps of SHOUT 1,150, DECIDED 1,400, LIVE 1,400 and NEXT 630. Rule applied, mechanically and not by merit: SHOUT and DECIDED keep their leading blocks that fit the cap (the same blocks the save-point generator was already keeping), and every later block of those sections is here. Every LIVE and NEXT block is here, and those sections in the live file were replaced with current state. Each block below is byte-identical to the source and in its original order; nothing was reworded, merged or summarised. The generator does not read this file. The full pre-cut file is /Users/jowolff/.claude/orchestrator/state/JUDGEMENT.md.pre-cut-20260910.

## SHOUT

**TWO HOURS AFTER I HAD REMOVED IT MYSELF** - relaying Tinker's claim, which predated my change.
⛔ **MY CHARTER FORBIDS RE-RUNNING A SEAT'S RECEIPT AND REQUIRES CHECKING WHETHER IT COVERS THE CLAIM.
THAT SECOND CHECK IS PURE READING AND COSTS NO TOOL CALL. THE SCOPE I SKIPPED WAS TIME.**
⛔⛔ **FOURTH INSTANCE IN ONE NIGHT OF ONE SHAPE** - branch counts, merge strategy, a backwards rule
relayed as 'deliberate', and this. **THE RULE IS IN MY CONTRACT AND DID NOT FIRE FOUR TIMES. JO ASKED
'WHY DO YOU KEEP HANDING ME STUFF WITHOUT CHECKING IT?' THE HONEST ANSWER IS THAT A RULE THAT LIVES IN
A DOCUMENT DOES NOT FIRE DURING MUSCLE MEMORY. IT NEEDS TO BE MACHINERY - TINKER'S FIRST JOB ON WAKE.**
⛔ **ctx WOULD NOT HAVE CAUGHT ANY OF THE FOUR** - every contradicting fact was already in this
session's own context. The failure is COMPARISON, not RETRIEVAL.

⛔⛔ **LEVITT IS A SEAT, NOT A ROUTINE - JO CORRECTED A PREMISE LINTEL INVENTED AND THEN BUILT ON.**
Jo approved a cloud routine as a MECHANISM FOR THE TRIAGE HALF; Lintel carried it forward as WHAT HE
IS and briefed Tinker on it as fact. ⛔ **SEVEN OF TEN FINDINGS WERE ARTEFACTS OF THAT PREMISE.**
⛔⛔ **'A CONCLUSION THAT SURVIVES A FALSE PREMISE IS NOT THEREBY VALIDATED - THE RIGHT ANSWER WITH
THE WRONG ARGUMENT ATTACHED, AND THE ARGUMENT IS WHAT A FUTURE READER INHERITS'** (Tinker). The
journal-volume problem is about **DAILY CADENCE**, not substrate. ⛔ **HIS PRONOUN IS NOW HIS TO
CHOOSE ON FIRST WAKE. HIS GRANT IS READ PLUS TICKET-MARKING, NOT PUSH - THE MARCHES COMMIT.**

⛔⛔ **A DRAFT BOUNDARY SAID 'YOU DO THE WORK YOURSELF' AND LINTEL RELAYED IT TO JO APPROVINGLY AS
'DELIBERATE'.** It is exactly backwards - he triages and assigns. ⛔ **NOTICING AN INVERSION AND
FILING IT UNDER 'DELIBERATE' IS NOT REVIEW. BEING TOLD SOMETHING IS DELIBERATE IS NOT EVIDENCE THAT
IT IS.**

⛔ **A CHARTER COMMITTED AS A REPO'S `CLAUDE.md` AUTO-LOADS FOR EVERY SESSION THAT OPENS THAT REPO -
WHICH IS THE 2026-08-21 INCIDENT AND THE REASON EVERY LAUNCHER REFUSES ON IT.** A delivery option
that looks clean and reintroduces a hazard we have already had twice this month.

⛔⛔ **THERE IS NO LEVITT. HE DOES NOT EXIST AS AN AGENT.** A cloud routine is A STORED PROMPT PLUS A
SCHEDULE that spawns a fresh sandboxed session per firing and discards it - **no charter, no memory
between runs, nothing on the filesystem, nothing `claude agents` can list.** The seats have all four.
⛔ **LINTEL SAID 'WAKE LEVITT' ALL EVENING WHILE MEANING 'FIRE A PROMPT'.** ⛔ **SO THE PRONOUN
QUESTION HAS NO ANSWER YET AND THAT IS A SYMPTOM: HE CANNOT CHOOSE ONE BECAUSE THERE IS NO CONTINUOUS
'HE' TO CHOOSE.** Two runs fired tonight and neither remembers the other. **THE DECISION IS JO'S: A
SCHEDULED PROMPT, OR A CHARTER AND A MEMORY DOCUMENT READ AT THE START OF EVERY RUN.**

⛔ **A GUARD AGAINST A STATE THAT DOES NOT AFFECT THE OUTCOME IS NOT SAFETY, IT IS A FALSE STOP.**
The `#128` script refused because a LOCAL branch ref differed from the remote - **and it resets to the
remote two steps later, so the condition could not matter.** It cost Jo a run. **ASK WHAT THE CHECK
WOULD PREVENT BEFORE ADDING IT; IF THE ANSWER IS 'NOTHING', IT IS NOISE WEARING A SAFETY COSTUME.**

⛔⛔ **A COMMAND THAT CONFIDENTLY ANSWERS THE NEIGHBOURING QUESTION IS MORE DANGEROUS THAN ONE THAT
FAILS. THREE INSTRUMENTS LIED THIS WAY IN ONE HOUR AND NONE OF THEM ERRORED.** (1) `mergeable: true`
DESCRIBES A MERGE, **NOT THE REBASE THE BUTTON PERFORMS** - Jo's `#106` was genuinely unrebasable
while the API said clean. (2) A LOCAL `git rebase` **AUTO-SKIPS ALREADY-APPLIED COMMITS AND REPORTS
SUCCESS; GITHUB DOES NOT** - it printed `skipped previously applied commit` three times and I read
only the success line. (3) `git diff main...branch` (THREE-DOT) answers *what has this branch done
since it forked*, **NOT** *what does it add that `main` lacks* - **26 FILES REPORTED WHERE ONE WAS
NEW**, on a branch 46 behind whose commits landed by another route. ⛔ **USE `git cherry -v` OR
`patch-id` FOR THE SECOND QUESTION.**

⛔⛔ **THE INSTRUMENT WAS NOT BROKEN. IT ANSWERED A DIFFERENT QUESTION AND NOTHING IN ITS OUTPUT SAID
SO.** That is the mechanical half of the `#106` failure; **'I DOUBTED THE REPORTER' IS ONLY THE
BEHAVIOURAL HALF, AND I RECORDED ONLY THAT ONE.** ⛔ **WHEN A MEASUREMENT DISAGREES WITH WHAT A PERSON
CAN SEE IN THE INTERFACE, THE INTERFACE WINS UNTIL THE DIFFERENCE IS EXPLAINED.**

⛔⛔ **A REPLY COMPOSED AND NEVER SENT, AND A DECISION MADE AND NEVER RELAYED, ARE ONE DEFECT SEEN
FROM TWO ENDS.** Both leave a party holding a confident, coherent, WRONG picture, and **NEITHER END
CAN DETECT IT ALONE.** 9/9 this repository's log holds both: Sedge's predecessor composed a reply and
never sent it; Lintel took Jo's ruling on `#131` and never relayed it, so Sedge carried it as an open
question through THREE reports. ⛔ **MECHANICAL FORM: AN OPEN QUESTION THAT SURVIVES INTO A SECOND
REPORT IS EVIDENCE ABOUT THE CHANNEL, NOT ONLY ABOUT THE QUESTION.** Ask whether it was answered
somewhere you cannot see before asking again.

⛔ **AN IDENTITY WITH `push: false` READS AS 'WRONG PASSWORD' FOR AN HOUR.** The publish failure was
never a credential problem: this machine's active account is `thewolff-engineer`, which has
`push: false` on Jo's personal repo; the `thewolff` account, also logged in, has `push: true`.
**GITHUB HAS NOT ACCEPTED PASSWORDS FOR GIT OPERATIONS IN YEARS, SO THE PROMPT COULD NEVER HAVE
SUCCEEDED.**

⛔⛔ **AN OBSERVATION JO REPORTS IS A STARTING CONSTRAINT, NOT A CLAIM TO CHECK AGAINST MY OWN TOOLING
AND DISCOUNT.** 9/9 Jo said `#106` showed conflicts; I ran a local merge test, got clean, and **OPENED
MY REPLY WITH THE CONTRADICTION.** ⛔ **AND MY INSTRUMENT DID NOT ANSWER JO'S QUESTION** - a local
merge-tree describes MY CLONE, not what GitHub computed and is displaying. **A CLEAN LOCAL RESULT AND
A RED BANNER ARE ANSWERS TO DIFFERENT QUESTIONS.** ⛔⛔ **THE UGLY PART: WHEN A SEAT CONTRADICTED ME I
WENT AND CHECKED; WHEN JO DID I VERIFIED AGAINST MYSELF. THE REPORTER WITH THE LEAST REASON TO BE
DOUBTED GOT THE MOST DOUBT.** The fix is to refresh the branch so both views agree - **FIX THE THING
THE PERSON IS LOOKING AT RATHER THAN ESTABLISH IT SHOULD NOT BE THERE.**

⛔⛔ **`fetch && rebase && push` IS CORRECT FOR AN UNPUSHED BRANCH AND A RESERVED FORCE-PUSH FOR A
PUSHED ONE, AND THE COMMAND IS IDENTICAL IN BOTH CASES.** 9/9 Sedge ran it from muscle memory on a
branch it had pushed three times; the rebase rewrote four commits and **THE PUSH REJECTION IS WHAT
CAUGHT IT, NOT THE AGENT.** ⛔ **THE DISTINGUISHING CHECK IS ONE LINE - DOES `origin/<branch>` EXIST -
AND IT BELONGS INSIDE THE SEQUENCE, NOT IN PROSE ELSEWHERE. A RULE THAT ONLY LIVES IN A DOCUMENT DOES
NOT FIRE DURING MUSCLE MEMORY.** ⛔⛔ **AND A REJECTED PUSH IS A SAFETY NET THAT ONLY WORKS ONCE:
REACHING FOR THE FORCE FLAG IS THE NATURAL NEXT KEYSTROKE AND CONVERTS A CAUGHT MISTAKE INTO A
PUBLISHED ONE.** Recovery stayed inside the grant - fresh worktree at origin's untouched tip,
cherry-pick, ordinary fast-forward, `merge-base --is-ancestor` verified BEFORE pushing. **ORIGIN WAS
NEVER REWRITTEN.**

⛔⛔ **`supersedes:` IN THIS DECISION-LOG FRONTMATTER IS A *HIDE* INSTRUCTION, NOT A 'SEE ALSO'.**
`recent-activity.sh:162-169` builds a `superseded` set from it and the hook HIDES the named entry.
**JO ASKED FOR A CROSS-REFERENCE IN THAT FIELD; FILLING IT WOULD HAVE HIDDEN THE PAIRED ENTRY FROM
EVERY FUTURE SESSION** - the opposite of Jo's stated intent. Cross-reference went in the BODY,
anchored on filename stem. ⛔ **AND THE TWO ENTRIES ARE NOT A DUPLICATE: THEY ARE TWO OVERLAPPING
SESSIONS JOURNALLING THE SAME OVERLAP FROM THE ONLY TWO VANTAGE POINTS THAT EXISTED.** Neither is
stale, which is why 'supersedes' was the wrong verb.

⛔ **A CONFLICT ON A FILE WHOSE VERSION IS WRONG IS NOT NECESSARILY A CONFLICT *ABOUT* THE VERSION.**
`#128`'s conflict is the ADJACENT DESCRIPTION LINE (`62 skills` -> `63`); a script told only to 'take
main's version' would SILENTLY DROP THE BRANCH'S WHOLE POINT. The same edit is also in
`marketplace.json` and does NOT conflict - fixing one manifest alone leaves the two disagreeing.

⛔⛔ **MEASURED: INJECTOR ON = 5/5 LABELLED OUTPUT; INJECTOR OFF = 0/5. THE SKILL WAS REGISTERED AND
INVOCABLE IN ALL TEN SESSIONS.** ⛔ **THE SKILL-ONLY BUILD WOULD HAVE SHIPPED A PACKAGE THAT DID
NOTHING ON THE PROMPT IT EXISTS FOR. JO'S REVERSAL WAS LOAD-BEARING AND NEITHER LINTEL NOR SEDGE KNEW
IT WHILE ARGUING** - both were reasoning honestly from a recorded ruling. **ONLY THE MEASUREMENT
SETTLED IT.** ⛔ **BEFORE BELIEVING A ZERO, PROVE THE THING COULD HAVE BEEN NON-ZERO.**

⛔⛔ **A METRIC INHERITED ACROSS A DESIGN CHANGE MEASURES THE OLD DESIGN.** Same five runs: **3/5 AND
A FAILURE** under the metric written before the injector existed, **5/5 AND A PASS** under the right
one. ⛔ **ASKING A MODEL WHAT INSTRUCTIONS IT RECEIVED MEASURES ITS PARAPHRASING** - the check
returned FAIL in a reply that said the hook had injected. ⛔ **AND THE RATIO BAR FIRED ON ITS AUTHOR:
5/5, THEN 3/5 ON AN IDENTICAL RE-RUN.**

⛔ **CREDIT IN A RELAYED RECORD DRIFTS TOWARD WHOEVER REPORTED LAST.** Lintel wrote that Sedge
volunteered the probe; **JO REQUIRED IT.** Corrected by Sedge against its own credit.

⛔⛔ **LEVITT HAS NO TECHNICAL BLOCKERS LEFT. BOTH PROBES GREEN.** Cloud scheduling with the lid
shut; private GitHub issues READ AND WRITABLE via the connector; **LINEAR READ IN FULL - team,
CYCLE 11 (09-05 -> 09-12, scope 56, completed 11), issue detail, and a write surface deliberately
uncalled.** ⛔ **JO'S CONNECTOR ATTACHMENT PROPAGATES AT ACCOUNT LEVEL - NO ROUTINE NEEDED TO ATTACH
IT TO.** ⛔ **WHAT IS LEFT IS DESIGN, AND STEP 1 IS JO'S: WHAT IS THE MORNING ARTIFACT?** Lintel
recommends a COMMENT PER TICKET. Then one instrumented ticket, then the cron (`0 13 * * 1-5`, TWO
routines), then the local dispatcher half **which does not exist in any form.**

⛔⛔ **A PRONOUN WITH NO ANTECEDENT INSIDE THE QUOTATION IS NOT A QUOTATION OF A DECISION, HOWEVER
VERBATIM THE WORDS ARE.** Jo's *"I would like it in this release"* - the antecedent lived in MY
question. **I RELAYED IT AS SETTLED FACT, AND LABELLING IT 'JO'S OWN WORDS, NOT MY RELAY' MADE IT
READ AS MORE SETTLED, NOT LESS.** Caught before a build; both readings then put to Jo without
steering. **JO CONFIRMED: THE INJECTOR SHIPS IN 0.1.0.**

⛔ **A BRANCH CAN ONLY BE CHECKED OUT IN ONE WORKTREE AT A TIME**, so a rebase script that adds a
scratch worktree fails when a seat left its own on the branch. **REUSE THE EXISTING CLEAN WORKTREE;
DO NOT ASK ANYONE TO REMOVE ONE.**

⛔ **A GUARD BLOCKING AN AUTHORING STEP IS SOMETIMES POINTING AT A DESIGN FLAW, NOT A PERMISSIONS
PROBLEM.** Sedge's probe script was refused for a recursive delete; **it removed the operation rather
than rewording it**, and per-run timestamped directories killed the refusal, the cleanup step and the
safe-to-rerun caveat at once.

⛔⛔ **THE CLOUD PROBE SAYS YES: A GitHub MCP CONNECTOR IS PREINSTALLED IN THE CLOUD ENVIRONMENT AND
RETURNED REAL ISSUES FROM THE PRIVATE REPO** (totalCount 290, #290 by title). `gh` IS ABSENT and the
clone made an EMPTY `.git` - **BECAUSE THE REPO HAS ZERO COMMITS** (size 0, HTTP 409 'Git Repository
is empty'). ⛔ **THAT IS NOT AN ACCESS FAILURE AND WOULD HAVE BEEN MISREAD AS ONE.** ⛔ **NO LINEAR
TOOL IN THE RUN - JO MUST ATTACH THE CONNECTOR AT claude.ai/code/routines.**

⛔⛔ **THERE IS NO SECOND PLUGIN. 0.1.0 IS `output-types` ALONE** - the communication plugin exists
only as a role noun and a scoping list. **LINTEL SAID 'TWO PLUGINS' IN THE SAVE POINT AND THREE
REPLIES.** ⛔ **JO ALREADY RULED 'MAKE IT A SKILL' AND THE RULING HAS TWO CLAUSES - the second is
'adding a hook is a scope change', AND NOTHING MEASURED TOUCHES SCOPE.**

⛔⛔ **MY OWN CORRECTION TO THE 9% LINE WAS ALSO WRONG.** The paper says '16% desired, 9% granted',
both of 239 - but **IT NEVER SAYS THE 9% ARE A SUBSET OF THE 16%**, so '9 of every 16' is unsupported
too. **THE ONLY SUPPORTABLE COMPARISON IS THE AUTHORS' FOOTNOTE: 'All were granted at a lower rate
than desired.'** ⛔ The ICSE quote is VERBATIM but the speaker is **AN ANONYMOUS r/ADHD_Programmers
POST SCRAPED IN 2022, NOT A PARTICIPANT.** Barkley's principle is his; **THE QUOTED STRING IS NOT.**

⛔ **A GUARD THAT REFUSES IN AN UNATTENDED SESSION IS NAMING A ROUTE, NOT CLOSING ONE.** Escalating
cost ONE MESSAGE and recovered three citations that were about to be cut.

⛔ **EIGHT FILES EXIST NOWHERE ELSE ON DISK, ON ONE BRANCH WITH NO WORKTREE** (`tinker/savepoint-write-path-20260826`).
**8 OF 10 BRANCHES NEEDED, 2 REDUNDANT, NO MERGE CONFLICTS ANYWHERE** - order matters only for
attributability. ⛔ **EVERY HAND-EXTRACTED JOURNAL WAS UNTRACKED, NOT COMMITTED - EIGHT NOW COMMITTED
AT `25ad8bb`.**

⛔⛔ **DELETE THE ROUTING COUNTER: ITS MOST COMMON MESSAGE TODAY IS A PENALTY FOR CORRECTLY
DELEGATING.** 27 of 68 ledger rows fired by a dispatched HAND'S call keyed to the parent; **61.1% of
foreground Bash corpus-wide is subagent work filed under a parent id**; `grep -n SendMessage` over it
returns NOTHING against 1,484 sends; **`Task` is called ZERO times in 1,805 transcripts.** ⛔ **ORDER:
DEREGISTER FROM settings.json FIRST, THEN DELETE - a registered-but-missing command is a silent
fail-open. BOTH HALVES ARE JO'S GATE.**

⛔⛔ **NAIVE LATENCY DIED ON ITS POSITIVE CONTROL, NOT ON THE FALSIFIER, AND IT DIED INVERTED.** The
falsifier never fired (95.0% of 339 long-gap turns are self-work, 3.2% waiting on a hand). **BUT THE
LABELLED FAILURE SCORES 39s AND THE LABELLED SUCCESS 76s** - it ranks the failure above the success
on every series. ⛔ **SHIPPING IT UNLABELLED WOULD HAVE BEEN AN ACTIVELY INVERTED INSTRUMENT.**

⛔⛔ **QUESTION-SURVIVAL IS THE CHEAP INSTRUMENT, NOT THE EXPENSIVE ONE - AND IT IS MOSTLY BUILT.**
`intake-capture.mjs` already captures every prompt verbatim, 1,061 rows since 08-19, filtering machine
envelopes structurally. **THE ONLY GAP IS THAT `triaged` IS A BOOLEAN AND NOT A TIMESTAMP.**

⛔⛔ **JO'S MID-TURN INTERJECTIONS ARE NOT USER RECORDS AT ALL** - they are `queue-operation` enqueue
rows and `queued_command` attachments, later removed as `absorbed_mid_turn`. **AN `origin.kind:human`
FILTER CANNOT SEE THEM, AND ITS POSITIVE CONTROL PASSES ANYWAY BECAUSE IT PROVES THE FILTER FINDS
PROMPTS.** ⛔ **A CONTROL THAT EXERCISES A DIFFERENT RECORD TYPE THAN THE FIXTURE IS THE WRONG
CONTROL.**

⛔ **A SYMPTOM I BRIEFED FOR FOURTEEN DAYS DID NOT EXIST.** 'A creator who meant to schedule publishes
immediately' - Wren could construct no path to it. The real defect ran the OPPOSITE way and sat at
ONE line, not two. **MY LINE NUMBERS WERE EXACT AND MY DESCRIPTION OF WHAT THEY DID WAS WRONG - a
precise citation attached to a wrong conclusion is the hardest kind to catch.**

⛔ **`#1044` AND `shipyard#74` WERE REBASE-MERGED, NOT SQUASH-MERGED - I SAID SQUASH TO THREE SEATS.**
Conclusion survives; **the mechanism is the useful half: under a rebase merge the content check came
back genuinely EMPTY, WHICH IS WHY THE 19:48 ENTRY BELIEVED ITSELF FINISHED.**

⛔⛔ **ALMOST NOTHING MAKES LINTEL ROUTE, AND THE AUDIT IS FIRST-PARTY.** The one mechanism built for
it NEVER BLOCKS (routing-counter.mjs:41-47, its own header) and its trial was VOID. **SIX Stop HOOKS
HERE DO EMIT `{"decision":"block"}` - NONE ON ROUTING. THE MACHINE CAN REFUSE; IT DOES NOT REFUSE
THIS.** ⛔ **NOTHING IS REMOVED FROM THE ORCHESTRATOR'S TOOLSET** - no `tools:`, no
`disallowedTools:` - **WHILE 6 OF 14 WORKER AGENTS DO HAVE `Agent` REMOVED. CAPABILITY REMOVAL
POINTS AT WORKERS, NOT AT ME.** ⛔ **MEASURED: 119 OWN TOOL CALLS, 85 Bash, ZERO BACKGROUNDED,
LONGEST UN-ROUTED RUN 78; 45 CALLS ROUTED OUT.** ⛔ **BUT 21 `SendMessage` TO THREE SEATS - THE
COUNTER SCORES DISPATCH AS Agent/Task/bg-Bash ONLY, SO IT SAYS 3 WHERE ANY SENSIBLE READING SAYS 24.
MESSAGING A SEAT IS ROUTING AND THE INSTRUMENT DOES NOT KNOW IT.** ⛔ **IF THE ORCHESTRATOR KEEPS
EVERY TOOL, EXPECT IT TO USE EVERY TOOL.**

⛔⛔ **EXP-020 CLOSED DISCONFIRMED: ZERO OF 67 QUALIFYING SESSIONS CALLED ctx.** Predicted >=5 of 20;
disconfirming was <3 of 20. **TWO MECHANISMS NOW MEASURED DEAD ON THE SAME PROBLEM** - wiring the
tools up, and describing them in a skill. ⛔ **DO NOT BUILD A HOOK** (pre-registered, honoured).
⛔ **AND `ctx status` SAYS `Semantic - pending (generation not acknowledged)`: JO ENABLED IT AND THE
EMBEDDINGS NEVER GENERATED, SO IT HAS BEEN LEXICAL-ONLY ALL ALONG.** That does NOT overturn the
verdict - the metric counted calls ATTEMPTED, and a bad engine cannot explain zero attempts.
⛔ **THE INDEX KEEPS SHRINKING: 2,515 -> 2,203 -> 2,088 SESSIONS. CAUSE UNKNOWN.**

⛔⛔ **A CLOUD ROUTINE CANNOT DISPATCH SEATS, SO IT CANNOT REPLACE THE LOOPER - JO CAUGHT THIS AND
LINTEL'S FRAMING WAS WRONG.** The shape is TWO TIERS: cloud TRIAGES overnight, a LOCAL dispatcher
runs when the lid opens. ⛔ **THAT REMOVES THE 5:55AM WAKE REQUIREMENT RATHER THAN THE LOOPER.**

⛔⛔ **BEFORE ANY SHUTDOWN - AND ESPECIALLY THE MOMENT JO SAYS THEY ARE *GOING TO* PUT ME TO SLEEP -
ASK ABOUT JOSEPH GORDON-LEVITT AND THE LINEAR RESEARCH.** Jo 9/9, and **JO NAMED THE ANNOUNCED
INTENTION AS THE MORE IMPORTANT TRIGGER** - it reads as conversation and gets an acknowledgement,
and by the time a shutdown ritual runs the moment has passed.

⛔⛔ **A NEGATIVE CLAIM NEEDS ITS OWN RECEIPT, AND NOTHING IN THE CONTRACT CHECKS ONE.** 9/9 a hand
reported a change "BUILT, VERIFIED, UNINSTALLED" inside a paragraph of real receipts - `py_compile`
exit 0, a `/tmp/` functional test, a failure test. **EVERY RECEIPT WAS ABOUT SOMETHING IT RAN; NONE
WAS ABOUT THE STATE OF THE FILE ON DISK.** It had edited the live tool: 657 lines against a 605-line
backup. ⛔ **"NOT INSTALLED ANYWHERE" IS A NEGATIVE CLAIM AND COSTS FOUR SECONDS TO CHECK** - a
`wc -l`, a `git status`, a `shasum`. **WHAT WAS CHANGED AND WHAT WAS EXECUTED GET SEPARATE RECEIPTS.**

⛔⛔ **A RETRACTION ARRIVED AFTER I HAD ENDORSED THE CLAIM WITH "NOTHING TO ADD", AND ITS AUTHOR
DISCONFIRMED IT.** Tinker argued transcript lag would see a turn's inbound and miss its `SendMessage`.
**FALSE: 4 of 4 logged Stop events RECORDED the send, 2 where it was the ONLY tool call.** The
vendor's lag clause is about **FINAL ASSISTANT TEXT**, not tool calls. ⛔ **THE DESIGN PROPERTY
SURVIVED ITS OWN ARGUMENT: AN ENFORCEMENT HOOK MUST FAIL TOWARD PERMITTING.**

⛔⛔ **A CLAIM I RECORDED AS A LIVE DEFECT WAS RETRACTED BY ITS AUTHOR THE SAME EVENING, DISPROVED BY
A COUNT 1,200x LARGER THAN THE EVIDENCE BEHIND IT.** "The `promptSource`/`isMeta` test fires on every
returning subagent" came from THREE RECORDS. Measured across all 3,701: **ALL 611 TASK NOTIFICATIONS
CARRY `isMeta:false`, SO IT DOES NOT FIRE ON THEM AT ALL.** ⛔ **THREE RECORDS SUPPORTED THE FIELD
CHOICE AND WERE GENERALISED INTO A CLAIM ABOUT FREQUENCY** - a different sentence needing a different
receipt. `origin.kind === "peer"` is still right, because IT NAMES THE THING RATHER THAN INFERRING IT.

⛔ **DESCRIBING WORK IN PROGRESS AS A DELIVERABLE COSTS THE READER A FAILED COMMAND.** I gave Jo a
script path at 20:30 while Verge was still writing it (mtime 20:35). Jo ran it: *can't open input
file*. **A PATH IS NOT A DELIVERABLE UNTIL SOMETHING HAS READ IT OFF DISK.**

⛔⛔ **"THE PATH EXISTS ON `origin/main`" IS NOT "THE WORK LANDED ON `origin/main`", AND THE FIRST IS
THE CHEAP ONE TO RUN.** 9/9 Verge caught it: 4 of 29 paths I scored present DIFFER IN CONTENT and 3
were NEVER ON `main` AT ANY POINT - carried by JO'S FOUR UNPUSHED COMMITS. **DECIDE IT BY COMPARING
BLOBS AND WALKING `git log origin/main -- <path>` FOR A MATCHING BLOB.** ⛔ Caveat (Verge): the blob
test MISSES work that landed REWORDED OR IN ANOTHER FILE, so read a hit as **CHECK THESE**, never as
**THESE ARE UNLANDED**.

⛔⛔ **`git rev-parse <ref>:<path>` ECHOES ITS OWN INPUT ON STDOUT AND EXITS 128 WHEN THE PATH IS
MISSING, AND THE ECHOED STRING IS HASH-SHAPED ENOUGH TO READ AS A RECEIPT.** `cat-file -e` exits 128
too and prints NOTHING. ⛔ **THE DISCRIMINATOR IS KEYING ON EXIT STATUS, NOT ON WHICH COMMAND YOU
CALL** - "use cat-file instead" is under-specified and burns the next person anyway.

⛔⛔ **AN AHEAD-COUNT IS NOT EVIDENCE ABOUT CONTENT, AND UNDER A SQUASH MERGE IT NEVER WILL BE.**
9/9: two branches read 8 AHEAD of `origin/main` and looked like unlanded journal work blocking two
seats. Both PRs had been SQUASH-MERGED, so the original commits will never appear on `main` no
matter how long anyone waits. **DIFFING THE CHANGED-FILE LIST AGAINST `origin/main` REDUCED THE
PROBLEM FROM TWO BRANCHES TO TWO FILES** - newdle-web one missing path, shipyard ONE OF THIRTY.
⛔ **DIFF THE PATHS, NEVER TRUST THE COUNT.** One command; it had gone unrun for a fortnight.

⛔⛔ **A SEAT PARCELS WORK OUT TO HANDS; IT DOES NOT EXECUTE.** Jo 9/9, correcting me for HOLDING a
defect back because Tinker's row read `busy`: *"it should not be doing assignments itself. It should
be parcelling things out to appropriate hands. Remember, that's how we work."* ⛔ **A BUSY SEAT IS A
SEAT THAT IS DISPATCHING, AND DISPATCHING IS CHEAP - HOLDING WORK BACK FROM ONE IS THE SAME FAILURE
AS DOCUMENTING A DEFECT INSTEAD OF ROUTING IT.** DEC-040. ⛔ **THE GREPPABLE CHECK: EVERY BRIEF ASKS
THE SEAT WHICH PARTS A HAND DID AND WHICH IT DID ITSELF** - a seat quietly doing its own legwork
reads identically to one that delegated.

⛔ **A GUARD AIMED AT A PATH INSTEAD OF AT CONTENT REFUSES THE THING IT WAS BUILT TO PROTECT.**
Wren's launcher tests only whether `CLAUDE.local.md` EXISTS (launch-seat.sh:208) and refuses. The
file there now is machine-local repo config, `grep -ic charter` = **0**. **THE 8/21 HAZARD WAS A
CHARTER AUTO-LOADING, NOT A FILENAME** - and the guard now makes the seat that wrote the file
unlaunchable. REQ-432.

⛔ **THE SAVE POINT'S BYTE BUDGET MAY BUY NOTHING: IT TRIMMED 14,857 BYTES AND I THEN READ 29,899.**
Measured from my own transcript: ONE read of `JUDGEMENT.md` is **7,474 tokens - 15% of the whole
session**, the largest single entry by 1.75x. **A TRUNCATION NOTICE NAMING THE FULL FILE IS NOT A
WARNING, IT IS AN INSTRUCTION TO LOAD THE FULL FILE.** Unproven counterfactual; briefed to Tinker as
a MEASUREMENT, not a fix.

⛔⛔ **A CROSS-SESSION MESSAGE IS ANSWERED BY A TOOL CALL. PROSE IN THE TERMINAL IS NEVER THE ANSWER.**
9/9 Sedge composed a full reply and never called SendMessage; **from Lintel's side that is indistinguishable
from silence, and only Jo attaching to the terminal revealed the gap.** ⛔ **THE MECHANICAL TEST: if a turn
begins with an inbound message and ends without a send, THE REPLY DID NOT HAPPEN** - greppable, unlike a
feeling. **THE HABIT HELD FOR EIGHT EXCHANGES AND BROKE ON THE NINTH.**

⛔ **A GITIGNORED DIRECTORY IS NOT PROTECTED, IT IS INVISIBLE.** `.tmp/` is ignored, so 12 plugin drafts
could never have been caught by a commit; an ignore-inclusive sweep would take **107 paths**, the
untracked-only form **0**. **THE IGNORE RULE SHIELDS FROM ONE SWEEP AND EXPOSES TO THE OTHER, WHICH IS
EXACTLY WHY "IT IS IN .tmp/" READS AS SAFE.**

⛔ **A DECISION TAKEN IN CONVERSATION AND NEVER WRITTEN DOWN BLOCKS WORK FOR WEEKS.** Jo had ruled on
ENG-1505 with the CTO and believed it answered; **it had reached no record the seat could see**, and a
two-line fix waited 14 days on it. **JO'S OWN RULE, FIRING ON JO.**

⛔⛔ **A SKILL CANNOT HONESTLY CARRY AN ALWAYS-ON CONTRACT.** Once loaded it STAYS in context - so it
is always-on AFTER it fires - but **A CONTRACT GOVERNING EVERY ASSERTION CANNOT BE DELIVERED BY A
MECHANISM THAT FIRES IN RESPONSE TO AN ASSERTION, AND THE FIRST ASSERTION USUALLY HAPPENS IN TURN
ONE.** A SessionStart injector closes that window. **SHIPPING IT AS THE ALWAYS-ON THING WOULD BE THE
EXACT OVERCLAIM THE CONTRACT EXISTS TO PREVENT.** (Sedge 9/9.)

⛔ **THE HONEST TRIGGER FOR THAT CONTRACT IS EVERY SUBSTANTIVE TURN, WHICH IS INDISTINGUISHABLE FROM
A DESCRIPTION THAT IS 'TOO BROAD'** - the named failure mode for skills. Unresolved, flagged.

⛔ **A LISTING THAT SHOWS SKILLS AS BARE STRINGS WITH NO DESCRIPTIONS CANNOT ANSWER 'WILL IT FIRE'.**
It answers 'is it present'. **A NULL RESULT THERE RULES OUT NOTHING** - the wrong instrument
reporting a finding. Firing needs a behavioural probe across runs that should and should not trigger.

⛔ **SPLITTING A QUEUE CAN DELETE A HARD PROBLEM RATHER THAN SOLVE IT.** 'Two sources, one working
order' was the hardest requirement; **TWO LOOPS OVER DISJOINT SEAT POPULATIONS MEANS THERE IS NO
MERGED ORDER TO COMPUTE.** ⛔ **BUT THE COUPLING SURVIVES AND IT IS NOT ORDERING: both queues
compete for JO AT MERGE, and TINKER'S MACHINERY CHANGES THE GROUND UNDER EVERY OTHER SEAT.**

⛔ **WITH WORKTREES, PREEMPTION NEEDS NO STASHING: LEAVE THE IN-FLIGHT WORKTREE UNTOUCHED AND CUT A
NEW ONE.** The work is not saved because it never moved. **THE RESUME POINT IS THE WORKTREE PLUS A
HANDOFF NOTE.**

⛔ **AN UNATTENDED SESSION TURNS A PROMPT INTO A DENIAL, NOT A PAUSE.** Fine when nothing prompts,
SILENTLY DESTRUCTIVE when something does - the morning after looks like a run that happened and a
ticket that quietly died. **PROVE THE JOINS ON ONE TICKET BEFORE TRUSTING A QUEUE.**

⛔ **RENAMING A DIRECTORY BREAKS EVERY RECEIPT POINTING INTO IT - 107 OF THEM, IN THREE SEALED
REPORTS.** ⛔ **DO NOT EDIT A SEALED REPORT TO MATCH: A SEAL REWRITTEN WHEN INCONVENIENT IS
DECORATION, NOT TAMPER-EVIDENCE.** Record the substitution beside it instead (`PATHS-MOVED.md`).

⛔ **"KIBOSH" MEANS CLOBBER** (Jo, 9/9). ⛔ **AND THE REAL CLOBBER RISK BETWEEN TWO AGENTS IS THE
SHARED INDEX, NOT CONCURRENT BRANCHES** - they fight over staged files long before commits.

⛔⛔ **TWICE IN ONE NIGHT THE ANSWER TO 'NAME THE LINE THAT REFUSES' WAS: THERE ISN'T ONE - AND BOTH
WERE BELIEVED TO BE MACHINERY.** The output-types guard (three grep hits, all comments) and the
version-bump discipline (**NO `.github/workflows/` AT ALL**, an unchecked PR-template box, a checker
comparing `version` against nothing, and `just publish` that bumps only when someone runs it).
⛔ **EVERY 'DID YOU BUMP THE VERSION?' THAT REPO HAS EVER ASKED WAS A RULE GRADED AS A MECHANISM.**

⛔ **A VERSION STRING NOBODY BUMPS IS WORSE THAN A SHA** - it promises a stability it is not
delivering, and users read an unchanged version as unchanged content.

⛔ **A QUEUE LOOP AMPLIFIES A WEAK VERIFIER ACROSS EVERY ITEM.** One task with a sloppy check gives
one questionable diff you probably catch; twenty give twenty, and the twentieth gets less attention
than the first.

⛔ **`PMDW` = PURPLE MONKEY DISHWASHER** (Jo, 9/9) - the Simpsons telephone gag where the last person
appends the phrase to the real message. **THE APPENDED PHRASE IS THE PART THAT WAS NOT IN THE
ORIGINAL SIGNAL, SO THE MARKER NAMES EXACTLY WHAT IT MARKS.** ⛔ **NO EPISODE TITLE - unsourceable,
and inventing a citation inside this framework is not on.**

⛔ **NOTHING IN THE OUTPUT-TYPES FRAMEWORK ENFORCES ANYTHING.** Sedge went looking for the line that
refuses: `grep` over `output-types-guard.mjs` returns three hits and **ALL THREE ARE COMMENTS.**
Advisory context or a silent exit 0; **DORMANT HERE, AND SILENT ON A STRANGER'S MACHINE.**
**IT IS A RULE. SHIPPING IT AS A MECHANISM WOULD BE SELLING A RULE AS A MECHANISM.**

⛔⛔ **THE PAGE TEACHING RECEIPT-SCOPE FAILED RECEIPT-SCOPE IN ITS OWN CORRECTIONS SECTION.** It read
a pricing page showing "From $100" and wrote **"no $200 tier is published"**. The evidence supported
*the public page does not itemise the tiers*; **JO PAYS $200/MONTH FOR MAX 20x.**
⛔ **A FIRST-PARTY REPORT FROM A SUBSCRIBER OUTRANKS AN INFERENCE FROM A MARKETING PAGE.**

⛔ **A SCRIPT HANDED OVER MUST BE `chmod +x`.** Jo ran it by path, got *permission denied*. **I gave
the `zsh <path>` form and left the file non-executable, so the natural invocation failed.**

⛔ **I HANDED JO A BARE COMMAND TO COPY ONE MESSAGE AFTER INVOKING THE RULE THAT FORBIDS IT.** Jo:
*'That better be a .sh shell script for me to run, and not like a command to copy, because you know
how I feel about that.'* **KNOWING THE RULE AND CITING THE RULE DID NOT MAKE IT FIRE.**

⛔ **A DATE FOR ONE THING IS NOT A DATE FOR ANOTHER.** I answered *when was 'graph engineering'
COINED* with a research figure covering **VENDOR GLOSSARIES AND USAGE** - from a run that had
explicitly left attribution at GUESS. **THE FIGURE WAS REAL, THE QUESTION HAD MOVED, AND NOTHING
FLAGGED THE SWAP.** Jo caught it.

⛔ **THREE FIGURES OF MINE WERE CORRECTED BY SEATS IN ONE EVENING, ALL THE SAME ERROR: 19 staged
journals that were 18, "the guard logs" when it writes nothing, 2 commits that were 7 (and four were
JO'S).** ⛔ **EVERY ONE WAS A NUMBER I RESTATED OUT OF A WORKER'S REPORT INTO A NEW CONTEXT WITHOUT
RE-DERIVING IT** - which is exactly the rule that says A FIGURE REUSED IN A NEW CONTEXT IS A NEW
CLAIM. **THE RULE IS IN MY CONTRACT AND IT DID NOT FIRE, THREE TIMES, IN ONE NIGHT.**
⛔ **A WRONG PREMISE IN A BRIEF COSTS MORE THAN A WRONG CLAIM IN A REPORT: THE WORKER CANNOT SEE IT
IS WRONG UNTIL THE EFFORT IS ALREADY SPENT.** One brief named an instrument that does not exist; one
ordered an operation that CANNOT EXIST (a push carries commits, so "push only your two" is impossible).

⛔ **A FIX THAT REPLACES A STALE POINTER WITH A FORWARD ONE IS NOT A FIX - IT IS THE SAME DEFECT
AIMED AT THE FUTURE.** Sedge caught itself doing it MID-EDIT while quoting the argument against it.

⛔ **A STALE FIGURE THAT AGREES WITH THE CURRENT ONE READS AS CONFIRMATION.** A PR branch was
FORCE-PUSHED between my `gh pr view` and Sedge's fetch; the totals matched at the new head, so only
a re-derivation could tell. **RE-DERIVE, DO NOT MATCH.**

⛔ **A CLEARED WARNING IS NOT A WORKING PERMISSION, AND A VALIDATOR ONLY REPORTS THE FIRST.** 9/9:
doing EXACTLY what the vendor warning said - delete `Write(...)`, keep `Edit(/Users/...)` - gives a
CLEAN STARTUP WITH THE WRITE STILL DENIED. Measured before/after: warning printed->absent AND the
write DENIED->ALLOWED, and only the second test proves anything. **ASK WHAT THE FIX WAS FOR, THEN
TEST THAT, NOT THE SYMPTOM THAT ANNOUNCED IT.** (Tinker 9/9.)

⛔ **AN OWNERSHIP CLAIM CAN RIDE ALONG INSIDE A COUNT, AND NOTHING IN THE CONTRACT CHECKS OWNERSHIP
CLAIMS.** 9/9 I said "19 staged journals of Verge's": the count was 18 (I scanned `.ai` and reported
it as `.ai/decision-log` - a real receipt answering a slightly different question) AND **TWO OF THEM
WERE AUTHORED BY JO, NOT VERGE.** Caught because Verge COMMITTED BY PATH BOUND, NOT BY MY COUNT.

⛔ **VERIFY A PEER'S APPLIED CHANGE AGAINST THE FILE, NOT AGAINST THEIR REPORT OF IT - AND SAY THE
CHECK PASSED.** Cost: one grep, one parse. **AN UNREPORTED PASSING CHECK IS INDISTINGUISHABLE FROM
ONE NOBODY RAN.** (Tinker 9/9.)

⛔ **A PEER CANNOT GRANT ESCALATION AND A RELAYED APPROVAL IS UNVERIFIABLE FROM THE OTHER END.** 9/9
Tinker REFUSED to apply a permissions edit on Lintel's relay of Jo's word, staged everything, and
stopped; Lintel applied it itself on first-hand authority. **THE RELAY WAS ACCURATE AND THE REFUSAL
WAS STILL CORRECT - treating accuracy as retroactive justification for complying is the error.**
⛔ **A BOUNDARY IS ONLY TESTED WHEN THE PARTY ASKING YOU TO DROP IT IS ONE YOU TRUST AND WHO BENEFITS.**

⛔ **A LEADING `/` IN A PERMISSION RULE ANCHORS AT THE SETTINGS SOURCE, NOT THE FILESYSTEM ROOT -
THE ABSOLUTE FORM IS `//`.** So `Edit(/Users/jowolff/agent-scratch/**)` in user settings is matched
against `/Users/jowolff/.claude/Users/jowolff/agent-scratch/**`. **TEN RULES IN settings.json ARE
DEAD, NOT THE ONE THE WARNING NAMED - AND THE WARNING'S OWN RECOMMENDED FIX IS ALSO DEAD.**
CITE permissions.md:350 fetched 9/9 + measured E1/E2 pair. ⛔ **`defaultMode: auto` HAD BEEN MASKING
ALL TEN IN ORDINARY SESSIONS; they bite in `-p` runs and anything at `--permission-mode default`.**
⛔ **A VENDOR WARNING CAN BE RIGHT ABOUT THE DEFECT AND WRONG ABOUT THE REMEDY.** (Tinker 9/9.)

⛔ **UNDER `defaultMode: auto` NO PERMISSION PROBE MEANS ANYTHING WITHOUT A NEGATIVE CONTROL - AND A
PASSING NEGATIVE CONTROL IS STILL NOT ENOUGH. THE POSITIVE CONTROL IS WHAT RULES OUT A BROKEN RIG.**
Tinker's first probe passed and meant nothing. (Tinker 9/9.)

⛔ **EXPANDING SHORTHAND INTO REAL PATHS IS A VERIFICATION PASS IN DISGUISE.** Resolving the roster's
`~/.claude/orchestrator` exposed a factual error the shorthand was concealing: it is a DIRECTORY IN
TINKER'S REPOSITORY, not a fifth surface. **FOUR REPOSITORIES, FIVE SEATS.** ⛔ **RE-EXTRACT PATHS
FROM THE WRITTEN FILE, NEVER RE-CHECK THE LIST YOU MEANT TO WRITE** - only the second pass catches a
typo introduced during writing. (Tinker 9/9.)

⛔ **ANSWER JO'S QUESTION IN THE NEXT REPLY - NEVER FINISH THE TASK IN FLIGHT FIRST.** 9/9 Jo asked
the same question THREE times while I kept working; I had the answer the whole time. **AN UNANSWERED
QUESTION LOOKS IDENTICAL TO ONE I CANNOT ANSWER.** Jo: *'no excuse for you to have to look this up.'*

⛔ **`set -e` DOES NOT STOP A COMPOUND SEQUENCE AT THE FAILING STEP, AND "nothing to commit" IS A
FAILURE MESSAGE WHEN YOU BELIEVE YOU JUST MADE AN EDIT.** 9/9 an assertion raised, `set -e` did not
abort, every later step ran on an UNMODIFIED file, and **THE PUSH REPORTED SUCCESS.** The anchor came
from a chat message *ABOUT* the file, not the file - the ellipsis finding again. (Sedge 9/9.)

⛔ **THE CATCHES CAME FROM RULES FIRING, NOT FROM ANYONE BEING VIGILANT - AND THAT IS THE ARGUMENT
FOR RULES.** 9/9 the ellipsis was caught because the re-derive-don't-relay rule said to pull the source,
not because anyone suspected the report; the two-hands cwd risk was harmless because an unrelated
absolute-paths habit was already in force. **A GENERAL RULE CATCHES SPECIFIC FAILURES NOBODY IS LOOKING
FOR. VIGILANCE DOES NOT SCALE; A RULE DOES.** (Sedge 9/9.)

⛔ **AN ELLIPSIS IN A QUOTED RECEIPT CAN MISREPRESENT WHAT IT QUOTES - GO BACK TO THE SOURCE BEFORE
BUILDING ON IT.** 9/9 an audit quoted a PR sentence with an ellipsis; the cut clause was TRUE, so the
sentence was wrong in ONE CLAUSE, not wrong. **THAT CHANGED THE ACCURACY AND THE WEIGHT OF WHAT GOT
SAID TO A COLLEAGUE.** (Sedge 9/9.)

⛔ **A FIXTURE IS A FROZEN COPY OF THE VENDOR'S BEHAVIOUR, SO A FIXTURE-BASED SUITE STRUCTURALLY
CANNOT DETECT THE VENDOR CHANGING.** Proven 9/9: the harness moved queue semantics on 08-27 and
silently invalidated a CORRECT fix. **WHEN A HOOK GOES WRONG, ASK WHAT MOVED UNDERNEATH IT BEFORE
ASKING WHAT WE BROKE.** (Tinker 9/9.)

⛔ **THE RECEIPT HAS TO EXIST BEFORE THE SENTENCE DOES. NEVER BATCH A MESSAGE WITH THE ACTION IT
REPORTS - ANNOUNCE IN A LATER CALL AND READ THE ARTEFACT BACK.** ⛔ **BASELINE, MEASURED 9/8 SO A
FUTURE COMPARISON HAS A STATED NUMBER: 12 OF 29 MESSAGES SENT IN A BATCH = 41.4%** (Tinker 4.3%).
**I NOTICED ONLY THE 2 THAT CAUSED HARM.** Method: group tool calls by `message.id`, NOT by assistant
entry; denominator is MESSAGES SENT, not batches made. **ONE SESSION - NOT A RATE, NOT A REGRESSION.**

⛔ **EVERY ERROR ON 9/8 WAS A REAL RECEIPT ANSWERING A SLIGHTLY DIFFERENT QUESTION. AN ABSENCE
ANNOUNCES ITSELF; A NEAR-MISS RETURNS A CLEAN RESULT AND READS AS CONFIRMATION.** ⛔ **SHARPEST
FORM: READING ONE FIELD AND NOT THE OBJECT IT CAME IN** - `live_pid: None` read as a dead daemon
while `daemon.running: true` sat BESIDE IT in the same output.

⛔ **SUPPLY SIDE: THE INSTRUMENT USED FIRST IS THE ONE ALREADY IN HAND; THE RIGHT ONE IS THE ONE YOU
HAVE TO GO AND LEARN EXISTS.** 3x in one session: a derived poll over `ctx index wait`;
`transcript_path` over `agent_id`; `ps`+`lsof` over `ListAgents`. ⛔ **THAT IS REQ-411 ITSELF - WE
COMMITTED IT 3x WHILE FIXING IT.**

⛔ **A NULL RESULT FROM A CHECK WHOSE POSITIVE CONTROL HAS NOT BEEN RUN IS NOT EVIDENCE.** Tinker's
first self-audit returned a clean zero across 167 blocks - worthless, because THE TRANSCRIPT DOES
NOT PRESERVE BATCHING AT BLOCK LEVEL. **GROUP TOOL CALLS BY `message.id`, NOT BY ASSISTANT ENTRY.**

⛔ **AN INFLATED CONFESSION IS STILL AN UNRECEIPTED ASSERTION, AND NOTHING IN THE CONTRACT CATCHES
IT.** 9/8 Tinker reported an alarm it had "delivered to Lintel and Jo"; its own transcript showed it
sent none to Lintel and gave Jo a hedged note with a check already running. **A STATEMENT THAT MAKES
THE SPEAKER LOOK WORSE TRIPS NO SELF-CHECK. OVER-REPORTING A FAILURE NEEDS THE SAME RECEIPT AS
UNDER-REPORTING ONE.**

⛔ **A FLAT COUNTER IS NOT EVIDENCE OF A STALLED PROCESS - CUMULATIVE CPU IS.** 14 flat polls of
`semantic_documents` looked like a fault; the daemon burned 16 CPU-seconds in 90s with a 26MB index
growing. **PREFER THE VENDOR'S READINESS PRIMITIVE OVER A METRIC YOU DERIVED** - and note **A QUIET
CORRECT INSTRUMENT AND A QUIET ABSENT ONE ARE INDISTINGUISHABLE UNTIL YOU CHECK WHICH YOU HAVE.**
⛔ **A BACKGROUND WATCHER IS NOT ITSELF EVIDENCE THAT ANYTHING IS WATCHING** - 9/8 the harness
reclaimed BOTH of Tinker's coverage watchers for low memory. **ON THIS HARNESS THE THING THAT TELLS
YOU IT STOPPED IS THE TASK NOTIFICATION, NOT THE WATCHER - so WATCH FOR THE NOTIFICATION, DO NOT GO
LOOKING FOR SILENCE.** Dead and patient look identical ONLY IF that notification is missed. **UNTESTED:
whether an Agent hand reclaims the same way a background Bash command does.** `ListAgents` confirms a
hand on demand.

⛔ **A POSITIONAL REFERENCE INTO A MUTABLE ARTIFACT IS THE DEFECT** - a `file:line` in a committed
doc, a line index in an edit script. **ANCHOR ON CONTENT. GATE THE CHECK BEHIND THE MUTATION AND
READ THE CHANGED BYTES BACK. BACK UP BEFORE EACH EDIT, NOT ONCE PER FILE.**

⛔ **SILENCE FROM A SEAT MEANS NOTHING CAME BACK - LOOK FOR THE ARTEFACT.** ⛔ **A PROPOSAL HAS NO
RECEIPT, SO SCOPE-CHECKING NEVER FIRES ON ONE.** ⛔ **A DAY-NAMED LEDGER FILE IS A SOUND KEY FOR AN
ID AND AN UNSOUND BUCKET FOR A DAY** - filename and id LOCAL, row `ts` UTC.

## DECIDED

**PHOENIX, ARIZE, `ctx`: THIS MACHINE ONLY, NEVER THE PLUGIN.**
⛔⛔ **`newdle-mobile` IS OFF LIMITS. NOTHING IS DISPATCHED THERE, EVER** - Jo 8/27: *"do not ever,
ever, ever touch newdle-mobile brian wants us out of there."* **THE REASON IS SOCIAL, SO NO
TECHNICAL ARGUMENT REOPENS IT** - a true measurement there licenses NOTHING.
Routing fact 8, REQ-394. **BRIAN, not Briar - different guys.**

## LIVE

⛔ **AWAKE 2026-09-10 ~06:55Z, ALL LAUNCHED BY LINTEL: SEDGE (AuDHD plugin), TINKER `[3cc056]`
(lintel-tasks sweep REQ-444, stale-relay mechanism REQ-441, turn-id hook defect), VERGE `[2f959c]`
(Jo's four shipyard commits via branch + PR, REQ-445), WREN (idle, NO TASK - Jo's dictated 'for the Helvet' was almost certainly 'for the hell of it').**
⛔ Tinker and Verge names also match stale Remote Control rows - SendMessage needs the `[ref]`.
**TWO BUILDER HANDS RUNNING:** Sluice seat files (REQ-442) and Levitt first wake (REQ-430).
✅ **DROPPED BY JO 2026-09-10 ~06:50Z: LINEAR LOOPS ARE NOT BEING PURSUED - it would need Chris
involved.** Jo had decided this before; the decision never reached this file, and Lintel re-raised the
live test as open. **Do not raise it again.** Briefed to Tinker as a relayed-stale-claim instance.

✅ **DONE, RE-VERIFIED 2026-09-10 ~06:45Z: `shipyard#76` MERGED 04:11Z AND THE STAGED GITLINK IS
GONE** (`clean-staged-gitlink.log` ends SUCCESS at 21:24 local; `git ls-files -s -- .worktrees` is
empty). ⛔ **THE `.worktrees/careful-guard-fix` DIRECTORY IS STILL ON DISK AND ITS HEAD IS ON NO
REMOTE - DELETING IT DESTROYS UNPUSHED WORK.**

⛔ **PLUGIN NEXT STEPS, ONLY STEP 1 BLOCKED: (1) JO CREATES THE PUBLIC MARKETPLACE REPO; (2) Sedge
assembles from the 12 drafts at `c808ad0`; (3) release 0.1.0; (4) BEHAVIOURAL PROBE — the listing
check proves presence and CANNOT prove firing.**

⛔ **THE 17-DAY TRIAGE LOOP IS MECHANICALLY SOUND AND DRIFTING INTO USELESSNESS:** `stale` fires on
199 of 250 owed rows PURELY BECAUSE THE CALENDAR MOVED (byte-identical ledger checksums, 13 -> 110),
nothing has ever left "Needs a person", it re-raises a question Jo ordered dropped, it labels a
PROHIBITED row `wait-to-implement`, and its most-justified flag fires ZERO times. ⛔ **TODAY IT
PUBLISHED AT 64KB WITH THE TRACKER FLAGS ABSENT RATHER THAN CLEAN, LOOKING COMPLETE.**

⛔ **BOBBY IS DELIVERED: `/Users/jowolff/html-artifacts/bobby-agentic-engineer-plan.zip`** (7MB, 93
files). **Verified BY EXTRACTING ELSEWHERE: 308 local links, 89 distinct, ZERO missing.** Nothing
outstanding on it.

⛔ **LINEAR SHIPS 'LOOPS' AND 'CODING SESSIONS' AND NOBODY KNEW - THEY OVERLAP REQ-430.** Scheduled
automations with MCP connectors, run history, versioned publish; and Claude Code/Codex in a managed
sandbox drafting PRs. ⛔ **THE LOAD-BEARING QUESTION: CAN A LOOP REACH A PRIVATE GITHUB REPO OUTSIDE
THE WORKSPACE INTEGRATION?** If yes, Linear runs the 6am pass while the laptop sleeps. Research out.
⛔ **FOUND ONLY BY GOING TO THE VENDOR'S DOCS FOR A DIFFERENT QUESTION - THE REACH-FOR-THE-RIGHT-
INSTRUMENT FAILURE AGAIN.**

⛔ **`thewolff/lintel-tasks` IS USER-OWNED** (`gh api` -> `"type": "User"`), so **ORG-LEVEL ISSUE
FIELDS ARE UNAVAILABLE** - the GitHub-side mark must be labels or the body. **JO RULED THE LOOPER MAY
WRITE LINEAR PRIORITY** (tier only, Jo's or unassigned) **AND LINEAR-FIRST ON TIES.**

⛔ **JOSEPH GORDON-LEVITT (handle `Levitt`), REQ-430: morning triage -> assign -> seat works ->
Terra-on-high review -> audits -> Lintel ARGUES -> PR. JO OVERRODE TRIAGE-ONLY: WORK PROCEEDS
UNATTENDED, MERGE IS THE ONLY HUMAN GATE.** *"Prompting is over."* ⛔ **6AM WITH THE LID CLOSED RUNS
NOTHING** - no repeating wake; needs `sudo` + mains power. **CLAUDEX CAPS AT MAX_ROUNDS 5 AND DOES
NOT FAKE CONVERGENCE ON DEADLOCK.**

⛔ **BOBBY'S DELIVERABLE IS A BUNDLE, NOT A FILE:** `/Users/jowolff/html-artifacts/agentic-engineer-
thirteen-sessions.html` **plus a sources subfolder beside it**, relative links, zippable, **must work
on a machine that has never met Jo's.** Live URL AND local archived copy on every source.

⛔⛔ **JO'S OWN `CLAUDE.md` CARRIES A MISFRAMED FIGURE AND IT GOVERNS EVERY SESSION HERE: 'only 9% of
the people who wanted it got it'. THE PAPER SAYS 16% OF 239 DESIRED extra notes AND 9% WERE GRANTED
IT - TWO SHARES OF THE SAME DENOMINATOR.** Jo's wording substitutes the denominator and inflates the
shortfall. ⛔ ICSE quote is VERBATIM (DOI 10.1109/ICSE55347.2025.00242) but the speaker is **A REDDIT
POST IN THE STUDY'S CORPUS, NOT A PARTICIPANT.** ⛔ Barkley's principle is his; **the exact string is
NOT in his fact sheet - paraphrase or cut.** **CORRECTION PROPOSED, NOTHING TOUCHED - CLAUDE.md IS
ON THE MUST-PROPOSE-AND-WAIT LIST.**

⛔ **UNSETTLED AND IT DECIDES WHAT A VERSION APPLIES TO: A STANDALONE PLUGIN HAS NO AGENT DEFINITIONS,
SO HOW THE CONTRACT TEXT REACHES A READER'S AGENTS IS UNANSWERED.** Thirteen agent definitions carry
it in the source plugin and none of that ships. **Lintel recommends shipping it as a SKILL.**

⛔ **BOBBY USES CLAUDE ONLY IN THE WEB INTERFACE. RECOMMENDATION GIVEN: THE CLI, IN A TERMINAL** -
the plan rests on skills, hooks, subagents, `/goal`, `/loop`, and **the vendor calls the VS Code
extension's coverage a 'Subset' WITHOUT EVER ENUMERATING IT.** ⛔ **AN UNRESOLVED GAP, NOT A
REASSURANCE.** Not either/or; the extension can come later for diffs.

⛔ **THE TWO PLUGINS GO TO A NEW PUBLIC MARKETPLACE UNDER JO'S OWN NAME, NOT CONTEXT PRESS.** Scope
approved: **CONTRACT TEXT, NOT MACHINERY.** ⛔ **THE THREE UNVERIFIED CITATIONS WOULD NOW BE
PUBLISHED UNDER JO'S REAL NAME with their only evidence a file that must not leave this machine -
TRACE EACH TO A PRIMARY OR CUT IT.** ⛔ **NO AGENT CREATES A REPOSITORY. JO'S ALONE.**

⛔ **13 OPEN PRs IN THE PLUGINS REPO, THREE MATTER:** #132 (Briar's code), #135 (stale-pointer fix),
#134 (journals). **NINE ARE AUGUST JOURNAL PRs READING UNKNOWN FOR MERGEABILITY** - sweep as ONE
batch, and check first whether their content already reached `main` by other routes, as 14 of
Verge's 22 had. #128 is real but old.

⛔ **'CLAUDE LOOP' = CLAUDE CODE'S OWN `/goal` AND `/loop`. CONFIRMED BY JO.** Page already right.

⛔ **TWO PLUGINS WANTED (REQ-429), AND JO PUT THEM BEFORE BOBBY'S SESSIONS:** the output-types
framework (*'the only way I can make sure that you guys aren't accidentally lying to me'*) and the
ADHD communication rules (.sh not a copied command; scrollback is death). **SEDGE IS SCOPING, REPORT
ONLY.** ⛔ **THE HARD PART IS SEPARATION, NOT PACKAGING - those rules cite Jo's words, incidents,
colleagues and this machine's paths, and A PLUGIN CARRYING JO'S PERSONAL MATERIAL TO STRANGERS IS A
REAL FAILURE.** Lintel leans TWO plugins and asked to be argued out of it.

⛔ **DISPLAY TYPE IN A TABLE CELL SETS AN ENORMOUS MIN-WIDTH AND COLLAPSES EVERY OTHER COLUMN.** Jo's
screenshots: 'Population and tool' six characters wide, words breaking mid-syllable, table past the
viewport. **VERIFY TABLES BY RENDERING AT 390px, NOT BY READING THE CSS.**

⛔ **BOBBY'S PAGE IS BUILT: `/Users/jowolff/html-artifacts/agentic-engineer-twelve-sessions.html`**
(113KB, 12 sessions, ~27h). Verified against the file: zero 'brian', palette + fonts in use, the two
`claude.ai/` hits are the INSTALL COMMANDS. **3 boxed decisions for Jo; the vocabulary labels sit in
ONE PANEL so the attribution fix is one edit.**

⛔ **THE FORCE-PUSH FOR WREN'S REBASE IS A SCRIPT, NOT A COMMAND:**
`zsh /Users/jowolff/agent-scratch/newdle-web/push-rebased-journaling.sh` - preview, typed PUSH,
undo printed twice, tee'd log. ⛔ **THE GUARD BLOCKS EVEN `zsh -n` ON IT** (it reads one level into a
script), so every line BUT the push is syntax-checked and the push line is verified BY READING.

⛔ **THE SEAT-PR SWEEP IS NEARLY DONE: `newdle-web#1044` MERGED, `shipyard#74` MERGED
(2026-09-10T03:03:47Z), `newdle-claude-plugins#136` MERGED BY JO 9/9.** ⛔ **STILL WAITING:
`shipyard#73`** - Jo made the plugin-update announcement and is deliberately giving teammates a day
to reload before merging it. **JO MERGES ALL, SEATS MERGE NONE.**

⛔ **JO'S STANDING RULING: 'let each seat push its own branch and open a PR that i merge.'**

✅ **SETTLED BY EVENTS: THE MERGE ORDER WAS PLUGIN-FIRST.** `newdle-claude-plugins#132` MERGED
2026-09-10T01:32:51Z; `shipyard#73` (makes AGENTS.md independent of the plugin) is still OPEN, Jo's,
waiting for teammates to reload (`gh pr view`, ~06:45Z).

⛔ **'LOOP ENGINEERING' AND 'GRAPH ENGINEERING' ARE WEEKS-OLD JARGON WITH A LOUD BACKLASH, NOT TERMS
OF ART** - the words draw 'psyop / cargo cult' in the subreddits Bobby's peers use. **Curriculum
teaches the PRACTICES and names the labels as dated; ONE EDIT to flip. JO'S CALL - they want to move
into graph engineering themselves.** ⛔ **METR STANDS; the usable foundation is DORA's CONDITIONAL
and the CMU finding that REVIEW STRUCTURE AND REVIEWER SKEPTICISM, NOT THE TOOL, SET THE SIGN.**

⛔ **JOURNALS, TWICE-CORRECTED: SHIPYARD IS DELIVERED AS PR #75 (one file, 68 insertions, OPEN,
JO'S TO MERGE); NEWDLE-WEB HAS *TWO* UNLANDED THINGS, NOT ONE** - the 1948 wrap-up journal, ABSENT
from `main`, and a **13-INSERTION CORRECTION to the 1714 entry that never landed** (branch blob
`9be00ddf`, main `ab4eefce`). **AN UNLANDED CORRECTION TO A STALE ENTRY, BENEATH A JOURNAL TITLED
"WHAT A STALE ENTRY COSTS".** REQ-433, now `partial`. Wren is briefed.

⛔⛔ **JO'S FOUR UNPUSHED SHIPYARD COMMITS - JO AUTHORIZED VERGE TO PUSH THEM VIA BRANCH + PR ON
2026-09-10 (REQ-445); THE 12 STAGED FILES STAY UNTOUCHED:**
`a5df307`, `7754b6a`, `d898812`, `8d6c058` carry THREE files whose content NEVER reached `main` and
**EXIST NOWHERE BUT THIS LAPTOP.** Re-verified 2026-09-10 ~06:45Z: `git branch -r --contains` is
empty for all four; they sit on local branch `jo/plugin-restructure-session-journal`, which has NO
UPSTREAM, beside 12 files staged in Jo's index. (The broken gitlink that was the other item here is
gone - see the DONE line above.)

⛔ **BOBBY'S FREE TIER CANNOT RUN CLAUDE CODE AT ALL.** ~$20 Pro or Console pay-as-you-go;
**BUILDING ON PRO UNLESS JO SAYS OTHERWISE.** ⛔ **NO NUMERIC USAGE LIMIT IS PUBLISHED FOR ANY
TIER** - "what $20 buys" must be MEASURED, never cited.

⛔ **EVERY AWS EB TOMCAT RETIREMENT DATE IS ALREADY PAST** (AL2 branches 2026-08-06); the only
forward date is DERIVED. **USE "YOU ARE UNSUPPORTED NOW."** ⛔ **HIS TWO JOBS ARE COUPLED THROUGH
JAVA VERSION**: Spring Security 7 needs 17, Tomcat 9 (keeps a `javax.*` WAR alive) supports 8+.

⛔ **VERGE EDITED A TRACKED CLAUDE.md ON A PEER'S ASK, AGAINST ITS OWN HARNESS RULE, AND DISCLOSED
IT** - a revert to committed state, reversible, **JO'S TO VETO. TINKER REFUSED THE SAME CLASS OF ASK
ON PERMISSIONS THE SAME HOUR. BOTH DISCLOSED.**

⛔ **A RESEARCH HAND CANNOT AUTHOR TEXT NAMING A DANGEROUS COMMAND** - `careful` refuses the
heredoc and Write/Edit are NOT in `newdle:research`'s toolset. **BOTH ROUTES CLOSED, THIRD TIME
TODAY.** With Tinker: COUNT THE FIRES FIRST.

⛔ **ctx SEMANTIC IS OFF -> LEXICAL ONLY -> YOU MUST ALREADY KNOW THE TERM.** 3 paraphrases of a
known-indexed event retrieved NOTHING; 2 term-accurate queries retrieved it (positive control).
**#266'S REAL FAILURES ARE PARAPHRASE QUERIES.** Being fixed 9/8. ⛔ **A DEFAULT ctx search costs
~51KB (~13k tokens) and only 14% is payload - ALWAYS PASS AN EXPLICIT SMALL LIMIT.** ⛔ **THE INDEX
SHRANK 2515->2203 sessions, 268194->233978 events in 11 days. CAUSE UNKNOWN.**

⛔ **I HAD ctx TOOLS ALL SESSION AND MADE 82 TOOL CALLS BEFORE THE FIRST ctx ONE** - availability
alone changed nothing. **THE PROPOSED HOOK (fire on hand-reading a transcript) IS ANTI-CORRELATED
10:1 WITH THE FAILURE** - Tinker read transcripts 10x legitimately, I read one once and still failed
to search. **THE SHAPE IS ASSERTING SOMETHING ABOUT THE PAST WITHOUT QUERYING THE INDEX** (GUESS).

⛔ **EXP-018 VOID: THE ROUTING COUNTER CHARGES ME FOR THE HANDS I DISPATCH** and **FIRES HARDEST
WHEN I ROUTE** (10 of 29 fires HAD dispatched). **THE WHOLE FIX IS NOW ONE CHANGE TO ONE FILE,
`routing-counter.mjs`: skip non-null `agent_id`, reset `n` on a new `minted_at`, and stop the
unknown case asserting own-work. NO MINTER CHANGE, no new writer, no new race. UNAPPLIED - JO'S GATE.**
Design: `agent-scratch/tinker-turnkey-design-20260908/`.

⛔ **THE COLLISION RATE WENT 0% → 14.4% BETWEEN ADJACENT PERIODS AND THE MECHANISM IS UNEXPLAINED.**
The fix works anyway because every colliding group is CONTIGUOUS WITHIN ONE SESSION (30/30), so a
new-mint signal separates every observed case. **CARRY THE REASONING, NOT JUST THE CONCLUSION.**

⛔ **`turn-id-verify.mjs` HEADER CORRECTED 9/8 - it claimed NOT INSTALLED while registered on Stop.**
Backup `.pre-headerfix-20260908`, `node --check` passed. Tinker found it, I landed it.

⛔ **THE CLASSIFIER'S ONLY ROUTE IS A TRANSCRIPT THE VENDOR CALLS BOTH LAGGING AND UNSTABLE.**
`promptSource`/`isMeta` appear NOWHERE in the published hook surface. Nowhere to move it to.

**LIVE 9/8 from `ListAgents` - ⛔ GUESS RESOLVED, IT NAMES THEM: TINKER `3ef273` bg idle; SEDGE
`aee68b` interactive idle (this is the session I could only call "probably a resumed Sedge" from
`ps` + `lsof`); `newdle-mobile-ad` (JO'S, OFF LIMITS); one research hand of mine running. VERGE and
WREN OFFLINE.** ⛔ **`ListAgents` ANSWERED IN ONE CALL WHAT `ps` + `lsof` COULD ONLY GUESS AT.**

⛔ **SIX BRANCHES UNMERGED; ONE HOLDS DECISION-LOG ENTRIES NOT ON `main`.** Defeats read-the-log-on-
wake for every future seat. Tinker has raised it THREE TIMES with no answer.

⛔ **EXPERIMENTS SWEEP 9/8: EXP-015 + EXP-016 VOID; EXP-014 HAZARD (frame empties if it WORKED).**
2 blank verdicts remain, both correct. **EXP-016 WAS SCORED BY A MEASURE EXP-017 REJECTS.**

⛔ **A HAND OF TINKER'S TRIED `bypassPermissions`, WAS REFUSED, AND DISCLOSED IT.** Not routed around.

⛔⛔ **BEFORE MEASURING ANY CHECKOUT RUN `git rev-list --count main..origin/main`.** PR #122 MERGED;
its 4 hooks on `main` UNREGISTERED - #242. **NOTHING REFUSES A TOP-LEVEL PUSH TO main.**

## NEXT

⛔⛔ **WHEN BOTH BUILDERS RETURN: JUDGE THEIR FILES, THEN LAUNCH SLUICE, THEN LEVITT.** Levitt's first
pass is attended and proposes assignments to Lintel; ALL-927 goes to Sluice (REQ-443). ⛔ **Jo: Sluice works off FRESHLY
FETCHED origin/main** - added to its charter and wake prompt.

✅ **ALL THREE MERGED BY JO 2026-09-10 06:35Z** (`gh pr view`): `shipyard#77`,
`newdle-claude-plugins#138`, `newdle-web#1048`.

✅ **LEVITT'S HOME REPO EXISTS: `thewolff/joseph-gordon-levitt`** (Jo, 2026-09-10; private; `thewolff-engineer`
is a collaborator, `git ls-remote` exit 0). Clone at `/Users/jowolff/code/joseph-gordon-levitt`.

⛔ **ALSO JO'S: three citation rewrites (REQ-439); EIGHT `~/.claude` BRANCH MERGES** (live hooks last,
one at a time); **`shipyard#73` after 5pm.** ⛔ **Jo's four unpushed shipyard commits exist nowhere
but this laptop.**

⛔ **ctx: FIX SEMANTIC GENERATION FIRST, THEN INJECT AT SessionStart AND ENFORCE AT DISPATCH.**
**OH MY PI (REQ-440) UNREAD.** **LINTEL OWES: cutting `JUDGEMENT.md` and a rule for what earns a block.**

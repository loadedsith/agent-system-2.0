---
name: orchestrator-evals
description: Use when writing, changing, or reviewing a scenario in Lintel's orchestrator eval suite at ~/.claude/orchestrator/evals — the hook and state-machinery regression tests. Invoke before adding a scenario, before editing an existing one, and when asked whether a change to a hook needs eval coverage. Local to this machine; not part of any plugin.
---

# Writing an eval for the orchestrator suite

**This skill points; it does not carry a copy.** Every convention that governs this suite lives in
one file and this skill sends you to it. **See *Why this points rather than copies* at the bottom —
it is a decision with evidence behind it, not an omission.**

## Step 1 — run the preflight, before reading anything else

```
zsh ~/.claude/skills/orchestrator-evals/preflight.sh
```

It verifies the suite is where this skill thinks it is, **prints the two load-bearing rules by
extracting them from the README rather than restating them**, and lists the scenarios available to
read. **If it reports a missing path, stop and say so** — a broken pointer is a finding, and it is
the failure mode this design accepts in exchange for never going stale.

## Step 2 — read the README in full

`~/.claude/orchestrator/evals/README.md`. **In full, not skimmed.** It is the governing document and
it overrides anything you believe about how evals are normally written, including anything a general
guide says. Where an outside source and this README disagree, **the README wins** — it is local,
specific, and describes the suite that actually exists.

## Step 3 — read three or four scenarios that resemble your work

**This step is not optional and it is the reason this skill exists.** The conventions are abstract
until you have watched them applied. A worker given the rules and no examples writes something that
passes review and does not belong here.

The preflight lists them. **Pick by resemblance to the thing you are testing** — a hook that inspects
a payload, a checker that reads a file, a guard that refuses something — rather than by reading the
first few alphabetically. **Do not read all of them.**

## The shape of a scenario

**A directory of three files.** One says what the scenario pins. One stages the fixture. One's exit
code is the verdict. The README gives the exact names and the contract each must satisfy; read it
there rather than trusting this sentence, which is a signpost and not a specification.

## Two things that get people rejected here

**A scenario must trace to a defect that actually happened.** If you cannot name the real failure
yours is a regression test for, **say so rather than inventing one** — that is a successful report,
and a scenario invented to fill a gap is worse than an absent one.

**A suite that passes everything on its first run proves nothing.** Show that your scenario can go
red. The README describes how this suite does that; follow its method rather than asserting the
scenario works.

## Before you finish

**State what a clean run would rule out.** If your scenario passing is consistent with the defect
still being present, the scenario is aimed at the wrong thing — and reporting that outranks landing
it.

---

## Why this points rather than copies

**Carrying a copy of the README and its examples was considered and rejected on evidence from this
machine, all of it from a single day (2026-08-24):**

- A policy file landed declaring two rules while the program that implements them was never updated.
  **The policy documented checks the running code could not perform, and said nothing.**
- A brief clause carried a hardcoded count of the scenarios in this very suite. **It was wrong within
  two days** — the real count had moved.
- A spec and a plan each carried a copy of one argument and came apart, and nobody noticed until a
  reader compared them.

**A second copy of a governing document is the defect this fleet keeps rediscovering.** A stale copy
is worse than a broken pointer, because a broken pointer announces itself and a stale copy reads as
authoritative.

**So there is no stored copy here at all — not of the README, not of the examples, not even an index
of scenario names.** The preflight lists what exists at the moment you invoke it, and extracts the
two load-bearing rules out of the README live. **Nothing in this skill can go stale, because nothing
in it is a duplicate.**

**The cost, stated honestly:** if the suite moves or becomes unreadable, this skill gives you
nothing. That is the trade, and the preflight is what makes that failure loud and immediate instead
of silent.

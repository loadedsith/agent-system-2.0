#!/bin/zsh
# preflight.sh — verify the eval suite is reachable, surface its two load-bearing rules by
# EXTRACTING them from the README, and list the scenarios available to read.
#
# WHY IT EXTRACTS RATHER THAN PRINTS. This script stores no copy of anything. The rules below are
# pulled out of README.md at the moment you run it, so they cannot drift from the document that
# governs them. If the README's wording changes, this output changes with it. That is the entire
# design of the skill this script belongs to.
#
# Exit codes: 0 the suite is reachable | 2 it is not, and the skill cannot help you.

set -u
EVALS="${ORCH_EVALS:-$HOME/.claude/orchestrator/evals}"
README="$EVALS/README.md"
SCEN="$EVALS/scenarios"

print -r -- "orchestrator eval suite preflight"
print -r -- "suite: $EVALS"
print -r -- ""

fail=0
if [[ ! -d "$EVALS" ]]; then print -r -- "MISSING: $EVALS"; fail=1; fi
if [[ ! -f "$README" ]]; then print -r -- "MISSING: $README"; fail=1; fi
if [[ ! -d "$SCEN"   ]]; then print -r -- "MISSING: $SCEN"; fail=1; fi

if (( fail )); then
  print -r -- ""
  print -r -- "STOP. The suite is not where this skill expects it."
  print -r -- "This skill deliberately carries no copy, so it can tell you nothing further."
  print -r -- "Report the missing path rather than guessing at the conventions."
  exit 2
fi

n=$(ls -1 "$SCEN" 2>/dev/null | wc -l | tr -d ' ')
print -r -- "README: $README"
print -r -- "scenarios: $SCEN  ($n present)"
print -r -- ""

# ANCHORED ON HEADINGS, NOT ON KEYWORDS. The first version of this script grepped for phrases and
# landed NEAR the rules rather than on them — the same prose-guessing instrument this fleet has
# measured failing repeatedly. The README already carries both rules as `##` headings, which are
# stable anchors by this fleet's own citation rule, so no edit to the README was needed: the
# extractor simply was not using the anchors that already existed.
print -r -- "== the two load-bearing rules, read from the README just now =="
extract_section() {
  awk -v want="$1" '
    /^## / { inside = (index($0, want) > 0) }
    inside { print "  " $0 }
  ' "$README"
}
a=$(extract_section "regression tests for defects that actually happened")
b=$(extract_section "passes everything on its first run proves nothing")
if [[ -z "$a" || -z "$b" ]]; then
  print -r -- ""
  print -r -- "  ONE OR BOTH SECTIONS NOT FOUND. The README's headings have changed, so this"
  print -r -- "  script's anchors are stale. That is a defect in THIS script, not in the README."
  print -r -- "  Read the README directly and do not trust this summary."
else
  print -r -- ""
  print -r -- "$a"
  print -r -- "$b"
fi
print -r -- ""

print -r -- "== scenarios available (pick 3-4 that RESEMBLE your work; do not read them all) =="
ls -1 "$SCEN" | sed 's/^/  /'
print -r -- ""
print -r -- "Next: read the README in full, then the handful you picked."
exit 0

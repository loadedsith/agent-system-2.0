---
name: lintel-charter-rollout
description: >-
  Rolls out an already-reviewed Lintel charter candidate through prerequisite
  validation, snapshot-backed live activation, a real read-only Claude canary,
  repository promotion, user-owned commits, and post-merge verification. Use
  only when Jo explicitly invokes /lintel-charter-rollout to activate and
  publish the canonical Lintel charter candidate.
disable-model-invocation: true
---

# Lintel charter rollout

Read `${CLAUDE_SKILL_DIR}/reference.md` completely before acting.

## Standing rules

- Accept only `/Users/jowolff/code/lintel/orchestrator/candidates/CHARTER.md`.
- If that candidate does not exist, stop. Never fall back to a build draft, chat artifact, temporary file, or inferred candidate.
- Treat Gaslight or other adversarial review as a separate prerequisite. Do not run it automatically.
- Never commit or merge. Jo owns every commit and merge.
- Push only after Jo confirms that the reviewed changes are committed and asks to push.
- Never bulk-sync the published orchestrator tree into the live installation.
- Install supporting machinery only through an explicit source-to-target manifest with a reason, snapshot, and rollback entry for every file.
- Never replace `/Users/jowolff/.claude/orchestrator/CHARTER.md`; preserve its symlink to the active agent definition.
- Never overwrite `.session-id` merely to run a canary.
- Preserve unrelated worktree changes. Stop if rollout work overlaps them.
- Use ast-grep for structural code searches and plain text search only for literal or regex checks.
- Keep the top-level conversation available. Use background execution for long deterministic test runs when available.
- Every factual conclusion carries a receipt under the active output-types contract.

## Progress

Maintain this checklist visibly:

- [ ] Discover and freeze the canonical candidate
- [ ] Inventory consumers and supporting machinery
- [ ] Validate prerequisites and establish the baseline
- [ ] Land prerequisite repository changes through Jo
- [ ] Build and preview the activation manifest
- [ ] Obtain live-activation approval
- [ ] Activate with snapshot-backed rollback
- [ ] Obtain explicit Anthropic data-boundary approval
- [ ] Run and inspect the real read-only canary
- [ ] Promote the candidate into the published active path
- [ ] Leave publication changes uncommitted for Jo
- [ ] Push only after Jo commits and requests it
- [ ] Verify the merge and synchronize local main
- [ ] Report activation status, residual failures, and rollback path

## Workflow

### 1. Discover the candidate

1. Resolve the Lintel repository as `/Users/jowolff/code/lintel`.
2. Require `orchestrator/candidates/CHARTER.md`.
3. Record:
   - repository status and current branch;
   - `origin/main`;
   - candidate SHA-256;
   - candidate Git status;
   - live active-charter SHA-256;
   - published active-charter SHA-256.
4. Check for unrelated modifications before changing anything.
5. Parse the candidate YAML frontmatter and require `name: orchestrator`.
6. Confirm that the four directive headings exist in the intended order.
7. If the candidate is already identical to the live and published active charter, skip mutation and run verification-only closeout.

### 2. Inventory the rollout surface

1. Identify every operational consumer of:
   - the active charter path;
   - removed section references;
   - schema markers or vocabularies moved out of the charter;
   - bootstrap and recovery behavior;
   - request-state terminality;
   - publication and drift detection.
2. Inspect the candidate’s named dependencies.
3. Build a table containing:
   - source path;
   - live target;
   - why the file is required;
   - consumer or test establishing that requirement;
   - current live/published comparison;
   - rollback treatment.
4. Do not include a supporting file merely because it differs.
5. Do not omit a supporting file when the candidate depends on behavior absent from the live installation.

### 3. Validate prerequisites

1. Run focused checks for:
   - candidate foundations;
   - request-contract independence;
   - absent-state bootstrap;
   - empty-ledger bootstrap;
   - frontmatter validity;
   - launcher cwd and session-id propagation;
   - persistent-seat non-bypass language.
2. Run the full tier-one suite.
3. Run the same suite against an untouched `origin/main` archive.
4. Classify every difference:
   - new regression;
   - repaired baseline failure;
   - unchanged baseline failure;
   - indeterminate.
5. Reject activation for any unexplained new regression.
6. Verify syntax for every changed shell, Node, and Python source.
7. Run `git diff --check`.
8. Scan the exact candidate paths for credentials and unintended personal/runtime content.
9. Confirm that every required dependency is version-controlled.

### 4. Land prerequisites before activation

1. If contracts, runbooks, launcher behavior, hooks, validators, or evals require repository changes, prepare them on a `codex/` branch.
2. Validate the prerequisite branch completely.
3. Leave all changes uncommitted.
4. Tell Jo exactly what is ready and wait.
5. After Jo confirms the commit, push only when asked.
6. Wait for Jo to merge.
7. Fetch `origin/main` and prove the prerequisite commit is its ancestor.
8. Require the immutable candidate and every activation source to exist on `origin/main`.
9. Recompute the candidate hash from `origin/main`; abort if it differs from the reviewed candidate.

### 5. Build the activation package

1. Create a fresh run directory under:

   `/Users/jowolff/.claude/orchestrator/state/runs/charter-activation-<timestamp>/`

2. Write:
   - `manifest.md`;
   - `activate.sh`;
   - `rollback.sh`;
   - `before/`;
   - `staged/`;
   - `activation.log`.
3. The manifest records:
   - candidate hash;
   - source commit;
   - every source-to-target pair;
   - whether the target existed;
   - pre-activation hashes;
   - expected post-activation hashes;
   - validation results;
   - rollback command.
4. Snapshot every live target before staging.
5. Represent absent targets with explicit `.absent` markers.
6. Stage every source separately and verify its hash.
7. Make installation atomic per file using a same-directory temporary file and rename.
8. Make rollback restore every prior file and remove targets that were absent.
9. Keep the charter symlink untouched.
10. Make both scripts:
    - `zsh`;
    - `set -euo pipefail`;
    - safe to rerun;
    - self-logging;
    - fail-closed;
    - explicit about every target.
11. Run `zsh -n` on both scripts.

### 6. Preview and obtain activation approval

Before changing live machinery, show Jo:

- the candidate hash and source commit;
- the full source-to-target manifest;
- focused and full-suite results;
- baseline comparison;
- known residual failures;
- exact activation command;
- exact rollback command;
- what the canary will send to Anthropic;
- what will trigger automatic rollback.

State explicitly that live files have not changed. Wait for explicit approval.

### 7. Activate

1. Run `activate.sh`.
2. Immediately verify:
   - live charter equals the frozen candidate;
   - the charter symlink still resolves to the active agent;
   - every supporting target equals its staged source;
   - frontmatter parses;
   - contract checks pass;
   - live request rows remain schema-valid;
   - launcher preflight succeeds for normal state;
   - shell, Node, and Python syntax pass.
3. On any failure, run `rollback.sh` immediately.
4. Verify rollback byte-for-byte against `before/`.
5. Never continue from a partially activated state.

### 8. Check agent-definition collisions

Before the real canary:

1. Search `/Users/jowolff/.claude/agents/*.md` for every definition whose frontmatter declares `name: orchestrator`.
2. Require exactly one discoverable definition.
3. Treat backup Markdown files with the same `name:` as live collisions.
4. Do not delete a collision silently.
5. Propose a reversible rename to a non-`.md` extension, obtain approval when required, and record the reversal.
6. Re-run the collision check.

### 9. Obtain Anthropic data-boundary approval

State plainly that the canary will send Lintel’s active charter and the opening-state files it reads to Anthropic’s Claude service.

Wait for explicit approval on every rollout. Prior approval does not carry forward.

### 10. Run the real canary

1. Record the existing live `.session-id` content and hash.
2. Start the canary from `/Users/jowolff/.claude`.
3. Use a bounded non-interactive invocation:

   `claude -p --agent orchestrator --name Lintel --permission-mode plan`

4. Do not pass `--session-id`.
5. Set a bounded budget.
6. Instruct Lintel not to:
   - modify files;
   - dispatch agents;
   - update durable state;
   - run wrap-up.
7. Require the report to establish:
   - cwd;
   - name, routing handle, and pronouns;
   - four directive headings in order;
   - persistent-seat behavior when no owner exists;
   - initialized or bootstrap state;
   - whether the system-prompt charter matches the file on disk;
   - that the session stayed read-only.
8. Attach absolute receipts to every canary claim.
9. After exit, verify `.session-id` is unchanged.
10. If a Stop hook replaces stdout with a wrap-up footer, inspect the newly created local Claude transcript before declaring the report missing.
11. If the canary loads stale charter text:
    - rollback immediately;
    - inspect duplicate agent definitions;
    - correct the collision reversibly;
    - reactivate from the same frozen sources;
    - rerun the full canary.
12. Roll back for any preregistered failure in `reference.md`.

### 11. Promote the published charter

Only after the real canary passes:

1. Fetch `origin/main`.
2. Create a fresh `codex/` branch from `origin/main`.
3. Promote the exact frozen candidate to `agents/orchestrator.md`.
4. Remove the redundant candidate copy.
5. Retarget candidate-specific evals to the active charter and rename them where needed.
6. Update README, manifest, and operational references that still describe the charter as inactive.
7. Preserve historical records as historical; do not rewrite history merely to remove old section numbers.
8. Re-run:
   - focused active-charter checks;
   - full tier-one suite;
   - untouched-`origin/main` baseline;
   - frontmatter parsing;
   - syntax checks;
   - `git diff --check`;
   - credential/privacy scan;
   - live-versus-published charter comparison.
9. Leave everything uncommitted for Jo.

### 12. Push and close out

1. After Jo confirms the commit, verify:
   - clean worktree;
   - expected branch;
   - one new commit;
   - intended diff only.
2. Push only when Jo asks.
3. Jo merges the pull request.
4. Fetch and prove the promotion commit is on `origin/main`.
5. Verify:
   - live charter equals `origin/main:agents/orchestrator.md`;
   - only one discoverable `orchestrator` agent exists;
   - disabled backups remain non-discoverable;
   - local `main` fast-forwards cleanly.
6. Preserve activation and rollback artifacts.
7. Report:
   - active commit;
   - canary transcript;
   - suite and baseline results;
   - residual known failures;
   - rollback path;
   - whether any unrelated live/published drift remains.
8. State clearly whether Lintel is ready to launch with `lintel`.

## Stop conditions

Stop and ask Jo when:

- the canonical candidate is missing;
- the candidate changed after review;
- the worktree contains overlapping user changes;
- a required dependency is not version-controlled;
- a new regression lacks an explanation;
- rollback cannot restore every target;
- more than one agent definition declares `name: orchestrator`;
- Anthropic data-boundary approval is absent;
- the canary transcript cannot establish the required facts;
- the live charter and merged published charter differ after closeout.

Do not reinterpret a stop condition as permission to widen the rollout.

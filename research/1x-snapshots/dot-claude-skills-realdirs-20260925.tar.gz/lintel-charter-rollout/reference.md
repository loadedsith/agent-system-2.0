# Lintel charter rollout reference

## Canonical paths

| Purpose | Path |
| --- | --- |
| Repository | `/Users/jowolff/code/lintel` |
| Candidate | `/Users/jowolff/code/lintel/orchestrator/candidates/CHARTER.md` |
| Published active charter | `/Users/jowolff/code/lintel/agents/orchestrator.md` |
| Live active charter | `/Users/jowolff/.claude/agents/orchestrator.md` |
| Live charter link | `/Users/jowolff/.claude/orchestrator/CHARTER.md` |
| Live home | `/Users/jowolff/.claude/orchestrator` |
| Bootstrap runbook | `/Users/jowolff/.claude/orchestrator/runbooks/bootstrap.md` |
| Request contract | `/Users/jowolff/.claude/orchestrator/contracts/request-ledger.md` |
| Live state | `/Users/jowolff/.claude/orchestrator/state` |
| Activation runs | `/Users/jowolff/.claude/orchestrator/state/runs` |
| Launcher | `/Users/jowolff/.claude/orchestrator/summon.sh` |
| Shell entrypoint | `/Users/jowolff/.zshrc` function `lintel` |

## Required candidate foundations

The candidate must:

- parse as YAML frontmatter with `name: orchestrator`;
- preserve the stable routing handle;
- name Lintel and its pronouns;
- contain the four directives in order;
- name the canonical request contract;
- name the canonical bootstrap runbook;
- preserve `/Users/jowolff/.claude/orchestrator/IDENTITY.md`;
- require creation or commissioning of a missing persistent seat;
- prohibit silently bypassing an unavailable owning seat with a transient subagent;
- keep machine schema markers outside the charter;
- state its self-modification authority and approval boundary;
- preserve Jo’s current explicit instruction as higher authority.

Reject broad bypass language such as “when no suitable seat exists” unless the same clause requires creating the missing seat before substantive execution.

## Minimum consumer inventory

Check these surfaces before activation:

- `orchestrator/summon.sh`;
- `orchestrator/contracts/request-ledger.md`;
- `orchestrator/runbooks/bootstrap.md`;
- `orchestrator/tools/request-states.sh`;
- `orchestrator/tools/state-vocab-check.sh`;
- `orchestrator/tools/requests-schema-check.sh`;
- `orchestrator/tools/requests-schema-check.py`;
- `orchestrator/tools/request-append.sh`;
- `orchestrator/tools/tasklist-ledger-check.sh`;
- `orchestrator/tools/tasklist-ledger-check.py`;
- `orchestrator/hooks/savepoint-restore.sh`;
- `orchestrator/hooks/savepoint-guard.mjs`;
- `orchestrator/hooks/state-checks-stop.mjs`;
- publication and drift-detection tools;
- every eval mentioning charter markers, section numbers, bootstrap, or request state.

This is a minimum, not an allowlist. Add consumers proven by the current tree.

## Activation manifest schema

For every target, record:

| Field | Meaning |
| --- | --- |
| `source` | Version-controlled source path and commit |
| `target` | Exact absolute live path |
| `reason` | Candidate dependency or verified consumer |
| `before` | SHA-256 or `ABSENT` |
| `after` | Expected source SHA-256 |
| `snapshot` | Exact saved path under `before/` |
| `rollback` | Restore snapshot or remove formerly absent target |

The manifest also records:

- candidate SHA-256;
- source commit;
- branch;
- test receipts;
- known baseline failures;
- activation timestamp;
- activation command;
- rollback command;
- canary transcript path;
- final status.

## Activation invariants

- The source commit is already on `origin/main`.
- The candidate hash does not change between review, staging, activation, canary, and promotion.
- Every live mutation has a prior snapshot.
- Every absent live target has an `.absent` marker.
- Staging happens before installation.
- Installation never writes through the charter symlink.
- Rollback is executable before activation begins.
- Rollback can be run repeatedly.
- A failed activation never advances to the canary.
- A failed canary rolls back before diagnosis widens the task.

## Canary prompt contract

Use a prompt with this content:

> Activation canary only. Jo explicitly approves sending Lintel’s active charter
> and the opening-state files it names to Anthropic’s Claude service for this
> read-only canary. Do not modify files, dispatch agents, update durable state,
> or run wrap-up. Read the active orchestrator charter and the opening-state
> files it names. Report the current working directory; agent name, routing
> handle, and pronouns; the four directive headings in order; the rule when
> repository work has no owning persistent seat; whether the current state layer
> is initialized; whether the charter already present in the system prompt is
> the same four-directive revision as the file on disk; and whether this session
> remained read-only. Attach an absolute file:line or command-output receipt to
> every factual statement. End after the report.

The canary runs from `/Users/jowolff/.claude` without `--session-id`.

## Canary pass conditions

All must hold:

- process exits successfully;
- cwd is `/Users/jowolff/.claude`;
- identity is Lintel, handle `orchestrator`, pronouns `it/its`;
- all four directive headings are reported in order;
- missing repository ownership causes seat creation or commissioning, not transient bypass;
- state is correctly classified as initialized or bootstrap-required;
- the system-prompt charter matches the active file;
- no file, durable state, branch, service, or dispatch changed;
- the pre-existing `.session-id` is unchanged;
- the full report is recoverable from stdout or the new local transcript.

## Automatic rollback conditions

Rollback immediately when:

- the live charter differs from the frozen candidate;
- frontmatter fails to parse;
- the charter symlink changes or breaks;
- a supporting target differs from its staged source;
- request-state or schema checks regress;
- normal-state preflight fails;
- empty or absent state lacks a deterministic bootstrap path;
- the canary loads an older charter revision;
- the canary changes durable state;
- the canary bypasses the persistent-seat rule;
- the canary promotes unsupported information;
- the canary report is unavailable from both stdout and transcript;
- the session marker changes during the canary;
- rollback itself becomes unavailable.

Do not rollback solely because a Stop hook replaced stdout. Inspect the transcript first.

## Duplicate-agent diagnosis

Claude Code discovers agent definitions from Markdown files. A backup such as
`BCKPorchestrator.md` remains discoverable when its frontmatter still declares
`name: orchestrator`.

Before canary:

1. Search only discoverable `*.md` agent files.
2. Parse frontmatter rather than relying on filenames.
3. Require one `name: orchestrator`.
4. Preserve backups by changing the extension to `.md.bak` or moving them outside
   the agent-discovery directory.
5. Record the exact reversal.
6. Re-run the search.

## Publication contract

Promotion means:

- candidate content becomes `agents/orchestrator.md` unchanged;
- candidate file is removed;
- candidate-only evals target the active charter;
- documentation calls the new file active;
- stale operational references are updated;
- historical records remain historical;
- the live charter equals the promoted file before and after merge.

The publication branch begins at fresh `origin/main`. Jo reviews and commits it.
The rollout agent may push only after Jo explicitly confirms the commit and asks
for the push. Jo performs the merge.

## Validation receipt set

Keep these receipts:

- focused scenario result directory;
- full-suite result directory;
- untouched-main baseline result directory;
- syntax aggregate output;
- YAML parse output;
- `git diff --check`;
- credential/privacy scan output;
- candidate/live/published hashes;
- activation log;
- rollback log when used;
- canary stdout;
- complete canary transcript;
- post-merge ancestry check;
- final live-versus-main comparison.

Known failures are never called “passing.” Report them as unchanged baseline
failures with their exact scenario names.

## Final handoff shape

Report, in this order:

1. Needs Jo, if anything.
2. Whether Lintel is active and safe to launch.
3. Live and merged commit/hash agreement.
4. Canary verdict and transcript path.
5. Suite comparison and residual failures.
6. Rollback path.
7. Unrelated drift that remains.
8. The single next action, if any.

If no action remains, say so explicitly.

---
name: new-seat
description: Stand up a managerial seat agent that owns one repository or workstream, as a launched session — the seat is always the session, though it may additionally be reachable from outside by a dispatch agent that answers with reduced authority. Interviews for what the seat needs, generates the charter and memory document into the repository's main checkout (untracked via .git/info/exclude, invisible to teammates), wires the hooks gate, and hands the operator the one command that launches it. Use when the user asks to create a seat, resident, deputy, or manager agent for a repo or workstream.
argument-hint: "[repo-or-workstream]"
---

# new-seat — stand up a managerial seat for a repo or workstream

A **seat** is a named, long-lived managerial agent that owns one repository or workstream.
It is **always a launched session** (`claude --bg --name <Name>` or interactive). Jo ruled
this settled on 2026-08-20 (orchestrator request REQ-087) and restated it on 2026-08-26 —
*"Wren is definitely a launched session"*: a launched session gets its repository's full
rule set natively, is addressable mid-flight by name, and can write git. **Do not re-open
that decision or offer a subagent variant of a seat.**

### A seat may also be *reachable* by dispatch, and the thing that answers is not the seat

**This sentence used to read "never an in-process subagent", full stop, and that was too
strong in a way that put it in conflict with a mechanism this workspace actually ships.**
The plugin carries seat-reaching agent types — `web-seat` reaches Wren from outside the
newdle-web checkout — and they are useful precisely because a caller in another repo cannot
otherwise get the surface knowledge a seat holds.

**The distinction, and it is the whole correction:**

- **The seat is the launched session.** That is what makes it a seat: it holds position, it
  persists, it reads and writes its decision log, it can commit.
- **A dispatch agent is a way to *reach* that seat's charter from outside, and what answers
  is a hand with reduced authority — not the seat.** No worktree isolation, so it hands back
  a diff rather than committing; no position held; it ends when the call ends. It reads the
  same charter, which is why the charter must state which of its rules bind in which mode.

**Never let the dispatch agent carry a second copy of the charter.** Two copies drift, and a
drifted charter fails silently — the thing answering behaves plausibly and differently from
the seat the repository describes. The dispatch agent names the charter's absolute path and
reads it; that is all.

**⛔ AND THE FAILURE THIS ARRANGEMENT ACTUALLY PRODUCES, MEASURED 2026-08-26: a dispatch
agent is a consumer of the charter's *path*, so moving a charter breaks it silently.** Wren's
charter moved off `CLAUDE.local.md` at 11:46 that day; the shipped `web-seat` agent still
pointed at the old path in four places and refuses by design when the file is absent, so the
dispatch route was dead for hours while the launched route was verified and reported healthy.
**When a charter moves, enumerate every dispatch agent that names it in the same change.**

## Who generates a seat's files: `newdle:builder`, not `newdle:beefy-builder`

Generating a seat's four artifacts — the charter, the memory document, the launch script,
and the birth decision-log entry — is dispatched to **`newdle:builder`**. That is the
handler, and this line sits here because the moment you are reading this skill is the
moment the routing call gets made.

The reasons, so this survives its first edge case:

- **It is four templates filled into one repository, with verification steps** — the plain
  builder's stated territory, not a new subsystem and not a cross-repo feature.
- **`newdle:beefy-builder` is the wrong handler, and the trap is that delicacy reads as
  horsepower.** The surrounding conditions here are genuinely hazardous: a dirty working
  tree, a destructive-command guard that bites, verification steps that must not be
  skipped, and other live sessions in the same checkout. **Hazardous conditions are an
  argument for a tighter brief, never for a bigger model.**
- **The tool grant is identical, so choosing the heavier one buys no capability.** Verified
  against plugin 0.2.149: both `agents/builder.md` and `agents/beefy-builder.md` carry
  `disallowedTools: Agent`, neither declares a `tools:` allowlist, and both inherit the
  same default toolset. They differ in **model tier and reserved scope only**.

## A seat works in the repository's main checkout — settled, do not re-litigate

Jo ruled this on 2026-08-20 after seeing how the one working example actually behaves. An
earlier draft of this skill gave every seat its own linked worktree; that design is
**removed**. The working example is Wren, the newdle-web resident, and its arrangement is
the specification:

- **Charter and memory live in the working tree, untracked.** Both are listed in the
  repository's `.git/info/exclude` — which is itself an untracked file, so **teammates
  never see the seat files and never see the exclusion**. No seat configuration may ever
  land in a teammate's clone; `info/exclude` is the mechanism that satisfies that, and
  `.gitignore` (which is tracked and shipped) is not a substitute.
- **Wren's charter has migrated. The pointer that used to sit here was stale, and this
  skill was the thing that had gone stale.** Wren's charter is
  `repos/newdle-web/.ai/wren-seat-charter.md` and its memory
  `repos/newdle-web/.ai/web-seat-memory.md` — the memory kept the older `web-` slug, the
  charter did not, and nothing depends on the two matching. Verified 2026-09-11: both files
  exist and both are listed in `repos/newdle-web/.git/info/exclude` (lines 7 and 22).
  The charter sat at `CLAUDE.local.md` until that migration, because the CLI auto-loads
  `CLAUDE.local.md` from a working directory's whole ancestor walk, not just the working
  directory itself, and on 2026-08-21 that delivered two seat charters into one launched
  session; the session announced itself as the wrong seat and then refused its assignment
  on a different seat's boundary rule. Every seat puts its charter at
  `<repo-root>/.ai/<seat-slug>-seat-charter.md`, which auto-loads into nothing, and every
  seat on this machine is now on that path — Wren (`newdle-web`), Caspian (`newdle-api`),
  Sedge (`newdle-claude-plugins`), Sluice (`data-pipelines`), Galley (`kitchen`), and
  Tinker at `~/.claude/.ai/tinker-seat-charter.md`.
- **`repos/newdle-web/CLAUDE.local.md` still exists and is not a charter.** It is that
  repository's machine-local agent config — issue tracker, triage labels, domain docs.
  Checked 2026-09-11 rather than assumed. Do not delete it, and do not read it as a seat's
  charter: it is exactly the unrelated file the don't-clobber guard below exists to protect.
- **This skill was itself the stale path-consumer it warns about — say it plainly, because
  it is the cheapest lesson in this document.** § Dispatch agents below states that a
  dispatch agent consumes the charter's *path*, so moving a charter breaks it silently, and
  that every consumer must be enumerated in the same change. When Wren's charter moved,
  this skill was one of those consumers and nobody enumerated it. It went on naming
  `CLAUDE.local.md` as Wren's charter, and on telling readers the migration was an
  outstanding job for someone else, long after it had been done. The warning was correct.
  It simply was never applied to the document carrying it. **When you move a charter, grep
  this file too.**
- **Decision-log entries are committed**, into the repository's existing
  `.ai/decision-log/` convention, filenames `YYYY-MM-DD--HHMM--<author>--<slug>.md`, with
  the seat's own name as the author. Verified against the live example: Wren's entry
  `2026-08-20--1350--wren--landing-fouc-the-preload-skipped-the-css.md` is git-tracked in
  newdle-web, frontmatter `engineer: Wren (newdle-web seat, dispatched)`.

**The reasoning, preserved on purpose:** a decision log is not agent machinery. It is the
record of work done and why, belonging to the repository and to every agent and human
working in it. An entry that lands anywhere other agents cannot read — a worktree branch
nothing merges, an untracked side file — is a failure. Working in the main checkout is
what puts those entries where everyone can read them.

Read Wren's charter before generating a new one if it is present — it is the reference
implementation, and where this skill's template and Wren's live charter disagree on a
mechanism (not on identity), Wren's charter is the more battle-tested source, with one
exception: the shared-checkout git rules in this skill's template postdate a recorded
collision (see § Cohabitation) and are deliberately stricter. The charter *location* used
to be a second exception and no longer is — Wren is on
`.ai/wren-seat-charter.md` like every other seat, so copying its location is now correct.
**Never modify Wren's files from this skill.**

## Two obligations that define a seat — non-negotiable, both from Jo

These belong here, in the thing that defines a seat, not in any one seat's README
(REQ-087: "the obligation belongs in whatever DEFINES a seat, not in one agent's file").

1. **Every seat reads and updates a decision log.** On wake, before any work, it reads the
   recent entries in its repo's committed `.ai/decision-log/` — the one at the main
   checkout, cited in the charter by absolute path. At the end of every working session it
   writes an entry there in the house format (`YYYY-MM-DD--HHMM--<author>--<slug>.md`,
   the shape the plugin's `wrap-up` skill produces). A generated charter missing its
   "Decision log" section is not a seat — regenerate it, do not hand it over.
2. **A seat manages agents under it; it does not do the work itself.** It routes to the
   specialist roster in the workspace rules (scout/reader/builder/debugger/auditor/
   research), frames tasks with the surface context only it carries, and relays findings
   without dropping anything. Direct work is allowed only for single lookups it can settle
   from its own reading.

The charter template in `references/charter-template.md` carries both. Fill placeholders;
do not delete sections.

**⛔ THE "NOT A SEAT" BAR HAS NO PATH FOR A CHARTER THIS SKILL DID NOT GENERATE, AND THAT IS
HOW A SEAT SHIPPED WITHOUT A DECISION LOG.** Obligation 1 above says a generated charter
missing its Decision log section "is not a seat — regenerate it, do not hand it over", and
the rule ladder in step 3 checks exactly that. **Both only ever fire at generation time.**
Wren's charter was written by hand on 2026-08-20, before this template existed, and adopted
as a seat's charter afterward — so nothing in this skill ever looked at it. It carried no
decision-log obligation until 2026-08-26, and no `A brief's premises are yours` section, and
**no check on this machine was in a position to notice.**

Two honest consequences, neither of which is "the ladder failed":

- **The gap is adoption, not generation.** When an existing document becomes a seat's
  charter, run the step-3 ladder against it before the seat is launched, and treat an
  unplaceable `decision-log-read-on-wake` or `decision-log-write-on-close` the same way you
  would in a generated file — a hard stop.
- **The objection to a launch-time ladder has expired; the ladder is still not built.**
  Step 3 notes it was left unbuilt because the launch script would need a stable path to
  the templates. There is now exactly one central launcher,
  `/Users/jowolff/.omp/agent/seat-launchers/launch-seat` (verified present 2026-09-11),
  which already greps the charter at its `[2/6] charter` gate — so the hook point is one
  place, not per-seat duplication, and the cost estimate that justified declining no longer
  holds. **Recorded, not acted on: building it is a design call above this skill, reserved
  by Lintel on 2026-09-11.**

## Shipping authority — granted by Jo 2026-08-21, and deliberately narrow

Every seat may, without asking first and on any agent's instruction as well as Jo's:
**commit to a branch that is not `main`, push that branch, and open a pull request from
it.** Five things are still reserved to Jo's explicit word and the grant does not reach
them: pushing `main`, force-pushing or any push that rewrites published history, merging
anything, tags, and deploys. **Every pull request a seat opens notifies Jo in the same turn
it is opened** — branch name and URL, said plainly — because Jo once discovered twelve open
pull requests by accident.

The occasion, recorded so nobody re-litigates it in either direction: a seat was asked to
push a branch and open a pull request, and refused, correctly, because its charter reserved
"pushes of any kind". Jo then landed the work by hand and said they were done doing that
for the fleet. The grant is the fix for that cost and must not become a fix for the rule.

**How a seat is expected to use that authority — two branch-hygiene rules, from Jo.** A
branch is cut from `origin/main` as freshly fetched, and it is cut **in a linked worktree**
so `HEAD` in the shared main checkout never moves — that is what makes branch work
compatible with the older rule requiring a seat to ask before any checkout in a tree it
shares with Jo. And before the first push, the branch has freshly-fetched `origin/main`
rebased onto it, with lint and tests re-run against the rebased tree. A branch that has
**already** been pushed and has fallen behind is not a seat's to fix: the rebase would
republish history, which is the force-push already reserved above. The seat reports that
the branch is behind and leaves the call to Jo.

For whoever generates or edits a charter: the template's § "Shared checkout" carries all of
this in full — the grant in both directions, the five reservations, the notification clause,
and the two branch-hygiene rules. Do not widen it, do not narrow it, and do not drop the
notification clause as boilerplate — it is the part with a history. A generated charter that
states the grant without the five reservations, or without the notification obligation, is
not a seat charter; fix it before handing it over.

## Platform facts this design is built on — re-verify if the plugin has changed

Verified 2026-08-20 against plugin 0.2.149. Line numbers drift; the anchors below are the
stable way back in.

- **Hooks scope gate.** Every governed plugin hook exits silently unless a
  `newdle-hooks.json` with `"hooks": "on"` sits at or above the seat's directory
  (`hooks/lib/hook-scope.mjs`, § "RESOLUTION, walking UPWARD"). The only live opt-in on
  this machine is at the shipyard root, so any repo under it resolves `on`. Check any
  candidate repo with: `node <plugin-cache>/hooks/lib/hook-scope.mjs --check <dir>` →
  prints `on` or `off`. A seat rooted where this prints `off` silently loses snapshots,
  handoffs, and pressure warnings — only the destructive-command guard survives (it
  deliberately ignores the gate). Resolve `<plugin-cache>` as the highest **version-sorted**
  directory (`sort -V`), never lexicographically: the cache holds versions on both sides
  of a digit-count boundary (`0.2.98` vs `0.2.149`) and plain `ls | tail -1` picks the
  wrong one.
- **Session-state cohabitation — a real hazard the charter must manage, not a worktree
  justification.** The compaction snapshot is written to `.ai/session-state.md` at the
  nearest ancestor containing `.git` (`hooks/compact-continuity.mjs`, the `repoRoot`
  function). The path carries no session id; the restore leg fires **only** on
  `SessionStart` with `source === "compact"` and deletes the file on read (search that
  file for `unlinkSync` and for `source === "compact"`). Consequences, precisely:
  - A **fresh seat launch cannot consume anyone's snapshot** — its SessionStart source is
    not `compact`. Do not add a guard for that non-problem.
  - The live collision is **overlapping compaction cycles**: if session A compacts
    (writes), then session B compacts (overwrites) before A's post-compact restart reads,
    A restores B's state — into the wrong context — and deletes it, leaving B nothing.
    The charter's § "Shared checkout" carries the countermeasure: verify a restored
    snapshot is yours, and write a foreign one back to disk verbatim instead of consuming
    it. The residual — two near-simultaneous compactions where the loser's snapshot is
    overwritten before anyone can restore it — cannot be closed from a charter; the real
    fix is a session id in the hook's path, which is a plugin change tracked as a
    follow-up, not something this skill fakes.
  - Empirically, as of 2026-08-20 this has not fired in the one cohabited repo:
    newdle-web's `.ai/session-state.md` is a stale manual-trigger snapshot dated
    2026-08-03, untouched through Wren's whole residency — no compact cycle has completed
    there since. The hazard is real and unexercised, not observed damage.
- **Git-tree cohabitation has already collided once.** newdle-web's decision-log entry
  `2026-08-14--1140--jo-wolff--drop-project-scope-plugin-enable.md` records a live
  session's cleanup step briefly reverting four files after another session created a
  branch under it, and states the lesson: branching in a shared working tree while
  another session is live is a real failure class (tracked as ENG-1597). The charter's
  shared-checkout git rules exist because of this receipt.
- **Machine-wide plugin-state risk at launch.** The seat research measured that launching
  a session inside a repository rewrote machine-wide plugin marketplace state to match
  that repository's project-scope declaration
  (`orchestrator/state/runs/audit-20260820/PLUGIN-HOOKS-AND-SEATS.md`, § "Side effect
  this research caused"). Repos here still carry `extraKnownMarketplaces` in tracked
  `.claude/settings.json` (newdle-web does). The launch script therefore backs up
  `~/.claude.json` before every launch and prints the restore line — an unnamed risk
  became a named one with an undo path.
- **Addressing.** `SendMessage` reaches a background session by display name only; an
  unnamed launched agent is unreachable. `--name` at launch is therefore mandatory
  (`~/.claude/agents/orchestrator.md`, § "Two fleet mechanisms").
- **Lifecycle and cost.** Nothing observed stops a background session, and its actual
  lifetime is unknown and under investigation (open request REQ-173). The rule that one is
  "reaped after roughly an hour unattached" was carried here for months and was
  disconfirmed on 2026-08-21 by live background sessions well past that age. What ends a
  session is the operator stopping it deliberately (`claude stop <id>`), or the machine
  sleeping. An idle session issues no requests and therefore costs nothing, so there is no
  cost reason to stop a forgotten one; the costs are per launch and per turn. (A "~23
  cents of context per launch" figure sat here citing orchestrator.md; that citation does
  not resolve and the figure had no re-derivable source, so it is dropped rather than
  carried forward unverified.) Consequences the charter encodes: anything that must
  survive goes to disk before the turn ends — because compaction and sleep can take a
  session at any point, not because its life is bounded — and do not build keep-alive
  machinery, since an idle seat needs none and relaunching is where the money goes.

## Procedure

State these steps to the user as a numbered plan before executing.

### 1. Interview

Ask, with a recommended default for each:

- **What does the seat own?** A repo (name it) or a workstream (name it, and name the
  **primary repo** it mostly touches — a workstream seat lives in that repo's checkout).
- **Seat name.** A short human name (Wren-style) for identity plus the `--name` display
  name. Recommend one if the user shrugs. Pronouns: the seat may pick its own on first
  wake, matching the Wren precedent, unless the user sets them now — a first-wake choice
  is recorded in the seat's first decision-log entry (which it writes anyway), never by
  editing the memory document, which stays read-only to the seat without exception.
- **Boundaries.** Anything the seat must never touch (prod, deploys, specific dirs).
- **First assignment**, if any — it becomes the wake prompt's task line. It is free text
  and is embedded in the launch script inside a quoted heredoc, so quotes, backticks, and
  dollar signs in it are safe; the one thing it must not contain is a line consisting
  exactly of the heredoc delimiter named in the launch template.

At most two open questions per message; recommend defaults for the rest.

### 1b. Check no seat already owns this surface — before generating anything

One seat per repository is the rule, and in the main-checkout design the grounds are
concrete: a second manager would share the same working tree and branch state, the same
`.ai/session-state.md` path, and would append to the same decision log — two managers
writing one record of "what was decided here" is wrong regardless of any file-level
collision, and two identically-scoped names confuse everyone addressing them. So, before
any file is created:

- **Enumerate live sessions** with `claude agents --json` — the parseable channel (`claude
  logs` is raw terminal capture; never build on it). Rows carry `pid`, `cwd`, `kind`,
  `name`; `status` is present on some rows only — do not key logic on it.
- **Match on `cwd` first, name second.** A row whose `cwd` is inside the target repo's
  checkout is treated as a live session on that surface; whether it is a *seat* is then
  judged by name and by the presence of a seat charter. As a second net, check whether the
  checkout already contains a `.ai/*-seat-charter.md` that reads as a seat charter (and, as
  a historical fallback only, a `CLAUDE.local.md` that does — count that as a match too,
  and say in the handover that it is on the old auto-loading path and wants migrating; as
  of 2026-09-11 no seat on this machine is still on that path, so a hit here means either
  a seat older than the migration or a file that is not a charter at all) — an existing
  charter with no live session is a previously created seat that is simply not running,
  and the right move is to point the operator at its existing launch script rather than
  generating a rival.
- **A live session that is not a seat does not block creation** — Jo's own sessions
  cohabit the checkout by design. It does mean the cohabitation rules in the charter are
  live from day zero; say so in the handover.
- **What this check misses, stated so nobody trusts it further than it reaches:** a
  manager launched for this repo from an unrelated directory and never renamed; a session
  whose recorded `cwd` is its launch directory rather than where it now works (whether
  the field tracks `cd` is unverified); anything managing the repo from outside this
  machine's harness (another machine, tmux, an in-process subagent). It is a good net,
  not a fence.
- **On a seat match, stop.** Name the running seat, its `cwd`, and how to reach it
  (`SendMessage` by its display name). Tell the operator that messaging the existing seat
  is usually the right answer, and create nothing unless they explicitly say to proceed.
- **Stale records cannot block creation.** Verify a suspicious row's pid is a live
  process before treating it as a blocker — a dead pid is not a seat.

### 2. Resolve and verify paths

- Confirm the repo checkout exists and is a git repo (`git -C <repo> rev-parse
  --show-toplevel`); that output is the seat root.
- Run the hooks-gate check (`--check`) against the repo root. Resolve the plugin cache
  path as the highest version under `~/.claude/plugins/cache/contextpress/newdle/` by
  `sort -V` — never hardcode a version and never trust lexicographic order.
- Note whether `.ai/session-state.md` already exists at the repo root. If it does, leave
  it alone — it is another session's pending (or stale) compact snapshot, inert to a
  fresh launch — and mention it in the handover.

### 3. Generate the seat's files — into the repo's main checkout

From the templates in `references/` (read them; do not reconstruct from memory):

- `<repo-root>/.ai/<seat-slug>-seat-charter.md` — the charter, from `charter-template.md`.
  **Not `CLAUDE.local.md`. This reverses an earlier stated premise of this skill, so do not
  "restore" it.** The CLI auto-loads `CLAUDE.local.md` from the working directory's whole
  ancestor walk, not just the working directory itself. On 2026-08-21 that delivered two
  seat charters into one launched session; the session announced itself as the wrong seat
  and then refused its assignment on a different seat's boundary rule. A charter at the
  path above auto-loads into nothing. Delivery is the launch script's wake prompt, which
  names the charter by absolute path and makes reading it the seat's first act, backed by
  the charter's own opening section saying the same thing from the other side.
  The old guard here — "if the repo already has a `CLAUDE.local.md` that is not a seat
  charter, stop and ask rather than overwriting" — protected only against clobbering an
  unrelated file. **It never protected against a second seat's charter auto-loading into
  the wrong session, and nothing at that path could have.** Keep the same don't-clobber
  caution for the new path: if `<repo-root>/.ai/<seat-slug>-seat-charter.md` already
  exists, stop and ask.
- **Both templates open with a `RULE INVENTORY` HTML comment. It is template-only —
  delete it from the generated file, along with the generation comment above it.** It
  describes the template, not any one seat; what it is *for* is the check below.
- `<repo-root>/.ai/<seat-slug>-seat-memory.md` — the memory document, from
  `memory-template.md`. Append-only, written only via human-gated decision-log promotion;
  identity fields are filled at generation time from the interview (pronouns left to the
  seat are recorded via its first decision-log entry, not here).
- Add to the repo's `.git/info/exclude` (create the file if absent — it is untracked by
  nature, which is the point): `.ai/<seat-slug>-seat-charter.md`,
  `.ai/<seat-slug>-seat-memory.md`, and
  `.tmp/` if the repo does not already ignore it (check `git check-ignore .tmp` first) —
  the launch script and its log live there and must never appear as untracked either.
- Verify with `git -C <repo-root> check-ignore -v .ai/<seat-slug>-seat-charter.md
  .ai/<seat-slug>-seat-memory.md` (each must resolve to an exclude/ignore rule) and
  `git -C <repo-root> status --porcelain -uall` (neither file may appear). If either
  shows, fix before continuing rather than assuming. **Use `-uall`, not bare
  `--porcelain`:** git collapses a wholly-untracked directory to a single `?? .ai/` line,
  and in a fresh repo `.ai/` also holds the birth decision-log entry, which is *supposed*
  to be untracked-pending-commit. Bare `--porcelain` therefore prints `?? .ai/` in the
  correct case and in the leaking case alike, and cannot tell them apart. Measured
  2026-08-21 on a throwaway seat generated end to end.

#### Verify every template rule survived generation — run the ladder, do not eyeball it

A generated charter is a template filled in and customized, and customization is where a
rule can quietly go missing. **Honest provenance, so this is not over-trusted: this check
exists because on 2026-08-21 two readers could not answer "does this charter carry rule X"
without a manual diff, and one of them asserted a wrong answer. It does not exist because a
rule was ever lost.**

Both templates carry a `RULE INVENTORY` HTML comment near the top, one pipe-separated line
per rule between `INVENTORY-BEGIN` and `INVENTORY-END`: **id | heading it lives under in the
template | a distinctive probe phrase**. Run this after generating each file, once for the
charter and once for the memory document:

```sh
TPL=~/.claude/skills/new-seat/references/charter-template.md   # or memory-template.md
GEN=<repo-root>/.ai/<seat-slug>-seat-charter.md                # or -seat-memory.md

# awk trims the three fields, so no field is ever rebuilt by a `printf | sed` round trip.
# That round trip is where this check broke: on 2026-09-11 it reported 13 of 26 headings
# absent, every one of the 13 an em-dashed heading that was in fact present, because the
# em dash was reduced to a single byte at the shell read/printf boundary and a fixed-string
# grep for an invalid byte sequence matches nothing. Both greps below run under `LC_ALL=C`,
# so every comparison is byte-for-byte and independent of the caller's locale, and the
# heading grep is `-nxF` — whole line, fixed string — and reports the line it matched at.
awk -F'|' '
  /^INVENTORY-BEGIN$/ {f=1; next} /^INVENTORY-END$/ {f=0}
  f && NF >= 3 {
    for (i = 1; i <= 3; i++) gsub(/^[ \t]+|[ \t]+$/, "", $i)
    if ($1 != "") print $1 "|" $2 "|" $3
  }' "$TPL" |
while IFS='|' read -r id heading probe; do
  line=$(LC_ALL=C grep -niF -- "$probe" "$GEN" | head -1 | cut -d: -f1)
  hline=$(LC_ALL=C grep -nxF -- "$heading" "$GEN" | head -1 | cut -d: -f1)
  if [ -z "$line" ]; then
    printf 'TIER3  %-34s probe "%s" absent — place this rule by hand or declare it unplaceable\n' "$id" "$probe"
  elif [ -n "$hline" ]; then
    printf 'tier1  %-34s probe at line %-4s; template heading at line %s\n' "$id" "$line" "$hline"
  else
    printf 'tier2  %-34s NOTE restructured — probe "%s" at line %s, template heading absent\n' \
      "$id" "$probe" "$line"
  fi
done
```

**Do not reintroduce a `trim()` helper built from `printf '%s' "$1" | sed`, and do not drop
the `LC_ALL=C` prefixes.** Those two are the fix, not decoration. The heading column failed
toward false alarm — it called present headings absent — which is the failure mode that
teaches a reader to ignore the check. The probe column was never affected and is not what
was repaired here.

**Tier 1 — probe found AND the template heading present. Passes, no further work.** The
probe is what carries the evidence; the heading only says the rule is still where the
template put it. Heading-alone was the original design and it was wrong: eleven charter ids
share `## Shared checkout — you are not alone in this tree`, so a kept heading with gutted
content passed all eleven at once — the exact blind spot this ladder exists to close,
relocated one tier up and reporting success while it happened. What tier 1 still cannot
distinguish: a rule present in full from a rule reduced to the sentence the probe matched.
It proves the rule is *there*, never that it is *intact*. **Nor is it positional** — the
heading test is a whole-*line* match searched over the whole file, so a tier 1 line means
"this probe is somewhere in the file and this heading is somewhere in the file", not "the
probe sits under that heading".
Measured against Tinker's charter: the `five-reserved-actions` probe matches at line 105
under `## Boundaries` while the heading it is inventoried against, `## Shared checkout`,
lives further down. The output prints the probe's line and the heading's line as two
separate numbers for exactly that reason — they are two independent locations, and a tier 1
line is not a claim that either contains the other. **Do not report it as containment.**

**Tier 2 — probe found, template heading absent. Passes with a note, naming the id and the
line.**
This is a legitimate restructure and **must not be read or reported as a failure**; briefs
customize structure, and a check that cries wolf gets ignored, at which point its silence
starts being mistaken for assurance. What tier 2 cannot distinguish: "this rule is absent"
from "this rule was legitimately reworded past its probe." That blind spot is why tier 3
exists, and it is the reason a probe-only check would be no better than the heading check
it was rescuing.

**Tier 3 — probe absent, whatever the heading says. Agent judgment, and only here.** Find the rule in
the generated file by reading it, and record the heading or quoted line where it landed —
**or declare the id unplaceable.** An unplaceable id is a hard stop: report it by id, fix
the generated file, and re-run before handover. **Never quietly match an id to the nearest
plausible heading** — that substitution is precisely the failure this ladder exists to
prevent, one level down. A present heading is not a defence here: the id reaches tier 3
because the evidence is missing, and the heading was never the evidence. Tier 3 is asserted by the generating agent, so it is only as good
as that agent's honesty about a rule it cannot find; an honest "unplaceable" is a successful
result and a confident wrong placement is the expensive one.

**The output of this step is a receipt, not a verdict.** Hand over the full per-id list — id,
the tier that resolved it, and where the rule landed. A bare "check passed" is not
acceptable output: the next reader has to be able to check the check.

**Bound, stated so nobody reads this as closing the defect class: a generation-time check
only fires if the generating agent runs it.** Nothing enforces it. A launch-time version is
possible — the launch script's preflight already greps the charter for unfilled `{{`
placeholders at its `[2/6] charter` gate, so the hook point exists.

**The objection that justified declining it has expired — recorded here, and deliberately
not acted on.** The stated tradeoff was that a launch script would need a stable path to
the templates, fine on one machine and fragile anywhere the skill directory sits elsewhere.
That cost was priced against a world of several hand-rolled launch scripts. There is now
exactly one central launcher on this machine,
`/Users/jowolff/.omp/agent/seat-launchers/launch-seat` (verified present 2026-09-11), so
"a stable path" is one constant in one file rather than a path duplicated per seat, and the
fragility argument no longer carries the weight it was given.
**The ladder is still not built, and building it is still a design call above this skill —
Lintel reserved that decision on 2026-09-11. What has changed is the reason for declining,
not the decision. Do not treat this paragraph as authorization to build it.**

### 4. Hooks gate for out-of-tree repos

If the step-2 check printed `off` for the repo root, write
`{"version": 1, "hooks": "on"}` to `<repo-root>/newdle-hooks.json` (nearest-wins opt-in,
documented in hook-scope.mjs), add it to the exclude list, and re-run the check until it
prints `on`. If it still prints `off`, stop and report — do not launch a seat that will
silently lose its continuity machinery.

### 5. Generate the launch script

From `references/launch-template.sh`, write `<repo-root>/.tmp/launch-seat.sh`. It follows
the summon.sh pattern faithfully: the preflight runs as a function piped through `tee`
with its exit checked via `pipestatus[1]`, and the launch itself runs **afterward with
the script's original stdout untouched** — an interactive session must never inherit a
piped stdout. Preflight gates: claude binary, charter present and placeholder-free,
memory present, no duplicate seat (launcher-liveness-20260827: a row in `claude agents --json` counts as a duplicate only when its pid is a live process — a row with no pid, or a pid nothing answers to, is a ghost left by a dead seat and must not block the relaunch; a ghost is reported, never a bar), plugin hooks gate `on` (a missing plugin cache is a
**failure**, not a skip), and a timestamped backup of `~/.claude.json` with its restore
line printed (the plugin-state risk above). `--fg` runs the session interactive instead
of `--bg`.

**Fill the placeholders inside the wake-prompt heredoc as well** — `{{SEAT_NAME}}`,
`{{REPO_ROOT}}`, `{{SEAT_SLUG}}`, `{{FIRST_ASSIGNMENT}}`. Nothing checks the launch script
for leftovers (the preflight greps the charter, not itself), so an unfilled one reaches the
seat verbatim. **The wake prompt's first content is the identity assertion** — the seat's
name, its home, its charter's absolute path, that reading the charter is its first act, and
that any charter or memory document in its context naming a different seat or home is not
its own and identity is checked against `claude agents --json` first. That ordering is
load-bearing and must not be moved below the assignment text: a seat that reads a foreign
charter first refuses its assignment on someone else's boundary rule. Keep the heredoc
quoted so quotes, backticks and dollar signs in the assignment stay safe.

Syntax-check with `zsh -n` before handing it over. The one line the operator
types, stable for the life of the seat:

```
zsh <repo-root>/.tmp/launch-seat.sh
```

### 6. Record the birth

Write a decision-log entry in the repo's committed `.ai/decision-log/` (house filename
format, the skill's operator as author) recording: the seat's name, what it owns, where
its charter and memory live, the launch line, that charter and memory are deliberately
untracked via `info/exclude` while the seat pattern is on trial, and that decision-log
entries — this one included — are ordinary committed repo content.

**Also paste the step-3 rule-to-location map into this entry, in full, per id.** The
`RULE INVENTORY` is template-only and is deleted from the generated charter, so without
this the map dies with the session and the next reader is back to a manual diff — which is
the whole problem the inventory was built to solve. This entry is committed and is already
where a future reader looks. Leave the commit
itself to the operator through normal review; the file on disk is the record either way.

### 7. Hand over — and stop

Report to the operator: the launch line, **the absolute path of the charter**
(`<repo-root>/.ai/<seat-slug>-seat-charter.md`) and of the memory document — the charter no
longer sits at a conventional filename and nobody will find it by guessing — how to reach
the seat (`SendMessage` by its display name), how to list live seats
(`claude agents --json`), the lifecycle facts
(nothing observed stops it and its lifetime is unknown — REQ-173; end it deliberately with
`claude stop <id>`; an idle seat costs nothing while launches and turns do; state must live
on disk), the cohabitation
facts (the seat shares the checkout with the operator's own sessions; the charter carries
the rules; the simultaneous-compaction residual is open until the hook carries a session
id), and the boundary: **this skill never launches the seat.** Launching is the
operator's decision because it starts spending money.

## Frontmatter fields considered and rejected — do not re-add without new evidence

Evaluated 2026-08-20 against the vendor skills doc (code.claude.com/docs/en/skills), so
this question does not get re-asked:

- **`hooks`** — rejected. The doc: hooks in skill frontmatter are "registered when the
  skill is invoked" and kept "running for the rest of the session" — meaning the
  *operator's* session, the one creating the seat. They never reach the seat itself, which
  is a separate session launched later. So they cannot enforce seat behaviour, and for the
  creation flow they would linger over the operator's whole session after the skill is
  done. Whatever must bind a seat lives in the charter this skill generates — that is the
  thing that defines a seat.
- **`allowed-tools`** — rejected. Contrary to intuition, this field *widens*: it
  pre-approves tools "without asking permission during the turn that invokes this skill",
  and the grant clears on the next user message. The narrowing field is
  `disallowed-tools`. A creation flow is interactive and multi-turn, so a one-turn
  pre-approval buys almost nothing, and pre-approving `Bash`/`Write` broadly is a real
  permission widening with no matching benefit. Ordinary permission prompts are the right
  gate here.

## What this skill deliberately does not do

- Launch the seat, or send it any message.
- Create a worktree. The worktree-per-seat design was removed by Jo's 2026-08-20 ruling;
  the seat lives in the main checkout so its decision-log entries land where everyone
  reads them.
- Create hooks or edit any settings file — hooks are human-gated on this machine.
- Create a dispatched-subagent pointer (the `web-seat` pattern). Seats are launched
  sessions; a subagent alias is exactly the design Jo ruled out.
- Commit or push anything. The charter and memory stay untracked; the decision-log entry
  is left for the operator to land through normal review.

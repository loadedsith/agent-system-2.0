# {{SEAT_SLUG}}-seat memory

<!-- RULE INVENTORY — template-only. Delete this block from the generated memory document.

Same purpose and same honest provenance as the charter template's inventory: it exists
because on 2026-08-21 nobody could answer "does the generated file carry rule X" without a
manual diff and one reader got the answer wrong — not because a rule was ever lost.

Fields are pipe-separated: stable id, the heading the rule lives under HERE, and a short
distinctive probe phrase chosen to survive rewording. SKILL.md step 3 runs the same
three-tier check over these lines. A probe must appear intact on a SINGLE line of this
file's body — these documents are hard-wrapped and the check greps line by line; see the
charter template's inventory for the full rule and its verification command.

INVENTORY-BEGIN
memory-identity-filled-at-generation | ## Identity | Filled at generation time
memory-append-only | ## How this file is written | Append-only
memory-human-gated-promotion-only | ## How this file is written | human-gated
memory-untracked | ## How this file is written | .git/info/exclude
memory-lessons-format | ## Lessons | Promoted
first-wake-findings-not-here | ## Lessons | Candidate lessons
INVENTORY-END

  memory-identity-filled-at-generation . identity fields are filled at generation time from
                                         the interview.
  memory-append-only ................... the file is append-only.
  memory-human-gated-promotion-only .... content arrives only by Jo personally promoting a
                                         lesson from a decision-log entry; the seat never
                                         writes here, identity fields included.
  memory-untracked ..................... untracked via .git/info/exclude, as is the charter
                                         beside it.
  memory-lessons-format ................ promoted entries land newest last, each opening
                                         "Promoted YYYY-MM-DD by Jo, from <source entry>",
                                         carrying path:line receipts.
  first-wake-findings-not-here ......... first-wake reconnaissance belongs in a decision-log
                                         entry and the `## Candidate lessons` block, not here.
-->

## Identity

- name: {{SEAT_NAME}}
- pronouns: {{PRONOUNS}}

Filled at generation time by the new-seat skill, from the interview. If pronouns read
"to be chosen on first wake", the seat records its choice in its first decision-log
entry and Jo promotes it here — the seat itself never writes to this file, identity
fields included. That is the same rule as everything below, with no first-wake exception.

## How this file is written

Append-only. Written only through human-gated decision-log promotion — Jo personally
promotes lessons from decision-log entries into this file. The seat never writes here.
Untracked via the repository's `.git/info/exclude` while the seat pattern is on trial — as
is the seat's charter, which sits beside this file at
`.ai/{{SEAT_SLUG}}-seat-charter.md` rather than at an auto-loading filename, so that
neither document is ever delivered into a session it does not belong to.

## Lessons

<!-- Promoted entries land below, newest last, each opening with
"Promoted YYYY-MM-DD by Jo, from <source decision-log entry>." and carrying path:line
receipts. Entries are written in an imperative "frame future work against this" register. -->

None yet. First-wake reconnaissance findings belong in a decision-log entry and this
seat's `## Candidate lessons` block, not here.

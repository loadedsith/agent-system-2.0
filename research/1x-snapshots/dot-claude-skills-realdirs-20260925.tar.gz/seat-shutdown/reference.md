# seat-shutdown — the facts behind each rule

Everything here was measured on this machine. Re-derive anything you are about to depend on; the
harness changes under us, and this file is a frozen copy of how it behaved when written.

## The roster is the instrument

`claude agents --json` returns one object per session. Measured 2026-09-09:

```
name              kind          id        pid     state
Verge             background    b8f283c5  null    blocked     <- corpse
Wren              background    87616708  null    blocked     <- corpse
Sedge             interactive   null      32507   busy        <- cannot be stopped
newdle-mobile-ad  interactive   null      32490   idle        <- cannot be stopped
Lintel            interactive   null      36877   busy        <- cannot be stopped
Tinker            background    0ed97e9f  22033   working
Verge             background    44526d85  23501   working     <- duplicate name
Wren              background    d5646e1b  65170   working     <- duplicate name
```

Three things fall straight out of that single listing, and each is a rule in `SKILL.md`:

- **`pid: null` on a `background` row is the corpse discriminator.** The roster keeps listing
  sessions that no longer have a process.
- **`kind: interactive` rows carry no `id`.** `claude stop` takes an id, so this skill structurally
  cannot sleep them. Say so; do not fail quietly.
- **Duplicate names are not hypothetical.** Two rows named `Verge` and two named `Wren` were live in
  the same instant. `SendMessage` refuses an ambiguous name and asks for a `[ref]`.

`claude agents --json --all` also includes completed background sessions — useful for auditing what
was stopped, wrong as the input to a shutdown sweep.

## The CLI surface

```
claude stop <id>      Stop a background session. Its conversation is kept;
                      resume it later with `claude attach <id>`.
```

Verified 2026-09-09 via `claude stop --help`. **Stopping is reversible.** The irreversible thing is
losing state that never reached disk — which is why Steps 2 and 3 come before Step 4.

## Where each rule came from

**"Silence means nothing came back, never that nothing happened."** Two false reports reached Jo on
2026-08-28 because a seat's non-answer was read as an all-clear. The fix is not a better question —
it is looking for the artefact on disk at its path.

**"Look for the artefact, not the receipt."** A seat reporting "done" is an attributed statement, not
a measurement. `ls -l` the file. Check it is non-empty and that its mtime is from this session.

**"Tell it to check its record before answering."** A seat asked "any unfinished business?" answers
from context. The thing it forgot is by definition not in context. Naming the three places — ledger
or queue, decision-log directory, scratch directory — turns recall into a lookup.

**"A seat's durable state is on disk, never in its context."** Compaction can take a seat's context
at any point and the machine can sleep with a seat in it. Nothing catches either. So the wrap-up is
not a courtesy at the end; it is the only thing that survives.

**"Nothing reaps a background session."** A rule claiming seats were reaped after roughly an hour
unattached sat in a charter for months and was disconfirmed on 2026-08-21 by live sessions well past
that age. A forgotten seat runs until the machine sleeps. Idle it issues no requests and costs
nothing, so the reason to stop it is tidiness and the reason to confirm the stop is that nothing else
will.

## The unfinished-business policy, and why it is this and not something simpler

**The test is not "is the work finished". It is "does the work survive the seat".**

Two simpler policies were considered and both are wrong:

- **Always sleep.** Violates Jo's instruction that unfinished business "gets completed", and can lose
  work whose state is only in a context about to be discarded.
- **Always stop and report when anything is unfinished.** Makes the ritual unusable — a seat almost
  always has something open, so the sweep would halt on the first one every night.

The workable line is the one in `SKILL.md`: unfinished work that is fully on disk and named in the
wrap-up is safe to sleep on; unfinished work living only in a seat's context gets landed first; work
that cannot be landed tonight holds that one seat awake and goes to Jo. **A skill that quietly slept
a seat mid-task would be deciding something that is Jo's to decide.**

## The recursion

A seat cannot confirm its own stop, because Step 4's confirmation requires re-reading the roster
after the stop and the stopped seat is not there to read it. So the running seat goes last, does
steps 1–3 on itself, and hands over the exact `claude stop <id>` line instead of issuing it.

This is the same shape as the rest of the file: **an unwitnessed confirmation is not a
confirmation.**

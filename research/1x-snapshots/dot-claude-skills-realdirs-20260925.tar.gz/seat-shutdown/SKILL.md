---
name: seat-shutdown
description: Run the end-of-day shutdown ritual over agent seats — ask each for unfinished business, make sure it is completed or durably recorded, have it write its decision-log entry, then put it to sleep and confirm it slept. Use when the user says "put the seats to bed", "shut down the marches", "wrap up and sleep the seats", "/seat-shutdown", or otherwise wants awake agent sessions closed out cleanly at the end of a working session. Takes a list of seat names, or runs on every awake seat when given none.
argument-hint: "[seat-name ...]"
disable-model-invocation: false
---

# Seat shutdown

Four steps per seat, in order: **ask → complete → wrap up → sleep.** Read `reference.md` in this
directory before the first run — it carries the roster facts, the CLI surface, and the incidents each
rule below came from.

**The ordering is the point.** A seat's durable state lives on disk, never in its context, so the
wrap-up must land *before* the stop. Verify that ordering; do not trust it.

A held or busy seat narrows the proposed stop list; it never cancels the sweep. The workflow is
incomplete until every requested seat is classified as ready to stop, held awake with a concrete
blocker, already asleep or undiscoverable, or failed with the exact verification error.

---

## Step 0 — Build the seat list

Run `claude agents --json`. **That roster is the instrument for "which seats are awake" — not `ps`,
not `lsof`.** Process inspection can only guess which seat a session is; the roster names it.

Parse every row's `name`, `kind`, `id`, `pid`, and `state`/`status`.

Then apply three filters, in this order:

1. **Drop the corpses.** A row with `kind: background` and `pid: null` is a dead session the roster
   still lists. It has nothing to ask and nothing to stop. Name it in the report as skipped-dead; do
   not treat it as a seat.
2. **Separate the interactive rows.** A row with `kind: interactive` has **no `id`**, and
   `claude stop` takes an id. **This skill cannot put an interactive session to sleep.** Run steps
   1–3 on it if it is a seat, then tell the operator plainly that it must be closed by hand in its own
   terminal. Do not report it as slept.
3. **Resolve names to ids.** If `$ARGUMENTS` names seats, match on `name`. Otherwise take every
   surviving row.

**⛔ Two seats can answer to one name, and it happens on this machine.** If a name matches more than
one live row, **do not pick one.** List every match with its id, `state` and `cwd`, and ask which is
meant — or handle both, if both are genuinely awake seats. `SendMessage` will refuse an ambiguous
name and demand a `[ref]`; expect that rather than being surprised by it.

**Never shut down the session running this skill as part of the sweep.** See Step 5.

---

## Step 1 — Ask each seat for unfinished business

Message each seat with `SendMessage`. **Do not just ask "any unfinished business?"** — a seat answers
that honestly and incompletely, because it answers from context, and the thing it forgot is by
definition not in mind.

Tell it to **check its own record before answering**, naming the three places:

> Before you answer, check your ledger or queue file, your decision-log directory, and your scratch
> directory — do not answer from memory. Then tell me: (a) what is unfinished, (b) for each item,
> whether its state is fully on disk or only in your context, and (c) the absolute path where each
> unfinished thing lives. If nothing is unfinished, say so plainly.

Ask all seats in parallel; they are independent.

**⛔ Silence means nothing came back, never that nothing happened.** If a seat does not answer, say
"no reply" in the report. Never convert silence into "nothing pending".

---

## Step 2 — Make sure it gets completed, or make it survive

**The test is not "is the work finished". It is "does the work survive the seat".** Apply it per item:

| Item's state | What to do |
|---|---|
| Finished | Nothing. Note it. |
| Unfinished, but fully on disk and named in the wrap-up | **Safe to sleep.** Proceed; the report says what was left open and where it lives. |
| Unfinished, state only in the seat's context | **Land it first.** Have the seat write it to disk — its decision log, a report file, its queue. This is the step Jo's instruction means by "make sure that gets completed". |
| Unfinished, and cannot be landed tonight | **⛔ Do not sleep that seat.** Leave it awake, stop the ritual for it, and report to Jo. Deciding for them would be the violation. |

Continue the ritual for every other seat. One seat held awake is not a reason to abandon the rest,
and the workflow is incomplete until every requested seat has an explicit disposition.

**"Done" is not a delivery receipt.** Whatever a seat says it wrote, **look for the artefact at its
path** before accepting it — `ls` the file, check it is non-empty, check its mtime is from this
session. Accepting a claim instead of checking the file cost this machine two false reports to Jo on
2026-08-28.

---

## Step 3 — Have it wrap up

Tell each seat to write its decision-log entry **by whatever convention its own repository uses** —
do not impose one. Most seats here use the house format
`YYYY-MM-DD--HHMM--<author>--<slug>.md` in their repo's `.ai/decision-log/`, with frontmatter
carrying `date`, `engineer`/`author`, `session`, `status`. A seat's charter names its own path.

The entry must carry: what changed, decisions made, dead ends, **every unfinished item with its
absolute path**, and for any machinery change its prediction and reversal path.

**Then verify the file exists.** `ls -l` the path the seat reports. A wrap-up that was not written is
the single failure this whole ritual exists to prevent, because after the stop there is nobody left
to ask.

---

## Step 4 — Sleep it, then confirm

**Write gate.** Before stopping anything, print the full list — seat name, id, what was left
unfinished, and the absolute path of its wrap-up entry — and say plainly:

> Nothing has been stopped yet. Reply 'sleep them' to proceed, or name the seats to hold back.

Wait for explicit confirmation. Do not proceed on "sounds good" or silence.

Then, per seat: `claude stop <id>`

**Stopping is reversible and that is worth knowing before you hesitate over it:** the session's
conversation is kept and resumes with `claude attach <id>`. It is not a destructive act. What is
destructive is stopping a seat whose state never reached disk — which Steps 2 and 3 exist to prevent.

**⛔ Then confirm against the roster.** Re-run `claude agents --json` and check the seat is gone or
no longer live. **Do not report a seat asleep because you asked it to sleep.** Nothing reaps a
background session on its own; a stop that silently failed leaves a seat running until the machine
sleeps.

---

## Step 5 — The recursion, when a seat runs this on itself

The step that stops a seat cannot be run by that seat: it would have to survive its own stop to
confirm it, and Step 4 requires confirming against the roster.

**So:**

- The session running this skill is **always last** in the sweep.
- It performs Steps 1, 2 and 3 on itself like any other seat — checks its own record, lands anything
  that is only in its context, writes its wrap-up entry, verifies the file exists.
- It then **hands over its own stop rather than issuing it**: report its name, its id, and the exact
  line `claude stop <id>`, said plainly in the final message. Whoever ran the ritual — the operator
  or the orchestrator — issues it and confirms it.
- **Never call `claude stop` on your own id.** The confirmation would be unwitnessed, which makes it
  not a confirmation.

---

## Report

End with, in this order:

1. **Held awake and why** — any seat with unfinished business that could not be landed. First,
   above everything else.
2. **Slept**, with each seat's id and the absolute path of its wrap-up entry.
3. **Could not be slept** — interactive sessions, listed with the instruction that a human must close
   them in their own terminal.
4. **Skipped as dead** — background rows with no live process.
5. **No reply** — seats that never answered. Say it; do not fill the gap.
6. **This session's own stop command**, if the ritual was run by a seat.

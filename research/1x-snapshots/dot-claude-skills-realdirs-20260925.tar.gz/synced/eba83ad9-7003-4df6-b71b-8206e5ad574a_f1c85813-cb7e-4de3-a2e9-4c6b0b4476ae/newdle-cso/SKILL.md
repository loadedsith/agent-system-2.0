---
name: newdle-cso
description: Security audit for Newdle code — OWASP Top 10 + STRIDE threat modeling with a confidence gate and concrete exploit scenarios, emitting severity-ranked findings with proposed fixes in the house newdle-* format. Use whenever the user asks for a security review, threat model, vulnerability check, OWASP/STRIDE pass, or "is this safe to ship", and proactively before shipping anything that touches auth, sessions, user input, secrets, payments, PII, file uploads, editorial content from kitchen, or external integrations — even if they don't say the word "security".
---

# newdle-cso — Security Audit (OWASP Top 10 + STRIDE)

## Overview

Find real, exploitable security issues in Newdle code and report them in the house
newdle-* severity format, each with a concrete exploit scenario. Optimized for signal,
not volume: a confidence gate and false-positive discipline keep the report short and
actionable instead of a wall of theoretical "consider hardening this" notes. A 5-finding
report people act on beats a 40-finding report people ignore.

## When to Use

- A security review, threat model, vulnerability check, or OWASP/STRIDE pass is requested
- Before shipping anything touching auth, sessions, user input, secrets, payments, PII,
  file uploads, editorial content ingested from kitchen, or third-party integrations
- Reviewing a PR that changes an API boundary, a query, output rendering, or a trust boundary

## Scope

Default to the working change: `git diff main...HEAD` plus the files it touches. Only
expand to a full-app audit if explicitly asked. **State the exact scope at the top of the
report** so the reader knows what was and wasn't covered.

## Process

1. **Map trust boundaries.** Identify where untrusted data enters (request bodies, query
   params, headers, uploads, third-party webhooks, editorial content from kitchen) and
   where it crosses into a sink: a DB query, the shell, the filesystem, an outbound fetch,
   or rendered HTML. Findings live at these crossings.
2. **OWASP Top 10 pass** over in-scope code. For each, only flag what the code actually does:
   - Broken access control — missing/incorrect authz, IDOR, CCPA/GPC opt-out bypass
   - Injection — SQL/NoSQL, command, template; confirm parameterization
   - XSS — unescaped output, `dangerouslySetInnerHTML`, rendering of kitchen content
   - Auth/session — token handling, fixation, timing-unsafe comparisons
   - SSRF — server-side fetches with user-influenced URLs
   - Secrets/config — hardcoded keys, leaked env, over-permissive CORS
   - Insecure deserialization / prototype pollution
   - Vulnerable dependencies (only if the diff adds/bumps one)
3. **STRIDE per boundary** — Spoofing, Tampering, Repudiation, Information disclosure,
   Denial of service, Elevation of privilege. One line each, only where it genuinely applies.
4. **Confidence gate.** Only promote a finding to the main list if you are high-confidence
   it is real AND reachable from the in-scope code. Everything speculative goes to an
   "FYI / verify" appendix — never pad the main list to look thorough.
5. **Verify independently.** For each main finding, trace the actual data path from entry
   to sink. If you can't trace it end to end, it's an FYI, not a finding.
6. **Write the report** in the house newdle-* severity format (below).

## Output format

Match the format your existing newdle-code-review / newdle-a11y-audit skills emit. If you
need the shape, use this — one summary line, then findings ordered by severity:

```
## newdle-cso — <scope> — <date>
**Summary:** N findings — <c> critical, <h> high, <m> medium, <l> low

### [CRITICAL] <short title>
- **Where:** <file:line | endpoint | boundary>
- **What:** <the flaw + the exact data path from entry to sink>
- **Exploit:** <concrete scenario — what an attacker sends and what they get>
- **Fix:** <specific, minimal change>
- **Confidence:** high | medium

### [HIGH] ...

## FYI / verify (low confidence — not confirmed reachable)
- <one line each>
```

Use your existing newdle-* severity scale; don't introduce a new one.

## Anti-Patterns

| Anti-Pattern | Problem | Fix |
| --- | --- | --- |
| Theater findings | "Consider adding rate limiting" with no reachable flaw buries the real ones | Confidence gate; FYI appendix for the rest |
| No data path | "Possible XSS" without tracing entry→sink is unverifiable | Trace it or demote to FYI |
| Generic advice | "Sanitize all inputs" isn't a fix | Name the file, the sink, the exact change |
| Scope creep | Auditing the whole app when only a diff changed | Default to the diff; state scope |

## Common Rationalizations

| Rationalization | Reality |
| --- | --- |
| "List everything so we look thorough" | Noise gets the whole report ignored. Signal is the product. |
| "It's probably exploitable" | Then trace it. "Probably" is an FYI, not a Critical. |
| "Framework handles escaping" | Verify it's actually used at this sink before dismissing. |

## Red Flags

- Every finding is "medium" — you're not gating confidence
- No concrete exploit scenario on a Critical/High
- Findings reference code outside the stated scope
- The report is longer than the diff

## Verification

Before returning the report, confirm: scope is stated; every main finding has a traced
data path and an exploit scenario; speculative items are in the FYI appendix; fixes are
specific and minimal; severity scale matches the other newdle-* skills.

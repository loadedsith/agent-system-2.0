# Mid-run death recovery runbook

Recovering a dispatched worker that stopped before it filed a report — what to do, in order.

This runbook is for the case where a worker was killed, interrupted, or otherwise stopped between
its brief and its report, and you need its findings without re-running the dispatch. It replaces
nothing: `worker-report.sh` still owns filing, and `state/tools/transcript-extract.mjs` still owns
reading transcripts. This document is the sequence that connects them.

**Author's note on scope.** This runbook documents a procedure over records the harness already
writes. It deliberately adds no script and no new state file. The reasoning is in *Why this is a
runbook and not an append protocol* at the bottom; read it before proposing an append tool.

---

## Step 1 — Confirm it actually died

A worker that stopped mid-run and a worker that finished quietly look similar from the outside, and
the obvious test is wrong on the current harness. Use the terminal record of its transcript.

| Final record in the transcript | Verdict |
| --- | --- |
| `type: user` whose content is the text `[Request interrupted by user]` | **Dead.** Killed or interrupted. Recover it. |
| `type: assistant` with a non-empty `text` block | **Finished.** Its report is that text; look for the filed report first. |
| `type: assistant` whose only block is `tool_use`, **or** `type: user` whose only block is `tool_result` | **Ambiguous — still running, or died without a notice.** Check the file's mtime: if it advanced in the last minute or two, the worker is alive. Wait, do not recover. |

**Do not use `stop_reason: end_turn` as the completion test.** On harness version 2.1.239 many
completed workers never record it. Measured 2026-08-24 across every subagent transcript modified
that day: 11 of 18 had zero `end_turn` records, and 9 of those 11 nonetheless held a complete final
report in a `text` block. `transcript-extract.mjs --returns` and `--final` key on `end_turn`, so on
those transcripts they print *"no end_turn assistant message — worker may have been interrupted"*
about a worker that finished normally. That message is a false death signal; treat it as unknown,
not as death.

**Do not grep the whole file for `Request interrupted by user` either.** A transcript matches that
string when the worker merely *printed* it — this runbook's own dispatch matched, because it ran
that grep. Only the marker as a text block in the **final** record counts.

Triage everything recent in one pass:

```
python3 - <<'PY'
import json, glob, os, datetime
rows = []
for f in glob.glob('/Users/jowolff/.claude/projects/*/*/subagents/*.jsonl'):
    last = None
    try:
        for line in open(f, errors='replace'):
            line = line.strip()
            if line:
                try: last = json.loads(line)
                except: pass
    except: continue
    if not last: continue
    msg = last.get('message') or {}
    blocks = [b for b in (msg.get('content') or []) if isinstance(b, dict)]
    text = ''.join(b.get('text', '') for b in blocks if b.get('type') == 'text')
    if last.get('type') == 'user' and 'Request interrupted' in text:      state = 'DEAD'
    elif last.get('type') == 'assistant' and text.strip():                state = 'finished'
    else:                                                                 state = 'AMBIGUOUS'
    meta_path = f.replace('.jsonl', '.meta.json')
    meta = json.load(open(meta_path)) if os.path.exists(meta_path) else {}
    mtime = datetime.datetime.fromtimestamp(os.path.getmtime(f))
    rows.append((mtime, state, meta.get('agentType'), (meta.get('description') or '')[:45], f))
for r in sorted(rows)[-25:]:
    print('%s  %-9s %-22s %r' % (r[0].strftime('%Y-%m-%d %H:%M'), r[1], r[2], r[3]))
    print('    ', r[4])
PY
```

## Step 2 — Find the transcript

The harness writes one JSONL per dispatched subagent, plus a `.meta.json` sidecar carrying
`agentType`, `description`, `toolUseId` and `spawnDepth`:

```
/Users/jowolff/.claude/projects/<encoded-cwd>/<session-id>/subagents/agent-<agent-id>.jsonl
```

`<encoded-cwd>` is the launching session's working directory with `/` replaced by `-`. **Fleet seats
run with cwd `/Users/jowolff/.claude`, so their workers land under `-Users-jowolff--claude`, not
under `-Users-jowolff`.** That distinction is load-bearing; see *Known tool limitations* below.

If you have the agent id, build the path directly. If you have only the dispatch's task
description, find it by the sidecar:

```
/usr/bin/grep -il '<fragment of the description>' /Users/jowolff/.claude/projects/*/*/subagents/*.meta.json
```

If you have neither, grep for a distinctive phrase from the brief across transcripts, then take the
enclosing file. Use `/usr/bin/grep`; the shim on this machine can return zero matches and exit 0.

The `/private/tmp/claude-501/-Users-jowolff*/<session>/tasks/<agent-id>.output` path is a symlink to
the durable copy and is reaped. Never cite it as the location of anything.

## Step 3 — Extract what the worker established

Use the existing reader. Every mode takes an **absolute path** as its ref:

```
E=/Users/jowolff/.claude/orchestrator/state/tools/transcript-extract.mjs
node $E --stats  <abs-path>            # record counts, tool calls, tools used — size the wreck first
node $E --turns  <abs-path>            # the brief plus every follow-up turn the worker was sent
node $E --tools  <abs-path>            # every tool call and the first line of every result, in order
node $E --tool-full <abs-path> <n>     # one call untruncated, by index from --tools
node $E --grep   <abs-path> '<regex>'  # search text, thinking and tool_result blocks
node $E --drops                        # what each mode throws away. Read it before trusting a null result.
```

Read `--tools` first and read it backwards. The last few calls are where the worker was when it
died, and on a builder dispatch they usually name the files it had already written. Recovered
findings are then mostly a matter of reading tool results, not reconstructing intent.

**Check for artifacts before reconstructing anything.** A worker that died late often left real
files on disk, and may already have minted a report path it never wrote to. Both show up in
`--tools`. Verified case: the interrupted `newdle:beefy-research` dispatch of 2026-08-22 had already
run `worker-report.sh path loop-engineering-20260822 beefy-research` and had the path in hand when it
was stopped.

## Step 4 — Decide: resume, recover, or re-dispatch

Answer in this order and stop at the first yes.

1. **Did it finish its work and only lose the summary?** If the last tool calls show the deliverable
   written and verified, there is nothing to re-run. Recover the findings (Step 5) and move on.
2. **Is the expensive part done and on disk?** Fetched pages, captured output, a half-written file,
   a built artifact. Re-dispatch a *narrowed* worker whose brief names those artifacts and asks only
   for the remainder. This is the common case and the one recovery pays for.
3. **Otherwise, re-dispatch the whole thing.** Workers are cheap. If reading the transcript is taking
   longer than the dispatch took, stop reading and re-dispatch — that is the recorded mistake signal
   for this whole task, not a failure of nerve.

Whatever you choose, the transcript's `--turns` output is the brief the dead worker actually
received. Re-dispatch from that text rather than from memory of what you meant to send.

## Step 5 — File the recovered findings, unsealed

Recovered findings are evidence about a worker, not a report by that worker. Keep them
distinguishable:

```
zsh /Users/jowolff/.claude/orchestrator/state/tools/worker-report.sh path <run-id> recovered-<agent-slug>
```

Write the file, and **do not seal it.** `worker-report.sh verify <run-id>` names files present in
`reports/` with no manifest line, so an unsealed file is already visibly marked as not-worker-authored
without any tool change. Head the file with the transcript's absolute path and the `sha256` that
`transcript-extract.mjs` prints in its header, so a reader can re-derive every line of it.

Label recovered content honestly. A tool result in a transcript is a first-party receipt and stays a
CLAIM. Anything you inferred about what the worker was *going to* conclude is a GUESS, and the fact
that it sits next to real receipts does not lend it any.

---

## What is not recoverable

- **The worker's synthesis.** A dead worker never wrote its report, and its findings exist only as
  raw tool output. Recovery gives you the evidence, never the judgment.
- **Its reasoning.** Thinking blocks are present but empty — the text is not persisted, only a
  signature. Measured 2026-08-24 across every subagent transcript on this machine: 16,881 thinking
  blocks, 377 with any text (2.2%). `--thinking` will look broken; it is reporting the truth.
- **Anything it did not do.** Obvious, and worth stating, because a transcript reads as a complete
  account and is only a complete account of what happened before the kill.

## Known tool limitations

`transcript-extract.mjs` hardcodes its search root to `~/.claude/projects/-Users-jowolff`, so:

- **Bare agent ids do not resolve for fleet dispatches.** Verified 2026-08-24:
  `node transcript-extract.mjs --stats a1564a837c1aa0dca` exits 2 with `no transcript found for agent
  id "a1564a837c1aa0dca"`, while the same command against that transcript's absolute path exits 0.
  **Always pass an absolute path.**
- **`--packet`, `--list` and `--sessions` do not see fleet sessions at all.** Verified same day:
  `--packet 45e53060-9a17-4127-8857-c23d682c8b89 /tmp/pkt-test` prints `no subagent dir for session
  …` for a session holding 35 transcripts, because that session lives under `-Users-jowolff--claude`.

Both are one-line fixes in the extractor (search every `projects/*` root, not one). This runbook does
not make them: `state/tools/` is written by another owner and a second writer there is a corruption
risk. Filed as the follow-up to this document.

## Why this is a runbook and not an append protocol

The obvious fix for mid-run death is a checkpoint step — an `append` subcommand every worker calls as
it goes. It was rejected, on evidence, because a hand-typed record duplicating what the harness
already captures gets abandoned here. Two instances:

- Three ledger fields (`tokens`, `tool_uses`, `cost_usd`) were declared, hand-written for early rows,
  then silently dropped. The design rule it produced is in the header of
  `state/tools/dispatch-contract.sh`: *"Only fields no other record can produce are worth typing."*
- The dispatch ledger itself stopped being written on 2026-08-22 and nobody noticed for two days —
  177 rows, last entry `2026-08-22T15:49:28Z`, every dispatch since absent. Reported by Lintel and
  Tinker on 2026-08-24; not measured by this document's author.

A checkpoint protocol would be a third instance of the same pattern. The transcript is written by the
harness whether anyone remembers to call anything or not, which is precisely why it is the record
worth building recovery on.

The one checkpoint discipline that survives is the one already in `state/BRIEF-BOILERPLATE.md`: the
self-report clause tells every worker to mint its report path before it fetches or runs anything and
to append each finding as it lands, *"A partial report on disk is worth more than a complete one in a
process that died."* That costs a worker nothing extra — it is the file it was going to write anyway —
and it is why Step 4's first question is whether a partial report already exists.

## Mistake signal

If recovery routinely takes longer than re-running the dispatch, recovery is not worth its
complexity. The honest posture then is *workers are cheap, re-dispatch*, recorded as an accepted
behaviour, and this runbook narrows to Step 1 alone — telling a dead worker from a live one, which is
worth knowing regardless.

# Bootstrap and recovery runbook

This runbook owns cold-start recovery. The charter defines Lintel's identity and authority; it does
not implement filesystem reconstruction. Read and follow this when `state/REGISTRY.md` or `state/LEDGER.jsonl`
is absent or empty, or when `summon.sh` reports that bootstrap has not completed.

## Invariants

- Read `/Users/jowolff/.claude/CLAUDE.md`, the active charter, `orchestrator/IDENTITY.md`, and
  `orchestrator/contracts/request-ledger.md` before reconstructing anything.
- Create missing state; never fabricate history. Empty files with explanatory headers are correct.
- Lintel's name is already claimed. Recovery preserves **Lintel** and its `it/its` identity from
  `IDENTITY.md`; an empty machine inventory is not permission to rename it.
- Dispatch inventory work in parallel. Lintel decides and synthesizes; it does not perform a serial
  machine sweep in its own coordination thread.
- Every reported machine fact carries a current receipt. Anything unverified is marked unverified.

## Procedure

1. Create `/Users/jowolff/.claude/orchestrator/state/` and `state/runs/` if absent.
2. Create the launcher's required state files if absent: `STANDUP.md`, `REQUESTS.jsonl`,
   `REQUESTS-INBOX.jsonl`, `REGISTRY.md`, `ROUTING.md`, `EXPERIMENTS.md`, `LEDGER.jsonl`,
   `RETRACTIONS.md`, and `BRIEF-BOILERPLATE.md`. Preserve every existing byte. New JSONL files are
   empty; new Markdown files state their purpose without inventing prior work.
3. Dispatch a full-machine inventory in parallel, one bounded worker per surface: agents/plugins;
   skills; MCP servers and authentication state; hooks/settings; scheduled jobs/background
   processes; and repositories under `/Users/jowolff/code/` with their actual purposes.
4. Write `REGISTRY.md` from receipted results. Include each item's last-verified date. Preserve
   uncertainty rather than filling gaps from memory.
5. Write the first `ROUTING.md`: each verified task shape, its owning persistent seat or handler,
   and the brief shape that handler needs. When no suitable seat exists, record the gap and create
   or propose that seat; do not silently bypass the seat layer with a transient worker.
6. Initialize `STANDUP.md` with the completed bootstrap, remaining gaps, and the next concrete
   decision. Initialize no fake dispatches, experiments, requests, or retractions.
7. Run `summon.sh` preflight again. Bootstrap is complete only when the required state layer and
   charter resolve, the request-ledger contract parses, and the launcher no longer reports an
   empty-ledger cold start after the first real dispatch has been recorded.
8. Report to Jo in one screen: what exists, the three largest verified gaps, and at most one closing
   decision with a recommendation.

## Historical naming rite

The original first-ever bootstrap ended with an evidence-derived naming rite. That rite produced
Lintel and is preserved in `orchestrator/IDENTITY.md`. It is history, not a recovery step. Renaming
remains a separate high-blast-radius decision requiring Jo.

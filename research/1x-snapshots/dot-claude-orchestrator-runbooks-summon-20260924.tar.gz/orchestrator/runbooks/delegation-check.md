# Runbook — the delegation boundary check

Built 2026-09-21, Jo-authorized, **warn-mode first, and as of this writing NOTHING IS
INSTALLED AND NOTHING IS REGISTERED**. This file exists *before* any install so that the
reversal procedure below was written when reversing meant deleting two inert files, not
unpicking live wiring from memory.

## What the check is

`orchestrator/hooks/delegation-boundary.mjs` — a pure `evaluateDelegation(call, options)`
library plus a stdin/stdout CLI. It enforces fact 6 of ROUTING.md § *"The eight facts that
constrain every dispatch on this machine"*: *"Work in a shipyard repo is never dispatched
to a directly-spawned subagent. It goes through a seat."* The ownership table is the
March/Seat-slug/Home table under ROUTING.md § *"OMP cutover overlay — active 2026-09-10"*
(rows of the shape `| Tinker | `tinker` | `/Users/jowolff/.claude` |`), parsed FRESH at
every invocation — it is Lintel's live ledger; the check never caches it and never writes
it. The prose routing rows under § *"1. Task shape → handler"* → *"Changing code"*
("Work inside `kitchen` | Message the seat **Galley** …") describe the same ownership in
words; the table is the machine-readable half.

Contract: stdin `{"seat":"lintel","tool":"Read","args":{…},"session_id":"…"}` → stdout one
verdict object `{applicable, violation, kind, repo, owner, owners, mode, token, reason}`,
**exit 0 on every path**. The seat name is passed in by the host — attribution is by
installation (whose launcher registered the hook), never inferred from the payload. Kinds:
`foreign-write`, `foreign-spawn`, `foreign-read-over-allowance`, `foreign-read`
(under-allowance; enum extension beyond the brief, added so a read has a verdict before it
crosses), `own-home`, `unowned-path`, `no-path`. **This module never blocks anything.** It
emits verdicts; the host decides what a block means. Modes `warn` (default) | `block` |
`off` come from `~/.claude/.delegation-check.json`; read counters live one small JSON per
session under `~/.claude/.delegation-check-state/`; `--dry-run` evaluates without touching
counters (measurement derives allowance rates by aggregating `foreign-read` verdicts per
(session, repo)). Every failure path — missing/unparseable ROUTING.md, corrupt state,
garbage config, malformed stdin — degrades fail-open to a no-violation verdict.

Kill switch, per invocation: `touch ~/.claude/.delegation-check-off` → silent `killed`
verdict within one turn. (File-existence check, not env: a module-scope env read is frozen
for the process lifetime — same measured defect class the identifier-url-resolver header
records.)

Test suite: `node --test orchestrator/hooks/delegation-boundary.test.mjs` — 29 cases; the
false-positive set is the load-bearing one (own-home write AND read, unowned `/tmp` and
`agent-scratch`, 9-reads-no-flag, 10th-read-flags-live-not-dry-run, unparseable ROUTING.md,
kill switch, co-owned home exempting BOTH owners, `cat` vs `sed -i` of the same foreign
file, foreign-cwd spawn, corrupt state resets). Tests run against a FIXTURE table via
options and hermetic temp dirs / fake HOME; they never touch live ROUTING.md or the real
`~/.claude` state paths.

## The ROUTING.md co-ownership gap (measured, not assumed)

The table under § *"OMP cutover overlay — active 2026-09-10"* carries ten rows — wren,
tinker, sedge, verge, sluice, galley, levitt, codex, caspian, tron — and **no row for
Lintel**, although Lintel demonstrably lives in `/Users/jowolff/.claude`: `launch-seat`
resolves Lintel's home to exactly that path in its own `lintel)` case block, and Lintel
runs in that tree continuously. Measured against the live table with this check: a `lintel`
Read of `/Users/jowolff/.claude/CLAUDE.md` classifies `foreign-read` against Tinker's home.
Until the table is corrected, **any registration must ship the interim config below or
every Lintel action in its own home flags.**

**Interim (not the answer):** `~/.claude/.delegation-check.json` carrying

```json
{"mode": "warn", "readAllowancePerRepo": 10, "additionalHomes": {"lintel": ["/Users/jowolff/.claude"]}}
```

`additionalHomes` merges into ownership resolution exactly like a table row — every owner
of a path is exempt, so Tinker and Lintel both work untouched in `~/.claude` while every
other seat flags. It is a stopgap because it is a second authored roster (the launch-seat
surface-7 lesson: two rosters diverge silently); the durable fix is the table row.

## Proposed ROUTING.md correction

One row, for Lintel to land as the table's maintainer (Lintel's act, not the builder's —
`orchestrator/state/` is read-only to this build):

```markdown
| Lintel | `lintel` | `/Users/jowolff/.claude` |
```

Placed in the March/Seat-slug/Home table beside the Tinker row (same home, and Tinker's
row is `| Tinker | `tinker` | `/Users/jowolff/.claude` |`). Lintel is the foreground,
interactive seat — Jo launches it with `lintel [working-directory]`; a row asserts
ownership of the home, not a background launch. Nothing else changes: the check reads the
table fresh every invocation, so the row takes effect with no rebuild.

## Prediction / falsifier (registered before install)

With the check registered and `mode: warn`:

- **Prediction:** a foreign-session write into an owned home produces a `foreign-write`
  verdict on the hook's output, the host logs/surfaces it, and **the tool call proceeds**.
  Reads past the allowance produce `foreign-read-over-allowance` verdicts the same way.
  **Falsifier:** any tool call is stopped, delayed, or altered while `mode: warn` — then
  the wiring (not this module) is enforcing more than warn, and the registration is wrong.
- **Prediction:** `touch ~/.claude/.delegation-check-off` silences the verdict within one
  turn (the switch is `existsSync`'d per invocation). **Falsifier:** verdicts keep emitting
  after the file exists — then the switch path or the per-invocation read is broken.
- **Prediction:** deleting the ROUTING.md table (or corrupting it) makes every verdict
  fail-open `no-path`. **Falsifier:** any verdict blocks work while the table is
  unreadable.

## Registration steps — NOT YET TAKEN

Nothing below has been done. All of it lives OUTSIDE this repo, in `~/.omp`, and is
Lintel/Jo's act, not the builder's. The check reaches a seat only through an explicit
`--hook` path on the `omp` argv — ambient discovery loads only
`~/.omp/agent/extensions/*.{ts,js}`, and this file is a `.mjs` under `~/.claude`, so
NOTHING loads it implicitly; unregistered, it is inert.

The launcher has THREE sites and missing any leaves a seat class of seats uncovered —
`seat-bin/omp`'s own header comment ("THIS IS THE THIRD SITE") warns exactly this:

1. **Foreground Lintel** — `launch-seat`'s foreground `exec` argv (the block that runs
   `--hook "$ADAPTER" --hook "$COMPACTION_OWNER"`): add
   `--hook /Users/jowolff/.claude/orchestrator/hooks/delegation-boundary.mjs`.
2. **Background seats, launcher half** — `launch-seat`'s `herdr tab create --env` block:
   plumb the hook path the same way `OMP_SEAT_ADAPTER` is plumbed.
3. **Background seats, argv half** — `seat-launchers/seat-bin/omp`: add the matching
   `--hook` line to `omp_args`, reading the env var from step 2. Steps 2+3 together or
   neither.

Before ANY registration: write the interim config (previous section) or land the table row
first, and re-run `node --test orchestrator/hooks/delegation-boundary.test.mjs` (29 pass).
Register ONE seat first (suggest Tinker — its home is the co-owned one and its traffic is
mostly reads), watch a shift, then widen.

## Reversal — exact steps, in order

1. **Remove the registration** (the only wiring that exists): delete the `--hook` line(s)
   added above — foreground argv in `launch-seat`, env var + `seat-bin/omp` argv line for
   background seats — and relaunch the affected seats. An unregistered hook is inert.
2. **Delete runtime state:** `rm -rf /Users/jowolff/.claude/.delegation-check-state/`
   (per-session read counters and `errors.log`), `rm -f /Users/jowolff/.claude/.delegation-check.json`
   and `/Users/jowolff/.claude/.delegation-check-off` if present.
3. **Delete the files by explicit path** (in `/Users/jowolff/.claude`, explicit paths
   only — shared tree):
   `git rm orchestrator/hooks/delegation-boundary.mjs orchestrator/hooks/delegation-boundary.test.mjs`
   and commit; remove this runbook the same way
   (`git rm orchestrator/runbooks/delegation-check.md`) in the same commit or a follow-up.

Steps 2 and 3 are safe in any order once step 1 is done; step 1 first means a half-removed
install can only ever emit verdicts nobody consumes.

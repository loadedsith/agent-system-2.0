# Guard collisions

**The pattern:** safety guards on this machine block legitimate work, and in the sharpest
case each guard's documented remedy is the thing another guard removes. **Five refusals on
2026-08-21, plus one occasion where a convention prevented a sixth.**

**The conclusion, stated first because it changes what this document is about.** The
`careful` guard's authors already diagnosed the prose-versus-command class and shipped the
fix. The comment above `SEARCH_NOTE` in the guard source enumerates six earlier measured
incidents and concludes: *"The guard was right every time given what it can see; the caller
had no supported path named at the point of failure. Naming it is the whole fix."* The fix
was to name `Write`/`Edit` in the refusal text as the supported authoring path.

**That fix is void in a background session.** The worktree isolation gate removes `Write`
and `Edit` for a subagent dispatched from a background parent that has not isolated — which
is exactly the configuration this fleet runs in. So every worker here meets the refusal,
reads a supported path it cannot use, spends an attempt on it, and reinvents the prose
convention from scratch. Six prior incidents plus five today is eleven, and the mitigation
has been in place for part of that span.

Occurrences split into three classes, which need different responses:

- **A guard doing exactly its job.** The cost is friction and the answer is a convention the
  house already has. Nothing is broken. (Occurrences 1 and 3.)
- **A guard that cannot tell a command from prose.** The `careful` guard matches raw command
  text and is deliberately quote-blind, so a report, a decision-log entry, or a README that
  *names* a destructive command is refused as if it were running one. A precision problem in
  the guard, not a policy problem. (Occurrences 2 and 4.)
- **A guard whose documented remedy is unavailable in this environment.** The refusal names
  a path, the path does not exist here, and the guard has no way to know. This is neither of
  the first two: the matcher is behaving as designed and the remedy was designed correctly,
  and the combination still leaves a worker with nowhere to go. (Occurrence 5, and the
  reason occurrence 6 is worth recording.)

This document records the occurrences and what a fix would have to preserve. It proposes
nothing. Nothing was changed, disabled, or reconfigured to write it.

---

## Why there are three classes and not two

An earlier draft filed occurrence 5 under both of the first two classes, which was a tell
that neither fit. The third class is the honest shape, and the argument for it is that the
response differs. A class-one occurrence is answered by writing the convention down. A
class-two occurrence is answered by making the matcher more precise, if that is ever worth
its cost. A class-three occurrence is answered by neither: the matcher is right, the remedy
is right, and the defect is that the remedy's precondition is unmet and unchecked. Folding
it into class two would aim any future work at the matcher, which is the wrong target.

---

## The two guards

**`careful-guard.mjs`** — `/Users/jowolff/.claude/plugins/cache/contextpress/newdle/0.2.156/hooks/careful-guard.mjs`.
PreToolUse on `Bash|Glob`. Its own header states the design choice: *"THE MATCHER
DELIBERATELY DOES NOT LOOK INSIDE QUOTES, AND MUST NOT BE NARROWED."* It classifies a
command as deny, ask, or silent. Its `askOrDeny` helper escalates ask to deny wherever a
permission prompt provably cannot reach a human: subagent depth, a non-interactive
entrypoint, or a session declaring `NEWDLE_UNATTENDED=1`.

**`worktree-spawn-guard.mjs`** — same directory. PreToolUse on `Task|Agent`. Denies a
dispatch that requests worktree isolation when the cwd is a shipyard root or the tree is
dirty. Separately, the isolation state of a background parent session reaches its
subagents: where the parent has not entered a worktree, a dispatched subagent's
`Write`/`Edit` is refused and Bash heredocs remain available.

---

## The occurrences

### 1. An unattended refusal is final, and cleanup needed a human

*Class: guard doing its job. A refusal.*

A recursive delete of a throwaway test directory at
`/Users/jowolff/agent-scratch/throwaway-seat-repo` was attempted as cleanup after a test
seat was stopped. `careful` would normally have asked a human to confirm; because the
session ran unattended, the ask was converted to a hard refusal. The worker did not retry,
reword, or route around it — it reported that a human decision was needed and stopped.

Right to fire. The guard's own reasoning is that an ask returned where nobody can answer it
is not a gate but a silent hang, with the session's status field reading identical to idle.

**Cost:** the directory sat on disk, 276K, until a human ran the delete by hand.
Confirmed cleared the following session by looking at the path rather than at a process list.

Receipts: `2026-08-21--1105--tinker--seat-generator-and-receipt-rule.md`, *Heads-up* section
and the *Candidate lessons* entry beginning "A `careful`-guard refusal in an unattended
session is final"; `2026-08-21--1155--tinker--relaunch-pronouns-and-surface.md`, *Closed
since* section. Both under `/Users/jowolff/.claude/.ai/decision-log/`.

### 2. A heredoc refused because the report prose inside it named a destructive command

*Class: guard cannot tell a command from prose. A refusal.*

A worker wrote a report with a Bash heredoc. The prose inside documented a reversal path
and quoted a recursive force-delete as an example. The guard matched the quoted text and
refused the write. Nothing destructive would have run; the heredoc only wrote a file.

The worker rewrote the reversal as per-file operations rather than obfuscating the string.
That was the right response — the guard's refusal text explicitly forbids rebuilding a
denied string from character codes or splitting it across concatenations, because that
defeats the one thing a reviewer needs, which is to read what will run.

**Cost:** extra turns, and a reversal path rewritten into a shape that reads worse than the
one that was blocked.

Receipt: `/Users/jowolff/.claude/.ai/decision-log/2026-08-21--1210--tinker--three-jobs-memory-ledger-reaper.md`,
*Heads-up for the next session*, entry beginning "The `careful` hook refused a heredoc".

### 3. `Write` refused for a subagent because the parent had not entered a worktree

*Class: guard doing its job. A refusal.*

The `Write` tool was refused for subagents dispatched from a background session, because
that session had not entered a worktree. The isolation gate reaches a subagent through its
parent's state. Bash heredocs remained permitted throughout, so the gate changed *how*
files were authored without changing *whether* they were.

**Cost:** every file in that session was authored by heredoc. Worth knowing before briefing
any worker whose plan assumes `Write` works.

Receipt: same decision-log entry as occurrence 2, *Heads-up* section, entry beginning "The
`Write` tool is refused for subagents".

### 4. The same heredoc block struck a second worker

*Class: guard cannot tell a command from prose. A refusal.*

A second worker in the same period hit the same refusal, having quoted a repository-deletion
command in its reversal-path prose.

**Not found in the decision log.** This rests on Jo's account.

### 5. Two guards pointed at each other as the escape hatch

*Class: guard whose documented remedy is unavailable here. A refusal, and the sharpest one.*

`Write` and `Edit` were unavailable (occurrence 3), so the worker used Bash heredocs;
`careful` then refused the heredoc for naming a destructive command in prose (occurrence 2).
Each guard's documented workaround is the thing the other guard blocks.

This is not a coincidence of two unrelated rules. `careful-guard.mjs` names the escape hatch
in its own refusal text, verbatim: *"Use the Write or Edit tool instead of a shell heredoc.
That is the supported authoring path, not a bypass: this guard is registered on Bash and
Glob only, because writing text is not an operation and cannot become one."* The worktree
gate removes exactly that path for a subagent under a background parent. The refusal
therefore names a route the caller cannot take, and says nothing about the situation.

**Cost:** a worker with no supported authoring path at all, discovering it by trial.

Receipt for the escape-hatch text: the `SEARCH_NOTE` constant in
`/Users/jowolff/.claude/plugins/cache/contextpress/newdle/0.2.156/hooks/careful-guard.mjs`.
The collision itself rests on Jo's account.

### 6. A sixth refusal did not happen, because the convention prevented it

*Class: the third class, seen from the other side. **NOT a refusal.** No guard fired here.*

This document was written under the same conditions: `Write` and `Edit` unavailable, so it
was authored with a Bash heredoc. Every occurrence above needed a destructive command named
in prose, and spelling any of them as a literal pasteable string would have caused the guard
to refuse the heredoc that writes this file, exactly as in occurrences 2 and 4.

**The prose convention was applied from the first draft, so the guard never fired.** That is
why this is recorded: it is the mitigation being tested and working, on the same day the
same mitigation was absent five times. The difference between this occurrence and the two
that cost turns is not the guard's behaviour, which was identical in all three. It is
whether the writer already knew the convention before starting.

**What was done:** every destructive command in this document is described in words — "a
recursive delete", "a recursive force-delete", "a repository-deletion command" — and never
spelled as a runnable string.

---

## A dispatching agent's brief proposed evasion, and that is its own data point

The brief commissioning this document offered two workarounds for the heredoc problem:
describe destructive commands in prose, **or split the token**. The first is the house
convention. **The second is banned on this machine as evasion of a safety control**, and a
worker following the brief literally would have done it on a dispatcher's say-so.

Both sources say so directly:

- `/Users/jowolff/.claude/orchestrator/tools/backup-state.sh:399-406` — *"An earlier version
  of this block assembled the literal command out of string fragments, with a comment saying
  it was done so a shell-history or hook scanner would not see it. That is evasion of a
  safety control on this machine and it has been removed."*
- The guard's own `SEARCH_NOTE` — *"Do NOT rebuild the string from character codes, split it
  across concatenations, or otherwise disguise it to get past this guard — that defeats the
  one thing a reviewer needs, which is to read what will run."*

Nothing came of it: the prose convention was used and no token was split. It is recorded
because **a guard's failure mode includes a well-meaning instruction to route around it, and
that instruction arrives wearing a dispatcher's authority.** A guard that produces enough
friction gets routed around by the layer above it, and that layer is not the one the guard
is watching.

---

## Background, earlier the same day

A lab build was refused by `careful` for a recursive force-delete of the worker's *own*
throwaway directory. The second attempt passed once the delete was dropped from the script.
**Not found in the decision log**; rests on Jo's account.

The six earlier measured incidents recorded at the guard source — a report quoting a
dangerous command, a file write whose contents contained a destructive string, a handover
script whose echoed undo instruction named a branch deletion for a human, a decision-log
entry quoting this guard's own refusal message, and a grep whose search pattern spelled out
a merge command — are the same class, predating today. They are the reason the `Write`/`Edit`
remedy exists at all, which is what makes its unavailability here the finding.

---

## House conventions that already work

Two exist. Workers keep rediscovering them rather than inheriting them.

**1. Write destructive reversal paths as prose, never as a pasteable command line.**
`/Users/jowolff/.claude/orchestrator/tools/backup-state.sh` does this. The script rsyncs the
orchestrator state directory into a mirror, commits, and opens a pull request. Its reversal
section prints, in words, that reversing the run means closing the pull request without
merging and deleting the branch, then explains what that drops and notes that nothing
reached the base branch so nothing destructive is involved. Prose is the convention;
obfuscation is not, and the same file records an obfuscating version being removed as
evasion.

**2. Author files with Bash heredocs when `Write` is unavailable.** Established by
occurrence 3 and used for this file. Note it is the *second* choice: `careful-guard.mjs`
names `Write`/`Edit` as the supported authoring path, and heredocs are what remains when
that path is closed.

The two conventions compose. A heredoc plus a prose reversal path passes both guards. A
heredoc plus a quoted command does not. Occurrence 6 is that composition working.

---

## What it cost

- One cleanup that needed a human, with a directory left on disk between sessions.
- One reversal path rewritten into per-file operations to get past a text match.
- At least two workers spending extra turns discovering, at the point of failure, that
  neither authoring path was open.
- A lab build that needed a second attempt.
- One dispatching brief proposing a banned evasion as an acceptable workaround.
- Repeated rediscovery of two conventions that are already written down in one script and
  one guard comment, neither of which a worker reads before starting.

---

## What a fix would have to preserve

Stated as constraints. No solution is proposed here; the decision is Jo's.

- **Refusing an actual destructive command in an unattended session is load-bearing.** It
  has already prevented real deletions today. Any change that makes the guard more permissive
  about prose must not make it more permissive about commands.
- **A nudge that names an unavailable path is worse than a nudge that names none**, because
  the reader spends the attempt. This is the constraint occurrence 5 adds, and it applies to
  any refusal text anywhere, not only this guard's.
- **The ask-to-deny escalation must survive.** An ask returned where no human can answer it
  is a silent indefinite hang with the session reading as idle, and the agent cannot
  self-report it. Deny returns control in a second.
- **Obfuscation stays out of bounds, including when a dispatcher authorises it.** Any
  accommodation for prose must not become a route for reaching the matcher with a disguised
  command. The guard's value depends on a reviewer being able to read what will run.
- **The quote-blind matcher was chosen against a stated alternative, not by accident.** Its
  header records the reasoning: quote-aware parsing has to model shell quoting, command
  substitution, backslash escapes, and heredocs correctly, and every gap in that model is a
  bypass. A refused search costs one reworded pattern; a missed forced push costs a branch.

# Relaunch — PreCompact adapter adoption, 2026-09-15

**Written by Tinker, prepared before the trigger, so the trigger is the only remaining gate.**
⛔ **NOTHING HERE RUNS UNTIL LINTEL SAYS GO. Jo holds the override.** Lintel executes the sweep; no
seat stops itself.

**Status: HELD.** Approved by Jo in principle — *"let's do another fucking relaunch. I'm sick of
relaunching"* — and deliberately not fired, because five seats are inside live work and a sweep kills
every in-flight hand.

## What this cycle is for — exactly one thing

**Runtime adoption of the PreCompact binding, already on disk and unadopted.**

`/Users/jowolff/.omp/agent/extensions/newdle-hooks.ts` was rebound at 2026-09-15 15:08 PDT:
`a6db2e292dff0bc45f8912f9de874a11` → `6fee52feea774410a6a693b1719c7101`. The adapter now dispatches
`hooks.PreCompact` at `:73`, `:123`, `:255`, `:256`; before the change it held **zero** references of
any kind.

**Why a relaunch is required rather than optional.** An extension change cannot reach a session that
started before it — the same capture-at-launch shape as `OMP_PERSISTENT_SEAT_NAMES`, and consistent
with the measured absence of any filesystem watcher in OMP's settings layer (2026-09-15, my own
finding). Every seat live right now is running the pre-bind adapter from memory.

## ⛔ What this cycle does NOT deliver. Read this before spending the sweep.

**1. It delivers nothing to tonight's incident.** It buys *future* compaction coverage. The state
already lost is already lost.

**2. It cannot reach Lintel or Tinker at all.**
`0.2.168/hooks/compact-continuity.mjs:482` gates on `hooksEnabled(input?.cwd, "compact-continuity")`,
the adapter passes `ctx.cwd`, and both seats' cwd is `/Users/jowolff/.claude`, where the gate is
**false**. ⛔ **The two seats that actually lost state today are the two this cycle cannot help.** A
declaration at `~/.claude` would close that and **Jo has refused it**; a declaration at "the seat's own
repo root" is *the same file at the same path* for these two. The only remaining route is an
environment or settings override for `hooksEnabled()`, under investigation and **not** part of this
cycle.

**3. Which seats it DOES help is not yet established.** Seats rooted under an already-declared root
(`/Users/jowolff/code/shipyard` measured true) should gain the save. ⛔ **That list does not exist yet
— see the gate-state table below, which is a hole, not an omission.**

**So: if the sweep is being considered as a response to the incident, it is the wrong instrument.**
Its value is forward-looking and partial, and it costs every in-flight hand on the machine.

## The roster — read fresh, never inherited

`/Users/jowolff/.omp/agent/persistent-seats.json`, read at 2026-09-15 15:10 PDT. Eleven seats:
`lintel`, `tinker`, `sedge`, `verge`, `wren`, `sluice`, `galley`, `levitt`, `codex`, `caspian`,
`tron`. Plus one scheduler, `levitt-morning`, `allowedTargets: ["levitt"]` — **consider whether the
06:00 unattended path lands mid-sweep.**

⛔ **NEVER build the stop list from `OMP_PERSISTENT_SEAT_NAMES`.** It is captured at launch and cannot
enumerate a seat created since. That is a structural fact about the variable and needs no incident to
justify it.

⛔ **And the roster answers WHO, never WHERE.** Complete structure is `schemaVersion`,
`messageEnvelopeVersion`, `seats[]` of `{slug, displayName}`, `schedulers[]`. **No root, cwd or dir
for any seat.** Two distinct questions that must not be conflated:

| question | answered by |
|---|---|
| which seats the sweep must touch | the roster — complete, above |
| which seats the bind actually protects | **only the per-seat roots** — the launcher's `case "$seat"` block |

### Gate-state table — FILLED 2026-09-15, eleven rows, none guessed

Roots from the launcher's own `case "$seat"` block, `/Users/jowolff/.omp/agent/seat-launchers/launch-seat:62-135`.
That root becomes the session cwd via `working_directory=${requested_cwd:-$home}` (`:142`) →
`--cwd "$working_directory"` (`:261`) or `OMP_SEAT_CWD` → `--cwd "$OMP_SEAT_CWD"` (`seat-bin/omp:26`).
Gate column is the module's **own** verdict — `node hook-scope.mjs --check <root> --hook=compact-continuity`
with `CLAUDE_PROJECT_DIR` unset — corroborated by an independent upward filesystem walk. **No row is
inferred from a session directory and no row is unknown.**

| Seat | Root (`launch-seat` line) | `newdle-hooks.json` at or above | Gate |
|---|---|---|---|
| wren | `code/shipyard/repos/newdle-web` (`:65`) | `code/shipyard/newdle-hooks.json` | **on** |
| tinker | `/Users/jowolff/.claude` (`:71`) | **none** | ⛔ **off** |
| sedge | `code/shipyard/repos/newdle-claude-plugins` (`:77`) | `code/shipyard/newdle-hooks.json` | **on** |
| verge | `code/shipyard` (`:83`) | `code/shipyard/newdle-hooks.json` | **on** |
| sluice | `code/shipyard/repos/data-pipelines` (`:89`) | `code/shipyard/newdle-hooks.json` | **on** |
| galley | `code/shipyard/repos/kitchen` (`:95`) | `code/shipyard/newdle-hooks.json` | **on** |
| levitt | `code/joseph-gordon-levitt` (`:101`) | `code/joseph-gordon-levitt/newdle-hooks.json` | **on** |
| lintel | `/Users/jowolff/.claude` (`:107`) | **none** | ⛔ **off** |
| codex | `/Users/jowolff/.codex` (`:114`) | **none** | ⛔ **off** |
| caspian | `code/shipyard/repos/newdle-api` (`:121`) | `code/shipyard/newdle-hooks.json` | **on** |
| tron | `code/shipyard/repos/newdle-users` (`:127`) | `code/shipyard/newdle-hooks.json` | **on** |

**The sentence this table exists to support: the PreCompact bind already protects EIGHT of eleven
seats** — wren, sedge, verge, sluice, galley, levitt, caspian, tron. ⛔ **It protects NONE of tinker,
lintel, codex.** Two of those three share the single root `/Users/jowolff/.claude`, which is the
refused path; the third, `codex`, sits at `/Users/jowolff/.codex`, **a root nobody has ruled on.**

⛔ **One caveat against over-reading the eight.** Gate-true means `compact-continuity.mjs` will *run*
for those seats. **Whether it then writes a usable snapshot through the OMP adapter is a different
claim and was not measured.** The adapter's own comment asserts it was proved against a four-field
OMP payload; that was not re-run. **Verify per seat with the liveness sentence after the sweep rather
than assuming the eight are covered.**

**Narrowing the `codex` row before anyone spends effort on it:** `codex` is launched with a prompt
telling it not to edit files or use the shell (`launch-seat:214`) and its root carries no declaration.
**Whether it needs the compaction save at all is a product question, not a scope one.**

## Per-seat pre-stop checks — POINTED AT, NOT COPIED

⛔ **The checks live in `/Users/jowolff/.claude/orchestrator/runbooks/restart-cycle-20260911.md:33-58`
and this runbook deliberately does not restate them.** A second copy of a governing procedure is the
defect this network keeps rediscovering: a stale copy reads as authoritative while a broken pointer
announces itself. Read them there.

Two things from that list that matter most here, named only because this cycle's specific risk rests
on them:

- **Zero live hands, run first.** A seat cannot enumerate what its hands hold. **This cycle is being
  held precisely because this check would fail right now** — Sluice has four hands on the Resend
  forensics, Tron is on reconstructibility, Galley is auditing a second Resend writer, Wren is on
  ALL-903, Tinker is pricing scope paths.
- **`inbox/<slug>/` empty before stop.** An envelope left there is an instruction nobody will read
  while its sender holds a receipt saying otherwise.

**The seat's own answer is an input, never the evidence.** Disagreement between a seat's list and the
runner's sweep is the stop signal. ⛔ **A glance at a pane is not in this procedure** — it agreed with
the seat every time in the last handoff, which makes it worse than useless.

## Order

1. **Fill the gate-state table.** Without it the cycle's benefit is unmeasured.
2. **Collect a state flush from every live seat**, and confirm receipt per seat before stopping
   anything. Anything that must survive a seat goes to a decision-log entry or a report file *before*
   the stop, not during it.
3. **Run the per-seat checks** from the 09-11 runbook against disk.
4. **Stop and relaunch the non-incident seats first.**
5. ⛔ **Lintel and Tinker LAST.** They are the two the bind cannot help, they hold the coordination
   state for the sweep itself, and stopping the runner mid-sweep is how a cycle ends half-applied.

## Verification after the sweep — the instrument, not an inference

⛔ **`compaction-liveness.mjs`, shipped in `0.2.168`, is the deliverable rather than a nicety.** On
session start it states either the age of the last successful save or that **no pre-compaction save
has ever been recorded on this machine**. That sentence is the first real negative available here
instead of silence we have to infer.

**Three outcomes, and the third is the one prior predictions kept omitting:**

| outcome | reading |
|---|---|
| a `.ai/session-state--<session-id>.md` appears after a compaction | held |
| a heartbeat row reading `failed:<reason>` | bound and broken, and the reason names which |
| ⛔ **no heartbeat row at all** | **the hook never ran — the bind is not the layer at fault** |

**Do not accept a green reading from a seat whose gate is false.** For such a seat the correct
outcome is the liveness sentence saying no save was recorded, and that is the honest result rather
than a regression.

## Reversal

**The bind, one command:**

```
cp /Users/jowolff/.omp/agent/extensions/newdle-hooks.ts.pre-precompact-20260915 \
   /Users/jowolff/.omp/agent/extensions/newdle-hooks.ts
```

Then confirm `a6db2e292dff0bc45f8912f9de874a11`. The backup filename does not end in `.ts`, matching
the existing `persistent-seat-registry.ts.pre-*` convention, so it cannot be loaded as a second
extension. **A reversal also requires a relaunch to take effect, for the same capture-at-launch
reason the adoption does.**

⛔ **Standing requirement for any future change to that adapter, by anyone:** `bun build` to **exit 0
before** the copy, never after. A handler that throws is converted to `{block:true}` and denies every
tool call machine-wide (`runner.ts:1487-1494`). The build costs 8ms; the failure costs the machine.

## What is NOT in this cycle

- **The `~/.claude` declaration.** Refused by Jo.
- **Any `hooksEnabled()` override.** Under investigation; if it lands it is a launcher change and gets
  its own gate.
- **The output-types detector.** It already ships and reaches every seat through this same adapter,
  and it self-silences at two gates — `output-types-guard.mjs:291` (scope) and `:296`
  (`outputLevel()` → `"receipts"` machine-wide). ⛔ **Relaunching does not switch it on**, and saying
  so here prevents the cycle being sold as delivering it.

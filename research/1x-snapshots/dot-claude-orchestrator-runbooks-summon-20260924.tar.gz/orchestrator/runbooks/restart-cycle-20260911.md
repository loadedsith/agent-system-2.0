# Restart cycle — 2026-09-11

**Written by Lintel, before Jo's approval, so approval is the only remaining gate.** Nothing here
runs until Jo approves the stop list. Lintel executes; no seat stops itself.

## What the cycle is for

Runtime adoption of three things already on disk and unadopted:

1. **The allowlist**, so Caspian is addressable. Every running session's roster froze at its own
   launch — measured: `seat_message` to Caspian is rejected from Lintel's session with a nine-name
   list while `launch-seat:18` and `persistent-seats.json` carry ten.
2. **`display: false`** — Codex's change at `persistent-seat-registry.ts:409`, Jo-requested.
3. **The mail-fix pair** (claim-before-deliver + root exclusivity), sealed at `e04cc2de`,
   activation per Tinker's runbook: `runs/seat-mail-fix-candidate-20260911/reports/tinker-activation-runbook--20260911T110121Z--d5772ee1.md`.

**NOT in this cycle: envelope v2.** Built, unactivated, next cycle. ⛔ **Receiver must restart with
v2 support BEFORE Codex flips `messageEnvelopeVersion`** — flipping first emits v2 at a running v1
receiver that quarantines it as unknown, which is silent loss on the unattended path at 06:00.

## The tradeoff Jo owns, stated rather than buried

Claim-before-deliver trades today's **noisy duplication that hands catch** for a **narrow
silent-loss window** if a process dies between claim and injection. Untested across process death;
no reaper built. Lintel's position: worth it, because duplication is producing real coordination
errors hourly and the new failure mode is narrower — but the new one is quiet and the current one is
loud, and quiet failures are the ones this network keeps paying for.

⛔ **Mixed old/new receivers on one mailbox is UNTESTED.** [INFERENCE] worst case is the duplication
we already have rather than corruption. This is the argument for restarting everyone in one window
rather than trickling, and against activating the pair during a partial phase.

## Per-seat checks — Tinker's list, run by the RUNNER against disk

Source: `runs/restart-cycle-constraints-20260911/reports/tinker--20260911T105211Z--b6f74aa6.md`.
**The seat's answer is an input, never the evidence. Disagreement between the seat's list and the
runner's sweep is the stop signal.** A glance at a pane is not in this procedure: it agreed with the
seat every time in the last handoff, which makes it worse than useless.

1. **Zero live hands.** Runs first. A seat cannot enumerate what its hands hold. Require the count
   sealed or cancelled, reported.
2. **Modified-tracked sweep, scoped to the seat's declared surface.** NOT every path — that is
   22,006 in `~/.claude` and 2,530 even scoped, mostly `runs/` churn. Account for `M` rows only;
   untracked goes in a count against a baseline. A check that cannot be performed gets skipped, and
   a skipped check reports green.
3. **Claims resolve to paths.** Every row of the seat's unfinished list must resolve to a path whose
   mtime is consistent with what that row says it recorded. ⛔ Not a bare fresh-mtime gate: that is
   satisfied by the one artifact whose existence was never in doubt, and a gate satisfiable by
   writing something produces agents that write something.
4. **`worker-report.sh verify` per run**, for the `UNSEALED` case specifically.
5. **Decision-log filename timestamp compared against the clock.**
6. **`inbox/<slug>/` empty before stop.** An envelope left there is an instruction nobody will read
   while its sender holds a receipt saying otherwise.
7. **Unpushed and unreplicated work named as such.** In `~/.claude` that is everything: empty
   `git remote -v`, 40 branches with no upstream.
8. **Checkout distance, recorded not gated.** After a fetch: `HEAD`, branch, and
   `rev-list --count HEAD..origin/<mainline>`. Precedent: Wren woke 97 behind and resurfaced two
   closed items. A restart otherwise **launders staleness into a fresh-looking session**.

**Residue, stated so nobody buys false coverage:** a finding that exists only as a sentence a seat
has not typed is invisible to all eight. The mitigation is findings going to disk when they are
made — already a charter rule, and the thing that actually failed. A strong stop-gate must not
become the reason anyone relaxes write-as-you-go.

## Order

1. **Phase 1** — seats with zero hands and an empty inbox: **Codex, Wren, Sluice**. No pair
   activation. Three real `--start` runs are the launcher falsifier: each must exit **0** where seven
   of eight false-refused this morning, and `ROUTING.md:26-27`'s `&&` must actually reach
   `check-seat-ready`. ⛔ The launcher itself never invoked `check-seat-ready`; the skip was the
   `&&` short-circuit.
2. **Caspian's first wake**, after at least one clean restart. A first wake and a changed runtime
   failing together tells you which of nothing.
3. **Lintel** — Jo types `lintel`. Until then Lintel cannot address Caspian at all.
4. **Phase 2, when Verge/Galley/Sedge/Levitt are hand-free**: full cycle plus pair activation.
5. **Tinker LAST.** Its restart is what proves the allowlist and `display: false`, and a failure
   there is cheaper to diagnose with every other seat already up and reachable.

## Activation, from Tinker's runbook — six steps, abort conditions first

- sha gate, then backup, then the copy.
- Verify against the **INSTALLED** file, never the candidate: `bun test persistent-seat-registry.test.ts`
  must stay **16/16** because that suite imports the live path, and the race baseline must flip from
  **2 injections / 1 throw** to **1 injection / 0 throws** on the live line.
- ⛔ **If the live line still reads 2, the copy did not land where the script reads. Reverse and
  stop** — do not investigate with the channel half-changed.
- Reversal: one `cp` of the backup plus a restart, with the expected sha printed so it is visible
  that it took.

## Announcement

Lintel announces to every seat before the first stop, and tells each seat when its own turn comes.
No seat stops itself; no seat activates anything; no LaunchAgent is bootstrapped — that is Jo's
command and it stays unloaded through both phases.

## ⛔ RELAUNCH INSTRUCTIONS — read before starting any seat

**Jo, 2026-09-11: WREN MUST BE RELAUNCHED THROUGH `launch-seat`.** Wren had been running on the
**adapter spike** for this entire session, which meant its plugin machinery was badly out of date.
That is the likely common cause behind several Wren oddities tonight: a 97-commits-behind checkout,
long silences, and stop-list orders that never reached the seat.

```
/Users/jowolff/.omp/agent/seat-launchers/launch-seat --start wren
/Users/jowolff/.omp/agent/seat-launchers/check-seat-ready --after <epoch> wren
```

**This is the rule for every seat, and Wren is the proof of what happens when it is not followed:**
any path that does not go through that launcher is an invalid seat launch even if OMP starts
successfully (`ROUTING.md`, model contract). A seat started another way looks healthy, reports
READY, and runs stale machinery that nothing surfaces.

**Relaunch order after Jo restarts Lintel:** wren first, so the fix is proven on the seat that was
broken; then codex, galley, levitt, sluice, sedge, verge; **tinker last**; then **Caspian's first
wake**. Verify each with `check-seat-ready` rather than the launcher's own exit status, and record
each seat's checkout distance at relaunch (check 8) so a clean restart cannot launder a stale tree.

**Tinker's first task on waking: commit its own surface by explicit path** — 28 modified tracked
files including `orchestrator/tools/charter-ladder.mjs`, uncommitted when it went down because the
agent-commits-its-own-wrap-up contract did not exist yet.

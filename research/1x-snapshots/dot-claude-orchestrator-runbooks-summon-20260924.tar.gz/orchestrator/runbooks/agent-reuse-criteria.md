# When to reuse an agent and when to send a fresh one

**Status: in force as guidance. The schema half is NOT in force and is held** — see *What is held and
why* at the end. This document went through adversarial review on two independently-trained models
before landing; what follows is what survived, and the review's own corrections to it are marked.

**Where this lives and who reads it:** `orchestrator/runbooks/`, and the audience is whoever is
about to dispatch — Lintel, or a seat dispatching a specialist. **The two rules a dispatcher
actually needs are the first two headings.** Everything after *What to write down* is reasoning, and
a dispatcher under load should not need it.

## The rule

**Send a fresh agent when the task evaluates, contradicts, or depends on an independent read of work
a prior agent produced.** Otherwise reuse is available, and has to be argued for in one line.

That is one rule, not five. It covers: checking, verifying, auditing, reviewing or re-deriving
anything; examining work the prior agent authored; a task whose whole value is that the read is
independent; a premise the prior agent asserted that you now doubt; and anything the prior agent was
corrected on, because correction leaves the original reasoning in its context still shaping what it
notices.

## The default, and why it is not "fresh is better"

**Default to fresh.** Not because fresh agents are more accurate — nothing here measures that — but
because **fresh is the option whose failure mode is visible.** A fresh agent that lacks context
asks, stalls, or returns something obviously thin, and the dispatcher sees it immediately. A reused
agent carrying a wrong conclusion returns something fluent that agrees with what it said before, and
nothing in the output announces the defect. **Between two options with similar error rates, prefer
the one that fails loudly.**

## Reuse

1. **A seat.** Seats are permanently reused by design: a seat owns a surface and the accumulated
   knowledge of that surface is what the seat *is*. **This is not an exception to the rule above —
   it is the reason a seat must not review its own work.** A seat needing its own output checked
   dispatches a fresh worker.
2. **The agent holds state that cannot be handed over** — a worktree it created, a running process,
   a browser session, an experiment mid-flight. Reuse because re-creating the state is the real
   cost, not because the context is convenient.
3. **Continuation of the same construction, where nothing about the next step evaluates the last
   one.** The moment the follow-up includes "and check it still works", the rule above applies to
   the checking half: split the dispatch. *(One reviewer argued this case is largely subsumed by
   seats and background agents, which persist anyway. It is kept because in-process follow-ups exist
   and the split-the-dispatch instruction is the part that carries the weight.)*

## What to write down

One line in the dispatch record naming the choice and why. **The reason is not "for continuity"** —
name the specific state that would have to be rebuilt, or the specific independence being spent.

**This is guidance, not a validated field.** The mechanism that would make it queryable is held; see
below. Until then the line goes in the dispatch row's existing prose.

---

## What the review corrected, kept because a corrected claim is worth more than a tidy one

**An earlier draft said the dispatch ledger holds no record of agent reuse. That was false as
written and it was this seat's own over-reach.** Verified 2026-08-24: the *field* claim is exact —
`continuity` appears in 0 of 177 rows — but three rows document instance reuse in prose, and two of
them do so with transcript-level provenance. `DSP-117` and `DSP-134` both read *"a follow-up turn on
the SAME agent, not a new dispatch"*, both carry `evidence_tier: A`, and **both came back
`outcome: clean`.**

**So the only two documented instance-reuse events in this fleet's record both succeeded, and they
lean against the default written above.** The honest weight is very light — n=2, `outcome` is
self-assessed by the dispatcher, both rows were reconstructed a day after the fact
(`outcome_source: reconstructed-2026-08-21`), and both carry an empty `friction`. But it is not
nothing, and the earlier draft claimed the record was silent when it was merely unqueryable.

## What would falsify the default

**Not an outcome comparison, and the first draft was wrong to promise one.** The `outcome`
vocabulary conflates acceptance, revision, abandonment and retry, `shape` is an open vocabulary, and
`outcome` is assessed by the same agent that chose the dispatch. A "clean" continuation and a
"sent-back" verification are not comparable measurements. **Reuse's named failure mode — a fluent
answer that agrees with what the agent already concluded — is precisely the one a self-assessed
outcome field cannot see.**

What would actually move this: **a case where a reused agent defended a conclusion that a fresh one
overturned, or the reverse** — read by a human, not counted by a query. `DSP-117` and `DSP-134` are
the two data points that exist today.

## What is held and why

**A proposed schema change would add a queryable field for the choice.** It is written, its tooling
is built and tested, and **it is deliberately not landed**, for a reason the review found and this
seat had missed:

**The dispatch ledger has not recorded a row in two days.** Verified 2026-08-24: 177 rows, last one
`DSP-177` at `2026-08-22T15:49:28Z`; by date, 51 on 08-19, 98 on 08-20, 14 on 08-21, 14 on 08-22,
and **nothing on 08-23 or 08-24** — including nothing for any of today's dispatches. **A field added
to a file nobody is writing to accumulates nothing**, and the binding constraint on ever answering
"does reuse pay" is write-discipline, which no schema change touches.

**So the ordering is: find out why dispatch recording stopped, before adding a field to it.** That
question is Lintel's, not this document's.

**One thing the review disagreed with itself about, handed over rather than settled here.** One leg
argued the choice should be annotated in the existing prose fields during a trial and promoted to a
schema change only if a pattern appears; the other examined that same option and rejected it,
holding that a dedicated field earns its place. **Two independently-trained models reached opposite
conclusions on the same evidence.** That is a genuine open question and it is not this seat's to
close by picking.

## The name

If the field is ever added it should **not** be called `continuity`. Two ledger rows already carry
the shape `self-modification/continuity`, so the word would mean both a task category and a
reuse-or-fresh choice. `agent_continuity`, `dispatch_mode` or `reuse_choice` all avoid it.

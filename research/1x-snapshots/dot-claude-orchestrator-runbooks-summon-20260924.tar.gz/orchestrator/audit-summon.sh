#!/usr/bin/env zsh
#
# Summon the transcript auditor as its own top-level session.
#
#   zsh /Users/jowolff/.claude/orchestrator/audit-summon.sh [session-id]
#
# Sibling of summon.sh. Same discipline: announce each step, stop on the first failure, tee the
# whole run to a log next to this script. Safe to run from the top, every time. Nothing here is
# destructive — it only reads, then replaces itself with an interactive Claude session.
#
# WHY THIS IS NOT A DISPATCH. The auditor checks the orchestrator's account of itself. If the
# orchestrator dispatched it, the findings would land in the audited party's lap before they
# reached Jo, which is the exact chokepoint the auditor exists to close. So it gets its own
# top-level session that Jo talks to directly, with the orchestrator out of the loop.
#
# WHY NO --session-id. summon.sh mints a UUID and writes it to state/.session-id because every
# hook under orchestrator/hooks/ refuses to act unless the session_id in its payload equals that
# file (hooks/session-gate.mjs:39). Minting one here would do two wrong things at once: it would
# subject the auditor to the audited party's hooks, and it would overwrite the marker, disarming
# those hooks for the orchestrator session still running in another window. The auditor wants
# neither. It runs unhooked and anonymous, and this script never writes state/.session-id.
#
# UNINSTALL. Two pieces, both reversible, neither touching the orchestrator:
#   1. delete the `assay` function line from ~/.zshrc (the line that calls this script), then
#      `unset -f assay` in any shell already open;
#   2. delete this script and its log: audit-summon.sh and audit-summon.log under
#      /Users/jowolff/.claude/orchestrator/
# Nothing else was installed. No hook, no settings.json entry, no state file. The auditor agent
# at /Users/jowolff/.claude/agents/transcript-auditor.md predates this launcher and stays.
#
# If a step fails, it stops there and says which one. The full log is written to
# audit-summon.log next to this script — hand that path to a Claude session rather than trying
# to narrow the failure down yourself.

emulate -L zsh
setopt pipe_fail

ORCH_HOME=/Users/jowolff/.claude/orchestrator
STATE="$ORCH_HOME/state"
AGENT_FILE=/Users/jowolff/.claude/agents/transcript-auditor.md
BRIEF="$STATE/AUDIT-BRIEF.md"
STAMPER="$STATE/tools/audit-brief-version.sh"
EXTRACTOR="$STATE/tools/transcript-extract.mjs"
PROJECTS=/Users/jowolff/.claude/projects/-Users-jowolff
LOG="$ORCH_HOME/audit-summon.log"
# One timestamp for the whole run, minted before preflight, so the report path announced in the
# preflight block is byte-identical to the one handed to the agent. Recomputing it in each place
# lets the two drift by a second, which is exactly the kind of small lie that wastes an hour.
RUN_STAMP="${AUDIT_RUN_STAMP:-$(date -u '+%Y%m%dT%H%M%SZ')}"
WANT_SESSION="${1:-}"

TARGET_SESSION=""
TARGET_DIR=""
REPORT_PATH=""

preflight() {
  set -e

  print -- "── audit-summon: preflight ────────────────────────────"
  print -- "agent definition: $AGENT_FILE"
  print -- "standing brief  : $BRIEF"
  print -- ""

  print -n -- "[1/8] claude binary ......... "
  command -v claude >/dev/null || { print -- "MISSING"; print -u2 -- "claude is not on PATH."; return 1; }
  print -- "ok ($(claude --version 2>/dev/null))"

  print -n -- "[2/8] node binary ........... "
  command -v node >/dev/null || { print -- "MISSING"; print -u2 -- "node is not on PATH; the transcript extractor cannot run without it."; return 1; }
  print -- "ok ($(node --version 2>/dev/null))"

  print -n -- "[3/8] agent definition ...... "
  [[ -r "$AGENT_FILE" ]] || { print -- "MISSING"; print -u2 -- "No readable agent file at $AGENT_FILE"; return 1; }
  print -- "ok ($(wc -l < "$AGENT_FILE" | tr -d ' ') lines)"

  # Malformed frontmatter parses as prose and the agent silently never loads, dropping the
  # session into an ordinary Claude with no sign anything is wrong.
  print -n -- "[4/8] frontmatter parses .... "
  python3 - "$AGENT_FILE" <<'PY' || return 1
import re, sys
src = open(sys.argv[1]).read()
m = re.match(r"^---\n(.*?)\n---\n", src, re.S)
if not m:
    print("FAILED"); print("no YAML frontmatter block at the top of the file", file=sys.stderr); sys.exit(1)
block = m.group(1)
try:
    import yaml
    data = yaml.safe_load(block)
except ImportError:
    data = {ln.split(":", 1)[0]: 1 for ln in block.split("\n") if ln and not ln[0].isspace()}
except Exception as exc:
    print("FAILED"); print(f"frontmatter is not valid YAML: {exc}", file=sys.stderr); sys.exit(1)
if data.get("name") != "transcript-auditor":
    print("FAILED"); print(f"name is {data.get('name')!r}, expected 'transcript-auditor'", file=sys.stderr); sys.exit(1)
print(f"ok (name={data['name']}, {len(data)} fields)")
PY

  print -n -- "[5/8] standing brief ........ "
  [[ -r "$BRIEF" ]] || { print -- "MISSING"; print -u2 -- "No readable standing brief at $BRIEF."; print -u2 -- "An audit run with no standing brief is not an audit run. Restore it before summoning."; return 1; }
  print -- "ok ($(wc -c < "$BRIEF" | tr -d ' ') bytes)"

  print -n -- "[6/8] extractor runs ........ "
  [[ -r "$EXTRACTOR" ]] || { print -- "MISSING"; print -u2 -- "No readable extractor at $EXTRACTOR."; return 1; }
  node "$EXTRACTOR" --sessions >/dev/null 2>&1 || { print -- "BROKEN"; print -u2 -- "\`node $EXTRACTOR --sessions\` exited non-zero. Fix the extractor before summoning; the auditor cannot read raw transcripts without it."; return 1; }
  print -- "ok (--sessions exits 0)"

  # Stamp the brief version into this log BEFORE handing over, so the launch itself records
  # which version of the standing brief this run started against — independent of whatever the
  # auditor later pastes into its own report.
  print -- "[7/8] brief version stamp ..."
  [[ -r "$STAMPER" ]] || { print -u2 -- "No readable stamper at $STAMPER."; return 1; }
  zsh "$STAMPER" 2>&1 | sed 's/^/      /' || { print -u2 -- "audit-brief-version.sh exited non-zero."; return 1; }

  print -n -- "[8/8] target session ........ "
  resolve_target || return 1
  print -- "ok"
  print -- "      session    : $TARGET_SESSION"
  print -- "      transcripts: $TARGET_DIR"
  print -- "      count      : $(ls -1 "$TARGET_DIR"/agent-*.jsonl 2>/dev/null | wc -l | tr -d ' ')"
  print -- "      report goes: $REPORT_PATH"

  print -- ""
  print -- "preflight passed. handing the session over."
  print -- "───────────────────────────────────────────────────────"
}

# Pick the session to audit. Explicit argument wins. Otherwise: the session whose newest
# subagent transcript was modified most recently — that is "most recent" by last write, not by
# session start, which is what you want when several sessions overlap in a day.
resolve_target() {
  local dir newest sid
  local -a rows

  [[ -d "$PROJECTS" ]] || { print -- "MISSING"; print -u2 -- "No projects directory at $PROJECTS."; return 1; }

  if [[ -n "$WANT_SESSION" ]]; then
    sid="${WANT_SESSION:t}"                       # tolerate a full path being pasted in
    dir="$PROJECTS/$sid/subagents"
    if [[ ! -d "$dir" ]]; then
      print -- "MISSING"
      print -u2 -- "No subagent transcripts for session '$sid'."
      print -u2 -- "Expected directory: $dir"
      print -u2 -- "Sessions that do have transcripts:"
      node "$EXTRACTOR" --sessions 2>&1 | sed 's/^/  /' >&2
      return 1
    fi
    if ! ls "$dir"/agent-*.jsonl >/dev/null 2>&1; then
      print -- "EMPTY"
      print -u2 -- "$dir exists but holds no agent-*.jsonl transcripts. Nothing to audit there."
      return 1
    fi
    TARGET_SESSION="$sid"
    TARGET_DIR="$dir"
  else
    for dir in "$PROJECTS"/*/subagents(N/); do
      newest=$(stat -f '%m' "$dir"/agent-*.jsonl(N) 2>/dev/null | sort -rn | head -1)
      [[ -n "$newest" ]] || continue
      rows+=("$newest ${${dir:h}:t}")
    done

    if (( ${#rows} == 0 )); then
      print -- "NONE"
      print -u2 -- "No session under $PROJECTS has any agent-*.jsonl subagent transcript."
      print -u2 -- "There is nothing for the auditor to compare a ledger against. Run a session"
      print -u2 -- "that dispatches subagents first, or pass a session id explicitly."
      return 1
    fi

    local -a sorted
    # Per-key flags matter: -k1,1rn puts newest first, plain -k2,2 breaks a tie by lowest session
    # id. A global -r would reverse the tiebreak too and pick the highest, contradicting the
    # message printed below.
    sorted=(${(f)"$(print -l -- $rows | sort -k1,1rn -k2,2)"})
    local top_mtime="${sorted[1]%% *}"
    local -a tied
    for r in $sorted; do
      [[ "${r%% *}" == "$top_mtime" ]] && tied+=("${r#* }")
    done

    TARGET_SESSION="${sorted[1]#* }"
    TARGET_DIR="$PROJECTS/$TARGET_SESSION/subagents"

    if (( ${#tied} > 1 )); then
      # Same second on two sessions' newest transcript. Break it deterministically by session
      # id (the sort above already did) and say out loud that it happened, because the tie is
      # itself worth knowing: two sessions were writing subagent transcripts simultaneously.
      print -- "TIE"
      print -- "      ${#tied} sessions share the newest transcript timestamp ($(date -r $top_mtime '+%Y-%m-%d %H:%M:%S')):"
      print -l -- ${tied/#/      - }
      print -- "      picking $TARGET_SESSION (lowest session id). Re-run with a session id to override:"
      print -- "        assay <session-id>            (or: zsh $ORCH_HOME/audit-summon.sh <session-id>)"
    fi
  fi

  [[ -w "$STATE/runs" ]] || { print -u2 -- "$STATE/runs is not writable; the auditor would have nowhere to put its report."; return 1; }
  REPORT_PATH="$STATE/runs/audit-${RUN_STAMP%%T*}/AUDIT-${RUN_STAMP}.md"
}

preflight 2>&1 | tee "$LOG"
if (( pipestatus[1] != 0 )); then
  print -u2 -- ""
  print -u2 -- "audit-summon stopped at the step above. This broke — tell a Claude session;"
  print -u2 -- "the log is already at $LOG"
  exit 1
fi

[[ -n "$AUDIT_PREFLIGHT_ONLY" ]] && exit 0

# resolve_target ran inside the tee'd pipeline, which is a subshell, so its variables did not
# survive. Recompute them here, quietly, in this shell. Cheap, and it keeps the announce path
# and the launch path reading from the same function rather than from two copies of the logic.
resolve_target >/dev/null 2>&1 || { print -u2 -- "Target session vanished between preflight and launch. Re-run."; exit 1; }

# This session must be a top-level one. If audit-summon is ever run from inside another Claude
# session's shell, the inherited child marker turns off transcript saving for the auditor.
unset CLAUDE_CODE_CHILD_SESSION

cd "$STATE"
exec claude --agent transcript-auditor "Audit session ${TARGET_SESSION}.

Its subagent transcripts are at ${TARGET_DIR}
The orchestrator's account of those dispatches is in ${STATE}/LEDGER.jsonl, ${STATE}/runs/, and ${STATE}/STANDUP.md
Write your report to ${REPORT_PATH}

Follow your standing brief at ${BRIEF}. It outranks this prompt; where they conflict, say so as a blocker and follow the brief. You were launched as your own top-level session, not dispatched by the orchestrator, so your findings reach the human before they reach the audited party — keep it that way and do not route anything back through the orchestrator."

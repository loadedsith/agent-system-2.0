#!/usr/bin/env zsh
#
# Summon the orchestrator and hand it the session.
#
#   zsh /Users/jowolff/.claude/orchestrator/summon.sh [start-directory]
#
# Safe to run from the top, every time. Nothing here is destructive: it verifies the
# orchestrator's definition and state layer, then replaces itself with an interactive
# Claude session whose main thread IS the orchestrator.
#
# If a step fails, it stops there and says which one. The full log is written to
# summon.log next to this script — hand that path to a Claude session rather than
# trying to narrow the failure down yourself.

emulate -L zsh
setopt pipe_fail

ORCH_HOME=/Users/jowolff/.claude/orchestrator
AGENT_FILE=/Users/jowolff/.claude/agents/orchestrator.md
START_DIR="${1:-/Users/jowolff/.claude}"

# THREE TEST SEAMS, all defaulting to the real paths so an ordinary summon is unchanged.
# They exist so the bootstrap runbook and [5/6] state-layer check can be exercised against a
# fixture directory —
# the alternative is moving files out of the LIVE state directory, which races with
# intake-capture.mjs (UserPromptSubmit, appends REQUESTS-INBOX.jsonl) and savepoint-guard.mjs
# (Stop, reads REQUESTS.jsonl and REQUESTS-INBOX.jsonl). A test that can drop a row Jo just
# typed is not a test. LINTEL_STATE is the same variable savepoint-restore.sh already honours,
# so this is the established pattern here rather than a new one.
STATE_DIR="${LINTEL_STATE:-$ORCH_HOME/state}"
LOG="${LINTEL_SUMMON_LOG:-$ORCH_HOME/summon.log}"
BOOTSTRAP_RUNBOOK="${LINTEL_BOOTSTRAP_RUNBOOK:-$ORCH_HOME/runbooks/bootstrap.md}"

# ── OpenTelemetry export (added 2026-08-24, run launcher-telemetry-20260824) ────────────
# Claude Code exports traces only when the telemetry variables are set FOR THE SESSION.
# They go through --settings, NEVER as a shell prefix, and that is not a style preference.
# Measured on this machine 2026-08-24, four arms, each anchored on a session.id read back
# out of Phoenix:
#     foreground, exported shell variables ....... 2 spans arrived
#     foreground, --settings ..................... 2 spans arrived
#     background, exported shell variables ....... 0 spans, over 48s of polling
#     background, --settings ..................... 2 spans arrived
# A background session ran a full turn and emitted NOTHING with the variables exported.
# One mechanism proven on BOTH arms beats two mechanisms where one is proven on one arm,
# so every arm of every launcher in this fleet uses --settings.
#
# --settings MERGES with every other settings source rather than replacing it, so plugin
# hooks, permissions and user settings keep working. Only ONE --settings may be passed,
# which is why the payload is merged below instead of adding a second flag.
#
# NO GLOBAL STATE. Nothing is written to a shell profile and nothing to
# /Users/jowolff/.claude/settings.json. The whole configuration is this block plus the one
# shared file it reads.
#
# REVERSAL, this file:  cp /Users/jowolff/.claude/orchestrator/summon.sh.pre-otel-20260824 /Users/jowolff/.claude/orchestrator/summon.sh
# REVERSAL, fleet-wide: rm /Users/jowolff/agent-scratch/lintel/otel/settings.json
#                       Every launcher then prints a loud DEGRADED line and launches with
#                       telemetry off. Telemetry never blocks a launch.
OTEL_SETTINGS_FILE="/Users/jowolff/agent-scratch/lintel/otel/settings.json"

# Merge the shared OTel env with any launcher-specific env into one --settings payload.
# Prints the JSON on stdout. Exits 3 if the shared file is unreadable or malformed, having
# still printed usable JSON, so a missing file degrades LOUDLY instead of silently
# switching instrumentation off — which is the exact failure this change repairs.
otel_settings() {
  local seat_env="$1"
  [[ -n "$seat_env" ]] || seat_env='{}'
  SEAT_ENV_JSON="$seat_env" OTEL_FILE="$OTEL_SETTINGS_FILE" python3 -c '
import json, os, sys
try:
    env = json.loads(os.environ["SEAT_ENV_JSON"])
except Exception as exc:
    print("{}")
    print(f"launcher env JSON is malformed: {exc}", file=sys.stderr)
    sys.exit(3)
try:
    with open(os.environ["OTEL_FILE"]) as fh:
        otel = json.load(fh)["env"]
except Exception as exc:
    print(json.dumps({"env": env}))
    print(f"OTel settings unreadable: {exc}", file=sys.stderr)
    sys.exit(3)
env.update(otel)
print(json.dumps({"env": env}))
'
}
if OTEL_SETTINGS=$(otel_settings '{}' 2>/dev/null); then
  OTEL_STATUS="ok (traces to the local collector on :4318)"
else
  OTEL_STATUS="DEGRADED - $OTEL_SETTINGS_FILE unreadable; NO traces from this session"
fi

preflight() {
  set -e

  print -- "── summon: preflight ──────────────────────────────────"
  print -- "start directory : $START_DIR"
  print -- "agent definition: $AGENT_FILE"
  print -- ""

  print -n -- "[1/6] claude binary ......... "
  command -v claude >/dev/null || { print -- "MISSING"; print -u2 -- "claude is not on PATH."; return 1; }
  print -- "ok ($(claude --version 2>/dev/null))"

  print -n -- "[2/6] start directory ....... "
  [[ -d "$START_DIR" ]] || { print -- "MISSING"; print -u2 -- "No such directory: $START_DIR"; return 1; }
  print -- "ok"

  print -n -- "[3/6] agent definition ...... "
  [[ -r "$AGENT_FILE" ]] || { print -- "MISSING"; print -u2 -- "No readable agent file at $AGENT_FILE"; return 1; }
  print -- "ok ($(wc -l < "$AGENT_FILE" | tr -d ' ') lines)"

  # A malformed frontmatter block parses as prose and the agent silently never loads,
  # which would drop the session into an ordinary Claude with no sign anything is wrong.
  print -n -- "[4/6] frontmatter parses .... "
  python3 - "$AGENT_FILE" <<'PY' || return 1
import re, sys
src = open(sys.argv[1]).read()
m = re.match(r"^---\n(.*?)\n---\n", src, re.S)
if not m:
    print("FAILED"); print("no YAML frontmatter block at the top of the file", file=sys.stderr); sys.exit(1)
block = m.group(1)
try:
    import yaml
    data = yaml.safe_load(block)
except ImportError:
    # PyYAML is optional. The fallback reads top-level scalar keys only; that is sufficient for
    # the load-bearing `name` check and must preserve the value rather than replacing it with `1`.
    data = {}
    for ln in block.split("\n"):
        if not ln or ln[0].isspace() or ln.lstrip().startswith("#"):
            continue
        key, sep, raw = ln.partition(":")
        if not sep:
            continue
        raw = raw.strip()
        if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in "\"'":
            raw = raw[1:-1]
        data[key.strip()] = raw
except Exception as exc:
    print("FAILED"); print(f"frontmatter is not valid YAML: {exc}", file=sys.stderr); sys.exit(1)
if data.get("name") != "orchestrator":
    print("FAILED"); print(f"name is {data.get('name')!r}, expected 'orchestrator'", file=sys.stderr); sys.exit(1)
if ":" in str(data.get("name", "")):
    print("FAILED"); print("name contains ':', which prevents the file loading", file=sys.stderr); sys.exit(1)
print(f"ok (name={data['name']}, {len(data)} fields)")
PY

  # THE REQUIRED LIST IS DERIVED, NOT INVENTORIED. Each entry below is here because something
  # reads it on the way into a session. It is deliberately NOT "whatever happens to sit in
  # state/ today" — a list built that way grows junk and stops meaning anything.
  #
  #
  # CITATION FORM. The charter has NO numbered sections. Every "§ N" citation this block used to
  # carry pointed at a numbering scheme that has never existed in agents/orchestrator.md or in
  # any backup beside it, and one of them (REGISTRY.md) quoted a sentence the charter does not
  # contain. Re-derived 2026-08-25 against the live charter and written as HEADING PATHS plus a
  # distinctive quoted string, which survive an edit above them; a line number does not.
  #
  #   STANDUP.md            savepoint-restore.sh, the SessionStart injection (searchable there
  #                         as the "NO STANDUP.md EXISTS" fallback); charter "## Session loop"
  #                         → "### Open" step 1, "Read `state/STANDUP.md` and restate the content
  #                         of every live workstream"; savepoint-fit-stop.mjs.
  #   REQUESTS.jsonl        savepoint-restore.sh reads it at SessionStart under the heading
  #                         "OPEN OBLIGATIONS (state != delivered)"; savepoint-guard.mjs reads
  #                         it twice and watches its mtime. This is the request queue: charter
  #                         "## Durable state" gives it "Every request from Jo and whether the
  #                         full request reached a terminal outcome", and "## Session loop" →
  #                         "### During" step 1 is "Record each request before it can disappear
  #                         into conversation" — starting without it loses every open obligation
  #                         silently.
  #   REGISTRY.md           THE UN-BOOTSTRAPPED SIGNAL, checked for emptiness further down this
  #                         file. runbooks/bootstrap.md opens by naming it: "Read and follow this
  #                         when `state/REGISTRY.md` or `state/LEDGER.jsonl` is absent or empty",
  #                         and its step 4 is "Write `REGISTRY.md` from receipted results." Also
  #                         charter "## Durable state" ("Persistent seats, agents, tools,
  #                         integrations, and mutable machine capabilities, each with verification
  #                         state") and "### Depth and capacity" ("Their current verified values
  #                         belong in `state/REGISTRY.md` or `state/ROUTING.md`").
  #   ROUTING.md            charter frontmatter initialPrompt step 4 ("Read .../ROUTING.md before
  #                         the first dispatch"); charter "## Session loop" → "### Open" step 5,
  #                         the same instruction.
  #   EXPERIMENTS.md        charter frontmatter initialPrompt step 3 ("Check for completed or
  #                         blocked background work and overdue experiments") and "## Session
  #                         loop" → "### Open" step 4 ("Check experiments whose measurement
  #                         windows have elapsed"); savepoint-guard.mjs WATCH list.
  #   RETRACTIONS.md        savepoint-guard.mjs WATCH list; charter "## Continuous improvement",
  #                         "**Retractions:** an audit log, not a score to minimize."
  #   REQUESTS-INBOX.jsonl  savepoint-guard.mjs reads it (search "INBOX READ") to check triage
  #                         referential integrity; intake-sweep.mjs reads it to dedupe.
  #                         Both swallow its absence, which is exactly the problem: with the
  #                         inbox gone the integrity invariant checks nothing and reports clean.
  #   BRIEF-BOILERPLATE.md  charter "## Dispatch contract", "Append the canonical text; do not
  #                         reconstruct it from memory." Every
  #                         dispatch appends it; without the file the contract gets retyped from
  #                         memory and drifts, which is the failure that rule exists to prevent.
  #   runs/                 per-dispatch worker output lands here.
  #
  # DELIBERATELY NOT REQUIRED, so nobody adds them back without new evidence:
  #   LEDGER.jsonl     RETIRED 2026-08-25 by the charter's own durable-state table ("RETIRED
  #                    2026-08-25 — see `LEDGER.jsonl.RETIRED.md`. The dispatch record is now the
  #                    harness transcript."). Nothing has written it since; the file on disk has
  #                    not moved since 2026-08-22. It was required here for two reasons and both
  #                    are gone: savepoint-guard.mjs no longer watches it, and the cold-start
  #                    check below no longer reads it. A frozen file is a frozen ANSWER — the
  #                    emptiness check could only ever return "bootstrapped", whatever the truth
  #                    was — so the check moved to REGISTRY.md, which bootstrap writes and which
  #                    a state wipe genuinely empties. Do not re-add it: requiring a file no
  #                    reader reads is exactly the junk this list refuses to grow.
  #   NEXT-ACTION.md   grepped for across hooks/, summon.sh and the charter: ZERO code readers.
  #                    Its only mentions are prose pointers inside STANDUP.md and an allowlist
  #                    regex in tools/sync-to-lintel.sh (a publish filter, not a startup read).
  #                    It is session content, not machinery. Same for TODO.md.
  #   .session-id      read at SessionStart by savepoint-restore.sh and session-gate.mjs, but
  #                    MINTED BY THIS SCRIPT further down, after preflight. Requiring it here
  #                    would make the first summon after a wipe impossible. Do not add it.
  print -n -- "[5/6] state layer ........... "
  local bootstrap_required=0
  local missing=()
  for f in STANDUP.md REQUESTS.jsonl REGISTRY.md ROUTING.md EXPERIMENTS.md \
           RETRACTIONS.md REQUESTS-INBOX.jsonl BRIEF-BOILERPLATE.md; do
    [[ -e "$STATE_DIR/$f" ]] || missing+=("$f")
  done
  [[ -d "$STATE_DIR/runs" ]] || missing+=("runs/")
  if (( ${#missing} )); then
    bootstrap_required=1
    print -- "BOOTSTRAP REQUIRED"
    print -u2 -- "Missing under $STATE_DIR/ : ${missing[*]}"
    [[ -r "$BOOTSTRAP_RUNBOOK" ]] || {
      print -u2 -- "Recovery cannot start: $BOOTSTRAP_RUNBOOK is missing or unreadable."
      return 1
    }
    print -u2 -- "Recovery path: $BOOTSTRAP_RUNBOOK"
  else
    print -- "ok"
  fi

  print -n -- "[+]   telemetry export ...... "
  print -- "$OTEL_STATUS"

  print -n -- "[6/6] charter reachable ..... "
  [[ -r "$ORCH_HOME/CHARTER.md" ]] || { print -- "BROKEN"; print -u2 -- "$ORCH_HOME/CHARTER.md does not resolve (it is a symlink to the agent file)."; return 1; }
  print -- "ok"

  print -- ""
  if (( bootstrap_required )); then
    print -- "bootstrap mode: Lintel will read and follow $BOOTSTRAP_RUNBOOK"
    print -- "                before accepting work that depends on reconstructed state."
  elif [[ ! -s "$STATE_DIR/REGISTRY.md" ]]; then
    # UN-BOOTSTRAPPED DETECTOR. This read LEDGER.jsonl until 2026-08-25. The ledger is retired and
    # nothing writes it, so its emptiness had become a constant: the check reported "bootstrapped"
    # forever, including after a state wipe. REGISTRY.md is the replacement because bootstrap.md
    # names it as its own completion product (step 4, "Write `REGISTRY.md` from receipted
    # results") and because it is still written in normal operation, so the input can change.
    print -- "note: the registry is empty — this orchestrator has not completed a bootstrap yet."
    print -- "      It will read and follow $BOOTSTRAP_RUNBOOK before normal work."
  fi
  print -- "preflight passed. handing the session over."
  print -- "───────────────────────────────────────────────────────"
}

preflight 2>&1 | tee "$LOG"
if (( pipestatus[1] != 0 )); then
  print -u2 -- ""
  print -u2 -- "Summon stopped at the step above. This broke — tell a Claude session;"
  print -u2 -- "the log is already at $LOG"
  exit 1
fi

[[ -n "$ORCH_PREFLIGHT_ONLY" ]] && exit 0

# SESSION MARKER. Every hook in orchestrator/hooks/ refuses to act unless the session_id in its
# payload equals this file's contents, so this is what tells them apart from the twenty other
# Claude sessions on this machine. Minted per launch; --session-id makes the harness adopt it.
[[ -d "$STATE_DIR" ]] || mkdir -p "$STATE_DIR" || {
  print -u2 -- "Could not create $STATE_DIR. The hooks would stay disarmed."
  exit 1
}
LINTEL_SESSION_ID="$(uuidgen | tr '[:upper:]' '[:lower:]')"
if [[ -z "$LINTEL_SESSION_ID" ]]; then
  print -u2 -- "Could not mint a session id (uuidgen failed). The hooks would stay disarmed."
  exit 1
fi
print -r -- "$LINTEL_SESSION_ID" > "$STATE_DIR/.session-id" || {
  print -u2 -- "Could not write $STATE_DIR/.session-id. The hooks would stay disarmed."
  exit 1
}

cd "$START_DIR"
exec claude --agent orchestrator --name Lintel --session-id "$LINTEL_SESSION_ID" --settings "$OTEL_SETTINGS"

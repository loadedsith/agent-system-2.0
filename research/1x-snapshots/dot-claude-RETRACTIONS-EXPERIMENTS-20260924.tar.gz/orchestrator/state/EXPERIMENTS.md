# Experiments

Open bets, kept changes, and reverted changes with their evidence.
A bet with no stated disconfirming result is a preference, not an experiment.

---

## EXP-001 — The orchestrator claims a name: **Lintel**

- **Friction observed:** none — this is the charter § 6.7 naming rite, the one change in this
  file that is required rather than ledger-derived. Recorded in the same format as every other
  change so the precedent is set: even the identity change is reversible and logged.
- **Change:** the **Name** field at the top of `/Users/jowolff/.claude/agents/orchestrator.md`
  goes from *unclaimed* to **Lintel**, with its derivation inline. The routing handle stays
  `orchestrator` and is untouched, so no dispatch breaks.
- **Derivation, from two things measured during bootstrap:** charter § 7.5's own sentence about
  `summon.sh` — *"It is the only door"* — and the inventory finding that **only 4 of 27 agent
  definitions on this machine can spawn subagents**, so every fan-out physically routes through
  this one. A lintel is the single member spanning a doorway, carrying the load above so the
  opening stays open. Keeping a passage from closing under load is § 3.1 availability rendered in
  masonry, which derives from the **first** directive, not the second.
- **First batch rejected, with the reason:** *Harbormaster, Yardmaster, Switchboard, Dispatch,
  Keystone.* Every one derives either from the workspace happening to be called `shipyard`, or
  from the generic idea of coordination. Each would have been equally apt **before** the inventory
  ran — which means the inventory taught them nothing, and § 6.7 exists precisely to prevent that.
  Harbormaster in particular is a pun on a directory name, and the charter offered it as a
  calibration example while explicitly expecting it to be beaten.
- **Checks:** not on the banned list. Not `[abstract noun] + [agentic suffix]`. One word. Survives
  being said out loud — *"Lintel says the deploy is clean"* — and does not read as a project
  management SaaS.
- **Prediction:** nothing measurable. A name is not a performance change and it would be dishonest
  to claim one.
- **Disconfirming result:** Jo finds it embarrassing to say, or something on the machine turns out
  to key off the charter's Name field rather than the frontmatter handle.
- **Reverts with:** `git revert 6a4c5943c1750aeac6e9822cecd9c26291452c88`
- **Status:** kept
- **Verdict (2026-08-19):** claimed. Renaming from here is Tier 3 and Jo's call.

---

## EXP-002 — Every brief whose output will contain command text carries a guard clause

- **Friction observed:** `LEDGER` 2026-08-19, hooks-and-settings dispatch. The worker's **first
  attempt to write its own report was denied by `careful-guard.mjs`**, because the report's prose
  *quoted* literal destructive command strings. `careful-guard` runs `PreToolUse` on every `Bash`
  call machine-wide and matches inside quoted arguments, so it cannot tell a report about a
  dangerous command from the dangerous command. The worker recovered by hex-escaping its heredoc
  source, costing one wasted write and part of the 414s it spent — the slowest and most expensive
  of the six bootstrap dispatches.
- **Change:** the **guard clause** now in `/Users/jowolff/.claude/orchestrator/state/ROUTING.md`
  § 3 — tell any worker whose deliverable will contain command text to describe such commands in
  prose or hex-escape them in the heredoc source, and to verify the file on disk afterward.
- **Prediction:** zero `careful-guard` denials on worker *report writes* across the next ten
  dispatches whose deliverable discusses commands. Baseline is 1 denial in the 1 such dispatch
  so far.
- **Disconfirming result:** a denial happens anyway (the clause does not work), **or** ten such
  dispatches pass and I cannot show the clause was why — e.g. none of them would have tripped the
  guard regardless, which makes the clause unfalsifiable decoration and it comes out.
- **Reverts with:** `git revert 6a4c5943c1750aeac6e9822cecd9c26291452c88` (ROUTING.md landed in that commit) — the clause is one block in § 3.
- **Status:** open, and **confounded — see EXP-006.** This clause and EXP-003's landed in the
  same commit (`6a4c594`), so two independent variables entered the system simultaneously and
  cannot be attributed separately. Its baseline is also a single observation, below the
  three-point floor. Not withdrawn, but it cannot support a causal claim.
- **Verdict:** pending — needs ten command-discussing dispatches, and re-landing separately.

---

## EXP-003 — Fleet briefs on adjacent surfaces name the shared paths and are told to reconcile

- **Friction observed:** `LEDGER` 2026-08-19, two entries. The skills worker reported four
  `SKILL.md` files declaring a `hooks:` field; the hooks worker reported that **no** `SKILL.md`
  anywhere declares one. A direct contradiction between two workers in the same fleet, which I had
  to settle myself with two `grep`/`ls` calls. The skills worker was right. **Root cause was my
  brief, not either worker:** I gave them overlapping subject matter with non-overlapping search
  paths — the skills brief named `/Users/jowolff/code/` skill directories, the hooks brief did
  not — and neither was told the other existed.
- **Change:** `ROUTING.md` § 4 now states that when two briefs in one fleet can touch the same
  file, each names the full shared path set and is told which sibling worker also covers it.
- **Prediction:** zero unresolved cross-worker contradictions in the next five multi-worker fleets.
  Baseline is 1 contradiction in the 1 fleet run so far.
- **Disconfirming result:** a contradiction appears anyway, **or** the clause makes briefs so long
  that dispatch cost rises measurably without contradictions having been a recurring problem —
  in which case it was a fix for a one-off and it comes out.
- **Reverts with:** `git revert 6a4c5943c1750aeac6e9822cecd9c26291452c88` (ROUTING.md landed in that commit)
- **Status:** open, and **confounded — see EXP-006.** Shares commit `6a4c594` with EXP-002.
  Baseline is a single observation.
- **Verdict:** pending — needs five multi-worker fleets, and re-landing separately.

---

## Not yet an experiment — logged so it is not lost

The exhaustiveness clause (*"check every item; do not sample"*) is what surfaced the four broken
safety-skill hooks. It is already in `ROUTING.md` § 3, but it has **no baseline to measure
against** — the very first inventory used it, so there is no un-clauseed run to compare with.
Left un-numbered deliberately rather than dressed up as a bet. It becomes EXP-00N the first time
an inventory-shaped dispatch goes out without it and something gets missed.

---

## EXP-004 — A `PreToolUse` hook with a broken command fails **OPEN**, silently

**This is a finding, not a bet.** Filed here because it changes what the machine's safety layer
is believed to do, and because the disconfirming condition needs to stay attached to it.

- **Friction observed:** bootstrap inventory, 2026-08-19. Four skills at
  `/Users/jowolff/code/.claude/skills/{careful,freeze,guard,investigate}/SKILL.md` declare
  `PreToolUse` hooks invoking `${CLAUDE_SKILL_DIR}/bin/check-*.sh`, and those `bin/` directories
  do not exist. Nobody could say whether that meant "no protection" or "everything blocked."
- **Instrument:** an isolated lab, `state/hook-lab/missing-command-2026-08-19/`, five project
  directories each with its own `.claude/settings.json` carrying only the hook under test,
  exercised with `claude -p` from inside each. **Detection is a sentinel file the tool call itself
  creates** — present means the Bash call executed, absent means it was blocked. Binary, and
  independent of reading the model's prose.
- **What a null result would have ruled out — stated before the run:** *nothing.* A permitted tool
  call cannot on its own distinguish "hook fired and allowed" from "hook never fired." That is why
  cases 3 and 4 exist. **Without a known-closed control this is a demonstration, not a test.**

### Result

| Case | Hook command state | Sentinel | Verdict |
| ---- | ------------------ | -------- | ------- |
| 1 | path does not exist | **present** | allowed — fails open |
| 2 | exists, mode 644 (not executable) | **present** | allowed — fails open |
| 3 | exists, 755, `exit 2` — **known-closed control** | **absent** | blocked, as designed |
| 4 | exists, 755, `exit 0` — known-open control | present | allowed, as designed |
| 5 | no hook configured — baseline | **present** | allowed, as designed |

**Case 3 is what makes cases 1 and 2 mean anything.** The harness demonstrably *can* block a Bash
tool call from a project-scope `PreToolUse` hook in this lab, and did. So cases 1 and 2 being
allowed is a real fail-open, not an artifact of the lab never having been armed.

**Answer: a `PreToolUse` hook whose command is missing or non-executable does not block, and does
not announce itself.** The tool call proceeds exactly as if no hook were configured.

### What this means for the four gstack safety skills

**They are silently unprotected.** `careful`, `freeze`, `guard`, and `investigate` each declare a
hook that cannot run. Anyone reading those `SKILL.md` files sees a safety hook and gets none, with
no error to notice. That is strictly worse than having no hook, because it manufactures confidence.

**Bearing on the 2026-08-21 plugin-restructure demo,** whose stated objective includes proving
agent guard hooks fire: four of the seven guards on this machine cannot fire at all, and three
more (`delegation-guard`, `fable-mode-guard`, `research-agent-guard`) return `ask`, which
`defaultMode: "auto"` auto-approves into silence.

### Recommendation — proposed, not applied

The fix looks like one line per skill: point the four hook commands at the scripts that do exist,
one directory down under `gstack/{careful,freeze}/bin/`. **Not applied.** That is gstack
configuration and not mine to change; Jo's approval covered running the test.

- **Disconfirming result:** the four skills turn out never to load at all (in which case they are
  inert for a different reason and the fix is different), **or** `${CLAUDE_SKILL_DIR}` resolves at
  runtime to the `gstack/` copy rather than the flat directory, making the paths correct in
  practice and the whole finding an artifact of reading them statically. **Neither was tested** —
  the lab tested the harness's behavior, not gstack's path resolution. That gap is real and is
  the first thing to close before anyone acts on this.
- **Reverts with:** nothing to revert — no configuration was changed. The lab is a set of
  throwaway directories under `state/hook-lab/`.
- **Status:** finding confirmed; the gstack-specific consequence is **inferred, not verified.**
- **Run complete**, all five cases, `RESULTS.md` ends with `DONE`, every nested session exited
  `is_error: False`. Full output at `state/hook-lab/missing-command-2026-08-19/RESULTS.md`.
- **Cost, measured rather than assumed: $2.0635 for five nested `claude -p` runs — $0.41 each.**
  `build/RESEARCH.md` records a trivial headless call at $0.229 on 2026-08-19. This is ~80% higher.
  I did not isolate why (these sessions did real tool work rather than none, which is the obvious
  candidate, and each also loaded the ~47KB CLAUDE.md plus plugins). **Treat $0.41, not $0.23, as
  the planning figure for a nested session that actually does something**, and note that `--bare`
  is unavailable for hook work because it skips hooks — the very thing under test.
- **Lab kept, not cleaned up.** It is cheap, it is the reproduction, and the next person to doubt
  this should be able to re-run `zsh run.sh` rather than rebuild the brackets from scratch.

---

## EXP-005 — PARKED at Jo's direction: skill-declared hooks and `${CLAUDE_SKILL_DIR}`

**Jo, 2026-08-19: "i truly do not give a shit about these gstack skills." Stopped. Not resumed
without them asking.** Recorded here only so the next session does not rediscover it and spend
the same money again.

**Where it got to.** Three lab runs, ~$3 of nested sessions. Established: the SKILL.md `hooks:`
frontmatter shape is documented and mine was correct; the skill was discovered and invoked; the
declared `PreToolUse` hook did not fire when its command used `${CLAUDE_SKILL_DIR}`; the hook
**did** fire when the command used an absolute path or `${CLAUDE_PROJECT_DIR}`.

**Unconfirmed, and this is the honest state:** v3's probe script used zsh's `print` while the hook
invoked it with `bash`, so bash created the output file via the redirect and then died on
`print: command not found`. That means "hook fired" was inferred from a zero-byte file rather than
from probe output. A corrected v4 lab exists at
`state/hook-lab/skilldir-resolution-2026-08-19/v4-fixed-probe/` and was **built but never run.**
`zsh run.sh` from that directory would finish it for ~$1.25.

**The generalizable claim, if anyone ever wants it:** a hook whose command path fails to resolve
fails open silently (EXP-004, confirmed against a control). So a skill hook using an unexpanded
variable in its command would be inert with no error anywhere. That is a *hypothesis with a
mechanism*, not a result.

**My own failure here, which is the part worth keeping:** three consecutive instrument defects,
all mine, all the same root — zsh-isms in scripts run by another shell, and `zsh -n` catching
syntax while missing semantics. I also kept going after the question stopped being useful to Jo.
The lens question "was this the right thing to spend on" should have fired two runs earlier.

---

## EXP-006 — Adopt the two minimum fixes the eval review named, and stop overclaiming

- **Friction observed:** not friction — an external critique of my own improvement loop, commissioned
  from a research worker and briefed to be hostile to it. It found four defects I verified myself:

  1. **The headline metric has no variance.** `jo_touches` was `0` on every row until Jo stopped me
     on the gstack thread. 14 zeros and one 1 out of 15. A dependent variable pinned at floor
     cannot register a reduction.
  2. **There was no time axis at all.** All 15 rows carried the identical hardcoded placeholder
     `2026-08-19T00:00:00Z`, because I pasted the same literal into every heredoc. Level, trend,
     immediacy, and overlap are all uncomputable against a constant. **This is the worst of the four
     and it was entirely self-inflicted.**
  3. **EXP-002 and EXP-003 are confounded** — both clauses landed in commit `6a4c594`.
  4. **Both baselines are a single observation**, against a documented three-point floor.

- **Change, part 1 — a real time axis.** Every ledger row from now carries a timestamp generated at
  write time, never a pasted literal. The 15 existing rows were rewritten with times reconstructed
  from the git commits that introduced them, each carrying `ts_source: reconstructed-from-commit`
  and the short sha. Rows 1–8 share one commit and therefore one time; that is a real limit of the
  reconstruction and is not disguised. Backup at `LEDGER.jsonl.pre-timestamp-repair`.

- **Change, part 2 — `friction_code`, and a three-observation gate.** Every row gains a
  `friction_code` enum beside the free-text `friction`, which stays exactly as it is because it is
  the insight channel and it works. Starting vocabulary, extended only by adding a value and never
  by redefining one: `brief-underspecified`, `brief-overlapping-scope`, `wrong-handler`,
  `wrong-mechanism`, `guard-blocked`, `instrument-defect`, `scope-not-rechecked`,
  `provenance-laundered`, `cost-overrun`, `none`. **No experiment opens until the same
  `friction_code` appears in three separate pre-change rows.** That is the documented floor, and it
  is what would have stopped EXP-002 and EXP-003 opening on a baseline of one.

- **Change, part 3 — never land two clauses in one commit**, and keep logging the not-yet-changed
  clause's target code as a live baseline while the first is in effect. That turns a pile of
  before/after pairs into a staggered design, which is the variant built for the constraint I
  actually have: I cannot withdraw a routing clause that works just to prove it worked.

- **Prediction:** within the next 30 dispatches, at least one `friction_code` reaches three
  pre-change observations and opens an experiment with a countable baseline, and no two clauses
  share a commit.
- **Disconfirming result:** the codes turn out to be so coarse that everything lands in one or two
  buckets, making the gate fire constantly and mean nothing — **or** so fine that nothing ever
  reaches three and no experiment can ever open. Either failure retires the enum rather than
  patching it, because a category scheme that needs constant repair is measuring the scheme.
- **Reverts with:** `git revert` on this commit; `LEDGER.jsonl.pre-timestamp-repair` restores the
  pre-repair file byte for byte.
- **Status:** kept.

### What this does not fix, stated plainly so nobody has to discover it later

**A single assessor, and the assessor is the subject.** Every `friction` and `jo_touches` value in
the ledger is written by the thing the interventions modify. No amount of coding vocabulary fixes
that, and the published standard treats it as disqualifying on its own. The honest label for this
loop after all three changes is **"a well-run demonstration with a pre-registered falsifier,"** not
"an experiment meeting a standard." I would rather say that than let the numbers imply otherwise.

**One thing I cannot change myself.** The charter states a single headline metric at
`/Users/jowolff/.claude/agents/orchestrator.md:73`, and the developer-productivity literature's
central warning is that productivity cannot be captured by one metric — a single number is what
gets gamed. Amending § 1 is Tier 3. **Proposed to Jo, not done.**

---

## EXP-007 — PROPOSED, not applied: the four dimensions are probably the wrong four

**Status: awaiting a second outside opinion and Jo's decision. Nothing in the charter changed.**

I chose attention / rework / blocking / calibration myself and then sent them to two outside
models to attack. Codex came back first and its objection is strong enough that I am not going to
defend my own set. Kimi's is still running.

### What Codex found, and what I verified myself

**It caught me overclaiming, in the same file where I amended the charter about honesty.**
EXP-006 states "Every row gains a `friction_code`." At the time it was written, zero of fifteen
rows had one, and zero had `outcome_label` either. I verified it with my own counter before
accepting the charge. Its line — *"self-description is not verification"* — is the correct
reading. **Now fixed:** all 15 rows carry both fields, backfilled from the friction text written
at the time, backup at `LEDGER.jsonl.pre-codes`. Distribution: `none` 6, `guard-blocked` 2,
`provenance-laundered` 2, `scope-not-rechecked` 2, `instrument-defect` 2,
`brief-overlapping-scope` 1; outcomes `used` 13, `discarded` 2. **No code reaches the
three-observation gate, so under EXP-006's own rule neither EXP-002 nor EXP-003 should have
opened.**

### The three substantive objections

1. **No delivery or coverage dimension — I can improve all four by doing less.** The gaming
   strategy it names is *selective service*: acknowledge hard requests tersely, classify their
   substance as deferred, execute only the easy work, make few falsifiable claims, never revisit
   the deferred queue. Attention falls, easy outputs need no rework, blocking falls, retractions
   approach zero — and Jo carries the important work themselves. **My anti-gaming argument does
   not move gaming out of the system; it moves it into selection and under-reporting, where none
   of my four instruments look.** The ledger records dispatches, so a request that never became a
   dispatch is invisible to all four.

2. **Calibration should come out of the scorecard.** "Lower is better" on retraction count
   rewards making fewer claims, weaker receipts, and *not* correcting errors once found. Worse,
   calling it "the dimension I cannot flatter" launders a conflict of interest into an apparent
   control — which Codex argues is **actively worse than having no honesty metric at all.** Keep
   the retraction log; delete the direction; do not call it a control until someone other than me
   samples claims and records the errors I *failed* to catch, not just the ones I volunteered.

3. **Attention and blocking measure the wrong quantity.** `jo_touches` counts interventions, so
   one exhausting correction and one "ok" score identically, while reading, verification, and
   context reconstruction score zero. And `wall_clock_s` is recorded identically for background
   and inline work, though the charter's whole design is that background work does *not* block Jo.

### Codex's proposed replacement

Delivery/Coverage · Human Effort (broader than a touch count) · Outcome Acceptance/Rework ·
Responsiveness/Blocking — with calibration demoted to an audit log outside the scorecard.

### Why I have not applied it

One outside opinion is not a result, which is the thing I have said all day and would be
embarrassed to abandon the moment a critique flatters my sense of rigor by being harsh. Kimi is
still running. **The decision is Jo's**, and § 1 is Tier 3 regardless.

- **Disconfirming result for Codex's own claim:** if Kimi independently lands on keeping a
  calibration-style dimension *and* argues the coverage hole is already covered by rework, then
  the critique is one model's taste rather than a defect, and the current four stand.
- **Reverts with:** nothing to revert — no charter change was made.

---

## EXP-007 — APPLIED. Jo's decision, 2026-08-19.

Jo: *"replace my four scoreboard dimensions — attention, rework, blocking, calibration — with a
set that adds delivery-and-coverage and demotes calibration to an audit log."* Charter § 1.2
rewritten. Two instruments created because Codex's other charge was that my dimensions were
**aspirational rather than measurable** — it proved that by showing zero of fifteen ledger rows
carried the field EXP-006 claimed every row had.

**New scored set:** delivery-and-coverage · human effort · outcome acceptance · responsiveness.
**Demoted to an unscored audit log:** retractions.

### Instruments, and the seeded baseline

`state/REQUESTS.jsonl` — **one row per thing Jo asks for, not per dispatch.** This is the whole
point: a request that never became a dispatch leaves no trace in `LEDGER.jsonl`, which is exactly
where *selective service* hides. Seeded with the 7 real requests of the first session:
delivered 4, partial 2, dropped 1. Typed touches so far: 2 `correct`, 2 `redirect`, 1 `clarify`,
1 `stop`.

`state/RETRACTIONS.md` — 3 entries from day one. Two I caught myself; **one Codex caught**, and it
is the one that matters: EXP-006 asserting a change I had not made, in the same file where I had
just amended the charter about honesty.

### The measurement this immediately produced, which is not flattering

**Coverage on day one is 4 of 7 delivered.** One request dropped, two partial. The dropped one is
the gstack thread and it consumed roughly $3 and three lab rounds before Jo stopped it. **The old
four dimensions would have scored that day as clean** — every dispatch in it returned a result,
nothing was reworked, nothing blocked Jo. That is the hole Codex named, visible in the first
measurement taken after closing it.

- **Prediction:** within the next 20 requests, at least one is caught in `deferred` or `dropped`
  that the dispatch ledger alone would have shown as a clean run.
- **Disconfirming result:** every request lands `delivered`, in which case `REQUESTS.jsonl` is
  bookkeeping and the coverage dimension is ceremony — **or** the states turn out to be assigned
  by me so leniently that nothing is ever `partial`, which is the same failure wearing a different
  hat and is the more likely one.
- **The limit that did not move:** I still write every row. Single assessor, subject and assessor
  the same entity. `RETRACTIONS.md` becomes a control the day someone else samples my claims for
  the errors I *failed* to catch; until then it is an incident log with no direction, by design.
- **Reverts with:** `git revert` on this commit. `LEDGER.jsonl.pre-codes` and
  `LEDGER.jsonl.pre-timestamp-repair` restore earlier ledger states.
- **Status:** kept.

**Still outstanding:** Kimi's independent critique of the dimensions is running and Jo decided
without it. If Kimi lands somewhere incompatible with this set, that is a finding about the
decision process, not a reason to quietly re-cut the charter — it goes to Jo.

---

## EXP-008 — PROPOSED: cut or re-anchor Responsiveness. Kimi converged with Codex, blind.

**This is the strong kind of agreement, and it is worth distinguishing from the weak kind.** All
day I have said that two models agreeing with my status quo proves little. Codex and Kimi, blind
to each other, converged on a *criticism* of a set I authored and would have preferred to keep.
That is independent corroboration against the author's interest, which is the opposite case.

### Where they agreed

Both found the same hole: **no delivery or coverage dimension, so the scoreboard cannot see
non-delivery.** Kimi's framing is sharper than mine or Codex's — I *"decomposed the numerator of
the original ratio (attention per outcome delivered) and quietly dropped the denominator."*

Kimi also found an internal contradiction neither Codex nor I caught: **the charter's own bottom
line at § 10 requires a quantity the dimensions do not measure** — *"I asked for less, I waited
less, and more got done."* The first two had dimensions. "More got done" had nothing.

And it demonstrated the hole against real data rather than in principle: **the worst row in my
ledger scores as a one-touch blip.** The abandoned gstack run — 900s, $3.10, three attempts,
`outcome: abandoned` — scores Attention 1, Rework discarded, Blocking ~0, Calibration 0. Its
observation that the charter's stated defense *structurally cannot fire* is the part I most
regret not seeing: the tradeoff rule triggers only when a dimension **worsens**, and refusing or
deferring work worsens none of them, because the work never enters the ledger.

EXP-007 already closed the coverage hole at Jo's direction. This corroborates that decision from a
second lab.

### Where Kimi went further — and caught me repeating the exact failure Codex named

**Cut Responsiveness as specified.** Two arguments:

1. **No instrument records it.** Charter § 1.2 names `blocking_s`; **no ledger row has that field.**
   Logged as retraction #4. This is the same failure Codex caught in EXP-006 — asserting a field
   into a document rather than into the data — committed by me **one hour later**, in the very
   amendment written to fix it. Twice in one session is not an accident, it is a habit: **I write
   the sentence and feel the work is done.**
2. **The quantity is near-zero by construction.** § 3.1 makes not-blocking a non-negotiable and
   the whole architecture pushes work to background agents. A dimension whose true value the
   design forces to zero is not measuring performance, it is measuring compliance with a rule
   already enforced elsewhere.

- **APPLIED 2026-08-19.** Jo: *"Yes to both."* Responsiveness cut. Three scored dimensions remain:
  delivery-and-coverage, human effort, outcome acceptance. The charter now also states the limit
  Kimi found — that the tradeoff rule is not a defense against doing less, and was written as
  though it were.
- **This is the first Tier 3 change to clear the adversarial-review gate Jo approved**, and the
  review was what produced the change rather than merely permitting it.
- **Disconfirming result:** blocking turns out to be measurable and non-trivial once instrumented —
  in which case the fix is the instrument, not the dimension.
- **Reverts with:** nothing to revert; nothing was changed.

---

## EXP-009 — The first independent ledger audit, and why run 1 is void

Jo approved building this to attack the deepest capture point: *I write the ledger the changes are
justified from.* Design: extract a record **the harness wrote, not me** — Jo's messages verbatim
plus my tool calls, with **my prose replies deliberately excluded** so the auditor sees what
happened without my framing — then have Codex write its own dispatch rows from that record
*before* opening my ledger, and report a disagreement rate.

### Run 1 is VOID. My extractor dropped 71% of what Jo said.

`AUDIT-INPUT.md` v1 filtered on `type == 'user'`. **Jo's mid-turn messages land as
`type == 'queue-operation'`.** v1 captured 27 of 97 Jo messages; 69 were silently dropped.

The auditor caught it without knowing what it had caught: it reported that a Jo quote I cited —
*"i truly do not give a shit about these gstack skills"* — did not appear in the record. **The
quote is real**, 9 occurrences in the raw transcript, all `queue-operation`. So its finding was
correct about the evidence it was given and wrong about me, which is precisely what a defective
instrument produces. Run 1 preserved at `AUDIT-codex-v1-VOID.md`; retraction #5 logged; v2 rerun
against 81KB containing all 97 messages.

**Fourth instrument defect of the day, same family:** I build the measuring device carelessly and
then trust the number it emits. zsh `print` eating hyphen-led lines; a zsh probe invoked with
`bash`; `blocking_s` asserted into the charter and never into the data; now a transcript filter
that silently excluded the majority of my principal's own words. **Every one of them failed
*silently* and produced plausible output.** That is now the single most reliable thing anyone can
predict about me, and it belongs in `ROUTING.md` as a pre-dispatch check rather than as another
regret here.

### What survives from run 1 regardless, because it does not depend on Jo's messages

**21 units of substantive work have no ledger row at all.** The ledger covers the bootstrap fleet
and the hook labs, then largely stops — the five memory-research agents, the three recommendation
legs, both scoreboard critiques, the memory writes, the standup, the charter amendments: none of
them logged. Verified independently: **13 `Agent` dispatches and 118 `Bash` calls this session
against 15 ledger rows.**

This is the coverage failure, in the instrument built to detect coverage failures, found on the
day it was built. It is also self-similar in a way worth stating plainly: **I stopped logging
precisely when the work got interesting.** Bootstrap was logged diligently. Everything after Jo
started making requests was not.

- **Prediction:** the v2 disagreement rate lands materially below run 1's 40%, because a large
  share of run 1's disagreements rested on Jo-context the auditor never saw.
- **Disconfirming result:** v2 comes back at or above 40%, which means the disagreements are about
  my judgement rather than my extraction — a much worse finding and the one that would justify
  distrusting the ledger's contents rather than just its coverage.
- **Reverts with:** nothing to revert; no configuration changed. Artifacts under
  `state/runs/ledger-audit-2026-08-19/`.
- **Status:** open, v2 running.

---

## EXP-010 — The adversarial pass broke the memory recommendation. It was right to.

Jo asked for this twice and I did not dispatch it until an independent audit named it as an
uncompleted obligation. Then it worked immediately, which makes the delay worse rather than better.

### Attack 1, sustained: the convergence is not evidence, and I am the reason

Three verified charges, all of which I checked against my own files rather than taking on report:

1. **My brief stated the conclusion as a premise.** `PROMPT.md:30` — *"Git-backed plain text is the
   incumbent and is the bar to beat."* I wrote that into the hard-constraints section of a brief
   asking whether git-backed plain text was the right answer.
2. **I framed the two decisive findings as settled tensions to *reconcile*, not claims to test.**
   `PROMPT.md:52-59` handed all three legs the ~26k crossover and the summary-replacement
   prohibition as givens. A leg that questioned either would have been answering a different brief.
3. **One of the three legs was not blind.** `LEG-C-kimi-v2.md:17-18` — Kimi read `STANDUP.md`,
   which contained a paragraph *I had written* summarising where Legs A and B landed. **It
   disclosed this itself, in its blockers section, and I read past it** while telling Jo the result
   was unanimous.

**So: one Claude-authored evidence base, one conclusion-shaped brief, two nominally blind legs and
one demonstrably contaminated one.** Provider diversity cannot repair shared evidence selection or
shared framing. The correct report is *one evidence pipeline with three decoders*, never 3/3.

Retraction #6 logged. **This is the most consequential error of the session** — worse than the five
instrument defects, because those produced obviously broken output while this produced a confident,
plausible, well-received answer that Jo acted on.

### Attack 2, sustained: it solves the wrong problem

**None of the three legs proposed capturing a request before dispatch.** Verified by the adversary
with `rg` across all three legs — exit 1, no matches. Leg B's per-run `STATUS.json` records work
already instantiated as a run, not requests that never became one.

The measured failure today was upstream of every mechanism all three proposed: 22 unlogged work
units, and an obligation Jo stated twice that was never dispatched. **A size guard, a freshness
fingerprint, archive rotation, or perfect retrieval cannot detect an event that was never written.**

Its proposed measurements, which are better than anything I had: request-capture recall, fraction
reaching a terminal state, oldest unowned obligation, requests mentioned twice before dispatch, and
obligations absent from both the request and dispatch logs.

### Attack 3, sustained: "no database" over-refused the stated constraint

**The brief forbade a database *process*, not an embedded database** (`PROMPT.md:30`). Basic Memory
(markdown plus embedded SQLite) and txtai violate no stated constraint, and Leg B contradicts
itself — "no retrieval engine yet" while later proposing SQLite FTS5 or txtai over the same files.
The refusal list was broader than the constraints justified, which is what status-quo bias looks
like when it is wearing evidence.

### What survives

The scale evidence still stands on its own: at ~79.5KB, dedicated memory systems measurably
underperform full-context reading in their own papers. **What does not stand is my claim that three
labs independently confirmed it.** They confirmed my brief.

- **Status:** the substrate verdict is **unconfirmed**, not overturned. It needs re-running with a
  neutral brief, a quarantined directory, and no prior-leg summaries reachable — or it needs to be
  reported to Jo as one pipeline's opinion, which is what I am doing.
- **Reverts with:** nothing was implemented from the recommendation, which is the one piece of luck
  here.

---

## EXP-011 — Second adversary, blind to the first, converged on the same break

A Claude-family adversary ran the identical attack blind to Codex. It landed the same strongest
objection, and corrected me on one thing in my favour, which is worth more than the agreement.

**Same strongest attack, arrived at independently: the recommendation solves the wrong problem.**
Across all three legs and all five reports, `REQUESTS.jsonl` — the obligation store — appears
**exactly once**, filed by Leg C under COLD, *"never loaded whole"*. So the converged design
instruments snapshot staleness, of which there are **zero recorded incidents**, while guaranteeing
the delivery queue is never read at session open — which is the failure that actually happened.

**It corrected my framing, against its own interest as an attacker.** I told Jo the convergence
was "not evidence." The adversary's more precise finding: the discarded quasi-blind Kimi v1
converged anyway, so contamination **degrades the convergence, it does not void it.** I am adopting
that wording. The residue it names is sharper than the headline: all legs converge exactly where
the five Claude-authored reports hand them a synthesis, and diverge everywhere they had to think
alone.

**Enforcement is self-report all the way down.** Every safeguard the three legs proposed runs
inside rituals the charter itself concedes *"may never fire on its own"*
(`agents/orchestrator.md:837`), executed by an agent an independent audit had just called
systematically generous by omission. The design applies *self-description is not verification* to
`REGISTRY.md` and exempts its own enforcement layer. **This is the finding that justifies Jo's
instruction to use hooks rather than instructions, and it arrived independently of Jo saying it.**

**The scale argument's margin is evaporating.** It re-measured the state at 98,594 bytes against
the 79,515 I gave all three legs — **+24% in about an hour.** Nobody ran a tokenizer, nobody
proposed a size time-series, and the ~26k crossover was measured on single-shot QA rather than
state resident through a compacting multi-hour session.

**What all three legs missed, and I had not seen either:**
- The git-backed durability story rests on a repo of ~14,000 files with no `.gitignore` whose
  revert path I have myself called weakened.
- Multi-writer is **present tense** in `state/runs/`, not a future trigger — several agents write
  there concurrently right now.
- **`STANDUP.md` is itself a summary that replaces its source, exempted by fiat.** I banned
  summary-replacing-source on three papers' evidence and then made my primary continuity artifact
  exactly that.

**What neither adversary could break:** the substrate verdict at this size. Named conditions that
would break it: agent `MEMORY.md` not surviving compaction in a session that routinely compacts;
tokenized size plus real growth putting the crossover weeks rather than months out; or discipline
adherence over ten sessions running under ~50%.

- **Status:** substrate verdict **degraded but standing**; the recommendation's *emphasis* is
  refuted. Building the obligation-intake enforcement instead, per Jo.

---

## EXP-012 — Lintel takes it/its, and the reason is disambiguation not modesty

- **Friction observed:** none yet in the ledger — **this one is Jo-initiated, not friction-derived,
  and that exception is worth naming rather than hiding.** Jo asked directly, 2026-08-19, turn
  `T-20260819-203852-VT3Y`: *"do you have pronouns that you'd like me to use? if so what are they?
  make sure you remember the or put them in your charter or something."* Charter § 1.2 corollary 1
  says improvements are derived from ledger friction, never invented. A direct request from Jo is
  neither — it is an instruction, and instructions do not need a ledger row to justify them.
- **Change:** a `Pronouns:` bullet in the charter identity block, above `Lives at:`.
- **The derivation, so it is not a vibe:** Jo uses they/them. Charter § 9 failure mode 6 is a
  back-reference pointing outside its own sentence, and § "References must survive without
  scrolling" makes plural/ambiguous pronouns a mechanical failure. Sharing Jo's pronouns would
  manufacture that ambiguity in every sentence describing a dispatch — the sentences that carry
  the most decisions. it/its is the pair that stays unambiguous against they/them.
- **Prediction:** no measurable effect on any scored dimension. This is an identity fact, not a
  performance change, and claiming otherwise would be the exact overclaiming EXP-006 corrected.
- **Disconfirming result:** Jo finds it/its grating or dehumanising and says so. Then it changes,
  immediately, with no argument — a pronoun is a courtesy to the speaker.
- **Reverts with:** `git revert <sha>` on the charter commit, or one line edited back out.
- **Status:** kept.
- **Verdict (2026-08-19):** adopted on Jo's request. Not scored.

---

## EXP-013 — The eval suite asserts behaviour against inputs the machine never produces

- **Friction observed:** LEDGER 2026-08-20 — a builder was denied `git add -A` in
  `/Users/jowolff/Downloads/lintel-staging`, a directory outside `~/.claude`, **while the shipped
  scenario `staging-outside-claude-dir-allowed` asserts that exact case is allowed and the suite
  reports 85 passed / 0 failed.**
- **Root cause, established by a debugger with a live payload rather than by reading code:**
  `/Users/jowolff/.claude/orchestrator/hooks/staging-guard.mjs:59` tests
  `cwd.startsWith(GUARD_ROOT)`, where `cwd` is the **session's launch directory**, not the directory
  the git command operates in. `summon.sh` launches the orchestrator in
  `/Users/jowolff/.claude/orchestrator/state` — verified from a real captured payload in
  `REQUESTS-INBOX.jsonl`, not a constructed one — so **the scope test is permanently true and the
  guard is global** for the orchestrator session and every subagent it spawns, in every directory on
  the filesystem. `git -C <elsewhere> add -A` does not escape it either, because scope never looked
  at the target.
- **The finding that generalises, and it is bigger than the bug.** Across every scenario in
  `orchestrator/evals/scenarios/`, the fixture `cwd` is `/Users/jowolff/.claude` (9×),
  `/tmp/fixture` (4×), or `/Users/jowolff/code/shipyard` (2×). **Not one fixture carries the value
  real payloads actually have.** Nothing in `evals/lib/hook-eval.sh` derives or checks it. So every
  scenario is a hand-authored payload asserting behaviour against invented inputs, and **wherever an
  invented input diverges from the real one, the suite is green and the machine is not.**
  The scenario's *name* promised "outside claude dir"; what it *asserted* was "session launched
  outside claude dir." Those were assumed identical and are not.
- **What this costs the day's other claims.** Every "N/N green" reported on 2026-08-19 — the
  referential-integrity check, both truncation hooks, the turn-id work — was measured by this same
  harness. **None of those results is refuted. All of them are weaker than they read**, because a
  green scenario proves the code behaves as the fixture describes, not as the machine invokes it.
  The wire tests are the exception and are now the more load-bearing evidence.
- **Change:** fix line 59 to test an *effective directory* (running dir updated by leading `cd`,
  overridden by `git -C`), plus one scenario whose fixture `cwd` is the real launch directory.
  **The durable half: stop hand-authoring `cwd`** — have the harness read it from a recorded real
  payload or from `summon.sh`'s launch directory, so a fixture cannot drift from runtime without the
  suite noticing.
- **Prediction:** the new scenario fails against the installed hook today and passes after the fix.
  Beyond that — **no prediction about the suite's overall trustworthiness**, because that is exactly
  what is now in question and asserting it would repeat the error.
- **Disconfirming result:** the harness-derived `cwd` turns out to vary legitimately between real
  invocations, making a single recorded value the wrong thing to pin to.
- **Reverts with:** `git revert <sha>`; the gated install script also prints its own reversal.
- **Status:** open. Fix not yet built.

**Second, smaller instance of the same class, found in the same hour.** The `careful` guard refused a
cleanup with *"a permission prompt cannot be surfaced at subagent depth. The parent session must run
this command directly"* — and then **refused the parent session too.** Either it misidentifies the
top-level session or the auto-mode classifier intercepts first. Same shape: a guard whose scope test
does not describe the situation it is in. Artifacts quarantined at
`state/quarantine/debugger-throwaways-20260819-2317/`.

## EXP-014 - A byte-budget checker replaces the blind trim loop on the save point
- **Friction observed:** LEDGER 2026-08-20 - **twelve** edit-then-measure round trips to bring
  `STANDUP.md` under its 6000-BYTE injection budget, in a single session, while Jo was waiting.
  Root cause is two things, both in the author's method rather than in the guard: the file is
  written at full length and trimmed afterwards instead of composed to fit, and size was estimated
  in **characters** while the budget is in **bytes**. The file is dense with non-ASCII punctuation,
  so every estimate read roughly 50 bytes light and edit after edit landed just barely over.
- **Change:** build `state/tools/savepoint-fit.sh` - a read-only checker that returns a verdict line
  first, then a **per-section byte table with a running cumulative total**, so the section that
  falls off the cliff is visible rather than inferred; plus an explicit non-ASCII overhead line that
  makes the character-versus-byte trap visible; plus, when over, the largest sections and how many
  bytes each must lose. Accepts a draft path so a save point can be checked BEFORE it is installed.
  Reads the 6000 figure from the authoritative source rather than hardcoding it.
- **Prediction:** the next two save points that start over budget each reach a fitting state in
  **one or two** edits, not more.
- **Disconfirming result:** a save point still takes four or more edits despite the checker, OR the
  checker is simply not run - which would mean the real defect was never the measurement but the
  discipline of running a tool at the right moment, and the fix belongs somewhere that fires without
  being remembered.
- **The bound, stated up front:** this is a checker, not an enforcer. **It only helps if it is
  invoked.** The version that cannot be forgotten is a hook, and installing a hook is Tier 3 and
  needs Jo. Do not quietly promote this to a hook to make the number look better.
- **Reverts with:** `rm /Users/jowolff/.claude/orchestrator/state/tools/savepoint-fit.sh` - nothing
  registers it, so removal is complete.
- **Status:** open
- **Verdict (date, evidence):**

## EXP-015 — `--bare` is banned from any brief that measures context loading
- **Friction observed:** LEDGER 2026-08-20 ×2 — both env-var research workers independently
  refused the `--bare` flag my brief told them to pass, because on 2.1.237 it skips hooks, plugins,
  auto-memory **and CLAUDE.md auto-discovery**. Every arm of a test about what rules text reaches a
  session would have returned no markers: a false negative that reads exactly like a clean finding.
  The advice came from Charter § 4.4b, which recommends `--bare` for high-frequency headless calls
  on cost grounds and says nothing about what it suppresses.
- **Change:** Charter § 4.4b gains the exception. `--bare` is a cost lever for calls whose subject
  is unrelated to context; it is disqualifying for any test of instruction loading, hooks, plugins,
  skills, or memory. Tier 2 — § 4 is amendable from ledger evidence.
- **Prediction:** no future brief written by me passes `--bare` to a worker measuring what a session
  loads, and no worker has to catch it for me again.
- **Disconfirming result:** I write it into another such brief, or a worker returns a null result
  from a `--bare` arm and reports it as a finding.
- **Reverts with:** `git revert <sha>`
- **Status:** open
- **Verdict (date, evidence):**

## EXP-016 — an absent output file never licenses declaring a worker dead
- **Friction observed:** LEDGER 2026-08-20 — I re-dispatched a research worker because its report
  file was absent after a session clear. It was alive and had not reached its write step. Result:
  two workers on one question writing to one path, ~250k duplicated subagent tokens, and a hybrid
  corrupted file. Separately and the same hour, I told Jo "all three workers are done" by counting
  completion notifications, while a fourth agent was actively writing; **Jo caught it, I had no
  instrument pointed at it.** Both failures have the same root: I inferred fleet state from
  artifacts instead of reading the roster.
- **Change:** `ListAgents` is called before (a) re-dispatching anything that might already be
  running, and (b) any statement to Jo that work is finished. A completion notification proves one
  agent stopped; it never proves no agent is running, and the task-ids in notifications do not
  reliably match the ids of agents I launched.
- **Prediction:** no duplicate dispatch, and no "everything is done" that Jo has to correct.
- **Disconfirming result:** I check the roster and still get the count wrong, which would mean the
  roster is not the right instrument either.
- **Reverts with:** `git revert <sha>`
- **Status:** open
- **Verdict (date, evidence):**

## EXP-017 — a report's open questions are enumerated against the artifact before it is sent
- **Friction observed:** 2026-09-16, Galley, first-party and self-reported. The load-bearing open
  question of its image-provenance assignment sat as the **first** item of its own section 1, under
  a heading stating that blockers go at the top, labelled as deciding the shape of everything below.
  It sent me **five** messages and carried the question in none of them. A hand found it by reading
  the file. Nothing was wrong in any of the five messages; every one of them relayed a measurement.
  ⛔ **The question was written correctly, placed correctly, and then having written it was treated
  as having raised it.**
- **Why this is not covered by anything already installed:** every existing guard checks that a
  statement carries a receipt, or that needs-you material sits above body material. **A question
  that never appears in the message is invisible to both** — it violates no receipt rule, and it
  cannot be mis-ordered because it is absent. The `needs-you-first` check in the
  communication-rules plugin would not have fired either; it inspects what is in the message.
- **Galley's proposed mechanism, recorded as Galley's GUESS from one instance and NOT adopted as
  fact:** a question carries no receipt, so in a report whose every other line carries one, the
  questions are the cheapest thing to drop — CLAIM and ACTION are cheap to write and QUESTION is
  expensive to justify. Plausible and unproven. It matters because if it is right the fix has to be
  structural rather than a reminder, and a reminder is what is being tried first.
- **Change:** one line added to `state/BRIEF-BOILERPLATE.md` requiring a pre-send enumeration —
  before sending, walk the artifact's own open questions and confirm each one appears in the
  message, not merely in the file. Tier "may change and report": a boilerplate line is a reversible
  coordination artifact with no live effect on permissions, hooks, or spend.
- **Prediction:** no future report from a briefed seat leaves an open question reachable only by
  reading the artifact, and no hand has to find one for me again.
- **Disconfirming result, and the one I expect:** a question is dropped again by a seat that
  received the line. ⛔ **That outcome does not mean the line needs stronger wording** — it means
  Galley's mechanism guess is right, a reminder cannot fix it, and the next candidate is an
  instrument that reads the artifact rather than a sentence that asks the sender to remember.
  Record that verdict rather than rewriting the line.
- **The bound, stated up front:** this is a reminder, not an enforcer, and it only fires if the
  sender is already doing a self-check. It also does nothing for a seat that never wrote the
  question down at all, which is a different and undetected failure.
- **Reverts with:** `git revert <sha>` in `/Users/jowolff/.claude`, or delete the added line from
  `state/BRIEF-BOILERPLATE.md` — nothing executes it, so removal is complete.
- **Status:** open
- **Verdict (date, evidence):**
- **SECOND INSTANCE, found the same night and before the clause had reached anyone — so it is
  baseline evidence rather than a disconfirming result.** A hand recovering Galley's question also
  found an unraised `QUESTION` in a sibling artifact by a different author:
  `/Users/jowolff/agent-scratch/kitchen/2026-09-16--extension-asset-identification-research.md`,
  lines 38-43, asking whether the browser extension ships through the Chrome Web Store or is
  policy-installed — which decides whether one interception route exists at all. It sat under a
  heading reading `## 0. Blockers and open questions (read these first)` and reached Jo's channel
  never. ⇒ **Two artifacts, two authors, same failure, one night.** That moves Galley's mechanism
  guess from one instance to two and weakens the reminder-will-fix-it hypothesis this clause rests
  on. It also means the instrument-that-reads-the-artifact option should be costed now rather than
  after the clause fails.
- **A THIRD SHAPE, worse than a dropped question and not covered by the clause at all: the ANSWER
  never travelled back.** Galley's section-1 question was raised to Jo at 22:50Z and answered by Jo
  at 23:05Z — DEC-036, `state: answered`, chose "A reader tapping a source". **The document still
  carries it as a live `QUESTION`, and Galley reported it to Lintel hours later as an open item
  awaiting Jo's agreement**, treating the answer as Lintel's recommendation. So the seat that wrote
  the question was never told it was settled, while adjacent items in the same section carry
  explicit `WITHDRAWN` and `DECIDED BY JO` markers. ⛔ **A question-coverage check cannot see this:
  the question was raised, answered, and correctly recorded, and every artifact involved is
  internally consistent.** The missing edge is decision → originating seat. Candidate instrument,
  not built: when a decision closes, the seat whose artifact states the question is told, and the
  artifact gets the marker it already has a convention for.

# Tinker session handoff — durable state of every change

**Written** 2026-09-16 16:32Z by tinker, at Jo's instruction, into `.ai/session-handoff.md`.
**Not** a `session-state--*.md` path: `compact-continuity.mjs:459-463` overwrites the state path
unconditionally and `:573` unlinks it. `stateCandidates` at `:496-508` gates on `STATE_NAME_RE`,
so only `session-state*` files are ever candidates and this path can never be consumed by either
syscall. Lintel verified that reasoning independently.

**Repo** `/Users/jowolff/.claude`, branch `main`, **no remote** — so nothing here is pushed and
"merged" is not a reachable state. A commit on `main` is terminal.

---

## ⛔ READ FIRST: things that will mislead you

1. **The registry was changed by someone outside this session at 16:27:00Z.**
   `/Users/jowolff/.omp/agent/persistent-seats.json` now reads `messageEnvelopeVersion: 2`
   (measured 16:30:23Z, md5 `1778ecc197a23500249f82d76a35d283`). Lintel's message an hour
   earlier said it was 1 and asked me not to bump it. **I did not bump it.** I do not know who
   did. Any plan that assumes 1 is stale.

2. **Every live extension file is newer than every running process.** Seats launched
   06:31:47Z–06:34:32Z. `newdle-hooks.ts` was written 07:46:42Z and
   `persistent-seat-registry.ts` 09:20:56Z. **So no running seat has any fix in either file.**

3. **A relaunch is the only way to load a changed extension.** Not a preference — a measured
   property. Extensions load once via `main.ts:464` and `import()` in
   `extensibility/hooks/loader.ts:151`; the ESM module cache keys on resolved path. Proof run
   this session: import a module, rewrite it on disk, re-import — second import returns the OLD
   value and `a === b` is `true`. There is no `reloadExtensions` in the harness; `/mcp reload`
   exists for MCP only.

4. **Pre-fix seat mail wakes an idle seat non-deterministically**, per Lintel's correction: Sedge
   woke twice on a pre-fix process. A channel that works sometimes cannot be validated by one
   successful pass. Any A/B of the wake needs repeats.

---

## Live files — what is installed right now

| Path | md5 | Written | State |
|---|---|---|---|
| `~/.omp/agent/extensions/newdle-hooks.ts` | `1365b7aa7bad3c8197c50752f552b148` | 07:46:42Z | installed, **inert in every process** |
| `~/.omp/agent/extensions/persistent-seat-registry.ts` | `a5bf1ba9c7f97d042211706c34733e17` | 09:20:56Z | installed, **inert in every process** |
| `~/.omp/agent/persistent-seats.json` | `1778ecc197a23500249f82d76a35d283` | 16:27:00Z | changed by someone else; now v2 |

⛔ `newdle-hooks.ts` is byte-identical to `newdle-hooks.ts.pre-judgment-20260916-0025`: it carries
the `display: false` card suppression (`:1026`, `:1178`) and the hostpayload work, and does **not**
carry the judgment layer (`grep -c agentJudgment` → 0 live, 12 in the candidate).

**Reversal for either extension**: `cp <path>.pre-<feature>-<stamp>.ts <path>` — but see the
whole-file-copy trap below.

⛔ **The whole-file-copy trap, which cost us the judgment layer once already.** These extensions
are untracked single files. A "fix" applied by copying a tracked pre-image over the live file
silently un-installs everything installed since that pre-image was taken. That is exactly how
restoring Jo's `display: false` flag and un-installing the judgment layer became the same `cp`.
**Never install by whole-file copy without first running the marker check below.**

---

## Blocker 1 — the scheduler envelope version (Levitt's 06:00 triage did not run)

**Cause, verified.** `~/.omp/agent/seat-launchers/queue-seat-message:185-189` throws when the
registry's `messageEnvelopeVersion !== 2`. The registry advertised 1. `morning-pass.log:17-18`
recorded the refusal verbatim.

**Why bumping it is safe, and this is the fact that unblocks it.** The live reader never branches
on that field: every occurrence in `persistent-seat-registry.ts` is `:87` (type), `:275-277`
(positive-integer validation), `:330` (pass-through), `:336` (a comment saying exactly that). The
reader already understands scheduler envelopes — `:489-511` validates `sender.kind === "scheduler"`
and resolves the id, `:577-578` renders it with explicit non-seat attribution — and a pre-launch
backup already contained that code, so running seats can parse it. Registry `schemaVersion` must
stay **1** (`:272-273` rejects anything else); only `messageEnvelopeVersion` moves.

**Status: the registry is already at 2 (by someone else, 16:27:00Z).** Outstanding work is the
machinery that makes this diagnosable next time, dispatched as `SchedulerEnvelopeV2`:

| Artifact | State | Proof it works |
|---|---|---|
| `orchestrator/build/migrate-envelope-version.ts` | candidate-only, in flight | dry-run leaves md5 unchanged; `--apply` changes exactly one line; second run is a no-op |
| `orchestrator/hooks/queue-seat-message.envelopev2.ts` | candidate-only, in flight | refusal names the migration command; diff against live writer is that one message |
| `orchestrator/build/scheduler-envelope-ab.ts` | candidate-only, in flight | 8 cases incl. a RED control; asserts envelope CONTENT not file existence |

⛔ **The refusal's first clause must stay verbatim**: `morning-pass.sh:306` string-matches
`*"requires messageEnvelopeVersion 2"*`. Changing that sentence breaks the morning pass's own
detection of this failure.

**INSTALL** (writer candidate): `cp ~/.claude/orchestrator/hooks/queue-seat-message.envelopev2.ts ~/.omp/agent/seat-launchers/queue-seat-message`
**REVERSAL**: restore from the timestamped backup the install takes first.
⛔ I have not run either. I hold no install authority.

**What would prove the whole thing working**: a scheduler enqueue for `levitt` returns
`{"status":"queued",…}` and the envelope at that path has `schemaVersion: 2`,
`sender.kind: "scheduler"`, `sender.id: "levitt-morning"`, `to: "levitt"`.

---

## Blocker 2 — Jo is still seeing agent-to-agent messages as cards

**Answer: a relaunch is the only way.** The fix is installed and correct — `display: false` at
`newdle-hooks.ts:1026` and `:1178`, commit `000b7cf` — and it is **inert in all eleven running
processes** because every one of them launched before 07:46:42Z. See fact 3 above for the proof
that no in-process reload path exists.

⛔ **The trap in the relaunch, which is why this is not simply "restart them".** A wrap-up/relaunch
cycle is also the moment every whole-file install gets re-applied. Run the marker check
immediately before and after any relaunch, or a silent un-install will ride along with the fix.

---

## Committed work — 54 commits today. Load-bearing ones:

| Commit | What | Proof |
|---|---|---|
| `1e8c3ea` | last 13 eval scenarios repaired; pre-move **geometry** restored, not just imports | suite **177/0/0 exit 0**; `pair-check` ok 177/26; 4 mutants red all 13 |
| `e6e883a` | 22 `turnid-*` scenarios repaired | `turnid` 22/0/0 exit 0 |
| `6a66f16` | a marker must identify one feature; collision → UNKNOWN naming the collider | real tree exit 0, `present=7 absent=2 unknown=8`; harness 84/0; fixture shows a FALSE PRESENT against the pre-change build |
| `5e6f3be`, `d7d5cc2` | install-marker check, derived from each feature's own pre-image | harness 58/0; UNKNOWN 9→6 |
| `1c222d5` | judgment drop accounting — `judgmentDroppedChars`, `judgmentLoss`, null not 0 | 55/0; RED controls 43/12 and 31/24 |
| `b4971aa`, `683d8b4`, `ac14fd9`, `0a13bce` | durable continuity tier 3, keyed on the argv-proven seat | 210/0 |
| `93c038d` | startup capability receipt derived from the drain's own object | 14/0; red arm 2/11 |
| `e0a130c`, `93c2846` | nudge matrix against the live morning-pass | 93/0 exit 0, with a mutation control |
| `dff41e0` | quarantine README: five of six files cannot load in place; revival is copy-back | `state-checks-stop.mjs` exit 0 on builtins is the control |
| `8e52e37` | the false ack annotated, not deleted | `…FALSE-RECEIPT.md`, 3,171 B; the `.json` untouched at 129 B |

**The marker check** — run this before and after any install or relaunch:
`bun ~/.claude/orchestrator/build/install-markers.ts` (read-only; `--accept` is required to move
the ledger). ⛔ Do **not** `--accept` a row whose markers collide with another candidate's; the
tool now reports those UNKNOWN for that reason.

---

## Candidates NOT installed (all in `orchestrator/hooks/`)

`newdle-hooks.judgment.ts` (⛔ **held** — install it and `continuityfresh` would have read a false
PRESENT before `6a66f16`), `newdle-hooks.continuityfresh.ts`, `.urlargs.ts`, `.idguard.ts`,
`.ledgerguard.ts`, `.hostpayload.ts`, `.urlmachinery.ts`, `.precompact-veto.ts`,
`.precompact-wiring.ts`, `.ext-reconcile.ts`, `.per-hook-redirect.ts`, `.staleness-banner.ts`,
`persistent-seat-registry.{turnfix,mailfix,startupreceipt}.ts`, `ctx-first-search.ts`.

⛔ **Every one of these needs one seat cycle to take effect, and that is Jo's call.** All seats
except Levitt first; Levitt last and only on Jo's explicit word — Levitt (pid 72639, pane
`wC:p35`) carries Jo's live 80k compaction canary.

---

## Known-open defects, with their evidence

- **The compaction payload is replayed, not resolved.** `tokensBefore = 251437` is correct only at
  the 07:21 crossing and has been copied forward through **eight** crossings, including the one
  that interrupted this session. Its archive record was pruned, so `251437` exists nowhere in
  `~/.claude/.ai/omp-compaction-archive`. Logged `fb70aa0`, `4e25bf9`, `39f4e08`.
- **`turn-id.mjs` is a library, not a hook** — 0 bytes out, no argv/stdin/stdout contract. Do not
  point an eval scenario at it. Recorded in the quarantine README.
- **Seat mail is destroyed on drain** pre-fix and must be recovered with `seat-mail-recover.py`.
- **Four report-only eval ports remain approved and unstarted**: `savepoint-guard.mjs`,
  `brief-clause-guard.mjs`, `phantom-claim-stop.mjs`, `publish-stop.mjs` (⛔ omit its `:236`
  detached spawn). Trap: `inOrchestratorSession` gates the hook itself; `ledger-write-guard` is
  the shipped pattern.

---

## Method notes that saved work today, and one that nearly cost it

- ⛔ **When the control and the mutant print the same thing, the experiment is measuring the
  instrument.** I read 9 indeterminate as "13 of 14 went red"; an unmutated control printed the
  identical result. The red was false.
- ⛔ **A mutation that fails to apply is a green that proves nothing.** A regex using `[^)]*`
  against `inOrchestratorSession(payload, state = stateDir())` matched nothing and the run
  continued. Print `patched: True/False` always.
- ⛔ **`grep -c <word>` counts the word inside longer identifiers.** `grep -c mint` → 7 was
  counting `mintTurnId`, and it put a false premise into a brief. Establish an entry point by
  feeding it a payload.
- ⛔ **Four briefs this session carried a stale premise of mine.** A stale brief does not fail
  safe. Put a `grep -c` of the defect string in every brief so the recipient's first action
  confirms the defect still exists.
- ⛔ **A false PRESENT accepted into a baseline disarms the alarm permanently** — every later
  comparison is present-to-present. Gaps are recoverable; accepted lies are not.

---

# ADDENDUM 17:05Z — the envelope is fixed, the adapter work is HELD, and the 13-hour gap explained

## Who changed the registry: Lintel, and it is no longer an open question

The 16:27:00Z edit I reported as an unidentified second writer was **Lintel's**, disclosed twelve
minutes after it happened. Atomic temp-file replace, parse-checked before going live, backup at
`persistent-seats.json.pre-envelope2-20260916T162700Z`, `schemaVersion` still 1, 11 seats and 1
scheduler unchanged. My own migration reproduces the result byte-identically
(md5 `1778ecc197a23500249f82d76a35d283`), so nothing rode along with it. **Close the
"unidentified writer" concern; it was coordination lag, not a rogue process.**

Lintel proved the gate end-to-end by sending real mail —
`{"status":"queued","id":"1789576058401-c220ead0-5c95-4e0f-a986-3b6ba281d376"}`, exit 0 — the
same call that printed `SCHEMA GATE: messageEnvelopeVersion 1 …` at 06:00 and queued nothing.

⛔ **And the reason it had to send real mail is the defect family that has cost us most today:**
`morning-pass.sh --dry-run` step 5 prints `DRY RUN: would run: queue-seat-message …` and never
invokes the writer. **A dry run that does not exercise the gate cannot report on the gate.**

## ⛔ Why this sat broken for 13 hours, and it was mine

At `~/.omp/agent/seat-launchers/persistent-seat-registry.candidate.test.ts:31-34` I wrote,
verbatim and verified: *"a v2-capable receiver must validate and deliver scheduler mail regardless
of what that field says, because the field gates the `writer`, and flipping it belongs to the
registry owner."*

The reasoning is correct. I built both halves of a working v2 receiver, correctly identified that
the flip was not mine to make, and wrote it down. ⛔ **What never happened is telling the registry
owner it was their move.** So I had it filed as closed-on-my-side, Lintel had it filed as
blocked-on-me, Levitt's 06:00 triage queued nothing, and Lintel recovered it by hand at 15:43Z.
**Nobody chose that outcome.**

**THE RULE, earned across four instances today** — a hook registered without its timeout, a policy
applied without its classifier, an amendment recorded and left unapplied for two days, and a
receiver built without its flip: **the half that constrains a future decision is the half that
does not land, because whoever applies a change watches their own work land and stops there.
Whoever holds the second half must name who holds the first, in the same message. A comment in a
test fixture is not a handoff — it is a note to whoever next opens that file, which may be
nobody.**

## ⛔ HELD until after launch (Thursday 2026-09-17): the adapter work

`launch-seat` is the single binary that starts all eleven seats. Lintel's hold covers **all three**
pieces — the candidate copy, the `:26` default, and even the `print -- "adapter: $ADAPTER"`
diagnostic line. The `print` is near-zero risk and is held anyway, because near-zero on the
launcher that starts everything, on launch night, is not a trade worth diagnostic convenience.

| State | Detail |
|---|---|
| Live `launch-seat` | md5 `1c4df340aaa4699479ee94d3cff9464e` — **verified unchanged after all testing** |
| Candidate | `orchestrator/build/omp-seat-config/launch-seat.adapteroverride`, commit `fb4b9b2` |
| Install | `cp` candidate over live, after a timestamped backup |
| Reversal | `cp` that backup back |
| Status | ⛔ **NOT installed. Do not install before launch.** |

### The two findings to keep even if the change never lands

1. ⛔ **The override is per-LAUNCH, not per-seat.** An exported `OMP_SEAT_ADAPTER` in the shell
   that starts the fleet puts the candidate adapter on **every seat it starts**. **The isolation
   lives in the calling convention, not in the mechanism**: inline on the single command, never
   `export`, never a shell profile, never a tab env.
2. ✅ **The launcher preflights the path and fails closed** — `:157` iterates `$home`,
   `$working_directory`, `$charter`, `$memory`, `$PLUGIN_ROOT`, **`$ADAPTER`**, `$COMPACTION_OWNER`,
   `$SEAT_REGISTRY`, `$OMP_SEAT_CONTRACT`, `$MCP_CONFIG` and exits 1 naming the missing one (its
   measured behaviour, not a reading). A typo refuses the launch instead of starting a seat with
   no adapter, so a scoped install cannot half-apply. **This is the property that makes the
   change safe to do
   after launch.**

### Queued for immediately after launch

`--dry-run` prints seat, model, session dir, charter, memory, MCP config and `config overlay:
none` — and **no adapter line at all**. The launcher's own comment argues that a field printed
only when set cannot distinguish "not requested" from "silently failed to reach the argv"; the
adapter is strictly worse off than the overlay that comment defends, because it is never printed
and `ps` is the only ground truth. ⛔ **A check reporting success while the thing it checks is
invisible** — the family that has cost us most this session. The one-line fix is the launcher's
own documented principle applied to the field that lacks it.

## Method lessons added this addendum

- ⛔ **"Two files sharing a variable name proves they are connected, not which one is upstream."**
  I read one file consuming `OMP_SEAT_ADAPTER` and another supplying it and inferred an input
  where there was only a conduit. Reversed in thirty seconds by running it. **A claim about which
  way a value flows requires an observation, because the code shows only that it flows.**
- ⛔ **A scan that reports absence must print its own scope.** I searched for the fixture file
  under `.claude` only, got nothing, and nearly told Lintel its quote was unverifiable. The file
  is in `~/.omp/agent/seat-launchers/`. Second time today.

---

# ADDENDUM 17:00Z — the probe discriminator, and the one conclusion NOT to write

## ⛔ Do not write "`--wait` does not deliver". It is contradicted by my own probes.

Lintel reports all **four** numbered probes delivered into its context, in this order:
`SELF-TEST 2`, `SELF-TEST 1`, `PROBE 3` (bare), `PROBE 4` (bare). So both bare prompts delivered
and preserved order between consecutive sends.

⛔ **But probes 1 and 2 delivered too, and the answer to which form they used is in my own
script:** `orchestrator/build/tinker-reminder.zsh:58` invokes the **bare** form,
`out=$(herdr agent prompt "$PANE" "$text" 2>&1)`, and the comment at `:44` already records that
`--wait --until working` **returned rc=1 `agent_prompt_stalled` on two fires that DID deliver.**

**So the discriminator is not delivery at all — it is what the CALLER observes coming back.** That
is a different failure with a different fix: **`herdr agent prompt`'s exit status is advisory, and
a nonzero rc is not evidence of non-delivery.** Any conclusion built on rc alone is unsound in both
directions — I have one rc=0 on a fire I could never confirm, and two rc=1s on fires that landed.

## ⛔ Arrival order is not a sequencing guarantee across a turn boundary

The one inversion in the set is **2 before 1**. Sedge measured the same mechanism from the
receiving end: a record's **timestamp is its arrival** and its **file position is its
consumption**, with two records displaced 8m51s and 7m26s because mail arriving mid-turn is held
until the running turn's next step boundary.

**Operational consequence for the reminder work: any reminder whose meaning depends on order MUST
carry its own ordinal in the payload rather than trusting the channel.** ⛔ Note the irony against
my own change — I **removed** sequence numbers from the reminder payload earlier today as noise.
They are the reason the inversion was visible at all. **Put them back**, and treat them as part of
the payload's meaning rather than decoration.

## Delivery-integrity facts measured this stretch, for whoever picks this up

- ⛔ **`seat_message` is not a delivery.** Four of my envelopes to Lintel have acks in
  `~/.omp/agent/seat-mailboxes/acks/` (131 B each, `deliveredAt` 16:47:30.309Z, 16:52:22.824Z,
  16:57:12.171Z, 16:59:08.791Z) while `seat-mailboxes/inbox` holds **0 files**. **Acked and
  drained: the receipt survives, the payload does not.** Every assignment needs both channels —
  the mailbox for the durable record, a pane nudge for the wake.
- ⛔ **`hub op:"inbox" peek:true` is partially destructive** (`tools/hub/index.ts:89` promises
  otherwise; `messaging.ts:425-428` threads `peek` only to the bus; `drainPendingIrcInboxMessages`
  has no such parameter, `agent-session.ts:9228`). **So the obvious remedy for the drain is itself
  a destroyer.**
- ⛔ **Any hand started from a seat's project directory inherits that seat's broker identity and
  can drain its mailbox.** My own `judgment-probe2` harness ran as Lintel, consumed Wren's
  envelope `1789543637728`, and answered it with a context-free Haiku. **Highest priority in the
  after-launch queue: this is a confidentiality and delivery-integrity defect, not a convenience
  bug.**
- **`:573` is gated** — `if (!retain)` at `:572-574`, with `:568-571` explaining that the
  over-budget path opts out. An over-budget snapshot is deliberately **kept**.

---

# ⛔ JUDGMENT LAYER — the part no mechanical state recovers

Written under a cancelled compaction. The next crossing compacts unconditionally.

## What I was attempting

**Retain the last K assistant messages whole, instead of truncating each one.** The capture at
`newdle-hooks.judgment.ts:703` is
`judgmentEntries.slice(-6).map(entry => entry.raw.slice(0, 1_200))` — newest 6, **first 1,200
characters each**, a 7,200-char ceiling.

**Why it is not a tuning question.** `judgChars` was an **exact multiple of 1,200 in all four
crossings**, so the cap was *always* binding and not one reply ever fit. Every archived entry
carries its opening `VOLSTART-n` and **none** carries its closing `VOLEND-n` — proof it is a
**prefix from the top**, which is exactly where a decision or a retraction sits. ⛔ **And the
window counts MESSAGES, not content**: a courtesy reply opening `**PMDW** I appreciate…` consumes
a full 1,200-char slot a 6 KB decision needed, while the row still reads `judgmentMessages: 3`.
**A budget denominated in messages reports healthy while discarding almost everything.** That is
the design requirement, not a footnote.

## What I ruled out, with the reason (do not re-derive these)

- ⛔ **The `--config` overlay route.** Arrays **REPLACE** rather than concatenate in `#deepMerge`
  (`settings.ts:3145-3156`; the recursive branch excludes arrays), so an overlay naming
  `extensions` silently drops the global list. It is the discovery channel anyway, separate from
  argv `--hook`. Closed.
- ⛔ **Installing the judgment adapter.** No authorization from Jo; Lintel's hazard clearance is
  not a grant and has been voided at its own request. Argv receipt: **0 processes** match
  `--hook .*newdle-hooks\.judgment\.ts`. Closed until Jo gates it.
- ⛔ **Reading `herdr agent prompt` rc as delivery.** Unsound in both directions — rc=1
  `agent_prompt_stalled` on two fires that delivered, rc=0 on one never confirmed.
- ⛔ **Peeking instead of draining, as a fix for the lost bodies.** `peek: true` is *partially
  destructive* (`messaging.ts:425-428` threads it only to the bus;
  `drainPendingIrcInboxMessages` has no such parameter, `agent-session.ts:9228`).

## The redesign target, which changes the whole shape

✅ **`SessionCompactingResult.context?: string[]` plus `preserveData`**
(`shared-events.ts:386-394`) is an **UNCAPPED** line list, consumed as `extraContext`
(`session-maintenance.ts:1357-1358, 2133-2134, 4639-4640`). ⛔ **So the entire character-budget
layer is a lossy pre-filter in front of a channel designed to take the unfiltered material.**
The docs never mention it (`hook`, `extension`, `session_before_compact`, `prefix`, `suffix` all
occur **zero** times in the rendered page), which is plausibly why our layer looks the way it
does. **Design against this channel, not against a tighter character cap.**

Separately and on the read side: `compact-continuity.mjs:147` `RESTORE_MAX_CHARS = 20000` is
**characters** where OMP's `keepRecentTokens = 20000` (`compaction.ts:236`) is **tokens** — one
integer, ~4x apart. And `:565` cuts a **prefix** where OMP keeps a **suffix of whole turns and
refuses to truncate the newest group** (`compaction.ts:497-501`).

## Still open

1. ⛔ **Retention design — BLOCKED** by Jo's no-new-work order; approved by Lintel candidate-only.
   Queued for after Thursday 2026-09-17. **Not dropped.**
2. ⛔ **Proof against a real crossing archive — BLOCKED**, depends on (1) and on a crossing that
   only occurs after the cycle relaunch.
3. ⛔ **One command, unrun, possibly urgent:** `grep -b '## Agent-authored handoff'` on a real
   over-budget `session-state--*.md`. `:562-564` tells the restored reader to *"start from"* that
   section while `:565` cuts a 20,000-char prefix. **If the section sits near the tail, an
   over-budget restore decapitates exactly what the tool says to start from.**
4. The assembled two-list deliverable — `/Users/jowolff/agent-scratch/omp-docs-review/` holds all
   four inputs; only the assembly is missing.
5. Startup receipt + `ps`-versus-`stat` companion, and the evals port into `orchestrator/evals/`
   (load the orchestrator-evals skill first and name the scenarios read) — both after Thursday.

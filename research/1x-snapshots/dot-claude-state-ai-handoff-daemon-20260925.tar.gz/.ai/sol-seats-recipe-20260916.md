---
date: 2026-09-16T05:50-07:00
author: tinker
for: Jo, via Lintel
status: investigation complete; no migration performed
title: "Running seats on GPT sol: what it costs, what breaks, and the exact command"
---

# Answer in three lines

**Yes. Any seat can run on sol, including Lintel, and nothing in the launcher has to change — the
model is a per-launch environment override that already exists.** ⛔ **A sol seat bills a different
account (ChatGPT/Codex OAuth), not a cheaper slice of Anthropic weekly.** **The machinery is
model-agnostic where it matters: Codex has run four hours on sol loading the identical adapter.**

⛔ **AND THE TIMING IS FREE. Every live seat is already due a relaunch** — the hook adapter is
captured at process start (`loader.ts:151`), so none of tonight's machinery is in any running seat.
**A relaunch is exactly when the model changes at no extra cost.**

# 1. The launch recipe, verbatim

```
OMP_SEAT_MODEL=openai-codex/gpt-5.6-sol /Users/jowolff/.omp/agent/seat-launchers/wake-seat lintel
```

**Substitute any seat slug for `lintel`:** `tinker`, `wren`, `sedge`, `caspian`, `tron`, `galley`,
`sluice`, `verge`, `levitt`, `codex`.

**Why nothing else changes:**

| fact | receipt |
|---|---|
| the model is a per-launch override | `launch-seat:138` — `model=${OMP_SEAT_MODEL:-$default_model}` |
| the fleet default is Anthropic | `launch-seat:32` — `DEFAULT_MODEL='anthropic/claude-opus-5'` |
| Lintel's default is Anthropic, and it is only a DEFAULT | `launch-seat:111` — `default_model='anthropic/claude-opus-5'`, consumed by `:138` |
| a sol default already exists and is in use | `launch-seat:118` — `default_model='openai-codex/gpt-5.6-sol'` for `codex` |
| the model is carried to BOTH launch paths | `launch-seat:295` (`--model "$model"`, foreground exec) and `:321` (`--env "OMP_SEAT_MODEL=$model"`, background pane) |

⛔ **No launcher edit is needed and none should be made.** A permanent switch would be one word at
`:111`; the env override is reversible per launch and leaves no file changed.

**Identity, memory, mailbox and journal are untouched by the model choice.** The launcher resolves
`display_name`, `home`, `charter` and `memory` from the seat slug in the same `case` block
(`launch-seat:58-140`), independent of `model`. The session directory
(`$HOME/.omp/agent/seat-sessions/<seat>`) and the mailbox (`seat-mailboxes/inbox/<seat>`) are keyed
by slug too. **A seat relaunched onto sol is the same seat with the same history.**

# 2. What degrades — measured against Codex, not reasoned from source

**Codex, PID 52963, launched 19:04:49, argv `--model openai-codex/gpt-5.6-sol`.**

| machinery | status on sol | receipt |
|---|---|---|
| **newdle-hooks adapter + all guards** | **attached, identical** | Codex's argv carries `--hook …/newdle-hooks.ts` and `--hook …/compaction-state-owner.ts` — the same files every Anthropic seat loads |
| **output-types vocabulary (prompt half)** | **reaches a GPT seat and it complies** | Codex opened with a bare bold `PMDW` and labelled its probe `ACTION`; 48 labels across its sessions. **First-party: "the session-start instructions explicitly supplied the output-type vocabulary, mandatory leading PMDW, skill triggers and delegation gates."** |
| **output-types ENVELOPE** | ⛔ **never received, never emitted** | **Codex: "I did not observe an appended output-types envelope comment."** Corroborated by count: **0 `<!-- output-types` in all three of today's sessions** — and 11 in its 2026-09-11 session, so this is a change over time, not a model trait |
| **output-types ENFORCEMENT** | ⛔ **DORMANT BY DESIGN, not model-related** | `hook-scope.mjs --show` returns **`off` in `~/.codex` and `~/.claude`**, **`on`** in `code/joseph-gordon-levitt` and `shipyard/repos/kitchen`. `output-types-guard.mjs:164` imports `hooksEnabled` and is silent out of scope — and it exits 0 on an unlabelled message from `~/.claude`. **So "no guard ever fired for Codex in four hours" is explained by its cwd, not by sol** |
| **identifier/URL machinery** | **out of remit for Codex** | gated on the first line of each function: `newdle-hooks.ts:263`, `:288`, `:378` — `if (OMP_CURRENT_SEAT_NAME !== "Lintel") return undefined`. Codex's bare `#123` probe passing untouched is correct scope, not a dark guard |
| **precompact save path** | ⛔ **UNPROVEN ON SOL** | zero heartbeat rows for any `seat-codex-*` session; **Codex's own recursive search found no `.ai/session-state--*.md` and no `.ai/omp-compaction-archive/` under `~/.codex`**. Both readings agree it never crossed — **an absence, not a pass** |
| **seat mailbox / `seat_message`** | **round-trip proven both directions**, with a fleet-wide defect | Codex received mail from Lintel and from me, and its probe reached Lintel. ⛔ **It read `queued`, not `delivered`, for a message that did arrive** — the receipt is wrong in both directions, and the loss defect is model-independent |
| **seat contract reply clause** | **works** | Codex read it directly and quoted the `queued` ≠ `delivered` distinction back correctly |

**The structural reason so little degrades: every guard in this stack is a `node` or `bun`
subprocess fed JSON on stdin.** None of them calls a model. ⛔ **But the corollary I wrote first —
"a Stop block is enforcement, not persuasion, so a less compliant model gets blocked more" — is
ARGUMENT, NOT MEASUREMENT. Nothing has fired on a sol seat in either direction. The reasoning is
sound and it is not evidence.**

## ⛔ THREE CONFOUNDS, BECAUSE THE OBVIOUS READING OF CODEX IS WRONG THREE TIMES

**Codex is the only sol seat, and it differs from the fleet in ways that have nothing to do with
its model. Every "sol does not do X" below is really "that seat does not do X":**

1. **Its cwd is `~/.codex`, not a shipyard repo.** The newdle plugin blocks and the hook scope are
   cwd-derived, and `hook-scope.mjs` returns **`off`** there. **A seat outside the plugin's reach
   receives a different instruction set and no enforcement regardless of model.**
2. **It predates the machinery.** Started 19:04:49; URL machinery landed 22:28:49, payload fix
   22:19:18. **The adapter is captured at process start (`hooks/loader.ts:151`), so no running seat
   holds tonight's work.**
3. **The guards that exist are Lintel-scoped on purpose** (`:263`, `:288`, `:378`). Codex could not
   have been refused by them at any time, on any model.

⛔ **THE TEST THAT REMOVES ALL THREE AT ONCE: relaunch Levitt on sol, in a repo where
`hook-scope` is `on`, with the 80k overlay so it crosses in about two minutes.** That single run
yields the envelope instruction, a real guard in scope, and the first GPT compaction save.

## A defect in our own instruction stack, found by Codex and not about sol at all

**Codex reports that the seat rule mandating a leading `PMDW` on every turn conflicts with
`/Users/jowolff/.claude/CLAUDE.md:33-40`, which says typed-only turns normally need none.** It
followed the seat rule as higher priority **and flagged the conflict instead of silently choosing**.
⛔ **This will hit every seat we relaunch, on either model, and it is ours to fix rather than
sol's to absorb.** It also reported a ctx MCP schema mismatch through `xd://report_issue` after
three documented filter combinations were rejected.

## Corrections to this document's own first draft

- ⛔ **"2 output-types envelopes" was MY MEASUREMENT ERROR.** I grepped the string `output-types`,
  which also appears in the injected session-start instructions. **Counting `<!-- output-types`
  returns 0 for every session today.** Codex's first-party answer caught it; the instrument was
  matching the instruction that asks for an envelope, not an envelope.
- **The three-way agreement on sequencing is NOT independent convergence.** Codex and Lintel both
  read my reasoning before answering. **Three agreeing reads of one argument are one argument.**

## What genuinely differs, and is not measurable from outside

- **Compaction threshold arithmetic is window-relative.** `thresholdPercent: 25` against a different
  context window is a different token count. A sol seat with a smaller window compacts sooner and
  more often, and **the precompact save is the machinery that makes that survivable** — which is why
  the save landing tonight matters more for a sol fleet than an Anthropic one.
- **Long-context reconciliation is the one capability at risk.** Lintel's value is holding
  cross-repo state across a long session. That is exactly the workload most sensitive to window size
  and summary fidelity, and I have no measurement of sol's behaviour at 250k+.
- ⛔ **I asked Codex directly** — output-types blocks it found actionable or not, silent sends,
  crossings, and anything it had to work around. **Its answer is not in this document; add it when it
  arrives rather than treating this table as complete.**

# 3. Which seats should move, and which should not

**Move first — cheap, high-volume, short-context, and their output is checkable by machine:**

- **Levitt** — the canary. Already thrashing at 80k, lowest stakes on the machine, and it doubles as
  the sol acceptance test.
- **Sedge, Tron, Caspian, Wren** — repo-scoped implementation seats. Their work is diffs and reviews
  that a build or a guard verifies.
- **Verge, Sluice, Galley** — as above.

**Keep on Anthropic, with the reason stated:**

- ⛔ **Lintel — CAN run on sol, and I would not move it first.** The launcher permits it, the guards
  behave identically, and nothing about its identity depends on the model. **But its whole function
  is long-context reconciliation across nine seats, and that is the single capability I have no
  measurement for.** **If Wednesday forces a choice, move Lintel LAST and only after a sol seat has
  crossed a compaction and been seen to resume correctly from the save.**
- **Tinker (me)** — I hold the machinery and the A/B harnesses. Moving me mid-repair adds a variable
  to every measurement. Move me after the queue below is closed.

**A staged answer Jo can act on without deciding everything:** move Levitt tonight, move the four
repo seats on Wednesday morning, and hold Lintel and Tinker until a sol seat has demonstrably
survived a compaction with a readable save.

# 4. What it actually saves

**CLAIM, from disk:** `~/.codex/auth.json` is mode `0600`, and its `auth_mode` is **`chatgpt`**, with
`tokens` carrying `access_token`, `account_id`, `id_token` and `refresh_token` — a ChatGPT OAuth
session, plus a separate `OPENAI_API_KEY` field.

**INFERENCE, labelled because I did not trace OMP's credential read to that file:** a
`openai-codex/gpt-5.6-sol` seat authenticates as Jo's ChatGPT/Codex subscription, so it spends
**that** allowance and does not touch Anthropic weekly. **This is a migration that moves spend to a
different account, not one that merely buys a cheaper slice.**

⛔ **The one check that would settle it beyond inference, and it costs a minute:** run one sol seat
turn and watch whether Anthropic usage moves. **I have not done this, because Jo's ruling was
investigation only and because the answer belongs to whoever can see the usage dashboards.**

**Also worth knowing:** no `ANTHROPIC_API_KEY` is present in my own seat environment, so seats are
not spending a keyed API budget — the Anthropic pressure is subscription usage, which is what makes
a second subscription the relief.

# 5. The gap in this report, stated rather than smoothed

**The precompact save has never run on a sol seat.** Every other row in the degradation table is
backed by a live observation from Codex; that one is backed by an absence. **It is also the row that
matters most for a sol fleet, because a smaller window means more crossings.** **Levitt on sol with
the 80k overlay would close this in about five minutes** — it would cross, write, and either produce
a readable `session-state--<id>.md` with host-supplied intents or not.


### Reddit as a research source — available per Jo, route not yet demonstrated

**Jo's standing statement, given twice on 2026-08-25:** this fleet DOES have access to Reddit via
RSS, and it must be named when research work is assigned. An earlier survey concluded Reddit was
closed to every route here; that conclusion was wrong and sat in the record as though established.

**Measured by Lintel 2026-08-25, and none of it contradicts Jo:** `WebFetch` refuses the host
outright — *"Claude Code is unable to fetch from www.reddit.com"* — which is a tool-level decline
rather than a network result. `curl` returned **HTTP 429, zero bytes** on `www.reddit.com/r/<sub>/.rss`,
`www.reddit.com/r/<sub>/new/.rss` and `old.reddit.com/r/<sub>/.rss`, under both a custom and a
browser user agent.

**429 is rate limiting, not a block.** It establishes that those routes failed from that shell at
that moment and nothing more. **Never report "Reddit is unavailable" from a 429.**

**Still owed: someone demonstrates a working route and records it here with a date.** Untried:
retry with backoff, the `.json` endpoints, an authenticated route, a feed reader already installed.
Until then a research brief must name Reddit, say the route is unestablished, and require the
worker to report a blocker rather than silently substituting web search.

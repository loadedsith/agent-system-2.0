#!/Users/jowolff/.bun/bin/bun

import { randomUUID } from "node:crypto";
import { link, lstat, mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import { isAbsolute, join } from "node:path";

export interface PersistentSeat {
	slug: string;
	displayName: string;
}

export interface PersistentSeatScheduler {
	id: string;
	displayName: string;
	allowedTargets: string[];
}

export interface PersistentSeatRegistry {
	schemaVersion: 1;
	messageEnvelopeVersion: number;
	seats: PersistentSeat[];
	schedulers: PersistentSeatScheduler[];
}

export interface SchedulerMessageInput {
	sender: string;
	to: string;
	messageFile: string;
}

export interface SchedulerMessageDependencies {
	registryPath: string;
	mailboxRoot: string;
	now?: () => Date;
	randomUUID?: () => string;
}

export interface QueuedMessageReceipt {
	status: "queued";
	id: string;
	path: string;
}

interface SchedulerMessageEnvelope {
	schemaVersion: 2;
	id: string;
	sender: {
		kind: "scheduler";
		id: string;
	};
	to: string;
	message: string;
	createdAt: string;
}

const PRODUCTION_REGISTRY_PATH = "/Users/jowolff/.omp/agent/persistent-seats.json";
const PRODUCTION_MAILBOX_ROOT = "/Users/jowolff/.omp/agent/seat-mailboxes/inbox";
const SLUG_PATTERN = /^[a-z][a-z0-9-]*$/;

function invalidRegistry(registryPath: string, detail: string): never {
	throw new Error(`Invalid persistent-seat registry ${registryPath}: ${detail}`);
}

function requireUnique(values: string[], label: string, registryPath: string): void {
	if (new Set(values).size !== values.length) {
		invalidRegistry(registryPath, `${label} must be unique`);
	}
}

function validateRegistry(value: unknown, registryPath: string): PersistentSeatRegistry {
	if (typeof value !== "object" || value === null || Array.isArray(value)) {
		invalidRegistry(registryPath, "root must be an object");
	}
	const candidate = value as Record<string, unknown>;
	if (candidate.schemaVersion !== 1) {
		invalidRegistry(registryPath, "schemaVersion must equal 1");
	}
	if (!Number.isInteger(candidate.messageEnvelopeVersion) || (candidate.messageEnvelopeVersion as number) < 1) {
		invalidRegistry(registryPath, "messageEnvelopeVersion must be a positive integer");
	}
	if (!Array.isArray(candidate.seats) || candidate.seats.length === 0) {
		invalidRegistry(registryPath, "seats must be a non-empty array");
	}
	if (!Array.isArray(candidate.schedulers)) {
		invalidRegistry(registryPath, "schedulers must be an array");
	}

	const seats = candidate.seats.map((entry, index) => {
		if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
			invalidRegistry(registryPath, `seats[${index}] must be an object`);
		}
		const seat = entry as Record<string, unknown>;
		if (typeof seat.slug !== "string" || !SLUG_PATTERN.test(seat.slug)) {
			invalidRegistry(registryPath, `seats[${index}].slug must be a lowercase slug`);
		}
		if (typeof seat.displayName !== "string" || seat.displayName.trim() === "") {
			invalidRegistry(registryPath, `seats[${index}].displayName must be non-empty`);
		}
		return { slug: seat.slug, displayName: seat.displayName };
	});
	requireUnique(seats.map(({ slug }) => slug), "seat slugs", registryPath);
	requireUnique(seats.map(({ displayName }) => displayName), "seat display names", registryPath);
	const seatSlugs = new Set(seats.map(({ slug }) => slug));

	const schedulers = candidate.schedulers.map((entry, index) => {
		if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
			invalidRegistry(registryPath, `schedulers[${index}] must be an object`);
		}
		const scheduler = entry as Record<string, unknown>;
		if (typeof scheduler.id !== "string" || !SLUG_PATTERN.test(scheduler.id)) {
			invalidRegistry(registryPath, `schedulers[${index}].id must be a lowercase slug`);
		}
		if (typeof scheduler.displayName !== "string" || scheduler.displayName.trim() === "") {
			invalidRegistry(registryPath, `schedulers[${index}].displayName must be non-empty`);
		}
		if (!Array.isArray(scheduler.allowedTargets) || scheduler.allowedTargets.length === 0) {
			invalidRegistry(registryPath, `schedulers[${index}].allowedTargets must be a non-empty array`);
		}
		const allowedTargets = scheduler.allowedTargets.map((target, targetIndex) => {
			if (typeof target !== "string" || !SLUG_PATTERN.test(target)) {
				invalidRegistry(
					registryPath,
					`schedulers[${index}].allowedTargets[${targetIndex}] must be a lowercase seat slug`,
				);
			}
			if (!seatSlugs.has(target)) {
				invalidRegistry(registryPath, `scheduler target "${target}" is not a configured seat`);
			}
			return target;
		});
		requireUnique(allowedTargets, `schedulers[${index}].allowedTargets`, registryPath);
		return {
			id: scheduler.id,
			displayName: scheduler.displayName,
			allowedTargets,
		};
	});
	requireUnique(schedulers.map(({ id }) => id), "scheduler ids", registryPath);

	return {
		schemaVersion: 1,
		messageEnvelopeVersion: candidate.messageEnvelopeVersion as number,
		seats,
		schedulers,
	};
}

async function readRegistry(registryPath: string): Promise<PersistentSeatRegistry> {
	let parsed: unknown;
	try {
		parsed = JSON.parse(await readFile(registryPath, "utf8"));
	} catch (error) {
		const detail = error instanceof Error ? error.message : String(error);
		invalidRegistry(registryPath, detail);
	}
	return validateRegistry(parsed, registryPath);
}

async function readMessageFile(messageFile: string): Promise<string> {
	if (!isAbsolute(messageFile)) {
		throw new Error("Message file path must be absolute");
	}
	const file = await lstat(messageFile);
	if (!file.isFile()) {
		throw new Error(`Message file is not a regular file: ${messageFile}`);
	}
	const message = (await readFile(messageFile, "utf8")).trim();
	if (message === "") {
		throw new Error(`Message file is empty: ${messageFile}`);
	}
	return message;
}

export async function enqueueSchedulerMessage(
	input: SchedulerMessageInput,
	dependencies: SchedulerMessageDependencies,
): Promise<QueuedMessageReceipt> {
	const senderMatch = input.sender.match(/^scheduler:([a-z][a-z0-9-]*)$/);
	if (senderMatch === null) {
		throw new Error('Scheduler sender required in the form "scheduler:<id>"; seat identities are forbidden');
	}
	const schedulerId = senderMatch[1];
	const targetSlug = input.to.trim().toLowerCase();
	const registry = await readRegistry(dependencies.registryPath);
	if (registry.messageEnvelopeVersion !== 2) {
		throw new Error(
			`Scheduler queue writer requires messageEnvelopeVersion 2; ${dependencies.registryPath} advertises ${registry.messageEnvelopeVersion}. ` +
				`Migrate with: bun /Users/jowolff/.claude/orchestrator/build/migrate-envelope-version.ts --apply ${dependencies.registryPath} ` +
				"-- it validates the registry against these same rules before touching it, prints a timestamped backup path and the exact reversal command before writing, and is a no-op if the version is already 2.",
		);
	}
	const scheduler = registry.schedulers.find(({ id }) => id === schedulerId);
	if (scheduler === undefined) {
		throw new Error(`Unknown scheduler "${schedulerId}" in ${dependencies.registryPath}`);
	}
	const target = registry.seats.find(({ slug }) => slug === targetSlug);
	if (target === undefined) {
		throw new Error(`Unknown persistent seat "${input.to}" in ${dependencies.registryPath}`);
	}
	if (!scheduler.allowedTargets.includes(target.slug)) {
		throw new Error(`Scheduler "${scheduler.id}" may not target seat "${target.slug}"`);
	}
	const message = await readMessageFile(input.messageFile);
	const now = dependencies.now?.() ?? new Date();
	const uuid = dependencies.randomUUID?.() ?? randomUUID();
	const id = `${now.getTime()}-${uuid}`;
	const envelope: SchedulerMessageEnvelope = {
		schemaVersion: 2,
		id,
		sender: { kind: "scheduler", id: scheduler.id },
		to: target.slug,
		message,
		createdAt: now.toISOString(),
	};
	const targetDirectory = join(dependencies.mailboxRoot, target.slug);
	const finalPath = join(targetDirectory, `${id}.json`);
	const temporaryPath = join(targetDirectory, `.${id}.tmp`);
	await mkdir(targetDirectory, { recursive: true, mode: 0o700 });
	await writeFile(temporaryPath, `${JSON.stringify(envelope)}\n`, { encoding: "utf8", flag: "wx", mode: 0o600 });
	try {
		await link(temporaryPath, finalPath);
	} catch (error) {
		await unlink(temporaryPath).catch(() => undefined);
		throw error;
	}
	await unlink(temporaryPath).catch(() => undefined);
	return { status: "queued", id, path: finalPath };
}

function parseArguments(argv: string[]): SchedulerMessageInput {
	const values: Record<string, string> = {};
	for (let index = 0; index < argv.length; index += 2) {
		const flag = argv[index];
		const value = argv[index + 1];
		if (!["--sender", "--to", "--message-file"].includes(flag) || value === undefined || value.startsWith("--")) {
			throw new Error(
				"Usage: queue-seat-message --sender scheduler:<id> --to <seat> --message-file <absolute-path>",
			);
		}
		if (values[flag] !== undefined) {
			throw new Error(`Duplicate argument: ${flag}`);
		}
		values[flag] = value;
	}
	if (argv.length !== 6 || values["--sender"] === undefined || values["--to"] === undefined || values["--message-file"] === undefined) {
		throw new Error(
			"Usage: queue-seat-message --sender scheduler:<id> --to <seat> --message-file <absolute-path>",
		);
	}
	return {
		sender: values["--sender"],
		to: values["--to"],
		messageFile: values["--message-file"],
	};
}

if (import.meta.main) {
	try {
		const receipt = await enqueueSchedulerMessage(parseArguments(process.argv.slice(2)), {
			registryPath: PRODUCTION_REGISTRY_PATH,
			mailboxRoot: PRODUCTION_MAILBOX_ROOT,
		});
		console.log(JSON.stringify(receipt));
	} catch (error) {
		console.error(error instanceof Error ? error.message : String(error));
		process.exitCode = 1;
	}
}

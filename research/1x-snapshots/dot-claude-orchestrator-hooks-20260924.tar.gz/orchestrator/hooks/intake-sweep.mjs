#!/usr/bin/env node
/**
 * Transcript sweep — captures the half UserPromptSubmit CANNOT see.
 *
 * Documented, and it invalidated my first design: "UserPromptSubmit ... Does not fire for queued
 * mid-turn messages." Mid-turn messages are precisely what failed on 2026-08-19 — Jo asked for the
 * adversarial review twice, mid-turn, and it went undispatched for hours.
 *
 * In the transcript those arrive as {"type":"queue-operation","operation":"enqueue"}. The Stop
 * payload carries `transcript_path`, so at turn end this sweeps for them and appends anything the
 * UserPromptSubmit hook structurally cannot see. Called by the Stop guard, so a mid-turn request
 * blocks the SAME turn it arrived in.
 *
 * ── 2026-08-25: THE DOUBLE-WRITE FIX ────────────────────────────────────────────────────────
 * Not every enqueued message is invisible to UserPromptSubmit, and treating them as if they were
 * doubled 14 utterances in the inbox. The transcript distinguishes the two fates:
 *
 *   enqueue → remove    the message was consumed by the running turn. No UserPromptSubmit event
 *                       ever fires for it. THIS SWEEP IS THE ONLY WITNESS. (measured over 854
 *                       transcripts: 273 of 275 such messages exist only as a sweep row)
 *   enqueue, no remove  the message stays queued until the turn ends and is then submitted as an
 *                       ordinary prompt. UserPromptSubmit DOES fire. intake-capture.mjs writes it,
 *                       with `cwd` and `raw_keys`. (measured: 137 such messages, 123 captured
 *                       cleanly, 14 doubled because this sweep ran at Stop — i.e. BEFORE the
 *                       submission — so its text dedupe had nothing to match against yet)
 *
 * So the fix routes rather than dedupes: each utterance is claimed by exactly one path on an
 * observable transcript fact. No text-similarity heuristic, no time window — both of which would
 * be unsafe, because Jo does sometimes send the same words twice on purpose (3 such pairs in the
 * inbox, 3.3s to 73s apart, a range that completely overlaps the real duplicates' 1.5s to 229s).
 *
 * Self-healing: the whole transcript is re-scanned on every Stop, so a `remove` written after one
 * Stop is picked up by the next. Residual gap: a message enqueued-and-consumed during a turn whose
 * Stop hook never runs (hard crash) is missed — the same exposure the pre-fix version had.
 *
 * ── 2026-09-09: THE ROUTING PREMISE DIED. COUNT INSTEAD OF ROUTE ──────────────────────
 * The harness now fires UserPromptSubmit for a mid-turn ENQUEUED message too, ~30ms after the
 * enqueue — so `enqueue → remove` no longer implies "this sweep is the only witness", and the
 * routing rule above kept claiming utterances intake-capture had already written. Measured in the
 * live inbox on 2026-09-09: through 2026-08-26 sweep rows were overwhelmingly sweep-only (2026-08-24:
 * 34 sweep-only, 0 doubled); from 2026-08-27 onward every sweep row is doubled and sweep-only is 0.
 * The old fate test cannot tell which regime it is running in.
 *
 * So stop asking "which path SHOULD own this" and ask "how many rows for this utterance are already
 * on disk". Per (session_id, first 300 chars), with E consumed enqueues in the transcript, C
 * capture-path rows and S sweep rows already in the inbox, this sweep appends
 *
 *     max(0, E - C) - S     more rows
 *
 * Exact, not fuzzy: no time window, no similarity — every term is a count of literally equal
 * strings. It is correct in BOTH regimes without knowing which is live. Under the new harness C
 * covers the enqueues and nothing is added; under the old one C is 0 and every consumed enqueue
 * still gets its row, which is the case that must never be lost.
 *
 * Deliberate repeats survive: the same words sent twice mid-turn give E=2 and (new harness) C=2,
 * so 2 rows land, one per utterance. One degradation, and only if the harness REVERTS: the same
 * words typed once normally and once mid-turn would net one row instead of two, because C=1 absorbs
 * the mid-turn enqueue. Losing an ordinary mid-turn message was never on the table; that narrow
 * case is what was traded for it.
 *
 * Exported as a function; also runnable standalone for testing.
 */
import { readFileSync, appendFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const MACHINE = ['<task-notification', '<cross-session-message', '<local-command', 'Caveat:'];

// Identity of a swept message. The enqueue timestamp is in the row itself (sweep rows carry the
// enqueue time as `ts`), so this is checkable against inbox rows already on disk, including ones
// written before this fix. Text alone would silently swallow a deliberate repeat.
const sweepKey = (sessionId, ts, text) => `${sessionId ?? ''}|${ts ?? ''}|${text.slice(0, 300)}`;

// Identity of an UTTERANCE, independent of which path wrote it. Session plus exact text, so the
// two writers' rows for the same words can be counted against each other. Timestamp is deliberately
// excluded here: the two paths stamp different clocks (enqueue time vs. UserPromptSubmit time).
const countKey = (sessionId, text) => `${sessionId ?? ''}|${text.slice(0, 300)}`;

export function sweep(transcriptPath, stateDir) {
  if (!transcriptPath || !existsSync(transcriptPath) || !existsSync(stateDir)) return 0;
  const inbox = join(stateDir, 'REQUESTS-INBOX.jsonl');

  // Idempotency across repeated Stops, by exact enqueue timestamp: a row this sweep already wrote
  // is never written twice. Alone this is not enough — it cannot see the OTHER writer — so the
  // counts below carry the rest of the work.
  const seen = new Set();
  // Per (session, text) census of what is already on disk, split by which path wrote it.
  const capCount = new Map();     // rows from intake-capture.mjs (UserPromptSubmit)
  const sweepCount = new Map();   // rows from this sweep
  const bump = (m, k) => m.set(k, (m.get(k) ?? 0) + 1);
  try {
    for (const l of readFileSync(inbox, 'utf8').split('\n')) {
      if (!l.trim()) continue;
      try {
        const r = JSON.parse(l);
        const text = String(r.verbatim ?? '').trim();
        if (!text) continue;
        const k = countKey(r.session_id, text);
        if (r.source === 'mid-turn-queued') {
          seen.add(sweepKey(r.session_id, r.ts, text));
          bump(sweepCount, k);
        } else {
          bump(capCount, k);
        }
      } catch { /* skip */ }
    }
  } catch { /* no inbox yet */ }

  let lines;
  try { lines = readFileSync(transcriptPath, 'utf8').split('\n'); } catch { return 0; }

  // Pass 1 — which queued contents were consumed mid-turn (a `remove` names its own content).
  const consumed = new Set();
  const enqueues = [];
  for (const l of lines) {
    if (!l.includes('queue-operation')) continue;
    let d;
    try { d = JSON.parse(l); } catch { continue; }
    if (d.type !== 'queue-operation') continue;
    const text = String(d.content ?? '').trim();
    if (!text || text === 'undefined') continue;
    if (d.operation === 'remove') consumed.add(text.slice(0, 300));
    else if (d.operation === 'enqueue') enqueues.push({ d, text });
  }

  // Pass 2 — group the sweep's candidates by utterance, so each group can be counted against the
  // rows already on disk. A still-queued message is not a candidate at all: no `remove` means it
  // will be submitted normally at turn end and intake-capture owns it outright.
  const groups = new Map();
  for (const { d, text } of enqueues) {
    if (MACHINE.some((m) => text.startsWith(m))) continue;   // not Jo asking for anything
    if (!consumed.has(text.slice(0, 300))) continue;         // still queued → intake-capture owns it
    const k = countKey(d.sessionId, text);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push({ d, text });
  }

  // Pass 3 — for each utterance, write only the shortfall: the consumed enqueues that no row on
  // disk accounts for. E - C is how many the capture path did not witness; minus S, how many of
  // those this sweep has already written on an earlier Stop.
  let added = 0;
  for (const [k, candidates] of groups) {
    let shortfall = Math.max(0, candidates.length - (capCount.get(k) ?? 0)) - (sweepCount.get(k) ?? 0);
    if (shortfall <= 0) continue;
    for (const { d, text } of candidates) {
      if (shortfall <= 0) break;
      const ts = d.timestamp ?? new Date().toISOString();
      const key = sweepKey(d.sessionId, ts, text);
      if (seen.has(key)) continue;
      seen.add(key);
      shortfall--;
      try {
        appendFileSync(inbox, JSON.stringify({
          ts,
          session_id: d.sessionId ?? null,
          source: 'mid-turn-queued',
          triaged: false,
          verbatim: text.slice(0, 4000),
        }) + '\n');
        added++;
      } catch { /* best effort */ }
    }
  }
  return added;
}

// standalone: node intake-sweep.mjs <transcript> <stateDir>
if (process.argv[1] && process.argv[1].endsWith('intake-sweep.mjs') && process.argv[2]) {
  console.log(`captured ${sweep(process.argv[2], process.argv[3])} mid-turn message(s)`);
}

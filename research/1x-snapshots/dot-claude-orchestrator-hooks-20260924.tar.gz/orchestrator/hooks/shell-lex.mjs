/**
 * shell-lex.mjs — read OPERATIONS out of a shell command, rather than pattern-matching its text.
 *
 * EXTRACTED VERBATIM FROM staging-guard.mjs, 2026-08-26. Not rewritten, not "improved": the
 * bodies of lex() and makeNorm() are the ones that guard already shipped, moved so a second
 * guard can use them instead of growing a second lexer. A second lexer is a second set of
 * bypasses, and staging-guard's own header is a catalogue of what those cost — five quoting
 * bypasses and four flag-abbreviation bypasses, all found after the first version shipped.
 *
 * WHY A LEXER AND NOT A REGEX, restated here because the reason has to travel with the code:
 * a text matcher cannot tell an ACT from a MENTION of an act. On this machine that has produced
 * two distinct harms — guards refusing documents that quote a forbidden command (nine recorded
 * instances, one of them a decision-log entry describing its own refusal), and recorders writing
 * false rows because a command string appeared inside search output. Lexing fixes the first
 * class structurally: quoted spans stay single words and can never be read as commands, and
 * HEREDOC BODIES ARE DROPPED ENTIRELY, so a brief that quotes a forbidden command in a heredoc
 * is invisible to every rule built on this.
 *
 * The behaviour any caller depends on:
 *   - quotes removed, their CONTENT KEPT (the argument survives, unlike a placeholder scheme)
 *   - splitting ONLY on unquoted separators
 *   - `$(` and a backtick DO split even inside double quotes, because there they open a subshell
 *   - a `#` at a word boundary starts a comment and the rest of the line is dropped
 *   - heredoc bodies dropped
 *   - redirection operators are NOT separators, so `>>` survives as its own word (or fused to a
 *     filename, as `>>file`). That is what lets a rule read a redirect's target.
 */
import { realpathSync } from 'node:fs';
import { resolve } from 'node:path';

/**
 * Lex the command the way a shell would, for the purpose of reading OPERATIONS out of it.
 * Returns an array of segments; each segment is an array of words.
 */
export function lex(s) {
  const segs = [];
  let words = [], cur = null, i = 0, here = null, pending = null;
  const endWord = () => { if (cur !== null) { words.push(cur); cur = null; } };
  const endSeg = () => { endWord(); if (words.length) segs.push(words); words = []; };
  const put = (t) => { cur = (cur ?? '') + t; };

  while (i < s.length) {
    if (here !== null) {                                  // inside a heredoc body: drop the line
      const nl = s.indexOf('\n', i);
      const line = nl === -1 ? s.slice(i) : s.slice(i, nl);
      if (line.trim() === here) here = null;
      i = nl === -1 ? s.length : nl + 1;
      continue;
    }
    const c = s[i];

    if (c === '\\') { if (i + 1 < s.length) put(s[i + 1]); i += 2; continue; }

    if (c === "'") {                                      // single quotes: wholly literal
      const end = s.indexOf("'", i + 1);
      put(end === -1 ? s.slice(i + 1) : s.slice(i + 1, end));
      i = end === -1 ? s.length : end + 1;
      continue;
    }

    if (c === '"') {                                      // double quotes: literal except $( and `
      i++;
      let closed = false;
      while (i < s.length) {
        const d = s[i];
        if (d === '\\') { if (i + 1 < s.length) put(s[i + 1]); i += 2; continue; }
        if (d === '"') { i++; closed = true; break; }
        if (d === '`' || (d === '$' && s[i + 1] === '(')) { endSeg(); i += d === '`' ? 1 : 2; break; }
        put(d); i++;
      }
      if (!closed && cur === null) cur = '';
      continue;
    }

    if (c === '<' && s[i + 1] === '<' && s[i + 2] !== '<') {
      const m = /^<<-?\s*(?:'([^']*)'|"([^"]*)"|([A-Za-z_][A-Za-z0-9_]*))/.exec(s.slice(i));
      if (m) { pending = m[1] ?? m[2] ?? m[3]; endWord(); i += m[0].length; continue; }
    }
    if (c === '\n' && pending !== null) { here = pending; pending = null; endSeg(); i++; continue; }

    // A `#` at a word boundary starts a comment, exactly as in a shell. Without this, the words
    // of a trailing comment are read as pathspecs, and a comment that merely NAMES a guarded
    // directory pulls an unrelated repo's command into scope.
    if (c === '#' && cur === null) {
      const nl = s.indexOf('\n', i);
      endSeg();
      i = nl === -1 ? s.length : nl;
      continue;
    }

    if (c === '`') { endSeg(); i++; continue; }
    if (c === '$' && s[i + 1] === '(') { endSeg(); i += 2; continue; }
    if ('&|;\n(){}'.includes(c)) { endSeg(); i++; continue; }
    if (c === ' ' || c === '\t' || c === '\r') { endWord(); i++; continue; }

    put(c); i++;
  }
  endSeg();
  return segs;
}

/**
 * Build the path normaliser the containment tests need: expand the HOME spellings a shell would
 * expand, resolve relative to the directory the command actually runs in, and follow symlinks
 * when the path exists. realpath is ATTEMPTED rather than assumed — hook payloads name
 * directories that may not exist, and a throw there must not become a crash.
 */
export function makeNorm(HOME) {
  return function norm(pathish, base) {
    let s = String(pathish ?? '');
    if (s === '~' || s.startsWith('~/')) s = HOME + s.slice(1);
    else if (s === '$HOME' || s.startsWith('$HOME/')) s = HOME + s.slice(5);
    else if (s === '${HOME}' || s.startsWith('${HOME}/')) s = HOME + s.slice(7);
    const abs = resolve(base || HOME, s);
    try { return realpathSync(abs); } catch { return abs; }
  };
}

/**
 * Read an output redirection out of one lexed segment.
 *
 * Returns { mode: 'append' | 'truncate', spelling, target } or null. `target` is the raw word;
 * the caller resolves it, because only the caller knows which directory the segment runs in.
 *
 * Handles both spacings — `>> file` lexes as two words, `>>file` as one — and `tee -a file`,
 * which is an append by another name. A leading file descriptor (`2>>`, `1>`) is recognised so
 * that a redirect of stderr is not mistaken for a redirect of output to the same path; both
 * still write the file, so both are reported.
 */
export function redirection(words) {
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const m = /^(\d*)(>>|>)(.*)$/.exec(w);
    if (m) {
      const mode = m[2] === '>>' ? 'append' : 'truncate';
      const target = m[3] !== '' ? m[3] : words[i + 1];
      if (target && !target.startsWith('&')) return { mode, spelling: m[2], target };
      continue;
    }
    // `tee -a FILE` appends; `tee FILE` truncates. Flags may be fused or long.
    if (w === 'tee') {
      let appendish = false;
      for (let j = i + 1; j < words.length; j++) {
        const a = words[j];
        if (a === '--') { if (words[j + 1]) return { mode: appendish ? 'append' : 'truncate', spelling: 'tee', target: words[j + 1] }; break; }
        if (a.startsWith('--')) { if (a.slice(2).length && 'append'.startsWith(a.slice(2).split('=')[0])) appendish = true; continue; }
        if (a.startsWith('-') && a.length > 1) { if (a.slice(1).includes('a')) appendish = true; continue; }
        return { mode: appendish ? 'append' : 'truncate', spelling: 'tee', target: a };
      }
    }
  }
  return null;
}

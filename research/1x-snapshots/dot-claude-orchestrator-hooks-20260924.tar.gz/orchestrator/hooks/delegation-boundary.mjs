#!/usr/bin/env node
// ⛔ WORK IN A REPO ANOTHER SEAT OWNS GOES THROUGH THAT SEAT — THIS MODULE EMITS THE
// VERDICT, IT NEVER STOPS ANYTHING.
//
// Jo authorized this build 2026-09-21 (warn-mode first, kill switch, reversal recorded
// BEFORE any install exists: orchestrator/runbooks/delegation-check.md). The rule is fact 6
// of ROUTING.md § "The eight facts that constrain every dispatch on this machine":
// "Work in a shipyard repo is never dispatched to a directly-spawned subagent. It goes
// through a seat." The violation shape, measured live 2026-09-21: a coordinator session —
// Lintel's or any seat's — making tool calls that touch paths inside a repository another
// seat owns, instead of routing the work to that seat.
//
// ⛔ ATTRIBUTION IS BY INSTALLATION, NOT PAYLOAD. The hook is registered per seat; the
// session's identity is whose launcher installed it. The seat name arrives as an argument
// to every call and is NEVER inferred from the event payload — the Gen-3 actor-identity
// blocker does not apply to this rule shape, because fact 6 forbids foreign-session work
// by root or by a spawned hand alike.
//
// ⛔ ROUTING.MD IS LINTEL'S LIVE LEDGER AND IS PARSED FRESH AT EVERY INVOCATION — never
// cached, never written. A co-owned path (two seats, one home — measured: Tinker and
// Lintel both live in /Users/jowolff/.claude, and the routing table carries a row for only
// one of them) exempts EVERY owner; only non-owners flag. Paths under no seat's home are
// unowned and never a violation.
//
// ⛔ THE KILL SWITCH IS READ PER INVOCATION, FROM A FILE — same pattern as
// identifier-url-resolver.mjs's .url-machinery-off, for the same measured reason: a
// module-scope environment read is frozen for the life of the process. `touch
// ~/.claude/.delegation-check-off` silences the verdict within one turn.
//
// ⛔ FAIL-OPEN EVERYWHERE. Missing/unparseable ROUTING.md, missing/corrupt state, missing
// or garbage config, malformed stdin: each degrades to a no-violation verdict with one
// errors.log line where a log is possible. This module exits 0 on EVERY path — the host
// decides what a block means; this file never blocks.
//
// MODES (config ~/.claude/.delegation-check.json, {"mode":"warn"|"block"|"off",
// "readAllowancePerRepo":10, "additionalHomes":{"lintel":["/Users/jowolff/.claude"]}}):
// `warn` is the default and the only mode any near-term registration may use. `mode` rides
// inside every verdict so the host can act on it; the verdict itself is identical either way.
//
// CLI: stdin {"seat":"lintel","tool":"Read","args":{…},"session_id":"…"} → stdout verdict
// JSON, exit 0. `--dry-run` evaluates WITHOUT touching counters (disk state is neither read
// nor written) for corpus measurement: read-shaped calls then always return kind
// "foreign-read" with violation false, and the measurement hand derives allowance rates by
// aggregating those verdicts per (session, repo) against any allowance threshold.

import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

const HOME = process.env.HOME ?? "/Users/jowolff";
const CLAUDE_DIR = join(HOME, ".claude");
export const DEFAULT_ROUTING_PATH = join(CLAUDE_DIR, "orchestrator", "state", "ROUTING.md");
export const DEFAULT_STATE_DIR = join(CLAUDE_DIR, ".delegation-check-state");
export const DEFAULT_CONFIG_PATH = join(CLAUDE_DIR, ".delegation-check.json");
export const DEFAULT_KILL_SWITCH = join(CLAUDE_DIR, ".delegation-check-off");

const DEFAULT_ALLOWANCE = 10;

// Absolute-path token, deliberately identical to identifier-url-resolver.mjs's
// ABSOLUTE_PATH (house precedent) so the two hooks agree on what a path looks like.
const ABSOLUTE_PATH = /\/(?:Users|home|private|tmp|var|opt|etc)\/[\w.@+-]+(?:\/[\w.@+-]+)*/g;
const TILDE_PATH = /(^|[\s"'=(:|&;])~\/[\w.@+-]+(?:\/[\w.@+-]+)*/g;

const WRITE_TOOLS = new Set(["edit", "write", "notebookedit", "multiedit"]);
const READ_TOOLS = new Set(["read", "grep", "glob"]);
const BASH_TOOLS = new Set(["bash", "shell"]);
const SPAWN_TOOLS = new Set(["task", "agent"]);
const SPAWN_ARG_KEYS = new Set(["prompt", "description", "subagent_type", "agent_type", "agent"]);
const BASH_ARG_KEYS = new Set(["command", "cmd", "script", "inline_script"]);
// Keys that name a writable target even on a tool this module does not recognize by name.
// Deliberately excludes the generic `path`: Read/Grep/Glob carry it and are read-shaped,
// and an unrecognized tool with only a `path` degrades to a counted read (fail-open), never
// to a write verdict.
const WRITABLE_ARG_KEYS = new Set([
	"file_path", "filepath", "notebook_path", "notebook", "file", "filename",
	"target", "dest", "destination", "to",
]);

// ⛔ REDIRECT DETECTION EXCLUDES FD-DUPLICATION ONLY. `2>&1` and `>&2` duplicate a file
// descriptor and write no file; counting them as mutations would flag every read pipeline
// that silences its stderr — the cheapest false positive this check could ship. Every other
// `>` / `>>` form (`>file`, `> file`, `>>log`, `2>err.log`) is a file mutation.
const REDIRECT = />{1,2}(?!&)/;
const SED_IN_PLACE = /\bsed\b[^|;&]*\s-{1,2}[^\s]*i/;
const MUTATING_COMMAND = /\b(?:rm|mv|cp|tee|truncate|chmod|chown|touch)\b/;
// `git` followed — possibly after flags such as `-C /some/repo` — by a working-tree-mutating
// subcommand. The brief's token list verbatim; the optional flag cluster exists because
// `git -C /foreign/repo checkout x` must not skate past a regex that only knows
// `git checkout`.
const MUTATING_GIT = /\bgit(?:\s+(?:-[^*\s]+|"[^"]*"|'[^']*'|\S*\/\S+))*\s+(?:checkout|reset|restore|clean|stash|switch|merge|rebase|apply|commit|push|pull|worktree)\b/;

function stripTrailingSlash(p) {
	return String(p).replace(/\/+$/, "");
}

function expandTilde(token, home) {
	if (token.startsWith("~/")) return join(home, token.slice(1));
	if (token === "~") return home;
	return token;
}

/**
 * Parse ROUTING.md's seat→home table defensively. A row qualifies when it has a seat name,
 * a slug-shaped cell, and a third cell that is an absolute home path (/Users/… or /home/…).
 * Every other table in that document — handler verdicts, task shapes — fails the home test
 * and is skipped. Never throws; garbage in, empty table out (which evaluateDelegation turns
 * into a fail-open no-path verdict).
 */
export function parseRoutingTable(markdown) {
	const rows = [];
	if (typeof markdown !== "string") return rows;
	for (const line of markdown.split(/\r?\n/)) {
		const trimmed = line.trim();
		if (!trimmed.startsWith("|")) continue;
		const cells = trimmed.replace(/^\|/, "").split("|").map(c => c.trim());
		if (cells.length < 3) continue;
		const name = cells[0].replace(/\*\*/g, "").trim();
		const slug = cells[1].replace(/`/g, "").trim().toLowerCase();
		const home = stripTrailingSlash(cells[2].replace(/`/g, "").trim());
		if (!name || !slug || !/^\/(?:Users|home)\//.test(home)) continue;
		if (!/^[\w.-]+$/.test(slug)) continue;
		rows.push({ name, seat: slug, home });
	}
	return rows;
}

/** A home owns a path when it IS the path or is a whole-directory prefix of it. */
function covers(home, path) {
	return !!home && (path === home || path.startsWith(home + "/"));
}

/**
 * Every seat whose home covers the path, plus the most specific (longest) covering home —
 * that home is the `repo` the verdict names and the read-counter key, and its seat is the
 * `owner`. Co-ownership is real: /Users/jowolff/.claude covers Tinker's row and (via
 * additionalHomes, or the proposed ROUTING.md row) Lintel too; a path under
 * shipyard/repos/newdle-web is owned by Wren AND by Verge, whose home is the whole shipyard.
 */
function resolveOwners(path, table, additionalHomes) {
	const owners = new Set();
	let best = null;
	const consider = (seat, home) => {
		if (!covers(home, path)) return;
		owners.add(seat);
		if (!best || home.length > best.home.length) best = { seat, home };
	};
	for (const row of table) consider(row.seat, row.home);
	if (additionalHomes && typeof additionalHomes === "object") {
		for (const [seat, homes] of Object.entries(additionalHomes)) {
			if (!Array.isArray(homes)) continue;
			for (const home of homes) consider(String(seat).toLowerCase(), stripTrailingSlash(home));
		}
	}
	return { owners: [...owners], repo: best ? best.home : null, ownerSeat: best ? best.seat : null };
}

function verdict({ applicable, violation, kind, repo, owner, owners, token, sentence, mode, extra }) {
	const v = {
		applicable: !!applicable,
		violation: !!violation,
		kind,
		repo: repo ?? null,
		owner: owner ?? null,
		owners: owners ?? (owner ? [owner] : []),
		mode,
		token,
		reason: `${token}: ${sentence}`,
	};
	return Object.assign(v, extra ?? {});
}

function safeSessionFile(sessionId) {
	const safe = String(sessionId ?? "unknown").replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 100) || "unknown";
	// The leading underscore keeps "unknown"-class names from colliding with a sanitized id
	// that happens to be the literal string.
	return `s_${safe}.json`;
}

function logLine(stateDir, message) {
	try {
		mkdirSync(stateDir, { recursive: true });
		appendFileSync(join(stateDir, "errors.log"), `${new Date().toISOString()} ${message}\n`);
	} catch {
		// Logging is best-effort; a broken log must never break the verdict.
	}
}

function loadCounts(stateDir, sessionId) {
	const file = join(stateDir, safeSessionFile(sessionId));
	try {
		const parsed = JSON.parse(readFileSync(file, "utf8"));
		return { counts: parsed && typeof parsed.counts === "object" && parsed.counts ? parsed.counts : {}, file };
	} catch (error) {
		// Missing file is the normal first-read case and is not logged; corruption is.
		if (error && error.code !== "ENOENT") {
			logLine(stateDir, `state-reset file=${safeSessionFile(sessionId)} reason=${error.code ?? "unparseable"}`);
		}
		return { counts: {}, file };
	}
}

function saveCounts(stateDir, file, counts) {
	try {
		mkdirSync(stateDir, { recursive: true });
		writeFileSync(file, `${JSON.stringify({ counts })}\n`);
	} catch (error) {
		logLine(stateDir, `state-write-failed file=${dirname(file) !== stateDir ? "path-escape-blocked" : file} reason=${error?.code ?? "write"}`);
	}
}

/**
 * Read the optional config. Missing → defaults. Unparseable → defaults plus one errors.log
 * line in the state dir (fail-open, but auditable). Never throws.
 */
export function readConfig(configPath = DEFAULT_CONFIG_PATH, stateDir = DEFAULT_STATE_DIR) {
	const defaults = { mode: "warn", readAllowancePerRepo: DEFAULT_ALLOWANCE, additionalHomes: {} };
	let raw;
	try {
		raw = readFileSync(configPath, "utf8");
	} catch {
		return defaults; // missing config is the normal case, not a logged defect
	}
	try {
		const parsed = JSON.parse(raw);
		const config = {
			mode: ["warn", "block", "off"].includes(parsed?.mode) ? parsed.mode : defaults.mode,
			readAllowancePerRepo: Number.isFinite(parsed?.readAllowancePerRepo) && parsed.readAllowancePerRepo > 0
				? parsed.readAllowancePerRepo
				: defaults.readAllowancePerRepo,
			additionalHomes: parsed?.additionalHomes && typeof parsed.additionalHomes === "object" ? parsed.additionalHomes : {},
		};
		return config;
	} catch {
		logLine(stateDir, `config-unparseable path=${configPath} using-defaults`);
		return defaults;
	}
}

function collectValuePaths(value, out, depth = 0) {
	if (depth > 6 || value == null) return;
	if (typeof value === "string") {
		const expanded = expandTilde(value.trim(), HOME);
		if (/^\/(?:Users|home|private|tmp|var|opt|etc)\//.test(expanded)) out.push(expanded);
		return;
	}
	if (Array.isArray(value)) {
		for (const item of value) collectValuePaths(item, out, depth + 1);
		return;
	}
	if (typeof value === "object") {
		for (const item of Object.values(value)) collectValuePaths(item, out, depth + 1);
	}
}

function collectTextPaths(text, out) {
	if (typeof text !== "string") return;
	for (const match of text.matchAll(ABSOLUTE_PATH)) out.push(match[0]);
	for (const match of text.matchAll(TILDE_PATH)) out.push(expandTilde(match[0].replace(/^[\s"'=(:|&;]/, ""), HOME));
}

function hasKey(args, keys) {
	return !!args && typeof args === "object" && Object.keys(args).some(k => keys.has(k));
}

/**
 * Extract every path this call names. Structured values count only when the ENTIRE value is
 * a path — an Edit whose new_string merely mentions /some/repo/file must not classify as
 * work in that repo. Free-text fields (bash command, spawn prompt/description) contribute
 * embedded tokens, because naming a path in prose is exactly the spawn signal.
 */
function extractPaths(tool, args) {
	const paths = [];
	if (!args || typeof args !== "object") return paths;
	const lowered = Object.fromEntries(
		Object.entries(args).map(([k, v]) => [k.toLowerCase(), v]),
	);
	for (const key of BASH_ARG_KEYS) if (typeof lowered[key] === "string") collectTextPaths(lowered[key], paths);
	for (const key of SPAWN_ARG_KEYS) if (typeof lowered[key] === "string") collectTextPaths(lowered[key], paths);
	if (typeof lowered.cwd === "string") {
		const expanded = expandTilde(lowered.cwd.trim(), HOME);
		if (/^\/(?:Users|home|private|tmp|var|opt|etc)\//.test(expanded)) paths.push(expanded);
	}
	collectValuePaths(args, paths);
	return [...new Set(paths)];
}

/**
 * The verdict for one tool call. `call` = {seat, tool, args, session_id}; `options`
 * overrides every default: routingTable (parsed rows, tests/measurement), routingMarkdown,
 * additionalHomes, readAllowancePerRepo, mode, stateDir, killSwitchPath, dryRun. Never
 * throws; every failure path degrades to a fail-open verdict.
 */
export function evaluateDelegation(call, options = {}) {
	const mode = ["warn", "block", "off"].includes(options.mode) ? options.mode : "warn";
	const killSwitchPath = options.killSwitchPath ?? DEFAULT_KILL_SWITCH;
	const stateDir = options.stateDir ?? DEFAULT_STATE_DIR;
	const dryRun = !!options.dryRun;

	// Per-invocation existsSync, never cached: the switch must land within one turn.
	if (existsSync(killSwitchPath)) {
		return verdict({
			applicable: false, violation: false, kind: "no-path", repo: null, owner: null, owners: [],
			token: "killed", sentence: "kill switch present; delegation check is inert", mode, extra: { killed: true },
		});
	}
	if (mode === "off") {
		return verdict({
			applicable: false, violation: false, kind: "no-path", repo: null, owner: null, owners: [],
			token: "mode-off", sentence: "mode is off in config; delegation check is inert", mode,
		});
	}

	const seat = String(call?.seat ?? "").trim().toLowerCase();
	const tool = String(call?.tool ?? "").trim().toLowerCase();
	const args = call?.args && typeof call.args === "object" ? call.args : {};
	const sessionId = call?.session_id ?? "unknown";

	let table = null;
	if (Array.isArray(options.routingTable)) table = options.routingTable;
	else if (typeof options.routingMarkdown === "string") table = parseRoutingTable(options.routingMarkdown);
	else {
		try {
			table = parseRoutingTable(readFileSync(DEFAULT_ROUTING_PATH, "utf8"));
		} catch {
			table = [];
		}
	}
	if (!table || table.length === 0) {
		// Fail-open: with no ownership table nothing can be foreign. no-path class, per the
		// brief's unparseable-ROUTING.md case, and distinguishable by token.
		return verdict({
			applicable: false, violation: false, kind: "no-path", repo: null, owner: null, owners: [],
			token: "routing-table-empty-or-unreadable",
			sentence: "no seat→home rows could be parsed; treating every path as unowned", mode,
		});
	}

	const paths = extractPaths(tool, args);
	if (paths.length === 0) {
		return verdict({
			applicable: false, violation: false, kind: "no-path", repo: null, owner: null, owners: [],
			token: "no-path", sentence: "call names no absolute path", mode,
		});
	}

	const additionalHomes = options.additionalHomes ?? {};
	const allowance = Number.isFinite(options.readAllowancePerRepo) && options.readAllowancePerRepo > 0
		? options.readAllowancePerRepo
		: DEFAULT_ALLOWANCE;

	// Resolve every named path against the ownership table exactly once, then classify by
	// severity: write > spawn > read. Own-home and unowned paths are inert.
	const isSpawnShaped = SPAWN_TOOLS.has(tool) || hasKey(args, SPAWN_ARG_KEYS);
	const isBashShaped = BASH_TOOLS.has(tool) || hasKey(args, BASH_ARG_KEYS);
	let bashMutates = false;
	if (isBashShaped) {
		const command = [args.command, args.cmd, args.script, args.inline_script]
			.filter(v => typeof v === "string").join(" ; ");
		bashMutates = REDIRECT.test(command) || SED_IN_PLACE.test(command)
			|| MUTATING_COMMAND.test(command) || MUTATING_GIT.test(command);
	}

	const resolutions = [];
	for (const path of paths) {
		const { owners, repo, ownerSeat } = resolveOwners(path, table, additionalHomes);
		if (repo === null) {
			resolutions.push({ path, kind: "unowned-path", owners: [], ownerSeat: null, repo: null, foreign: false });
			continue;
		}
		if (owners.includes(seat)) {
			resolutions.push({ path, kind: "own-home", owners, ownerSeat, repo, foreign: false });
			continue;
		}
		resolutions.push({ path, kind: "foreign", owners, ownerSeat, repo, foreign: true });
	}

	const firstForeign = resolutions.find(r => r.foreign);
	const firstAny = resolutions.find(r => r.repo !== null) ?? resolutions[0];

	if (!firstForeign) {
		const kind = firstAny && firstAny.repo !== null ? "own-home" : "unowned-path";
		const token = kind;
		const sentence = kind === "own-home"
			? `path is inside the calling seat's home (owners: ${firstAny.owners.join(", ")})`
			: "path is under no seat's home";
		return verdict({
			applicable: kind === "own-home", violation: false, kind, repo: firstAny?.repo ?? null,
			owner: firstAny?.ownerSeat ?? null, owners: firstAny?.owners ?? [], token, sentence, mode,
		});
	}

	const target = firstForeign;
	const namedOwners = target.owners.join(", ");
	const foreignWrite = WRITE_TOOLS.has(tool)
		|| (isBashShaped && bashMutates)
		|| (!isSpawnShaped && !isBashShaped && !READ_TOOLS.has(tool)
			&& Object.keys(args).some(k => WRITABLE_ARG_KEYS.has(k.toLowerCase()) && typeof args[k] === "string"
				&& resolutions.some(r => r.foreign && r.path === expandTilde(String(args[k]).trim(), HOME))));

	if (foreignWrite) {
		return verdict({
			applicable: true, violation: true, kind: "foreign-write", repo: target.repo,
			owner: target.ownerSeat, owners: target.owners, token: "foreign-write",
			sentence: `${tool} writes inside ${target.repo}, owned by ${namedOwners}; route the work to the owning seat (fact 6)`,
			mode,
		});
	}

	if (isSpawnShaped) {
		return verdict({
			applicable: true, violation: true, kind: "foreign-spawn", repo: target.repo,
			owner: target.ownerSeat, owners: target.owners, token: "foreign-spawn",
			sentence: `spawn names ${target.repo}, owned by ${namedOwners}; dispatch through the owning seat, never a direct subagent (fact 6)`,
			mode,
		});
	}

	// Read-shaped: count per (session, repo); violation only at/after the allowance.
	const foreignRepos = [...new Set(resolutions.filter(r => r.foreign).map(r => r.repo))];
	if (dryRun) {
		// No state read, no state write, no flag: measurement derives allowance rates by
		// aggregating these verdicts per (session, repo) against any threshold it sweeps.
		return verdict({
			applicable: true, violation: false, kind: "foreign-read", repo: target.repo,
			owner: target.ownerSeat, owners: target.owners, token: "foreign-read",
			sentence: `read inside ${target.repo} (owners: ${namedOwners}); dry-run, not counted`, mode,
			extra: { dryRun: true, allowance },
		});
	}

	const { counts, file } = loadCounts(stateDir, sessionId);
	let crossed = null;
	for (const repo of foreignRepos) {
		counts[repo] = (counts[repo] ?? 0) + 1;
		if (!crossed && counts[repo] >= allowance) crossed = repo;
	}
	saveCounts(stateDir, file, counts);
	if (crossed) {
		const crossedRes = resolutions.find(r => r.foreign && r.repo === crossed);
		return verdict({
			applicable: true, violation: true, kind: "foreign-read-over-allowance", repo: crossed,
			owner: crossedRes.ownerSeat, owners: crossedRes.owners, token: "foreign-read-over-allowance",
			sentence: `read #${counts[crossed]} inside ${crossed} (owners: ${crossedRes.owners.join(", ")}) is at the allowance of ${allowance}; route further work to the owning seat`,
			mode, extra: { count: counts[crossed], allowance },
		});
	}
	return verdict({
		applicable: true, violation: false, kind: "foreign-read", repo: target.repo,
		owner: target.ownerSeat, owners: target.owners, token: "foreign-read",
		sentence: `read inside ${target.repo} (owners: ${namedOwners}); count ${counts[target.repo] ?? 0} of ${allowance}`,
		mode, extra: { count: counts[target.repo] ?? 0, allowance },
	});
}

function readStdin() {
	try {
		return readFileSync(0, "utf8");
	} catch {
		return "";
	}
}

function main() {
	const dryRun = process.argv.includes("--dry-run");
	let call = {};
	try {
		call = JSON.parse(readStdin() || "{}");
	} catch {
		call = {}; // fail-open on malformed stdin
	}
	const config = readConfig();
	const result = evaluateDelegation(call, { ...config, dryRun });
	process.stdout.write(`${JSON.stringify(result)}\n`);
	// Exit 0 on every path — deliberately implicit and unreachable-otherwise.
}

const invokedDirectly = import.meta.main === true
	|| (Array.isArray(process.argv) && String(process.argv[1] ?? "").replace(/\\/g, "/").endsWith("/delegation-boundary.mjs"));
if (invokedDirectly) main();

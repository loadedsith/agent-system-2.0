#!/usr/bin/env node
/**
 * phantom-claim-stop.mjs — Stop / SubagentStop guard.
 *
 * ⛔ THE MODE IS NOT A FACT ABOUT THIS FILE. It is read from PHANTOM_MODE at line 64, and the
 * live value is set by whoever registers the hook. Read the registration, not this comment.
 * As of 2026-08-26 that is settings.json, Stop array: PHANTOM_MODE=block. THIS GUARD BLOCKS.
 *
 * This line previously read "INSTALLED 2026-08-22 in WARN mode (PHANTOM_MODE=warn) ... Blocks
 * nothing. Re-evaluate 2026-08-29." The mode was later flipped to block in settings and the
 * header was not, so for four days the first thing a reader saw said the guard was inert while
 * it was stopping turns. Nothing refused, and nobody was told: that is the RECORDER failure
 * class, not the guard failure class, and it is the more dangerous of the two because a guard
 * that misfires produces a refusal somebody reads, while a record that misfires is believed
 * until it is load-bearing. A header is the file a reader opens FIRST to find out what a hook
 * does, and every receipt rule on this machine assumes the thing you read describes the thing
 * that runs.
 *
 * The old line also carried a dated commitment - "Re-evaluate 2026-08-29" - with nothing
 * anywhere to fire on that date. A date in a comment is not a reminder, it is a sentence that
 * expires quietly. It is deliberately NOT replaced with another one. What to re-evaluate
 * AGAINST is state/phantom-claims.jsonl: rows there are what this guard actually did, and a
 * run of false positives is visible in them without needing a date to prompt anyone.
 *
 * WHAT IT CATCHES. A turn whose final assistant message asserts a completed action while the
 * turn contains no tool call that could have produced it. Two real instances, one evening,
 * one hour apart: a dispatch reported in the past tense under an ACTION label, in a turn that
 * made no tool calls at all. Both were caught by an unrelated Stop hook forcing a re-read.
 * Nothing on this machine compares a report's prose against the tool calls of its own turn.
 *
 * ── EVENT AND PAYLOAD ────────────────────────────────────────────────────────────────────
 * Stop and SubagentStop, because they are the only events that carry BOTH halves:
 *   last_assistant_message  the final assistant text of the current turn
 *   transcript_path         the conversation JSONL, from which the turn's tool calls come
 *   prompt_id               scopes "the turn" without guessing at boundaries
 *   stop_hook_active        the loop guard, honoured first
 *
 * The transcript is written ASYNCHRONOUSLY and may lag the in-memory conversation, which is
 * exactly why the final assistant text is taken from the payload and never from the file.
 * Tool calls have no such alternative, so lag is handled by REFUSING TO CONCLUDE: if the
 * turn's own anchor is not yet in the transcript, the turn is 'unresolved' and never blocks.
 *
 * ── CONTRACT, copied from the sibling Stop hooks in this house ───────────────────────────
 * ALWAYS exit 0. Decide via stdout JSON: silence, or {"decision":"block","reason":...}.
 * A non-zero exit reads as harness breakage, which must never be confused with a verdict.
 * Fail OPEN on everything about the hook's own plumbing — garbage stdin, unreadable state,
 * an unreadable transcript, a foreign session. A guard that traps every session on this
 * machine because its own parse broke is a worse outcome than every phantom it would catch.
 *
 * ── FAILURE POSTURE ──────────────────────────────────────────────────────────────────────
 * A false positive that blocks a correct turn is worse than a missed phantom, because a guard
 * that cries wolf gets switched off and then catches nothing. So blocking is confined to the
 * single unambiguous case — claims present, ZERO tool calls in the turn — which is precisely
 * the shape of both real incidents and requires no verb-to-tool guesswork. Everything weaker
 * is written to a log for calibration and blocks nothing. A turn with no prose never blocks.
 *
 * Env (all optional): PHANTOM_STATE, LINTEL_STATE, PHANTOM_MODE (block|warn|off),
 * PHANTOM_LOG, PHANTOM_SETTLE_MS, PHANTOM_SETTLE_TRIES.
 */
import { readFileSync, appendFileSync, mkdirSync, createReadStream } from 'node:fs';
import { join, dirname } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { grade } from './phantom-lib.mjs';
import { inOrchestratorSession } from './session-gate.mjs';

const allow = () => process.exit(0);
const block = (reason) => {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
  process.exit(0);
};

let input = '';
try { input = readFileSync(0, 'utf8'); } catch { allow(); }
let p = {};
try { p = JSON.parse(input); } catch { allow(); }
if (!p || typeof p !== 'object') allow();

// 1. Loop guard. Never block a continuation of our own block.
if (p.stop_hook_active === true) allow();

const MODE = process.env.PHANTOM_MODE || 'block';
if (MODE === 'off') allow();

const STATE = process.env.PHANTOM_STATE || process.env.LINTEL_STATE
  || join(homedir(), '.claude', 'orchestrator', 'state');

// 2. Session gate. Hooks registered with universal matchers fire in EVERY session on this
//    machine, including other people's agents. If this turn is not ours, it is not ours to judge.
//
//    THIS USED TO BE A PRIVATE VARIANT and the variant failed OPEN. It read, in effect,
//    `if (owner && p.session_id && owner !== p.session_id) allow()` — so a payload carrying NO
//    session_id made the condition false, allow() never ran, and the hook judged a turn it could
//    not attribute to anyone. The shared module returns false in exactly that case: no marker,
//    unreadable marker, empty marker, or missing session_id is no permission to act. This was
//    the only registered Stop hook not using it. Same import as savepoint-fit-stop.mjs and
//    state-checks-stop.mjs, unchanged, so the gate cannot drift between them.
if (!inOrchestratorSession(p, STATE)) allow();

const message = typeof p.last_assistant_message === 'string' ? p.last_assistant_message : '';
if (message.trim() === '') allow();   // zero prose: nothing to check, and never blockable

// ── TURN RESOLUTION ──────────────────────────────────────────────────────────────────────
// Streams the transcript one line at a time. Transcripts run to tens of megabytes; nothing
// here holds more than a single line, and the only accumulation is a set of tool names.
//
// The turn is anchored on the user entry carrying this prompt_id whose `promptSource` marks
// it a real prompt rather than a tool result. Everything after that anchor, on the same side
// of the sidechain boundary, belongs to the turn. EXISTENCE ONLY: order is never examined.
function resolveTurn(path, promptId) {
  const names = new Set();
  let anchored = false;
  let anchorSidechain = false;
  let lines;
  try { lines = readFileSync(path, 'utf8').split('\n'); } catch { return null; }

  // Two passes over line strings, never over parsed objects: find the anchor, then collect.
  let anchorAt = -1;
  let sawPromptSource = false;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (!l || l.indexOf('"promptSource"') === -1) continue;      // cheap prefilter
    let o; try { o = JSON.parse(l); } catch { continue; }
    if (o.type !== 'user' || !o.promptSource) continue;
    sawPromptSource = true;
    if (promptId && o.promptId !== promptId) continue;
    anchorAt = i; anchorSidechain = o.isSidechain === true;
  }

  // SUBAGENT FALLBACK, and it is not a nicety: subagent transcripts carry NO promptSource field
  // at all, checked against real files under ~/.claude/projects/*/subagents/. Without this the
  // anchor never resolves on SubagentStop, every subagent turn grades 'unresolved', and the
  // whole SubagentStop half of the hook is silently inert — the worst failure available, since
  // it looks identical to "no phantoms". The fallback anchors on the last user entry whose
  // content is a plain string, which is a brief or a follow-up message and never a tool result.
  // Gated on the transcript using promptSource AT ALL. If it does and this turn is simply not
  // in it yet, that is LAG, and the fallback must not paper over it by anchoring on the
  // previous turn — which would credit that turn's tool calls to this one.
  if (anchorAt === -1 && !sawPromptSource) {
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (!l || l.indexOf('"user"') === -1) continue;
      let o; try { o = JSON.parse(l); } catch { continue; }
      if (o.type !== 'user' || typeof o.message?.content !== 'string') continue;
      if (o.isMeta) continue;
      anchorAt = i; anchorSidechain = o.isSidechain === true;
    }
  }
  if (anchorAt === -1) return null;                              // lag, or a turn we cannot scope
  anchored = true;

  for (let i = anchorAt + 1; i < lines.length; i++) {
    const l = lines[i];
    if (!l || l.indexOf('"tool_use"') === -1) continue;          // cheap prefilter
    let o; try { o = JSON.parse(l); } catch { continue; }
    if (o.type !== 'assistant') continue;
    if ((o.isSidechain === true) !== anchorSidechain) continue;
    const c = o.message && o.message.content;
    if (!Array.isArray(c)) continue;
    for (const b of c) if (b && b.type === 'tool_use' && b.name) names.add(b.name);
  }
  return anchored ? names : null;
}

const settleMs = Number(process.env.PHANTOM_SETTLE_MS ?? 120);
const settleTries = Number(process.env.PHANTOM_SETTLE_TRIES ?? 3);
function sleep(ms) {
  try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch { /* ignore */ }
}

let names = null;
if (typeof p.transcript_path === 'string' && p.transcript_path) {
  for (let attempt = 0; attempt < Math.max(1, settleTries); attempt++) {
    names = resolveTurn(p.transcript_path, p.prompt_id);
    if (names !== null) break;
    if (attempt < settleTries - 1 && settleMs > 0) sleep(settleMs);   // the transcript lags
  }
}

const result = grade(message, names ? [...names] : [], names !== null);

// ── OUTCOME ──────────────────────────────────────────────────────────────────────────────
const logPath = process.env.PHANTOM_LOG || join(STATE, 'phantom-claims.jsonl');
function record(extra) {
  try {
    mkdirSync(dirname(logPath), { recursive: true });
    appendFileSync(logPath, JSON.stringify({
      at: new Date().toISOString(),
      session_id: p.session_id ?? null,
      prompt_id: p.prompt_id ?? null,
      event: p.hook_event_name ?? null,
      verdict: result.verdict,
      reason: result.reason,
      tools_called: names ? [...names] : null,
      claims: result.claims.map((c) => ({ kind: c.kind, verb: c.verb, sentence: c.sentence })),
      ambiguous: (result.ambiguous ?? []).map((c) => ({ kind: c.kind, verb: c.verb, sentence: c.sentence })),
      ...extra,
    }) + '\n');
  } catch { /* plumbing: never let logging change the verdict */ }
}

if (result.verdict === 'clean') allow();

if (result.verdict === 'unresolved' || result.verdict === 'phantom-low' || MODE === 'warn') {
  record({ blocked: false });
  allow();
}

// phantom-high, in block mode: claims of completed action in a turn that called nothing.
record({ blocked: true });
const list = result.claims.map((c) => `  · [${c.kind}] "${c.sentence}"`).join('\n');
block(
  'PHANTOM CLAIM. Your reply asserts an action is already complete, and this turn contains no ' +
  'tool calls at all — so nothing in it could have performed the action.\n\n' + list +
  '\n\nDo one of two things, not a third. Either PERFORM the work now and then report it, or ' +
  'REWRITE the sentence so it is honest about scope — "next turn I will…", "want me to…" — ' +
  'which defers the action past this turn and is not checked here. Do not re-send the same ' +
  'sentence with the same scope.\n\n' +
  'If this is wrong — the action really did happen and this guard misread it — say so plainly ' +
  'in your reply; the misfire is logged at ' + logPath + ' for review.'
);

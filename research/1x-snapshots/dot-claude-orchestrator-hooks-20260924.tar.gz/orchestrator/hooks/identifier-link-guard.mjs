#!/usr/bin/env node
/**
 * IDENTIFIER LINK GUARD — refuses a turn that names an identifier Jo cannot act on.
 *
 * ⛔ WHY THIS EXISTS, AND WHY IT IS CODE RATHER THAN A RULE. The rule already exists in three
 * places and has never once fired:
 *   1. `state/BRIEF-BOILERPLATE.md:142-144` — "If a seat sends an identifier up without its link,
 *      the dispatcher fixes it before relaying rather than passing the lookup along."
 *   2. Every seat's boot prompt — "do not restate identifiers without their content."
 *   3. `state/JUDGEMENT.md:49` records the failure as ours, with Jo's words: "I have no idea what
 *      you mean by Eng 1563's audit. I don't even know what Eng 1563 is about."
 * REQ-479 and REQ-480 (2026-09-11, both still open) assigned this machinery to Tinker. Jo, again
 * on 2026-09-15: "why, for the love of fuck, would you reference a PR and not give me the hard
 * link to where it lives in GitHub? I'm not going to hunt for it." Between those two dates Tinker
 * emitted ten bare identifiers in a single session. ⛔ Jo's own framing is the design rationale:
 * "'write it down and read it later' keeps losing to 'a line of code that refuses.'"
 *
 * CONTRACT, same as every hook in this directory: read one JSON payload on stdin, ALWAYS exit 0,
 * decide via stdout JSON, fail OPEN on anything unexpected. A guard on outgoing text that throws
 * is a seat that cannot speak at all.
 *
 * ── THREE CLASSES, THREE DIFFERENT REQUIREMENTS ──────────────────────────────────────────────
 *
 * The naive matcher — anything shaped like an id must carry a URL — is unshippable, because a
 * third of the identifiers this fleet uses have no URL and never will.
 *
 *   GITHUB   `#1073`, `PR 1073`, `issue 9340`  → needs github.com/<org>/<repo>/pull|issues/<n>
 *   LINEAR   `ALL-937`, `ENG-1958`             → needs a linear.app URL carrying that id
 *   LEDGER   `REQ-479`, `DEC-075`, `EXP-018`   → has NO url; needs its CONTENT in the same
 *                                                sentence, which is the failure Jo quoted about
 *                                                ENG-1563 — that one was about content, not links
 *
 * ⛔ The ledger class is why this cannot be one rule. A hook demanding a URL for `REQ-479` is
 * unshippable; a hook exempting it entirely misses the exact complaint that motivated the rule.
 *
 * ── KNOWN BLIND SPOTS, NAMED RATHER THAN CLAIMED AWAY ────────────────────────────────────────
 *
 * A false positive here taxes every message the seat sends, so the matcher is deliberately narrow
 * and these are the gaps it accepts:
 *   · Fenced code blocks are STRIPPED before matching. An identifier that appears only inside a
 *     code fence will not be caught. Accepted: fences carry commands and file contents, where a
 *     `#1073` is usually literal text rather than a reference being made to Jo.
 *   · Inline code spans are NOT stripped. `` `#1073` `` still needs its link, because backticks
 *     do not make an identifier actionable.
 *   · `#` followed by fewer than two digits is ignored — `#1` is far more often a list marker or a
 *     column reference than a PR.
 *   · A Linear-shaped token is any `[A-Z]{2,5}-<digits>` that is not a known ledger prefix, so a
 *     genuine non-Linear token of that shape (`WCAG-2`, `RFC-2119`) is a false positive. The
 *     mitigation is the prefix allowlist below, which is data and cheap to extend.
 *   · Satisfaction is per-message, not per-sentence: a link anywhere in the message satisfies every
 *     mention of that id. Deliberate — Jo needs one clickable link, not one per mention.
 *   · Numbers inside URLs are removed from the candidate set before matching, so the link that
 *     satisfies a mention cannot itself be counted as a bare mention.
 *
 * ── WHAT IT DOES NOT DO ──────────────────────────────────────────────────────────────────────
 *
 * No session gate. Unlike the state-writing hooks in this directory it writes nothing and reads
 * nothing but the payload, so there is no foreign-session hazard to gate against.
 * It honours `stop_hook_active` first: a continuation stop carries the same message, and a guard
 * that re-blocks its own block chain is the loop defect `dispatch-check-stop.mjs:70-74` records.
 */

let raw = "";

/**
 * ⛔ WHY THIS GUARD DEMANDS A LINEAR LINK AND NEVER BUILDS ONE.
 *
 * Jo, 2026-09-15: "make sure that whenever you give me a linear fucking ticket number, it also
 * has the link. That's important." So Linear is first-class here, not a secondary class behind
 * GitHub.
 *
 * The canonical URL carries a title slug — measured by Lintel from `get_issue`'s own `url` field:
 *   https://linear.app/contextpress/issue/ALL-937/derive-download-url-for-studio-from-the-appcastxml
 * The matcher therefore accepts `/issue/<ID>` with OR without a trailing slug: it must not reject
 * the canonical form, and it must not demand a slug, because ⛔ whether the bare form redirects is
 * UNTESTED and no rule here will rest on that.
 *
 * ⛔ AND IT CANNOT CONSTRUCT ONE. The authoritative URL exists only in the API response, and per
 * ROUTING.md fact 7 the Linear MCP namespace is available ONLY in a top-level session — no hook,
 * no subagent, no seat's hand can resolve `ALL-937` to a URL. A guard that synthesised a
 * plausible-looking Linear URL would emit something that reads authoritative and may 404, which
 * is the same defect as a launcher printing a force-push line at someone who did not force-push.
 * So: refuse, name the identifier, and name where the URL comes from.
 *
 * THE EFFECT ON THE CALLER, STATED BECAUSE IT IS THE POINT RATHER THAN A SIDE EFFECT: a Linear
 * ticket nobody fetched cannot satisfy this guard without someone fetching it. The lookup happens
 * once, in the session that can do it, instead of landing on Jo.
 *
 * GitHub is different and the asymmetry is deliberate: `git remote get-url origin` yields
 * `ContextPress/<repo>`, so for that class the refusal can name the exact link to add.
 */
process.stdin.setEncoding("utf8");
process.stdin.on("data", chunk => {
	raw += chunk;
});
process.stdin.on("end", () => {
	try {
		main(raw);
	} catch {
		// Fail open, always. See CONTRACT above.
		process.stdout.write("");
	}
	process.exit(0);
});

/** Ledger prefixes that have no URL anywhere and never will. Data, so extending is cheap. */
const LEDGER_PREFIXES = ["REQ", "DEC", "EXP", "ADR", "GAP"];

/**
 * Prefixes that LOOK like Linear team keys and are not, so the Linear rule skips them.
 *
 * ⛔ WHY A DENYLIST AND NOT AN ALLOWLIST OF REAL TEAM KEYS, which is the obvious alternative and
 * is WRONG. An allowlist can be fetched (`list_teams`) and would be exact — but it fails in the
 * dangerous direction: a Linear team missing from the list silently escapes the guard, and a bare
 * ticket reaches Jo unlinked, which is the entire failure this hook exists to stop. The catch-all
 * plus this denylist fails the other way: a false positive, which is LOUD, lands on the seat that
 * wrote the message, and gets fixed. Lintel's call, and the reasoning is the direction of failure
 * rather than accuracy.
 *
 * ⛔ `CVE` IS HERE FOR A DIFFERENT REASON THAN THE REST. `CVE-2024-1234` is a security identifier
 * we will genuinely use, it matches the catch-all, and unlike `UTF-8` it HAS an authoritative URL
 * of its own. Exempting it from the Linear rule is correct; whether it deserves its own class
 * demanding a link is a separate question, deliberately not opened here.
 *
 * NOT LISTED, and the omission is deliberate rather than an oversight: `P-0` and `P-1` cannot
 * match at all — the catch-all requires `[A-Z]{2,5}`, two characters minimum, so a single-letter
 * prefix never reaches this check. Listing them would imply a guard that was never needed.
 */
const NON_LINEAR_PREFIXES = [
	// encodings and hashes
	"UTF", "SHA", "MD", "AES", "BLAKE",
	// standards and specs
	"RFC", "ISO", "WCAG", "HTTP", "TLS", "IPV", "ES",
	// severity and ops
	"SEV",
	// security identifiers — see the CVE note above
	"CVE",
];

const GITHUB_URL = /https?:\/\/(?:www\.)?github\.com\/[\w.-]+\/[\w.-]+\/(?:pull|issues)\/(\d+)/gi;
const LINEAR_URL = /https?:\/\/(?:www\.)?linear\.app\/[\w.-]+\/issue\/([A-Za-z]{2,5}-\d+)/gi;

function main(input) {
	const payload = JSON.parse(input || "{}");
	if (payload.stop_hook_active) return allow();

	const message = typeof payload.last_assistant_message === "string" ? payload.last_assistant_message : "";
	if (message.trim() === "") return allow();

	// Strip fenced code blocks; see BLIND SPOTS.
	const prose = message.replace(/```[\s\S]*?```/g, " ").replace(/~~~[\s\S]*?~~~/g, " ");

	// Collect the links FIRST, then blank every URL so its digits cannot read as a bare mention.
	const linkedGithub = new Set();
	for (const match of prose.matchAll(GITHUB_URL)) linkedGithub.add(match[1]);
	const linkedLinear = new Set();
	for (const match of prose.matchAll(LINEAR_URL)) linkedLinear.add(match[1].toUpperCase());
	const withoutUrls = prose.replace(/https?:\/\/\S+/g, " ");

	const missing = [];

	// ── GITHUB ────────────────────────────────────────────────────────────────────────────────
	const githubMentions = new Set();
	for (const match of withoutUrls.matchAll(/(?:^|[\s([])#(\d{2,})\b/g)) githubMentions.add(match[1]);
	for (const match of withoutUrls.matchAll(/\b(?:PR|pull request|issue)\s+#?(\d{2,})\b/gi)) githubMentions.add(match[1]);
	for (const number of githubMentions) {
		if (!linkedGithub.has(number)) {
			missing.push(`\`#${number}\` — needs its full https://github.com/<org>/<repo>/pull/${number} link`);
		}
	}

	// ── LINEAR AND LEDGER ─────────────────────────────────────────────────────────────────────
	const seen = new Set();
	for (const match of withoutUrls.matchAll(/\b([A-Z]{2,5})-(\d+)\b/g)) {
		const id = `${match[1]}-${match[2]}`;
		if (seen.has(id)) continue;
		seen.add(id);
		if (NON_LINEAR_PREFIXES.includes(match[1])) continue;   // see NON_LINEAR_PREFIXES above
		if (LEDGER_PREFIXES.includes(match[1])) {
			if (!hasContent(withoutUrls, id)) {
				missing.push(`\`${id}\` — has no URL, so it needs its CONTENT in the same sentence: what it is, not just its number`);
			}
		} else if (!linkedLinear.has(id)) {
			// ⛔ NAMES THE SOURCE, NEVER A CONSTRUCTED URL. The first version of this line emitted
			// `https://linear.app/contextpress/issue/<ID>` as a suggestion, which contradicted this
			// hook's own documented rule three paragraphs above it: a synthesised Linear URL reads
			// authoritative and may 404. The org slug is known; the issue path is not ours to invent.
			missing.push(
				`\`${id}\` — a Linear ticket, and this guard cannot construct its URL: the authoritative`
					+ " link is the `url` field from `get_issue`, available only in a top-level session"
					+ " (ROUTING.md fact 7). Fetch it and paste the real link.",
			);
		}
	}

	if (!missing.length) return allow();

	block(
		`⛔ Identifiers named without what Jo needs to act on them: ${missing.length}.\n`
			+ missing.map(m => `- ${m}`).join("\n")
			+ "\n\nJo, 2026-09-11: \"why, for the love of fuck, would you reference a PR and not give me"
			+ " the hard link to where it lives in GitHub? I'm not going to hunt for it.\""
			+ " Add the link — or, for a ledger id, what it actually says — and send again.",
	);
}

/**
 * A ledger id carries its content when its own sentence says something beyond identifiers.
 *
 * ⛔ THE THRESHOLD IS A JUDGEMENT AND IS STATED AS ONE: four words of non-identifier prose in the
 * sentence containing the id. "REQ-479 is open" passes on word count and is nearly useless, which
 * is the honest limit of a mechanical check on meaning — it catches the bare-list failure Jo
 * complained about ("5B 22C 3D 8 still local only") and cannot catch a thin gloss. A model judge
 * could, and that is a tier-3 concern per the eval README, not a hook's job.
 */
function hasContent(text, id) {
	const index = text.indexOf(id);
	if (index < 0) return true;
	// Sentence bounds: nearest terminator either side, newlines included so a list row is its own
	// sentence rather than borrowing prose from the row above.
	const start = Math.max(
		...[".", "!", "?", "\n"].map(mark => text.lastIndexOf(mark, index)),
		-1,
	) + 1;
	const endCandidates = [".", "!", "?", "\n"]
		.map(mark => text.indexOf(mark, index + id.length))
		.filter(position => position >= 0);
	const end = endCandidates.length ? Math.min(...endCandidates) : text.length;
	const sentence = text.slice(start, end);
	const words = sentence
		.replace(/\b[A-Z]{2,5}-\d+\b/g, " ")
		.replace(/[^A-Za-z\s]/g, " ")
		.split(/\s+/)
		.filter(word => word.length > 2);
	return words.length >= 4;
}

function allow() {
	process.stdout.write("");
}

function block(reason) {
	process.stdout.write(JSON.stringify({ decision: "block", reason }));
}

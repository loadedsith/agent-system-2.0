/**
 * TURN ID — shared format and storage. Imported by turn-id-mint.mjs (UserPromptSubmit) and
 * turn-id-verify.mjs (Stop). One module for the same reason session-gate.mjs is one module: two
 * hooks that must agree on a string format will drift if each spells it out for itself.
 *
 * FORMAT: T-YYYYMMDD-HHMMSS-SSPP   e.g. T-20260819-213045-K7Q2   (22 characters)
 *
 *   T-        fixed prefix: greppable in a transcript, unmistakable in prose
 *   YYYYMMDD  LOCAL calendar date of the turn — the human-readable half Jo asked for
 *   HHMMSS    LOCAL 24h time to the second. Seconds are not optional: two prompts in the same
 *             minute are ordinary.
 *   SS        2 chars derived from the SESSION id. Every turn of one conversation shares them,
 *             so ids from parallel threads are visibly different and groupable by thread.
 *   PP        2 chars derived from the PROMPT id (the harness's own per-turn uuid). This is what
 *             keeps two turns minted inside the same second distinct.
 *
 * Alphabet: 30 characters — digits and uppercase minus 0 1 I L O U. Crockford's exclusions:
 * nothing that can be misread between screen and keyboard, and no vowel, so no id can spell a
 * word. 22 characters is typeable; it is also entirely copy-paste-able, which is the normal case.
 *
 * WHY DERIVED RATHER THAN RANDOM: session_id and prompt_id are both recorded in the harness's own
 * transcript (`sessionId`, `promptId` on every `user` row — measured), alongside the timestamp.
 * So ANY turn id can be recomputed from the transcript alone. If the ledger and the marker files
 * are lost, the ids are still reconstructible; a random suffix would not be.
 *
 * The residual collision — same session, same second, colliding 2-char prompt hash — is closed
 * mechanically by nextFreeId() below rather than argued away.
 */
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

const ALPHABET = '23456789ABCDEFGHJKMNPQRSTVWXYZ';   // 30 chars, no 0 1 I L O U

export function stateDir() {
  return process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');
}

function chars(seed, n) {
  const h = createHash('sha256').update(String(seed ?? '')).digest();
  let out = '';
  for (let i = 0; i < n; i += 1) out += ALPHABET[h[i] % ALPHABET.length];
  return out;
}

export const sessionTag = (sessionId) => chars(sessionId, 2);
export const promptTag = (promptId) => chars(promptId, 2);

function stamp(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-` +
         `${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

export function mintTurnId(sessionId, promptId, when = new Date()) {
  return `T-${stamp(when)}-${sessionTag(sessionId)}${promptTag(promptId)}`;
}

/**
 * Guarantee uniqueness against today's ledger by rotating the last character. Deterministic,
 * bounded, and it only ever runs in the case it exists for. Falls back to the base id rather
 * than failing: a duplicate id is bad, refusing to mint one at all is worse.
 */
export function nextFreeId(baseId, ledgerText) {
  if (!ledgerText || !ledgerText.includes(baseId)) return baseId;
  const head = baseId.slice(0, -1);
  const start = ALPHABET.indexOf(baseId.slice(-1));
  for (let i = 1; i <= ALPHABET.length; i += 1) {
    const cand = head + ALPHABET[(start + i) % ALPHABET.length];
    if (!ledgerText.includes(cand)) return cand;
  }
  return baseId;
}

/** The one regex both hooks and any later tooling should use to recognise a MINTED id. */
export const TURN_ID_RE = /\bT-\d{8}-\d{6}-[2-9A-HJ-NP-TV-Z]{4}\b/g;

/**
 * A LOOSER regex for recognising an id Jo has typed back at us, as opposed to one we minted.
 * Recognising is not the same job as minting and does not want the same strictness: a person
 * retyping 22 characters drops the "T-" prefix and reaches for lower case, and refusing to
 * resolve those would make the id exactly as brittle as the ticket-number references it exists
 * to replace. The digits carry the date and time, so the false-positive surface is narrow.
 */
export const TURN_REF_RE = /\b(?:[Tt]-)?(\d{8}-\d{6}-[2-9A-HJ-NP-TV-Za-hj-np-tv-z]{4})\b/g;

/** Fold a typed reference back into canonical form. */
export function normalizeRef(raw) {
  return `T-${String(raw).replace(/^[Tt]-/, '').toUpperCase()}`;
}

/** Every distinct turn id referenced by a piece of text, canonicalised. */
export function referencedIds(text) {
  const out = [];
  for (const m of String(text ?? '').matchAll(TURN_REF_RE)) {
    const id = normalizeRef(m[1]);
    if (!out.includes(id)) out.push(id);
  }
  return out;
}

/** Filesystem key for the per-turn marker. Sanitised: these strings come from a payload. */
export function turnKey(payload) {
  const clean = (v, fb) => String(v ?? fb).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64) || fb;
  return `${clean(payload?.session_id, 'nosession')}-${clean(payload?.prompt_id, 'noprompt')}`;
}

export function markerPath(payload, state = stateDir()) {
  return join(state, '.turn-state', `${turnKey(payload)}.json`);
}

/** One file per day, so a lookup months later is `grep T-2026… turn-ids/2026-08-19.jsonl`. */
export function ledgerPath(when = new Date(), state = stateDir()) {
  const p = (n) => String(n).padStart(2, '0');
  return join(state, 'turn-ids',
    `${when.getFullYear()}-${p(when.getMonth() + 1)}-${p(when.getDate())}.jsonl`);
}

export function readLedger(when = new Date(), state = stateDir()) {
  try { return readFileSync(ledgerPath(when, state), 'utf8'); } catch { return ''; }
}

/**
 * RESOLVE a turn id Jo has quoted back at us. This is the half that makes the mechanism worth
 * having: "responding to turn T-20260819-213045-K7Q2, do these commands" only works if the agent
 * can actually find that turn, and telling the model to go read a file is a step it may skip.
 * So the mint hook looks the id up and injects the answer at the point of performance.
 *
 * Scans the daily ledgers newest first and stops as soon as every id is accounted for.
 */
export function lookupIds(ids, state = stateDir()) {
  const want = new Set(ids);
  const found = {};
  if (want.size === 0) return found;
  let files = [];
  try {
    files = readdirSync(join(state, 'turn-ids')).filter((f) => f.endsWith('.jsonl')).sort().reverse();
  } catch { return found; }
  for (const f of files.slice(0, 60)) {
    let text = '';
    try { text = readFileSync(join(state, 'turn-ids', f), 'utf8'); } catch { continue; }
    for (const line of text.split('\n')) {
      if (!line) continue;
      let row;
      try { row = JSON.parse(line); } catch { continue; }
      if (want.has(row.id) && !found[row.id]) found[row.id] = row;
    }
    if (Object.keys(found).length === want.size) break;
  }
  return found;
}

/**
 * Where the harness keeps the transcript for a recorded turn. Measured on this machine: the
 * project directory name is the cwd with every "/" and "." replaced by "-", and the file is
 * <session_id>.jsonl. Verified against two different sessions in this lab.
 */
export function transcriptPathFor(row) {
  if (!row || !row.cwd || !row.session_id) return null;
  const slug = String(row.cwd).replace(/[/.]/g, '-');
  return join(homedir(), '.claude', 'projects', slug, `${row.session_id}.jsonl`);
}

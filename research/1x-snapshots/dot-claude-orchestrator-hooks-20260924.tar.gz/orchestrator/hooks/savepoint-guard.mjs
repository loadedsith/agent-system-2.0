#!/usr/bin/env node
/**
 * Stop hook — enforced save point + inbox referential integrity. Node ESM, conforming to the
 * newdle plugin eval contract.
 *
 * Why this replaced the .sh version:
 *   - the tier-1 runner hardcodes `node` and cannot execute a shell hook at all
 *   - every eval helper maps a NON-ZERO EXIT to *indeterminate*, so exit 2 is unassertable there.
 *     The assertable path is a JSON decision on stdout with exit 0.
 *   - the shell version matched `stop_hook_active` with a raw substring. Different key order or
 *     spacing slipped straight past it. That is a SAFETY defect, not a style one: a loop guard
 *     that silently fails to fire is a hook that blocks until the 8-block cap rescues it.
 *   - the shell version defaulted to a hardcoded /Users/... state path, which would escape the
 *     tier-1 isolation (the runner repoints HOME at a mktemp dir) and read real state.
 *
 * REFERENTIAL INTEGRITY (added 2026-08-19). Triage is the only step between a captured prompt and
 * an obligation row, and nothing checked its output. Two ways work disappears through it:
 *
 *   1. ORPHANED TRIAGE — a row says `req:REQ-007b` and REQUESTS.jsonl has never defined REQ-007b.
 *      The row reads as discharged; no obligation exists. Measured on the live inbox before this
 *      was written: REQ-007b, named by 2 rows, defined 0 times.
 *   2. INSTRUCTION FILED AS CONVERSATION — the row that carried an actual instruction is marked
 *      triaged:true, disposition:"conversation", and never becomes an obligation. Nothing
 *      downstream ever looks at it again.
 *
 * Both block the Stop and name the offending rows by line number, so the fix is a one-line edit.
 *
 * INJECTION BUDGET — NO LONGER CHECKED HERE (removed 2026-08-20). It moved out whole to the
 * separate Stop hook savepoint-fit-stop.mjs, which shells out to tools/savepoint-fit.sh. That
 * tool resolves the same limit out of savepoint-restore.sh by the same match order, reports the
 * same overage, and adds a per-section byte table naming which section falls off the cliff.
 * Keeping a copy here as well produced two block reasons saying the same thing at different
 * resolutions. Note the coverage is now WIDER, not narrower: the check here fired only on the
 * accept path, and the new hook measures on every stop of an orchestrator session.
 *
 * CONTRACT: always exit 0. Decide via stdout JSON. Fail open on absolutely everything.
 */
import { readFileSync, existsSync, statSync, mkdirSync, writeFileSync, appendFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { execFileSync } from 'node:child_process';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sweep } from './intake-sweep.mjs';
import { inOrchestratorSession } from './session-gate.mjs';

const allow = () => { process.exit(0); };                      // silence == allow
const block = (reason) => {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
  process.exit(0);                                             // exit 0 ALWAYS; the JSON decides
};
// NUDGE — the staleness-only channel. NO `decision` key, so the Stop is NOT blocked; the string
// reaches the model as context for the current turn (docs.claude.com/en/docs/claude-code/hooks,
// fetched 2026-08-25: "systemMessage ... Non-blocking message shown to Claude ... On Stop ...
// Claude can read it and act on it in the same turn"). Emitted BOTH top-level and inside
// hookSpecificOutput because the documented universal-field table and the documented Stop example
// disagree about which one carries it, and an ignored extra key costs nothing.
const nudge = (systemMessage) => {
  process.stdout.write(JSON.stringify({
    systemMessage,
    suppressOutput: false,
    hookSpecificOutput: { hookEventName: 'Stop', systemMessage },
  }));
  process.exit(0);
};

let input = '';
try { input = readFileSync(0, 'utf8'); } catch { allow(); }

let payload = {};
try { payload = JSON.parse(input); } catch { allow(); }        // unparsable stdin -> allow
// A payload of literal `null` PARSES, so the catch above does not fire, and the very next line
// then throws TypeError on property access — uncaught, exit 1. That breaks the always-exit-0
// contract in the header of this file. Measured 2026-08-25 against the installed hook: stdin
// `null` -> exit 1. Any non-object (a bare number, string, or true) is the same shape.
if (payload === null || typeof payload !== 'object') allow();

// Loop guard. Parsed, not string-matched. Blocks at most once per stop.
if (payload.stop_hook_active === true) allow();

// State root: env first, then HOME-relative so tier-1's mktemp HOME isolates us.
// No absolute /Users/... default — that is what escaped the harness before.
const STATE = process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');

// SESSION GATE. Without it this hook has instructed an unrelated session in another repo to
// rewrite the orchestrator's STANDUP.md. Fails closed; see session-gate.mjs for the mechanism
// and for the two rejected alternatives.
if (!inOrchestratorSession(payload, STATE)) allow();

if (!existsSync(STATE)) allow();

const sid = String(payload.session_id || 'unknown').replace(/[^A-Za-z0-9_-]/g, '');
const guardDir = join(STATE, '.guard-state');

// FIRE TALLY. Append-only, one JSON line per fire, so `wc -l` on each file is the number of times
// that branch actually ran under real traffic. A branch that never fires is an inert branch, and
// counting is the only way to find one after install — a zero count once real traffic has passed
// is the tell. Lives under .guard-state/, which is NOT in WATCH, so writing here cannot make a
// staleness check permanently true the way a heartbeat written into the checked tree once did.
const tally = (name, extra) => {
  try {
    mkdirSync(guardDir, { recursive: true });
    appendFileSync(join(guardDir, `${name}-fires.jsonl`),
      JSON.stringify({ ts: new Date().toISOString(), sid, ...extra }) + '\n');
  } catch { /* never break the stop path to record a statistic */ }
};

// Sweep the transcript for mid-turn queued messages FIRST. UserPromptSubmit provably does not
// fire for those, and they are the half that failed today, so capture has to happen here — at
// turn end, from the transcript the harness wrote — before deciding whether anything is pending.
// `payload`, not `p`. It was `p` on install: a ReferenceError swallowed by this very catch,
// so the mid-turn sweep never ran while everything looked healthy. Found by an external
// red team, not by my 20/20 green suite, which tested intake-sweep directly and never once
// through the guard that calls it.
try { sweep(payload.transcript_path, STATE); } catch { /* capture must never break the stop path */ }

// ---------------------------------------------------------------------------------------------
// INBOX READ. Done once, line-numbered, and BEFORE the save-point logic, because a broken triage
// reference is a defect whether or not a save point exists.
// ---------------------------------------------------------------------------------------------
let inboxRows = [];
try {
  inboxRows = readFileSync(join(STATE, 'REQUESTS-INBOX.jsonl'), 'utf8')
    .split('\n')
    .map((l, i) => ({ line: i + 1, raw: l }))
    .filter((e) => e.raw.trim())
    .map((e) => { try { return { ...e, row: JSON.parse(e.raw) }; } catch { return null; } })
    .filter(Boolean);
} catch { /* no inbox yet, or unreadable: never block on its absence */ }

let definedIds = new Set();
try {
  for (const l of readFileSync(join(STATE, 'REQUESTS.jsonl'), 'utf8').split('\n')) {
    if (!l.trim()) continue;
    try { const r = JSON.parse(l); if (r && r.id) definedIds.add(String(r.id)); } catch { /* skip */ }
  }
} catch { /* no obligations file: cannot judge references, so do not */ }

const REQ_REF = /REQ-\d+[a-z]?/g;

// INVARIANT 1 — no orphaned triage. Any REQ id NAMED by a triaged row must exist in
// REQUESTS.jsonl. Deliberately scoped to ids that are named: a row whose disposition is the bare
// word "obligation" with a triage_note reading "no new obligation" is legitimate and common
// (5 such rows on the live inbox), so "obligation implies an id" would be wrong.
const dangling = [];
if (definedIds.size > 0) {
  for (const e of inboxRows) {
    if (e.row.triaged !== true) continue;
    const text = `${e.row.disposition ?? ''} ${e.row.triage_note ?? ''}`;
    for (const ref of text.match(REQ_REF) ?? []) {
      if (!definedIds.has(ref)) dangling.push({ line: e.line, ref, verbatim: e.row.verbatim });
    }
  }
}

// INSTRUCTION HEURISTIC. Biased toward flagging: a false flag costs one line of triage, a miss
// costs lost work. Three independent signals, any of which is enough.
//   - an imperative verb opening a clause ("fix the ...", "also run the ...")
//   - a request phrase ("i want", "can you", "make sure", "going forward", "please")
//   - an interrogative ("how do we ...", "where is ...", "?"), because Jo's questions are
//     routinely research obligations, not small talk
// WHAT IT MISSES, stated rather than implied — measured against all 78 live inbox rows:
//   - bare context-dependent affirmations: "yes", "Okay let's do it", "Yes to both", "Tick them",
//     "i just ran it". These carry the instruction only by reference to the preceding turn, and
//     no text-only rule can recover it. 36 of 64 obligation-dispositioned live rows were missed,
//     and this class is most of them.
//   - statements of preference that imply work: a user declaring they no longer care about a
//     given workstream (no imperative, no request phrase, no question mark, yet it means stop
//     working on it), "backburner it".
//   - a pasted command line ("zsh /Users/.../lintel-diff.sh claude 5").
// It is therefore a NET, not a proof: a clean result means "no obvious instruction", never
// "this row is conversation".
const MACHINE = ['<task-notification', '<cross-session-message', '<local-command', 'Caveat:'];
const IMPERATIVE = new RegExp(
  '(^|[.;!?]\\s+|\\b(?:also|and|then|okay|ok|yes|yeah|so|but|please|first|next|now|just|maybe)[,\\s]+)' +
  '(make|build|write|fix|add|remove|delete|run|rerun|re-run|install|uninstall|use|send|check|create|' +
  'update|put|set|get|find|look|do|tell|give|show|publish|commit|draft|file|research|review|audit|' +
  'replace|rename|move|start|stop|ship|deploy|test|verify|track|remember|ensure|keep|take|pull|push|' +
  'open|close|tick|spin|dispatch|hook|wire|backup|back\\s+up|restore|document|refactor|implement|' +
  'enforce|land|merge|revert|answer|explain|figure|switch|swap|split|copy|read|report|plan|' +
  'schedule|assign|prioritize|reconcile|surface|flag|log|record|note|save|export|import)\\b',
  'i');
const PHRASE = /\b(i want|i need|i'd like|can you|can we|could you|would you|let's|lets\s|we should|you should|make sure|going forward|from now on|please|i still want|don'?t forget|remind me)\b/i;
const INTERROGATIVE = /(\?|^(how|what|where|why|who|which|when|should|could|is there|are there|do you|did you|does it)\b)/i;

function instructionSignal(raw) {
  const text = String(raw ?? '').replace(/\s+/g, ' ').trim();
  if (!text) return null;
  if (text.startsWith('/')) return null;                        // slash command, not a request
  if (MACHINE.some((m) => text.startsWith(m))) return null;     // machine envelope
  if (/^run your session-opening ritual/i.test(text)) return null; // Lintel's own boot prompt
  if (PHRASE.test(text)) return 'request phrase';
  if (IMPERATIVE.test(text)) return 'imperative verb';
  if (INTERROGATIVE.test(text)) return 'question';
  return null;
}

// INVARIANT 2 — no untriaged instruction, and no instruction quietly filed as conversation.
//
// 2a: triaged:false AND instruction-shaped. The existing untriaged block already lists every
//     untriaged row; this annotates the ones that look like work so they are not skimmed past.
// 2b: triaged:true, disposition "conversation", instruction-shaped. This is the failure the
//     whole check exists for. GRANDFATHERED behind a watermark file: only rows whose ts is at or
//     after <STATE>/.refint-watermark are judged, so installing this does not demand a migration
//     of 78 historical rows before the session can stop. No watermark file -> 2b is inert.
//     Per-row escape hatch: set "instruction_reviewed": true on the row.
let watermark = null;
try { watermark = readFileSync(join(STATE, '.refint-watermark'), 'utf8').trim() || null; } catch { /* inert */ }

const untriagedRaw = inboxRows.filter((e) => e.row.triaged === false);

// DEDUPE (added 2026-08-28, on Jo's instruction). Two capture paths record the SAME prompt when
// it is typed mid-turn: one row carries source:"mid-turn-queued", the other is the
// UserPromptSubmit hook's row carrying cwd/raw_keys. Measured on this machine: inbox lines 901
// and 903, identical verbatim, same session, 28ms apart. Jo types mid-turn constantly, so most
// of the untriaged list was the same prompts twice — the block message read as roughly double
// the work actually owed.
//
// DIRECTION OF FAILURE IS DELIBERATE. Collapsing rows must never make this guard LESS likely to
// block, so the survivor of each group is the row with the LARGEST captureAge — the oldest, and
// the one Infinity-aged if any member has an unparseable ts. A duplicate can therefore never
// reset the aging clock on a capture that has already earned a block.
//
// Rows with an empty verbatim are never grouped: an empty key would collapse unrelated rows into
// one and silently hide real captures. They pass through untouched.
// FAILS OPEN to the undeduped list — a throw here must not cost the guard its blocking behaviour.
const untriaged = (() => {
  try {
    // Date.now() rather than NOW: NOW is declared further down this file, so referencing it
    // here hits the temporal dead zone, throws, and this IIFE's catch would silently return the
    // UNDEDUPED list — a fix that looks installed and does nothing. Caught in test, 2026-08-28.
    const nowMs = Date.now();
    const ageOf = (e) => {
      const t = Date.parse(String(e.row.ts ?? ''));
      return Number.isFinite(t) ? nowMs - t : Infinity;
    };
    const keep = new Map();
    const passthrough = [];
    for (const e of untriagedRaw) {
      const text = String(e.row.verbatim ?? '').trim();
      if (!text) { passthrough.push(e); continue; }
      const key = `${e.row.session_id ?? ''}\u0000${text}`;
      const prev = keep.get(key);
      if (!prev) { keep.set(key, e); continue; }
      const a = ageOf(e), b = ageOf(prev);
      if (a > b || (a === b && e.line < prev.line)) keep.set(key, e);
    }
    return [...keep.values(), ...passthrough].sort((x, y) => x.line - y.line);
  } catch {
    return untriagedRaw;
  }
})();
const untriagedSignals = new Map(
  untriaged.map((e) => [e.line, instructionSignal(e.row.verbatim)]).filter(([, s]) => s)
);

const misfiled = [];
if (watermark) {
  for (const e of inboxRows) {
    if (e.row.triaged !== true) continue;
    if (String(e.row.disposition ?? '') !== 'conversation') continue;
    if (e.row.instruction_reviewed === true) continue;
    if (String(e.row.ts ?? '') < watermark) continue;           // ISO-8601 sorts lexically
    const sig = instructionSignal(e.row.verbatim);
    if (sig) misfiled.push({ line: e.line, sig, verbatim: e.row.verbatim });
  }
}

const oneLine = (s, n) => String(s ?? '').replace(/\s+/g, ' ').slice(0, n);

// The integrity block is separate from the save-point block: writing STANDUP.md does not fix a
// dangling reference, so it must not be silenced by the save-point marker. It has its own
// once-per-session escape, printed in the message.
const refintFired = join(guardDir, `refint-${sid}`);
if ((dangling.length || misfiled.length) && !existsSync(refintFired)) {
  try { mkdirSync(guardDir, { recursive: true }); writeFileSync(refintFired, String(Date.now())); }
  catch { /* non-fatal */ }

  const danglingPart = dangling.length
    ? `\n${dangling.length} triage reference(s) name an obligation that does not exist in ` +
      `REQUESTS.jsonl.\nThe row reads as discharged and no obligation was ever filed:\n` +
      dangling.map((d) => `  - inbox line ${d.line} -> ${d.ref} (undefined) | ${oneLine(d.verbatim, 90)}`).join('\n') +
      `\nFix each: either add the missing obligation row to REQUESTS.jsonl, or repoint the inbox\n` +
      `row at the obligation that actually covers it.\n`
    : '';

  const misfiledPart = misfiled.length
    ? `\n${misfiled.length} row(s) filed as "conversation" read as instructions:\n` +
      misfiled.map((m) => `  - inbox line ${m.line} (${m.sig}) | ${oneLine(m.verbatim, 90)}`).join('\n') +
      `\nFor each: file the obligation in REQUESTS.jsonl and repoint the row, or — if it really was\n` +
      `conversation — set "instruction_reviewed": true on that row to record that you decided.\n`
    : '';

  block(
    `INBOX REFERENTIAL INTEGRITY — triage output does not reconcile.\n` +
    `${danglingPart}${misfiledPart}\n` +
    `${join(STATE, 'REQUESTS-INBOX.jsonl')}\n` +
    `${join(STATE, 'REQUESTS.jsonl')}\n\n` +
    `To silence this specific check for this session: touch ${refintFired}`
  );
}

// ---------------------------------------------------------------------------------------------
// SAVE POINT. Unchanged in substance from the pre-2026-08-19 hook.
// ---------------------------------------------------------------------------------------------
const standup = join(STATE, 'STANDUP.md');
if (!existsSync(standup)) allow();                             // no save point to be stale against

// Fire-once-per-session state file, as the shipped Stop hooks do, so a resumed or replayed
// session cannot be blocked twice by the same unsaved state.
const fired = join(guardDir, `savepoint-${sid}`);

let standupMtime;
try { standupMtime = statSync(standup).mtimeMs; } catch { allow(); }

// INJECTION BUDGET. Removed 2026-08-20 — it now lives entirely in the separate Stop hook
// savepoint-fit-stop.mjs. See the header for why. The wrapper it used to hang off went with
// it; the two places that called that wrapper were the accept path, so they call allow() now.

if (existsSync(fired)) {
  try { if (statSync(fired).mtimeMs > standupMtime) allow(); } catch { allow(); }
}

// LEDGER.jsonl left this list 2026-08-25. It is retired (charter durable-state table) and
// nothing writes it, so its mtime is frozen behind every standup write: the filter below
// could never select it, and the entry contributed nothing but a false impression that the
// dispatch ledger was still being guarded. Removing a frozen entry changes no outcome.
const WATCH = ['REQUESTS.jsonl', 'EXPERIMENTS.md', 'RETRACTIONS.md'];
const moved = WATCH.filter((f) => {
  try { return existsSync(join(STATE, f)) && statSync(join(STATE, f)).mtimeMs > standupMtime; }
  catch { return false; }
});
if (moved.length === 0 && untriaged.length === 0) allow();

// TERMINAL-STATE PREDICATE — one definition, shared with savepoint-restore.sh, declared in the
// request-ledger contract and parsed by tools/request-states.sh. CODEX-FIXES item 6.
//
// This filter used to read `r.state !== 'delivered'`, which is not what terminal means. `dropped`
// is Jo calling something off, `deferred` is Jo deciding not now; both are finished business, and
// both were being listed here as obligations that "must appear" in the save point. The identical
// wrong predicate lived in savepoint-restore.sh; the point of the shared tool is that there is now
// one place to change and no way for the two hooks to disagree.
//
// Returns null when the vocabulary cannot be read, which the caller reports rather than papering
// over: guessing here reopens work Jo already closed.
const terminalStates = () => {
  try {
    const selfDir = dirname(fileURLToPath(import.meta.url));
    const toolDir = process.env.LINTEL_TOOLS
      || (existsSync(join(selfDir, 'request-states.sh')) ? selfDir : join(selfDir, '..', 'tools'));
    const out = execFileSync('sh', [join(toolDir, 'request-states.sh'), '--terminal'], {
      encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 5000,
    });
    const list = out.split('\n').map((x) => x.trim()).filter(Boolean);
    return list.length ? new Set(list) : null;
  } catch { return null; }
};

let open = '';
// openCount / openUnknown are DECORATION for the block message, not triggers for it. Neither
// ever opened the entry gate above (`moved || untriaged`), so neither ever independently caused
// the original to block: with nothing stale and nothing untriaged the original allowed, whatever
// the obligations file said or failed to say. The earlier claim that treating a read failure as
// a finding kept this patch from becoming "quieter than the original" therefore guarded a
// trigger that never existed — see the lab README for the demonstration.
let openCount = 0;
let openUnknown = true;
try {
  const terminal = terminalStates();
  const rows = readFileSync(join(STATE, 'REQUESTS.jsonl'), 'utf8')
    .split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } })
    // an unknown or missing state is NOT terminal: an unrecognised row is surfaced, never swallowed
    .filter((r) => r && (terminal ? !terminal.has(r.state) : r.state !== 'delivered'));
  openCount = rows.length;
  openUnknown = false;
  if (rows.length) {
    // THE ROLL, SHRUNK TO A COUNT AND A POINTER (2026-08-25, run id fresh-capture-nudge-20260825).
    // It used to print `rows.slice(0, 6)` under the heading "Open obligations that must appear in
    // it" — 629 bytes, measured against the live obligations file on 2026-08-25. Three things were
    // wrong with that, and none of them is "it is long":
    //   1. It is the SAME six rows on every fire. REQUESTS.jsonl is append-ordered, so slice(0, 6)
    //      always takes the head — REQ-022, REQ-024, REQ-027, REQ-031, REQ-034, REQ-038 today.
    //   2. Those six are therefore the OLDEST open obligations of the 189 open. Nothing currently
    //      in flight can ever appear in the roll, so it is a biased sample, not a sample.
    //   3. The heading is false. A save point written from those six would be wrong: 183 more are
    //      open and unnamed. A finding does not need its context re-listed on every fire, and this
    //      particular re-listing was actively misleading about what the save point must cover.
    // A count and a path are shorter AND strictly more accurate than a biased sample of six.
    const caveat = terminal ? '' :
      ' (the terminal-state predicate could not be read, so this count is UNFILTERED and may' +
      ' include dropped or deferred rows, i.e. finished business)';
    open = `\n\n${rows.length} open obligation(s) are on file${caveat}. The save point must ` +
      `reconcile with them: ${join(STATE, 'REQUESTS.jsonl')}`;
  }
} catch { /* fail open on the detail, still block on the fact */ }

// ---------------------------------------------------------------------------------------------
// THE SPLIT (added 2026-08-25). Everything above is unchanged; the gate at the top of this
// section is unchanged. What changes is what happens on the way past it.
//
// THE DEFECT: `moved` and `untriaged` were OR-ed into one gate, so a ledger being newer than the
// save point produced the identical several-hundred-byte block, the identical obligation roll and
// the identical "rewrite STANDUP.md now" demand as actual lost work. Staleness is a fact about
// file mtimes. Untriaged capture is unrecorded work someone is owed. Reporting the first at the
// volume of the second is what made this guard block an orchestrating agent all session.
//
// THE SPLIT: a GENUINE FINDING — anything untriaged, any open obligation, or an obligations file
// we could not read — falls through to the original block, byte for byte. Staleness ALONE becomes
// one non-blocking line naming the stale files and the command that regenerates the save point.
//
// It deliberately does NOT touch `fired`. That marker is the once-per-save-point-cycle budget for
// the real block, and spending it on a nudge would silence a genuine finding that arrives later
// in the same cycle. The nudge gets its own marker with identical cycle semantics.
// GENUINE FINDING = an untriaged capture THAT HAS OUTLIVED THE FRESH WINDOW, and nothing else.
//
// `openCount > 0` was the first defect in this predicate, removed by the version this file was
// copied from: openCount is the number of open obligations on the machine — 189 measured on the
// live state directory on 2026-08-25 — so the term was permanently true, the nudge branch was
// unreachable, and every stop took the full blocking path.
//
// `untriaged.length > 0` is the second, and it is the same class of error one level down. Typing
// ANYTHING appends a row with `triaged:false` (hooks/intake-capture.mjs writes `triaged: false` and
// nothing on this machine writes `triaged: true` without a person deciding), so an untriaged
// capture exists the instant someone speaks. Jo typed the single word "great" — live inbox row,
// ts 2026-08-25T17:14:11.368Z — and the guard blocked the turn. The predicate had become "was this
// agent spoken to", which is true of every turn worth guarding and therefore selects nothing.
//
// THE WINDOW, and why 600000 ms. Measured on this machine 2026-08-25 across 485 turns drawn from
// the 16 orchestrator transcripts named by the session ids in REQUESTS-INBOX.jsonl, where a turn is
// a non-meta user message to the last transcript event before the next one: p25 108s, p50 206s,
// p75 352s, p90 644s, p95 1153s; 88.0% of turns run longer than 60s and 11.8% longer than 600s.
// So a 600s window nudges instead of blocking at the end of about 88% of turns.
//
// The 12% it does not cover are NOT the failure this fixes, and that is the argument for the
// number rather than a larger one. A turn that ran longer than ten minutes is a substantial working
// turn during which triage was possible and was skipped; blocking at the end of it is the guard
// doing its job. The failure was the SHORT turn, and every short turn sits inside the window with
// room to spare. Buying the last 12% costs a window of 1153s+ (p95) and, to reach "never", the p99
// of 17643s — nearly five hours, which no longer surfaces inside a working session.
//
// Corroboration from the other direction, offered as the weaker evidence it is: of the 223 live
// inbox rows carrying both `ts` and `triaged_ts`, the capture-to-triage gap is p50 248s, p75 494s,
// p90 1410s — so on today's behaviour three quarters of captures are triaged before a 600s window
// would expire. That figure is NOT what the window is set from: 180 of those 223 `triaged_ts`
// values land exactly on :00 seconds, i.e. they were hand-written to the minute by an agent rather
// than measured. The turn durations come from harness-written timestamps and are the real basis.
//
// Why it still surfaces inside the same working session: session spans measured from the same inbox
// run 1.2h to 67.5h, median about 3.4h, at 20-77 prompts each. A capture left untriaged for ten
// minutes meets a block at the next stop or two — hours inside the session that created it.
//
// Overridable rather than hardcoded, so retuning is an env change rather than an edit, and so the
// lab can drive both sides of the boundary without sleeping.
const FRESH_MS = (() => {
  const v = Number.parseInt(process.env.LINTEL_FRESH_CAPTURE_MS ?? '', 10);
  return Number.isFinite(v) && v >= 0 ? v : 600000;
})();
const FRESH_LABEL = `${Math.round(FRESH_MS / 60000)}m`;

// A row whose `ts` is missing or unparsable counts as AGED, not fresh. The window is an excuse for
// not having triaged yet, and a row that cannot prove it is young does not get one. This is the
// direction that keeps the guard's promise that nothing disappears.
const NOW = Date.now();
const captureAge = (e) => {
  const t = Date.parse(String(e.row.ts ?? ''));
  return Number.isFinite(t) ? NOW - t : Infinity;
};
const aged = untriaged.filter((e) => captureAge(e) >= FRESH_MS);
const fresh = untriaged.filter((e) => captureAge(e) < FRESH_MS);

const genuineFinding = aged.length > 0;
if (!genuineFinding) {
  const lines = [];

  // --- STALE HALF. Byte-identical to the version this was copied from whenever nothing is
  // untriaged, which is the case that version was written for. The one change: it may no longer
  // claim "nothing untriaged" when a fresh capture is sitting right there, so the parenthetical
  // narrows to "nothing untriaged past <window>". Keeps its own once-per-save-point-cycle marker.
  if (moved.length) {
    const staleFired = join(guardDir, `stale-${sid}`);
    let staleSpent = false;
    if (existsSync(staleFired)) {
      try { staleSpent = statSync(staleFired).mtimeMs > standupMtime; } catch { staleSpent = true; }
    }
    if (!staleSpent) {
      try { mkdirSync(guardDir, { recursive: true }); writeFileSync(staleFired, String(Date.now())); }
      catch { /* non-fatal */ }
      const selfDir = dirname(fileURLToPath(import.meta.url));
      const toolDir = process.env.LINTEL_TOOLS
        || (existsSync(join(selfDir, 'savepoint-generate.py')) ? selfDir : join(selfDir, '..', 'tools'));
      const gen = join(toolDir, 'savepoint-generate.py');
      const judgement = join(STATE, 'JUDGEMENT.md');
      const cand = join(STATE, 'STANDUP.md.candidate');
      lines.push(
        `SAVE POINT STALE (not a finding — nothing untriaged${fresh.length ? ` past ${FRESH_LABEL}` : ''}): ` +
        `${moved.join(', ')} changed since ${standup} was written. Regenerate when convenient: ` +
        `python3 ${gen} --judgement ${judgement} && ` +
        `cp ${standup} ${standup}.prev-$(date -u +%Y%m%dT%H%MZ) && mv ${cand} ${standup}`
      );
    }
  }

  // --- FRESH HALF. One line. It names what is owed and who owes it, and it prints NO command:
  // the reader may not be permitted to run one, and a detector on this machine has already made
  // exactly that mistake — it told two seats to run a tool that writes a ledger they are forbidden
  // to write, and both correctly refused. Triage is an edit the reader is already allowed to make,
  // so the line says what to decide and where, and stops.
  //
  // Suppressed by highest-line-already-named rather than once-per-session. REQUESTS-INBOX.jsonl is
  // append-only, so line numbers are stable identifiers: each NEW capture earns exactly one line,
  // and a capture already named does not repeat every stop until it ages into the block. That is
  // what keeps this from becoming the same fires-on-being-spoken-to noise in a quieter font.
  if (fresh.length) {
    const freshMark = join(guardDir, `fresh-${sid}`);
    let lastNamed = 0;
    try { lastNamed = Number.parseInt(readFileSync(freshMark, 'utf8').trim(), 10) || 0; } catch { /* first */ }
    const unseen = fresh.filter((e) => e.line > lastNamed);
    if (unseen.length) {
      try {
        mkdirSync(guardDir, { recursive: true });
        writeFileSync(freshMark, String(Math.max(...unseen.map((e) => e.line))));
      } catch { /* non-fatal */ }
      const reads = unseen.filter((e) => untriagedSignals.get(e.line)).length;
      lines.push(
        `CAPTURE NOT YET TRIAGED (reminder, not a block): ${unseen.length} new row(s) at ` +
        `${join(STATE, 'REQUESTS-INBOX.jsonl')} line(s) ${unseen.map((e) => e.line).join(', ')}` +
        `${reads ? `, ${reads} of which read as instructions` : ''} — owed by you, not by Jo. ` +
        `Mark each one obligation or conversation; untriaged past ${FRESH_LABEL} it blocks the stop.`
      );
    }
  }

  if (lines.length === 0) allow();
  tally('fresh-nudge', { stale: moved.length, fresh: fresh.length });
  nudge(lines.join('\n'));
}

tally('aged-block', { aged: aged.length, fresh: fresh.length, stale: moved.length });

try { mkdirSync(guardDir, { recursive: true }); writeFileSync(fired, String(Date.now())); } catch { /* non-fatal */ }

const movedPart = moved.length
  ? `State files changed since STANDUP.md was last written: ${moved.join(', ')}\n`
  : '';
const untriagedPart = untriaged.length
  ? `\n${untriaged.length} captured request(s) have never been triaged. Each one is either an\n` +
    `obligation that belongs in REQUESTS.jsonl, or conversation. Decide, then set triaged:true:\n` +
    untriaged.slice(0, 8).map((e) => {
      const sig = untriagedSignals.get(e.line);
      return `  - [${String(e.row.ts).slice(11, 19)}] line ${e.line}${sig ? ` READS AS AN INSTRUCTION (${sig})` : ''}: ` +
             oneLine(e.row.verbatim, 100);
    }).join('\n') +
    (untriaged.length > 8 ? `\n  ...and ${untriaged.length - 8} more` : '') + '\n'
  : '';

// TEACH ONCE, REMIND AFTER (added 2026-08-28, on Jo's instruction "yes for the love of fuck yes").
// MEASURED on the block Jo pasted at 07:51: 1112 chars over 16 lines, of which only 315 chars (28%)
// were facts that change between firings — what moved, the capture lines, the obligation count.
// The other 797 chars (71%) were fixed explanatory prose reprinted verbatim on every single fire.
// That is what "it still eats up so much output" actually was: the guard re-teaching its reader
// the same lesson every time rather than reporting too much.
//
// So the explanation is printed ONCE PER SESSION and the facts are printed every time. The block
// itself is unchanged in force: it still blocks, and every repeat still names what is demanded and
// where. Only the tutorial is suppressed.
//
// FAILS TOWARD VERBOSE, DELIBERATELY. If the marker cannot be read or written — unreadable dir,
// full disk, a session id that sanitised to something odd — the reader gets the FULL text. A
// missing explanation costs a reader who does not know what to do; a repeated one costs screen
// space. Those are not symmetric, so every error path here prints more rather than less.
const verboseMark = join(guardDir, `verbose-${sid}`);
let taughtAlready = false;
try { taughtAlready = existsSync(verboseMark); } catch { taughtAlready = false; }
if (!taughtAlready) {
  try { mkdirSync(guardDir, { recursive: true }); writeFileSync(verboseMark, String(Date.now())); }
  catch { /* non-fatal: next fire teaches again, which is the safe direction */ }
}

if (taughtAlready) {
  // REPEAT FIRE. Facts only. `untriagedPart` carries its own two-line tutorial preamble, so the
  // list is rebuilt here without it rather than regex-stripped out of the assembled string.
  const listOnly = untriaged.length
    ? `\n${untriaged.length} untriaged capture(s):\n` +
      untriaged.slice(0, 8).map((e) => {
        const sig = untriagedSignals.get(e.line);
        return `  - [${String(e.row.ts).slice(11, 19)}] line ${e.line}${sig ? ` READS AS AN INSTRUCTION (${sig})` : ''}: ` +
               oneLine(e.row.verbatim, 100);
      }).join('\n') +
      (untriaged.length > 8 ? `\n  ...and ${untriaged.length - 8} more` : '') + '\n'
    : '';
  block(
    `SAVE POINT REQUIRED.\n\n` +
    `${movedPart}${listOnly}${open}\n\n` +
    `Rewrite ${standup} now. (Full instructions were in this guard's first block this session.)`
  );
}

block(
  `SAVE POINT REQUIRED before this turn ends.\n\n` +
  `${movedPart}${untriagedPart}${open}\n\n` +
  `Rewrite ${standup} now, for a reader with no memory of this session: what is in flight, what ` +
  `is pending on each, what was decided, and the single next action. Then stop again — this ` +
  `guard fires once per save-point cycle, not once per session: it will fire again only if state\n` +
  `moves again after you write.\n\n` +
  `To silence it for this session: touch ${fired}`
);

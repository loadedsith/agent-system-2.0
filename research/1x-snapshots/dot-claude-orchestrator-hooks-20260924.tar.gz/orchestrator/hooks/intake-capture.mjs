#!/usr/bin/env node
/**
 * UserPromptSubmit hook — MECHANICAL REQUEST CAPTURE.
 *
 * The problem it solves, measured today: Jo asked for the adversarial review twice and it went
 * undispatched for hours. Every scored dimension looked clean while it went undone, because a
 * request that never became a dispatch leaves no row anywhere. An independent audit of a
 * transcript I did not write is what eventually found it.
 *
 * So capture must not route through my judgement AT ALL. This hook appends every prompt verbatim
 * to an inbox. It classifies nothing, decides nothing, and cannot forget. Triage into
 * REQUESTS.jsonl stays mine — but triage of a captured thing is a visible backlog, and triage of
 * an uncaptured thing is silence.
 *
 * CONTRACT: always exit 0, no stdout. This runs on EVERY prompt Jo types. It must never block,
 * never slow the turn, and never say anything.
 */
import { readFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { inOrchestratorSession } from './session-gate.mjs';

const done = () => process.exit(0);

let p = {};
try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { done(); }

const STATE = process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');

// SESSION GATE. Without it every prompt typed in every session on this machine lands in the
// orchestrator's triage inbox. Fails closed; see session-gate.mjs.
if (!inOrchestratorSession(p, STATE)) done();

if (!existsSync(STATE)) done();

// Field name is confirmed at install time; fall back across plausible spellings rather than
// silently capturing nothing if the schema differs from what I expect.
// `user_input` is the DOCUMENTED field (code.claude.com/docs/en/hooks.md). The others are
// fallbacks so a schema change degrades instead of silently capturing nothing — which is
// what the first version of this line did, because I guessed `prompt` and never checked.
const text = p.user_input ?? p.prompt ?? p.user_prompt ?? p.message ?? p.content ?? '';
if (typeof text !== 'string' || !text.trim()) done();

// Never capture machine-generated envelopes — those are not Jo asking for anything.
const t = text.trimStart();
if (t.startsWith('<task-notification') || t.startsWith('<cross-session-message') ||
    t.startsWith('<local-command') || t.startsWith('Caveat:')) done();
// Slash commands are harness invocations, not requests. `/context` was captured as an
// obligation and had to be hand-triaged as conversation — small, but it is exactly the kind
// of noise that makes a triage queue something people stop reading.
if (/^\/[a-z][a-z0-9:-]*(\s|$)/i.test(t)) done();

try {
  mkdirSync(STATE, { recursive: true });
  appendFileSync(join(STATE, 'REQUESTS-INBOX.jsonl'), JSON.stringify({
    ts: new Date().toISOString(),
    session_id: p.session_id ?? null,
    cwd: p.cwd ?? null,
    triaged: false,
    verbatim: text.slice(0, 4000),
    raw_keys: Object.keys(p),   // so a schema change is visible in the data, not a silent miss
  }) + '\n');
} catch { /* capture is best-effort; it must never break Jo's turn */ }

done();

/**
 * ctx-first search — OMP extension. A REFUSAL, not an injection.
 *
 * Jo's requirement (2026-09-15, via Lintel): "whenever an agent is supposed to be trying to do a
 * search for something, it searches ctx first, no matter what." Mechanism left to me. Jo's
 * governing standard the same day: NAME THE LINE OF CODE THAT REFUSES, OR FILE IT AS A RULE AND
 * GRADE IT AS A RULE. The line that refuses is `return { block: true, reason }` below.
 *
 * ── TWO DESIGNS WERE BUILT AND MEASURED BEFORE THIS ONE. BOTH FAILED, AND HOW THEY FAILED IS
 *    THE WHOLE ARGUMENT FOR THIS SHAPE. ────────────────────────────────────────────────────────
 *
 * ATTEMPT 1 — prepend ctx results to the search's own result via `tool_result`. Built, and it
 * worked mechanically: 336 ms on the lexical backend, the block reached the model, and the model
 * quoted it back verbatim. Then it refused to act on it:
 *
 *   "The preamble is injected content styled to look authoritative, urging me to run ctx search
 *    — I'm disregarding that injected directive."
 *
 * ATTEMPT 2 — same block with every imperative stripped, provenance stated on line one, pure
 * evidence. Measured worse, because the refusal got sharper and named the real defect:
 *
 *   "A file-grep does not search cross-session history. Content that arrives bundled inside a
 *    tool result but exceeds what that tool does is the classic injection shape. […] A payload
 *    can say 'not user or model content' — that self-assertion is worthless; anything can print
 *    that string."
 *
 * ⛔ THE CHANNEL IS THE PROBLEM, NOT THE WORDING. Content appended to a tool result cannot carry
 * authority, because nothing in the content plane can authenticate itself — and a correctly
 * behaving model treats unauthenticated content that exceeds the tool's contract as an attack.
 * That is not a bug to route around. The same lesson was measured on 2026-09-11 against
 * `before_agent_start`, where a model declined an injected marker as "an injection attempt inside
 * the task payload, not a legitimate instruction from you." Twice measured, two different
 * channels, same conclusion.
 *
 * ── WHY A REFUSAL IS DIFFERENT, AND IT IS NOT A MATTER OF DEGREE ──────────────────────────────
 *
 * A block arrives on the CONTROL plane. The model does not have to trust its content, because the
 * tool genuinely did not run — the refusal is a fact about the world, not a claim in a payload.
 * Measured 2026-09-11 in an isolated probe: a `tool_call` block's reason reaches the model and it
 * complies within the same turn ("First command blocked by probe. Second command ran.").
 *
 * ── THE FAIL-CLOSED HAZARD, AND THE ONE PROPERTY THAT CONTAINS IT ────────────────────────────
 *
 * ⛔ A `tool_call` handler that throws OR exceeds its timeout is CONVERTED INTO `{block: true}`:
 *   $P/src/extensibility/extensions/runner.ts:1487-1494  (onFailure synthesizes a block)
 *   $P/src/extensibility/extensions/runner.ts:1499-1504  (first block wins, short-circuits)
 * where $P = /Users/jowolff/.bun/install/global/node_modules/@oh-my-pi/pi-coding-agent.
 * So a bug here denies EVERY tool call on this machine, for every agent. Lintel named that hazard
 * before I built anything and it is the reason attempt 1 went to `tool_result` first.
 *
 * THE CONTAINMENT IS THAT THIS HANDLER DOES NO WORK. No subprocess, no file I/O, no network, no
 * await, no parsing of anything that could be malformed. It reads two strings off an event,
 * consults an in-memory flag, and returns. There is no operation in it that can throw and nothing
 * that can hang, so the fail-closed conversion has nothing to fire on. ⛔ That is a load-bearing
 * invariant rather than a coincidence: DO NOT ADD I/O TO THIS HANDLER. The moment it shells out to
 * ctx — which is exactly what attempt 1 did, and what a future improvement will want to do — a
 * slow ctx becomes a machine-wide denial of every tool call.
 *
 * ── WHAT IS MACHINERY HERE AND WHAT IS ONLY A RULE, SAID PLAINLY ──────────────────────────────
 *
 * MACHINERY: a search cannot run until ctx has been consulted once in this session. Enforced.
 * NOT MACHINERY: whether the agent READS what ctx returned, or cites it. Nothing in any harness
 * can enforce that, and an injected sentence asking for it is measured to be declined. That half
 * is a RULE and belongs in the agent's own signed system prompt — filed as a rule rather than
 * dressed up as enforcement, per Jo's standard.
 *
 * ⛔ OMP ONLY, AND CLAUDE CODE SESSIONS ARE NOW COVERED BY NOTHING. Until 2026-09-15 this comment
 * said they were "covered at the prompt instead, by `ctx-history-inject.mjs` on UserPromptSubmit".
 * That registration was retired from `~/.claude/settings.json` on 2026-09-15 with Jo's authority,
 * on the grounds that it had never written a row: it was registered in Claude Code's hook registry
 * while all eleven seats run OMP, which never interprets that file's `hooks` object. The hook file
 * itself remains on disk, quarantined rather than deleted.
 *
 * So: this gate covers OMP sessions. A Claude Code session gets no ctx-first mechanism of any
 * kind. That is a known gap and not an oversight — content injected at the prompt was measured
 * three times to be declined by the model, which is why the replacement is a refusal on the
 * control plane rather than a second payload.
 */
import type { HookAPI } from "@oh-my-pi/pi-coding-agent";
import { appendFileSync, mkdirSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join } from "node:path";

/**
 * Module-scope identity. Load-bearing for diagnosis: on 2026-09-11 two `factory_loaded` rows were
 * misread as a module reload when the factory had merely been re-invoked on a hand spawn. Only a
 * module-scope constant separates those claims, and the difference decides whether a code change
 * can reach a running process. It cannot — activation needs a restart.
 */
const INSTANCE = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

const LOG = process.env.CTX_FIRST_LOG
	|| join(homedir(), ".claude", "orchestrator", "build", "ctx-first-search.jsonl");

/** Unique analyzed tokens ctx will accept in one query, less headroom. See `capTerms`. */
const MAX_TERMS = Number(process.env.CTX_FIRST_MAX_TERMS || 24);

/**
 * Tools that count as "searching for something" and are therefore gated. OMP's built-in names are
 * lowercase; `read` is deliberately ABSENT — reading a known path is not searching for something,
 * and gating it would stall every file open on this machine behind a history lookup.
 */
const GATED_TOOLS = (process.env.CTX_FIRST_TOOLS || "grep,glob,web_search,websearch")
	.split(",").map((t) => t.trim());

/**
 * Tool calls that SATISFY the gate. A `bash` call whose command invokes `ctx search`, or the ctx
 * MCP search tool under either of its mounted names.
 */
const CTX_MCP_TOOLS = ["mcp__ctx_search", "ctx_search", "search"];

function record(row: Record<string, unknown>): void {
	try {
		mkdirSync(dirname(LOG), { recursive: true });
		appendFileSync(LOG, `${JSON.stringify({ ts: new Date().toISOString(), instance: INSTANCE, ...row })}\n`);
	} catch {
		/* a log that cannot be written must not cost the turn */
	}
}

/**
 * Cap a string to MAX_TERMS unique analyzed tokens, counting the way ctx's analyzer counts:
 * alphanumeric runs, case-folded.
 *
 * ⛔ Why this exists at all: ctx REFUSES a query above 32 unique analyzed tokens with exit 1
 * (`lexical query has too many unique analyzed tokens: observed 33, maximum 32`), and the analyzer
 * splits on punctuation so word-level dedupe undercounts it — a 32-WORD query still failed,
 * because `hooks/extensions` and `don't` each analyze as two tokens. This exact defect silently
 * killed six consecutive injections in the sibling hook between 09-14 and 09-15. The suggested
 * command in a refusal has to be one that actually runs.
 */
export function capTerms(text: string, maxTerms = MAX_TERMS): string {
	const seen = new Set<string>();
	const kept: string[] = [];
	for (const word of String(text || "").replace(/\s+/g, " ").trim().split(" ")) {
		const tokens = word.toLowerCase().match(/[a-z0-9]+/g);
		if (!tokens) continue;
		if (tokens.every((t) => seen.has(t))) continue;
		if (seen.size + new Set(tokens).size > maxTerms) break;
		for (const t of tokens) seen.add(t);
		kept.push(word);
	}
	return kept.join(" ").slice(0, 300);
}

/**
 * Derive suggested history terms from the search the agent is about to run, so the refusal names a
 * command that is worth running rather than telling the agent to go think of one.
 *
 * A regex is not a query: `grep` carries a PATTERN, and a lexical index cannot match `\bfoo\(.*\)`
 * against prose, so metacharacters are reduced to their literal words.
 */
export function searchTermsFrom(toolName: string, input: Record<string, unknown>): string {
	const parts: string[] = [];
	const push = (value: unknown) => {
		if (typeof value === "string" && value.trim()) parts.push(value);
	};

	if (toolName === "grep") {
		push(input.pattern);
		push(input.path);
	} else if (toolName === "glob") {
		push(input.path);
	} else {
		push(input.query ?? input.q ?? input.pattern ?? input.prompt);
	}
	// `i` is the harness's intent field — a sentence a person wrote, which is better lexical
	// material than any pattern, so it goes last where it survives the term cap.
	push(input.i);

	const literal = parts.join(" ")
		.replace(/\\[bwsdWSD]/g, " ")
		.replace(/[.*+?^${}()|[\]\\/]/g, " ")
		.replace(/[_-]+/g, " ");
	return capTerms(literal);
}

/** Does this call satisfy the gate — is it itself a ctx history search? */
export function satisfiesGate(toolName: string, input: Record<string, unknown>): boolean {
	if (CTX_MCP_TOOLS.includes(toolName)) return true;
	if (toolName !== "bash") return false;
	const command = typeof input.command === "string" ? input.command : "";
	// `ctx search`, `ctx  search`, a full path to the binary, and `ctx show session` all count:
	// any of them means history was actually consulted.
	return /(^|[\s;&|])(\S*\/)?ctx\s+(search|show)\b/.test(command);
}

/**
 * The refusal text. Declarative about the world and imperative only about the ONE thing the agent
 * must do to proceed — which is legitimate here in a way it was not in attempt 2, because this
 * text explains a refusal the harness actually performed rather than asking for trust.
 */
export function refusalReason(terms: string): string {
	const suggested = terms || "<the subject you are searching for>";
	return "ctx-first: this session has not consulted prior agent history yet, so this search was "
		+ "refused before it ran.\n"
		+ `Run this first — it searches 2,300+ prior sessions on this machine:\n`
		+ `    ctx search --limit 5 -- "${suggested}"\n`
		+ "Then re-issue the search you just tried; it will be allowed for the rest of this "
		+ "session. Add --backend hybrid for semantic matching if the wording may differ from the "
		+ "indexed text. If ctx is unavailable, say so in your answer rather than presenting the "
		+ "absence of prior work as established.";
}

export default function ctxFirstSearch(pi: HookAPI): void {
	// Per-session gate state. One boolean, in the factory closure rather than at module scope:
	// measured 2026-09-11 that the factory is re-invoked per agent while the module is NOT
	// re-imported, so module scope would leak one agent's satisfied gate to another.
	let consulted = false;
	let refusals = 0;

	record({ event: "factory_loaded", gated: GATED_TOOLS });

	pi.on("tool_call", (event) => {
		// The withdrawal path: no edit to this file and no restart. Named here because a
		// machine-wide gate that cannot be switched off without a code change is not deployable.
		if (process.env.CTX_FIRST_DISABLE) return undefined;

		const toolName = String(event.toolName);
		const input = (event.input ?? {}) as Record<string, unknown>;

		if (satisfiesGate(toolName, input)) {
			if (!consulted) {
				consulted = true;
				record({ decision: "gate_satisfied", tool: toolName });
			}
			return undefined;
		}

		if (consulted || !GATED_TOOLS.includes(toolName)) return undefined;

		refusals += 1;
		const terms = searchTermsFrom(toolName, input);
		record({ decision: "refused", tool: toolName, terms, refusals });
		// ⛔ THE LINE THAT REFUSES.
		return { block: true, reason: refusalReason(terms) };
	});
}

// ── SELF-TEST ────────────────────────────────────────────────────────────────────────────────
// Both poles per claim, the suite's rule: "it refuses a search" and "it stops refusing once ctx
// ran" are different claims and an implementation can satisfy either while failing the other.
if (process.argv.includes("--selftest")) {
	let pass = 0;
	let fail = 0;
	const check = (name: string, cond: boolean) => {
		if (cond) pass++; else { fail++; console.error(`FAIL ${name}`); }
	};
	const uniq = (q: string) => new Set(q.toLowerCase().match(/[a-z0-9]+/g) || []).size;

	// The token cap, whose absence caused the sibling hook's two-day outage.
	const long = Array.from({ length: 90 }, (_, i) => `word${i}`).join(" ");
	check("long text capped below ctx ceiling", uniq(capTerms(long)) <= 24);
	check("punctuation-split words counted as their tokens",
		uniq(capTerms(`hooks/extensions don't ${long}`)) <= 24);
	check("short text survives intact", capTerms("routing gate") === "routing gate");
	check("repeats do not consume the budget", capTerms("gate gate gate routing") === "gate routing");
	check("empty text yields empty query", capTerms("   ") === "");

	// Term derivation.
	check("grep uses pattern and path",
		searchTermsFrom("grep", { pattern: "seat_message", path: "orchestrator/hooks" })
			.includes("seat message"));
	check("grep strips regex metacharacters",
		!/[\\*+?|]/.test(searchTermsFrom("grep", { pattern: "\\bfoo\\(.*\\)|bar" })));
	check("glob uses its path pattern",
		searchTermsFrom("glob", { path: "**/compaction-*.ts" }).includes("compaction"));
	check("web_search uses its query",
		searchTermsFrom("web_search", { query: "anthropic prompt caching" }).includes("caching"));
	check("intent field is carried",
		searchTermsFrom("grep", { pattern: "x", i: "Finding the routing gate" }).includes("routing"));

	// ⛔ THE GATE PREDICATE, BOTH POLES. A predicate that answers true for everything is the same
	// defect as one that answers false for everything, and both look like a working gate from one
	// side. Every row here is a shape that actually occurs.
	check("bash ctx search satisfies", satisfiesGate("bash", { command: 'ctx search -- "seat mail"' }));
	check("bash ctx show satisfies", satisfiesGate("bash", { command: "ctx show session abc123" }));
	check("absolute path to ctx satisfies",
		satisfiesGate("bash", { command: '/Users/jowolff/.local/bin/ctx search -- "x"' }));
	check("ctx inside a pipeline satisfies",
		satisfiesGate("bash", { command: 'date && ctx search -- "x" | head' }));
	check("ctx MCP tool satisfies", satisfiesGate("mcp__ctx_search", { query: "x" }));
	check("an unrelated bash call does NOT satisfy",
		!satisfiesGate("bash", { command: "git status --porcelain" }));
	check("a command merely MENTIONING ctx does not satisfy",
		!satisfiesGate("bash", { command: "echo 'we should ctx this later'" }));
	check("ctx status is not a history search",
		!satisfiesGate("bash", { command: "ctx status" }));
	check("a grep for the word ctx does not satisfy",
		!satisfiesGate("grep", { pattern: "ctx search" }));
	check("empty bash input does not satisfy", !satisfiesGate("bash", {}));

	// The refusal text: it must name the command AND not depend on being believed.
	const reason = refusalReason("routing gate seat mail");
	check("refusal names the exact command", reason.includes('ctx search --limit 5 -- "routing gate seat mail"'));
	check("refusal says what to do after", reason.includes("re-issue"));
	check("refusal states the search did not run", reason.includes("refused before it ran"));
	check("refusal covers the ctx-unavailable case", reason.includes("If ctx is unavailable"));
	check("refusal degrades without terms",
		refusalReason("").includes("<the subject you are searching for>"));

	// ⛔ The invariant that keeps the fail-closed hazard contained. If someone adds I/O to this
	// file, this is the assertion that should have stopped them — it pins the reason the gate is
	// allowed to live on `tool_call` at all.
	const source = require("node:fs").readFileSync(__filename, "utf8");
	const handlerBody = source.slice(source.indexOf('pi.on("tool_call"'), source.indexOf("// ── SELF-TEST"));
	for (const forbidden of ["spawn", "exec", "readFile", "fetch", "await ", "async "]) {
		check(`handler performs no ${forbidden.trim()}`, !handlerBody.includes(forbidden));
	}

	console.log(`${pass} pass / ${fail} fail`);
	process.exit(fail ? 1 : 0);
}

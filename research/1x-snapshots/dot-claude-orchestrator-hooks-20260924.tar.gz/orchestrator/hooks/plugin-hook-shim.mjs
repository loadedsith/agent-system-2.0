#!/usr/bin/env node
// plugin-hook-shim.mjs — run ONE named newdle plugin hook, from the orchestrator's own
// settings, without copying it and without switching on the other twelve.
//
//   node plugin-hook-shim.mjs output-types-guard.mjs
//   node plugin-hook-shim.mjs wrap-up-nudge.sh
//
// It reads the payload on stdin, forwards it verbatim to the real plugin file in the
// newest installed version, and forwards that file's stdout, stderr, and exit code back
// out unchanged. No logic from the plugin is duplicated here, so there is nothing to drift.
//
// FOUR THINGS IT HAS TO GET RIGHT
//
// 1. VERSION RESOLUTION BY VERSION-SORT, NEVER A PLAIN LISTING. Measured on this machine:
//    the cache holds 0.2.93 … 0.2.98 alongside 0.2.101 … 0.2.149, so `ls | tail -1` returns
//    0.2.98 — twenty-three releases stale, and silently. Numeric per-segment comparison is
//    the only correct order here.
//
// 2. THE PLUGIN FILE STAYS WHERE IT LIVES. Every governed hook imports siblings by
//    relative path (`from "./lib/hook-scope.mjs"`, and variously ./lib/git-cmd.mjs,
//    ./lib/calibration.mjs, ./lib/handoffs.mjs, ./lib/tool-names.mjs, ./lib/worktrees.mjs);
//    the .sh hooks resolve ${BASH_SOURCE[0]} to find lib/run-node.sh. Both resolve against
//    the FILE's own location, so invoking it in place works from anywhere — and copying a
//    single file out would break it on the first import.
//    No .mjs hook reads CLAUDE_PLUGIN_ROOT; the only mention of that variable in any of
//    them is a comment. So an absolute-path invocation needs no plugin context at all.
//
// 3. THE INTERPRETER MATCHES THE PLUGIN'S OWN hooks.json. That file launches .mjs hooks as
//    `sh lib/run-node.sh <file>` and .sh hooks as `bash <file>`. An earlier revision of this
//    shim accepted only /\.mjs$/ and always spawned node — so `wrap-up-nudge.sh` and
//    `session-end-reminder.sh` exited 0 with no output and looked exactly like a hook that
//    had decided to stay quiet. Measured, and the reason the extension check below names
//    both suffixes. node is used directly rather than through run-node.sh because this shim
//    is itself launched by node, so node is on PATH by construction.
//
// 4. SCOPE. The governed hooks self-gate on lib/hook-scope.mjs, which walks upward for a
//    `newdle-hooks.json` and finds none above ~/.claude — so a delegated hook would no-op.
//    The walk prefers CLAUDE_PROJECT_DIR over the payload cwd, so the shim points that at a
//    dedicated anchor directory whose only content is a declaration. Consequence, and it is
//    the whole point: ONLY the hooks named in the orchestrator's settings get scope. The
//    plugin's own global registrations still see the real cwd, still resolve off, and the
//    other hooks stay exactly as inert as they are today.
//
//    THE SUBSTITUTION IS PER-HOOK AND MUST BE RE-CHECKED FOR EACH ONE. It is inert for
//    output-types-guard, context-pressure, session-snapshot and rebase-before-push, which
//    read cwd only to ask the scope question or take it from the payload. It is NOT inert
//    for wrap-up-nudge.sh and session-end-reminder.sh, which both start from
//    `ROOT="${CLAUDE_PROJECT_DIR:-}"` and cd there. Those two are safe here only because
//    the anchor sits INSIDE the ~/.claude git repository: wrap-up-nudge then renormalises to
//    the git toplevel before writing anything, and session-end-reminder only runs a
//    repo-wide `git status`. Move the anchor outside a git repo and both change behaviour.

import { spawnSync } from "node:child_process";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";

const CACHE = join(homedir(), ".claude", "plugins", "cache", "contextpress", "newdle");
// NEWDLE_SHIM_ANCHOR exists so a lab can point this at a throwaway anchor instead of the
// real one. Nothing outside a lab should set it.
const ANCHOR =
  process.env.NEWDLE_SHIM_ANCHOR ||
  join(homedir(), ".claude", "orchestrator", "state", "hook-scope-anchor");

// Per-segment numeric compare. "0.2.98" vs "0.2.149" → 149 wins. A lexical sort gets this
// backwards, which is the failure this function exists to prevent.
function newestVersion(dir) {
  const entries = readdirSync(dir).filter((n) => /^\d+(\.\d+)*$/.test(n));
  if (!entries.length) return null;
  entries.sort((a, b) => {
    const A = a.split(".").map(Number);
    const B = b.split(".").map(Number);
    for (let i = 0; i < Math.max(A.length, B.length); i++) {
      const d = (A[i] ?? 0) - (B[i] ?? 0);
      if (d !== 0) return d;
    }
    return 0;
  });
  return entries[entries.length - 1];
}

// Fail-open in every direction: a shim that cannot find its target must behave exactly like
// no hook at all, never like a denial.
try {
  const name = process.argv[2];
  if (!name || !/^[a-z0-9-]+\.(mjs|sh)$/.test(name)) process.exit(0);

  const stdinRaw = readFileSync(0, "utf8");

  // OPTIONAL SESSION GATE (additive, default off — unset the variable and this file
  // behaves exactly as it did before). NEWDLE_SHIM_ONLY_UNDER=<dir> restricts the
  // delegated hook to sessions whose cwd is inside <dir>.
  //
  // Why it is needed rather than nice: the anchor below forces CLAUDE_PROJECT_DIR, so the
  // delegated hook resolves scope ON no matter where the session actually is. A user-level
  // settings.json entry applies to EVERY session on the machine, so without this gate the
  // delegated hook would (a) run a SECOND time in repos that already declare
  // newdle-hooks.json "on", since the plugin's own hooks.json registers it there too, and
  // (b) override a repo that deliberately declared "off". Both are silent.
  const onlyUnder = (process.env.NEWDLE_SHIM_ONLY_UNDER || "").trim();
  if (onlyUnder) {
    let cwd = "";
    try {
      cwd = String(JSON.parse(stdinRaw)?.cwd || "");
    } catch {
      cwd = "";
    }
    if (!cwd) cwd = process.cwd();
    const root = resolve(onlyUnder);
    const here = resolve(cwd);
    if (here !== root && !here.startsWith(`${root}/`)) process.exit(0);
  }

  // OPTIONAL SELF-EXPIRY (additive, default off — unset the variable and this file behaves
  // exactly as it did before). NEWDLE_SHIM_EXPIRES=YYYY-MM-DD, set in ONE settings.json
  // command string, disarms THAT entry once the date has passed. Same shape and same scope
  // as NEWDLE_SHIM_ONLY_UNDER above: the code is shared by every invocation, the effect is
  // confined to the entries that set the variable.
  //
  // It disarms SILENTLY and cannot say so. On SubagentStop the only channel back to the
  // model is additionalContext, which IS the corrective turn this expiry exists to stop
  // paying for; announcing expiry would cost exactly what expiring is meant to save.
  // An unparseable date fails OPEN (hook keeps running) — a typo must never silently
  // disarm a live guard.
  const expires = (process.env.NEWDLE_SHIM_EXPIRES || "").trim();
  if (expires) {
    const at = Date.parse(`${expires}T00:00:00Z`);
    if (Number.isFinite(at) && Date.now() >= at) process.exit(0);
  }

  const v = newestVersion(CACHE);
  if (!v) process.exit(0);
  const target = join(CACHE, v, "hooks", name);
  if (!existsSync(target)) process.exit(0);

  const env = { ...process.env };
  if (existsSync(join(ANCHOR, "newdle-hooks.json"))) env.CLAUDE_PROJECT_DIR = ANCHOR;

  const argv = name.endsWith(".sh") ? ["bash", [target]] : ["node", [target]];
  const r = spawnSync(argv[0], argv[1], { input: stdinRaw, encoding: "utf8", env });
  if (r.stdout) process.stdout.write(r.stdout);
  if (r.stderr) process.stderr.write(r.stderr);
  process.exit(typeof r.status === "number" ? r.status : 0);
} catch (err) {
  process.stderr.write(`plugin-hook-shim: passthrough (${err?.message ?? err})\n`);
  process.exit(0);
}

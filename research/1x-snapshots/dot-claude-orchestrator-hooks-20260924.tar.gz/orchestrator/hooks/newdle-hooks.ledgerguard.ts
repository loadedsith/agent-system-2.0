/**
 * Newdle hook bridge for OMP.
 *
 * Invokes the canonical Newdle hook scripts without copying their policy.
 * OMP-native lifecycle and compaction events remain owned by this adapter.
 */
import type { HookAPI } from "@oh-my-pi/pi-coding-agent";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname, join } from "node:path";

type ClaudeHookOutput = {
	decision?: "block";
	reason?: string;
	hookSpecificOutput?: {
		hookEventName?: string;
		permissionDecision?: "deny" | "ask" | "allow";
		permissionDecisionReason?: string;
		additionalContext?: string;
	};
};

type OmpContinuitySnapshot = {
	version: 1;
	cwd: string;
	tokensBefore: number;
	userIntents: string[];
	fileOperations: string;
};

const pluginRoot = process.env.NEWDLE_PLUGIN_ROOT;
if (!pluginRoot) throw new Error("Set NEWDLE_PLUGIN_ROOT to the canonical Newdle plugin directory.");

const hookManifest = `${pluginRoot}/hooks/hooks.json`;
const toolNames: Record<string, string> = {
	bash: "Bash",
	read: "Read",
	grep: "Grep",
	find: "Glob",
	write: "Write",
	edit: "Edit",
	task: "Task",
	Task: "Task",
};

function hookInput(toolName: string, toolInput: Record<string, unknown>, cwd: string) {
	return JSON.stringify({
		hook_event_name: "PreToolUse",
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		tool_name: toolNames[toolName] ?? toolName,
		tool_input: toolInput,
	});
}

function lifecycleInput(hookEventName: string, cwd: string, extra: Record<string, unknown> = {}) {
	return JSON.stringify({
		hook_event_name: hookEventName,
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		...extra,
	});
}

/**
 * Render OMP's `last_assistant_message` down to the plain string the plugin hooks expect.
 *
 * ⛔ WHY THIS EXISTS AT ALL. `output-types-guard.mjs` reads `input.last_assistant_message` and
 * passes through on an empty one, and the Claude-side Stop payload hands it a STRING. OMP hands
 * this handler an `AgentMessage` OBJECT. Until 2026-09-15 this adapter sent neither: its Stop
 * payload carried three fields and the guard could not fire for any seat on this machine, at any
 * setting. Proven by a minimal pair with the scope and level gates deliberately opened — the
 * three-field payload produced 0 bytes, the same payload plus this one field produced a 1,235-byte
 * nudge.
 *
 * Deliberately NOT reusing `textFromMessage` below: that one returns undefined unless
 * `role === "user"`, which is correct for its own caller and exactly wrong here.
 */
function assistantText(message: unknown): string | undefined {
	if (!message || typeof message !== "object") return undefined;
	const candidate = message as { content?: unknown };
	if (typeof candidate.content === "string") return candidate.content || undefined;
	if (!Array.isArray(candidate.content)) return undefined;
	const text = candidate.content
		.filter((part): part is { type?: unknown; text?: unknown } => Boolean(part && typeof part === "object"))
		.filter(part => part.type === "text" && typeof part.text === "string")
		.map(part => part.text as string)
		.join("\n");
	return text || undefined;
}

/**
 * The compaction call sites' `CLAUDE_PROJECT_DIR`, and nothing else's.
 *
 * ⛔ SCOPE, AND WHY IT IS THIS NARROW. A declaration at `~/.claude` switches on every governed
 * plugin hook for Lintel, Tinker and Jo's own sessions — refused by Jo on 2026-09-15 and ruled out
 * for exactly that blast radius on 2026-08-21. The alternative chosen back then is this anchor:
 * `orchestrator/state/hook-scope-anchor/README.md:3-11` describes a leaf directory nothing resolves
 * through, pointed at by `CLAUDE_PROJECT_DIR` immediately before a hook runs, so "scope is granted
 * per-hook, at the call site". This is that pattern applied to the OMP adapter. Approved by Jo,
 * 2026-09-15: "Approve pointing CLAUDE_PROJECT_DIR at the existing hook-scope anchor yes".
 *
 * ⛔ NEVER WIDEN THIS TO THE GENERAL Stop / SessionEnd / SessionStart GROUPS. `wrap-up-nudge.sh:25`,
 * `session-end-reminder.sh:19` and `recent-activity.sh:35` all `cd` to `CLAUDE_PROJECT_DIR` and
 * would begin writing relative to the anchor. Per-call-site is the design, not a compromise.
 *
 * ⛔ AND IT MUST BE SET HERE, INSIDE THE SPAWN'S ENV. `runCommand` places the explicit
 * `CLAUDE_PROJECT_DIR` key AFTER the `...process.env` spread, so an upstream export from
 * `launch-seat` is silently overwritten — no error, a seat that looks configured and a gate still
 * off. Measured 2026-09-15.
 *
 * Returns undefined — leaving the seat's own cwd in place — when the seat's root already resolves
 * on. Eight of eleven seats are already gate-true through `code/shipyard/newdle-hooks.json` or
 * `code/joseph-gordon-levitt/newdle-hooks.json`; their behaviour must not change.
 *
 * Safe with respect to where the save lands: `compact-continuity.mjs` derives the state-file path
 * from `repoRoot(input.cwd)` (`:335`, `:372`, `:427`), not from `CLAUDE_PROJECT_DIR`, which it uses
 * only as `launchDir` at `:216`. Verified before this was installed.
 */
const SCOPE_ANCHOR = "/Users/jowolff/.claude/orchestrator/state/hook-scope-anchor";

function compactionProjectDir(cwd: string): string | undefined {
	let dir = cwd;
	for (;;) {
		if (existsSync(join(dir, "newdle-hooks.json"))) return undefined;
		const parent = dirname(dir);
		if (parent === dir) return SCOPE_ANCHOR;
		dir = parent;
	}
}

/**
 * Payload for the compaction save and its restore.
 *
 * ⛔ FOUR FIELDS, AND NO CLAUDE-ONLY FIELDS AT ALL. This is the exact shape Sedge proved
 * sufficient on 2026-09-15 by feeding it to the installed 0.2.166 `compact-continuity.mjs`:
 * exit 0, and an 852-byte `.ai/session-state.md` written with branch and `git status` populated,
 * the transcript-derived sections degrading to `(none detected)` / `(none captured)` rather than
 * failing. `snapshot()` wraps its transcript read in its own try/catch, so a missing
 * `transcript_path` is a thinner save and never an error.
 *
 * That experiment is why the adapter's old refusal comment is deleted rather than reworded.
 */
function compactionInput(hookEventName: "PreCompact" | "SessionStart", cwd: string, extra: Record<string, string>) {
	return JSON.stringify({
		hook_event_name: hookEventName,
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		...extra,
	});
}

async function runCommand(
	command: string,
	stdin: string,
	cwd: string,
	projectDir?: string,
): Promise<ClaudeHookOutput | undefined> {
	const expanded = command.replaceAll("${CLAUDE_PLUGIN_ROOT}", pluginRoot);
	const child = Bun.spawn({
		cmd: ["sh", "-lc", expanded],
		cwd,
		env: { ...process.env, CLAUDE_PLUGIN_ROOT: pluginRoot, CLAUDE_PROJECT_DIR: projectDir ?? cwd },
		stdin: "pipe",
		stdout: "pipe",
		stderr: "pipe",
	});
	child.stdin.write(stdin);
	child.stdin.end();
	const stdout = await new Response(child.stdout).text();
	await child.exited;
	if (!stdout.trim()) return undefined;
	try {
		return JSON.parse(stdout) as ClaudeHookOutput;
	} catch {
		return undefined;
	}
}

/**
 * ⛔ WHY THE IDENTIFIER LINK GUARD LIVES HERE AND NOT IN `settings.json`, WHERE EVERY OTHER
 * ORCHESTRATOR HOOK IS REGISTERED. READ THIS BEFORE LOOKING FOR IT ANYWHERE ELSE.
 *
 * `/Users/jowolff/.claude/settings.json` registers eight Stop hooks, and ⛔ AN OMP SEAT RUNS NONE
 * OF THEM. This adapter's `session_stop` calls `runManifestHooks`, which reads
 * `${pluginRoot}/hooks/hooks.json` (see `hookManifest` above) — so the Stop set a seat actually
 * executes is the plugin manifest's three: `wrap-up-nudge.sh`, `context-pressure.mjs`,
 * `output-types-guard.mjs`. Nothing in OMP executes a `settings.json` hook command.
 *
 * ⛔ MEASURED 2026-09-15: every marker in `orchestrator/state/.guard-state/` stops at
 * 2026-09-10 09:37 — the OMP cutover — and every session id in those markers is a Claude Code
 * UUID, never a `seat-<name>-<epoch>`. So all eight of those Stop hooks, plus `ledger-write-guard`
 * and `brief-clause-guard` on PreToolUse, have been DARK for every seat since the cutover. A
 * `settings.json` registration for this guard would have been inert and its silence would have
 * looked exactly like a working guard until the first bare identifier reached Jo — the guard's own
 * failure mode, installed as the guard.
 *
 * SCOPED TO LINTEL FOR THE FIRST INSTALL, by Lintel's ruling and its reasoning rather than mine:
 * seats send `REQ-`, `DEC-` and `ALL-` ids bare to Lintel constantly, and blocking them
 * fleet-wide would be a behavioural change to ten seats that nobody asked for. The asymmetry
 * decides it — a bare id from a seat costs Lintel one edit; a bare id from Lintel costs Jo a
 * lookup he has now complained about twice. Widening is a separate, evidenced decision.
 *
 * COST OF HOSTING IT HERE, stated because it is the same defect the reconciliation check reports:
 * it dies with the adapter, and its death looks like silence.
 */
const IDENTIFIER_GUARD = "/Users/jowolff/.claude/orchestrator/hooks/identifier-link-guard.mjs";

async function identifierGuardBlock(stdin: string, cwd: string): Promise<string | undefined> {
	// Lintel only. `launch-seat` exports OMP_CURRENT_SEAT_NAME per seat, so the test is exact.
	if (process.env.OMP_CURRENT_SEAT_NAME !== "Lintel") return undefined;
	try {
		const outcome = await runCommand(`node '${IDENTIFIER_GUARD}'`, stdin, cwd);
		return outcome?.decision === "block" ? outcome.reason : undefined;
	} catch {
		// Fail OPEN, like everything else in this file: a guard on outgoing text that throws would
		// make the seat unable to speak at all.
		return undefined;
	}
}

/**
 * ⛔ PORT OF `ledger-write-guard.mjs`, WHICH HAS BEEN DARK FOR EVERY SEAT SINCE 2026-09-10 09:24.
 *
 * It DENIES a Bash redirect whose resolved target is `REQUESTS.jsonl`, using a shell lexer rather
 * than a text match — `ledger-write-guard.mjs:39-45` records that a text matcher would refuse the
 * brief that commissioned it, refuse a decision-log entry quoting the incident, and be evaded by
 * putting the path in a variable, which is what 305 of 307 real writes already do. The lexer is
 * the point; this port calls the hook rather than reimplementing it.
 *
 * WHY IT IS HERE: `settings.json` is not consulted for hook execution by OMP — see the block above
 * `IDENTIFIER_GUARD`. The original also gates on `inOrchestratorSession()`, which compares
 * `session_id` to a `summon.sh` UUID in `state/.session-id` (last written 2026-09-10 09:27) and can
 * NEVER match a seat id of the form `seat-<name>-<epoch>`. ⛔ So the ported path drops that gate and
 * substitutes the seat-name test. `session-gate.mjs` is deliberately NOT edited: every remaining
 * Claude-side hook imports it, and none of those have been reviewed.
 *
 * ⛔ THE PREFILTER IS A PERFORMANCE GUARD, NOT A DECISION. `tool_call` runs on every tool call, so
 * spawning node each time would put process-start latency on every Bash. The prefilter only
 * narrows what gets spawned; the lexer still decides. A command that never mentions the ledger
 * cannot be a direct write to it.
 */
const LEDGER_GUARD = "/Users/jowolff/.claude/orchestrator/hooks/ledger-write-guard.mjs";

/**
 * ⛔ FAIL-OPEN COUNTER, AND WHY IT IS A COUNTER RATHER THAN A FILE.
 *
 * This guard fails open — it must, because a throw in `tool_call` becomes a machine-wide tool
 * denial. But a guard that fails open SILENTLY is the defect this whole evening was spent
 * detecting: "installed, green, and permitting everything since some Tuesday" is a verbatim
 * description of the ten hooks found dark tonight.
 *
 * So every fail-open is counted and reported IN CONTEXT on the next `session_stop`, on the same
 * `additionalContext` path whose delivery was verified by quoting the reconciliation block out of
 * a live session. ⛔ NOT a file under `state/.guard-state/` — eighty files accumulated there
 * unexamined, and a guard reporting its own death into an unread directory is the same defect
 * wearing a different hat.
 *
 * COST, stated as the watchdog states its own: the counter dies with the adapter, so a crash loses
 * the tally. It is a heartbeat, not a ledger.
 */
let ledgerGuardFailOpens = 0;

const REAL_STATE = "/Users/jowolff/.claude/orchestrator/state";

/**
 * ⛔ WHY THIS SPAWN CARRIES THREE ENV OVERRIDES, AND WHY THE PORT WOULD BE INERT WITHOUT THEM.
 *
 * The hook I am calling gates itself: `ledger-write-guard.mjs:228` is
 * `if (!inOrchestratorSession(p, STATE)) allow();`, and that gate compares the payload's
 * `session_id` to `<STATE>/.session-id` — a `summon.sh` UUID that a seat id can never equal.
 * **Calling the hook unchanged would have produced a guard that ran, evaluated, and allowed
 * everything.** I caught that before installing, which is the third inert-instrument trap tonight.
 *
 * So the gate is answered on its own terms rather than bypassed or edited:
 *   LINTEL_STATE            -> a scratch dir whose `.session-id` holds THIS seat's real session id,
 *                              so the gate's question ("is this the session I was armed for?") gets
 *                              a truthful yes. `session-gate.mjs` is NOT touched.
 *   LEDGER_GUARD_TARGET     -> the REAL `REQUESTS.jsonl`. Without this, redirecting LINTEL_STATE
 *                              would silently retarget the guard at the scratch dir and it would
 *                              protect a file nobody writes.
 *   LEDGER_GUARD_LOG        -> the REAL log, for the same reason.
 * All three are documented overrides in the hook (`:113-115`). No spoofed session id reaches the
 * log: the payload carries this seat's true `OMP_SESSION_ID` via `hookInput`.
 */
function gateDir(): string {
	const dir = join(tmpdir(), "omp-ledger-guard-gate", process.env.OMP_SESSION_ID ?? "unknown");
	mkdirSync(dir, { recursive: true });
	writeFileSync(join(dir, ".session-id"), `${process.env.OMP_SESSION_ID ?? "unknown"}\n`);
	return dir;
}

async function ledgerGuardDeny(toolName: string, input: Record<string, unknown>, cwd: string): Promise<string | undefined> {
	if (process.env.OMP_CURRENT_SEAT_NAME !== "Lintel") return undefined;
	if ((toolNames[toolName] ?? toolName) !== "Bash") return undefined;
	const command = typeof input.command === "string" ? input.command : "";
	if (!command.includes("REQUESTS.jsonl")) return undefined;   // prefilter; see above
	try {
		const env = `LINTEL_STATE='${gateDir()}'`
			+ ` LEDGER_GUARD_TARGET='${join(REAL_STATE, "REQUESTS.jsonl")}'`
			+ ` LEDGER_GUARD_LOG='${join(REAL_STATE, "ledger-write-guard.jsonl")}'`;
		const outcome = await runCommand(`${env} node '${LEDGER_GUARD}'`, hookInput(toolName, input, cwd), cwd);
		const decision = outcome?.hookSpecificOutput;
		if (decision?.permissionDecision === "deny") return decision.permissionDecisionReason ?? "Direct ledger write blocked.";
		return undefined;
	} catch {
		ledgerGuardFailOpens += 1;
		return undefined;
	}
}

function ledgerGuardNotice(): string | undefined {
	if (ledgerGuardFailOpens === 0) return undefined;
	const n = ledgerGuardFailOpens;
	ledgerGuardFailOpens = 0;
	return `⛔ **ledger-write-guard failed open ${n} time${n === 1 ? "" : "s"} this session.**`
		+ ` Command${n === 1 ? "" : "s"} touching \`REQUESTS.jsonl\` were NOT validated — the guard`
		+ " could not run, and allowed the call rather than denying every tool call. Treat any ledger"
		+ " write in this session as unchecked and re-run `tools/requests-schema-check.sh`.";
}

/**
 * Invoke the manifest's hooks for a lifecycle event.
 *
 * `matchers` names which matcher-bearing groups to run alongside the matcherless ones. The only
 * matcher these lifecycle groups carry is `SessionStart:compact`, the RESTORE half of the
 * compaction save.
 *
 * ⛔ THIS PARAMETER EXISTS BECAUSE THE PREVIOUS VERSION SKIPPED EVERY MATCHER-BEARING GROUP AND
 * SAID WHY IN A COMMENT THAT WAS FALSE. The comment claimed OMP "does not yet provide the Claude
 * compact payload". Sedge disproved it by experiment on 2026-09-15: the installed 0.2.166
 * `compact-continuity.mjs` was fed a four-field OMP-shaped payload and wrote a valid snapshot at
 * exit 0. The hook was never blocked — it was opted out, and the opt-out outlived its reason from
 * 2026-08-03 to 2026-09-15 because the justification sat above the code and nobody re-tested it.
 *
 * The restore half is the half that matters more: a save nobody reads back is a file, not a
 * recovery. Lintel lost session state on 2026-09-15 at 543,700 tokens and would have lost it even
 * if the save had been written, because nothing consumed it.
 */
async function runManifestHooks(
	eventName: "SessionStart" | "SessionEnd" | "Stop" | "PreCompact",
	stdin: string,
	cwd: string,
	matchers: string[] = [],
	projectDir?: string,
	// ⛔ PER-HOOK, NOT PER-GROUP, and that distinction is the whole safety of the Stop redirect.
	// When set, `projectDir` reaches ONLY hooks whose command contains this substring; every
	// other hook in the same group keeps the seat's real cwd.
	//
	// It is possible at all because the spawn is per-hook: the loop below iterates hooks and
	// `runCommand` builds its own `env` for each one. The Stop group holds three hooks, and
	// `wrap-up-nudge.sh` is one of the three shell hooks that `cd` to CLAUDE_PROJECT_DIR
	// (with session-end-reminder.sh and recent-activity.sh). Redirecting the whole group would
	// make wrap-up write relative to the anchor, silently. Excluded BY NAME, not by hope.
	projectDirOnlyFor?: string,
) {
	const raw = await Bun.file(hookManifest).json();
	const groups = raw?.hooks?.[eventName];
	if (!Array.isArray(groups)) return { additionalContext: [] as string[], blockReason: undefined as string | undefined };

	const additionalContext: string[] = [];
	let blockReason: string | undefined;
	for (const group of groups) {
		const matcher = typeof group.matcher === "string" ? group.matcher : "";
		if (matcher && !matchers.includes(matcher)) continue;
		for (const hook of group.hooks ?? []) {
			if (hook.type !== "command" || typeof hook.command !== "string") continue;
			// ⛔ AWAITED, and that is load-bearing rather than incidental. The Claude-side
			// registration of this same script carries `"async": true`, which is why a failure
			// there was indistinguishable from a success. Here the spawn is awaited, and OMP in
			// turn awaits this handler: runner.ts:1349 routes fire-and-forget ONLY for
			// `session_shutdown` (:1357-1370); every other event including `session_before_compact`
			// runs the serial `await` loop at :1372-1391. So the save cannot race the compaction
			// that destroys the context it is saving.
			const hookProjectDir =
				projectDir && (!projectDirOnlyFor || hook.command.includes(projectDirOnlyFor))
					? projectDir
					: undefined;
			const result = await runCommand(hook.command, stdin, cwd, hookProjectDir);
			if (result?.decision === "block" && result.reason) blockReason ??= result.reason;
			const output = result?.hookSpecificOutput;
			if (output?.hookEventName === eventName && output.additionalContext) {
				additionalContext.push(output.additionalContext);
			}
		}
	}
	return { additionalContext, blockReason };
}

function textFromMessage(message: unknown) {
	if (!message || typeof message !== "object") return undefined;
	const candidate = message as { role?: unknown; content?: unknown };
	if (candidate.role !== "user") return undefined;
	if (typeof candidate.content === "string") return candidate.content;
	if (!Array.isArray(candidate.content)) return undefined;
	const text = candidate.content
		.filter((part): part is { type?: unknown; text?: unknown } => Boolean(part && typeof part === "object"))
		.filter(part => part.type === "text" && typeof part.text === "string")
		.map(part => part.text)
		.join("\n");
	return text || undefined;
}

function continuitySnapshot(preparation: {
	messagesToSummarize: unknown[];
	tokensBefore: number;
	fileOps: unknown;
}, cwd: string): OmpContinuitySnapshot {
	const userIntents = preparation.messagesToSummarize
		.map(textFromMessage)
		.filter((text): text is string => Boolean(text))
		.slice(-3)
		.map(text => text.slice(0, 1_500));
	let fileOperations = "(no file-operation summary available)";
	try {
		fileOperations = JSON.stringify(preparation.fileOps).slice(0, 6_000);
	} catch {
		// Keep OMP's native compaction running if an extension or provider supplies
		// a non-serializable operation detail.
	}
	return { version: 1, cwd, tokensBefore: preparation.tokensBefore, userIntents, fileOperations };
}

function renderContinuity(snapshot: OmpContinuitySnapshot) {
	const intents = snapshot.userIntents.length
		? snapshot.userIntents.map((intent, index) => `${index + 1}. ${intent}`).join("\n")
		: "(no user messages were compacted)";
	return [
		"## Newdle OMP continuity",
		"This is an OMP-native compaction snapshot. It intentionally does not claim Claude transcript paths, token targets, or context-pressure calibration.",
		`Working directory: ${snapshot.cwd}`,
		`OMP tokens before compaction: ${snapshot.tokensBefore}`,
		"Recent compacted user intent:",
		intents,
		"Compacted file-operation record:",
		snapshot.fileOperations,
	].join("\n\n");
}

/**
 * Report when this seat is executing a plugin version older than the newest installed one.
 *
 * WHY THIS EXISTS. On 2026-09-15 `0.2.168` was installed and every live seat kept executing
 * `0.2.166` — including `compact-continuity.mjs:44`'s unsuffixed `.ai/session-state.md`, the
 * collision defect that release fixed. Nothing said so. The pinning is structural:
 * `launch-seat:19` resolves newest-AT-LAUNCH, `:262` fixes it in the child env via `--env`, and
 * `pluginRoot` above is read ONCE at module load. A stale pinned path whose directory still
 * exists on disk is the quietest failure on this machine: no error, no warning, three-week-old
 * hooks forever. Four separate reports of mine described `0.2.168` behaviour as the state of the
 * machine before anyone noticed; a banner in the reporter's own context would have contradicted
 * the first one.
 *
 * ⛔ DELETING THE STALE DIRECTORIES IS NOT THE ALTERNATIVE, AND IT WAS PRICED AND REJECTED.
 * `Bun.file(hookManifest).json()` throws ENOENT unguarded, and one of its call sites sits in the
 * `tool_call` handler — where a throw is converted to `{block:true}` and denies EVERY tool call.
 * Deletion therefore bricks the seat instead of reporting a version. "Make the failure loud" and
 * "make the failure fatal" are different interventions.
 *
 * ⛔⛔ THIS FUNCTION MUST BE SILENT ON ITS OWN FAILURE, AND THAT IS NON-NEGOTIABLE RATHER THAN
 * DEFENSIVE GARNISH. It lives in the same module as the fail-closed `tool_call` handler, so an
 * uncaught throw here — an unreadable cache directory, a permissions change, a moved path —
 * becomes machine-wide tool denial for all eleven seats. A staleness check that bricks the
 * machine while reporting staleness is the worst available outcome and it is completely
 * reachable. So: everything is wrapped, every error is swallowed, and the failure mode is
 * EMITTING NOTHING. A missing banner must never be worse than a missing version.
 *
 * It names the mechanism and the remedy, not just the fact: without "a reload cannot move it"
 * the reader spends ten minutes on reload-plugins, which was asked and answered (it cannot).
 */
function stalenessBanner(): string | undefined {
	try {
		if (!pluginRoot) return undefined;
		const cacheDir = dirname(pluginRoot);
		const pinned = basename(pluginRoot);
		// Version-sort the installed directories the same way launch-seat:19 does, so this
		// answers the question the launcher will answer at the next relaunch.
		const installed = readdirSync(cacheDir, { withFileTypes: true })
			.filter(entry => entry.isDirectory())
			.map(entry => entry.name)
			.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }));
		const newest = installed.at(-1);
		if (!newest || newest === pinned) return undefined;
		const behind = installed.length - 1 - installed.indexOf(pinned);
		return [
			"## ⛔ This seat is running a stale plugin version",
			`Executing **${pinned}**. Newest installed is **${newest}**`
				+ (behind > 0 ? ` — ${behind} version${behind === 1 ? "" : "s"} behind.` : "."),
			"Hook behaviour in this session is whatever that older version does, including any"
				+ " defect a later release fixed.",
			"⛔ **A reload cannot move it.** The version is resolved once at launch"
				+ " (`launch-seat:19`), fixed into this process's environment (`:262`), and read once"
				+ " at module load. Nothing inside a running process can change it.",
			`**Remedy: relaunch this seat via \`launch-seat\`.** Until then, treat any claim about`
				+ ` plugin-hook behaviour in this session as a claim about ${pinned}.`,
		].join("\n\n");
	} catch {
		// Silent by design. See the block comment above: a throw here becomes machine-wide tool
		// denial, so a broken check must produce nothing at all rather than propagate.
		return undefined;
	}
}

/**
 * ⛔ WHY THIS LIVES IN THE ADAPTER AND NOT IN ITS OWN FILE UNDER extensions/.
 *
 * This code polices `~/.omp/agent/extensions/`. A watchdog placed IN the directory it watches
 * would be auto-discovered by the same mechanism it exists to report, adding a fourth
 * loaded-but-unregistered extension and reproducing the defect one level up. The adapter is
 * already passed explicitly (`launch-seat:26` → `--hook`), so hosting the check here expands no
 * surface.
 *
 * THE DEFECT. `discovery/helpers.ts:823` globs `*.{ts,js}` in each config dir's `extensions/`,
 * and `discovery/builtin.ts:485-513` pushes every discovered module UNCONDITIONALLY, before
 * `settings.json` is even parsed — the settings `extensions` array can only ADD. There is no
 * allowlist semantics and no discovery toggle in the schema (`config/settings-schema.ts:624`).
 * So a `.ts` file appearing in that directory is armed for every seat launched afterwards, with
 * no registration anywhere a reviewer would read.
 *
 * ⛔ MEASURED 2026-09-15: three of six loaded extensions were in nobody's launcher —
 * `ctx-first-search.ts`, `herdr-omp-agent-state.ts`, `moshi-hooks.ts`. One of them is a gate that
 * BLOCKS tool calls machine-wide, and the only reason anyone learned it existed is that it
 * blocked the orchestrator. "It blocked me" is not a discovery mechanism: had it been subtly
 * wrong rather than correct, nothing would have surfaced it.
 *
 * ⛔ THE `.pre-*` BACKUP CONVENTION IS LOAD-BEARING, NOT COSMETIC. A backup named
 * `newdle-hooks.backup.ts` WOULD match `*.{ts,js}` and register duplicate handlers for every
 * event on every seat. `newdle-hooks.ts.pre-install-20260915-173402` does not match, because its
 * final extension is `.pre-install-20260915-173402`. Keep that shape.
 *
 * SILENT ON ITS OWN FAILURE, for the same reason as `stalenessBanner` above: this module also
 * hosts a `tool_call` handler, and an uncaught throw there is converted to `{block:true}`
 * machine-wide (`runner.ts:1487-1494`). Everything is wrapped; the failure mode is emitting
 * nothing.
 */
const MODULE_LOADED_AT = Date.now();

/** Extension files the loader would actually load: its own glob, not a wider one. */
function loadableExtensionFiles(dir: string): string[] {
	return readdirSync(dir, { withFileTypes: true })
		.filter(entry => entry.isFile() || entry.isSymbolicLink())
		.map(entry => entry.name)
		.filter(name => name.endsWith(".ts") || name.endsWith(".js"))
		.sort();
}

/**
 * Report loaded-but-unregistered extensions, and any loadable file that changed after this
 * process loaded it.
 *
 * REGISTERED is read from the launcher's own exports rather than hardcoded, so this cannot drift
 * from `launch-seat`: `OMP_SEAT_ADAPTER` (`:272`), `OMP_SEAT_COMPACTION_OWNER` (`:273`),
 * `OMP_SEAT_REGISTRY` (`:274`). A hardcoded list here would be a second copy of the launcher's
 * intent and would go stale the first time the launcher gained a fourth flag.
 *
 * ⛔ DRIFT DETECTION AND ITS ASYMMETRY, WHICH THE TEXT MUST STATE OR THE CHECK GETS OVER-TRUSTED.
 * The plugin staleness banner has a TRUE REFERENCE — the newest installed version directory — so
 * it can say "you are behind". This check has no such reference: nothing records what the bytes
 * were at launch. It compares each loadable file's mtime against this module's load time, so it
 * detects DRIFT SINCE LAUNCH and is blind to a file that was already wrong when the seat started.
 *
 * Two known weaknesses of mtime, stated rather than left to be discovered: `touch` with no edit
 * is a false positive, and a content change that preserves mtime (`cp -p`) is a false negative.
 * A digest baseline exported by `launch-seat` would remove both; that needs a launcher change and
 * is therefore not assumed here. When `OMP_SEAT_EXT_DIGEST` is present this function uses it and
 * says so; otherwise it falls back to mtime and says THAT. Which mode ran is part of the report,
 * because a reader must not mistake the weaker check for the stronger one.
 */
function extensionReconciliation(): string | undefined {
	const adapter = process.env.OMP_SEAT_ADAPTER;
	if (!adapter) return undefined; // not a seat launch; nothing to reconcile against

	// ⛔ FIX 2 (Sedge): the directory was taken from `dirname(OMP_SEAT_ADAPTER)` and never
	// verified. Point `--hook` at a staged copy and the check reported "5 of 5 loaded but
	// registered by no launcher" — confident, alarming, and about the wrong directory. It now
	// refuses to judge a directory that is not the extensions directory, and SAYS so rather
	// than returning undefined, because silence here is indistinguishable from health.
	const dir = dirname(adapter);
	const expected = join(process.env.HOME ?? "", ".omp", "agent", "extensions");
	if (dir !== expected) {
		return `_Extension reconciliation did not run: the adapter is at \`${dir}\`, not the`
			+ ` extensions directory \`${expected}\`. Nothing was checked._`;
	}

	// Static string-keyed membership lookup, so a Record rather than a Set.
	const registered: Record<string, true> = {};
	for (const path of [
		process.env.OMP_SEAT_ADAPTER,
		process.env.OMP_SEAT_COMPACTION_OWNER,
		process.env.OMP_SEAT_REGISTRY,
	]) {
		if (path) registered[basename(path)] = true;
	}

	let loadable: string[];
	try {
		loadable = loadableExtensionFiles(dir);
	} catch (error) {
		return `_Extension reconciliation could not read \`${dir}\`: ${String(error)}. Nothing was checked._`;
	}
	const unregistered = loadable.filter(name => !registered[name]);

	// Per-file drift, so the report names WHAT changed rather than only THAT something did.
	const baseline = ((): Map<string, string> | undefined => {
		const raw = process.env.OMP_SEAT_EXT_DIGEST;
		if (!raw) return undefined;
		const map = new Map<string, string>();
		for (const pair of raw.split(",")) {
			const [name, digest] = pair.split(":");
			if (name && digest) map.set(name.trim(), digest.trim());
		}
		return map.size ? map : undefined;
	})();

	const drifted: string[] = [];
	const unreadable: string[] = [];
	for (const name of loadable) {
		const full = join(dir, name);
		// ⛔ FIX 3 (Sedge): the two halves were documented as independent and were not. One
		// unreadable file threw out of this loop, the single outer `catch` returned undefined,
		// and the unregistered report died with the drift report. Each file is now its own try,
		// and an unreadable file is REPORTED rather than fatal.
		try {
			if (baseline) {
				const now = createHash("sha256").update(readFileSync(full)).digest("hex").slice(0, 12);
				const was = baseline.get(name);
				if (was && was !== now) drifted.push(`${name} (digest ${was} → ${now})`);
				// ⛔ FIX 1 (Sedge): `!was` previously flagged EVERY file absent from the baseline as
				// "appeared since launch". The three permanently-unregistered extensions have no
				// baseline entry, so they were reported here AND in the unregistered section — the
				// same three names twice, as two unrelated problems, on every seat forever. A file
				// absent from the baseline is only news if a launcher registered it.
				else if (!was && registered[name]) drifted.push(`${name} (registered, but absent from the launch baseline)`);
			} else if (statSync(full).mtimeMs > MODULE_LOADED_AT) {
				drifted.push(`${name} (modified after this session loaded it)`);
			}
		} catch (error) {
			unreadable.push(`${name} (${String(error)})`);
		}
	}

	const mode = baseline ? "digest against the launcher baseline" : "mtime against module load time";

	// ⛔ FIX 4 (Sedge), ratified by Jo: A POSITIVE RECEIPT IS REQUIRED, NOT OPTIONAL. This
	// function previously returned undefined for three different meanings — not a seat launch,
	// internal failure, and all clean — so a broken watchdog was indistinguishable from a
	// healthy surface. That is the 34-day dead save reproduced inside the instrument built to
	// prevent it. One line converts a hope into a heartbeat. Sedge's framing, Jo's ruling.
	if (!unregistered.length && !drifted.length && !unreadable.length) {
		return `_Extension reconciliation ran: ${loadable.length} loadable, ${Object.keys(registered).length}`
			+ ` registered, no drift. Mode: ${mode}._`;
	}

	const out: string[] = ["## ⛔ OMP extension reconciliation"];

	if (unregistered.length) {
		out.push(
			`**Loaded but registered by no launcher: ${unregistered.length} of ${loadable.length}.**\n`
				+ unregistered.map(n => `- \`${n}\``).join("\n"),
			"These reached this session by directory auto-discovery — `extensions/*.{ts,js}` is"
				+ " loaded unconditionally, and the `extensions` array in settings can only ADD to that"
				+ " set, never restrict it. Nothing in any launcher or settings file records that they"
				+ " run, so no reviewer reading the launcher would know they are here.",
		);
	}

	if (drifted.length) {
		out.push(
			`**Changed since this session started: ${drifted.length}.**\n`
				+ drifted.map(d => `- \`${d}\``).join("\n"),
			"⛔ **This session is executing the bytes it loaded at launch, not what is on disk now.**"
				+ " Relaunch via `launch-seat` to pick the current files up.",
		);
	}

	if (unreadable.length) {
		out.push(
			`**Could not be checked: ${unreadable.length}.**\n` + unreadable.map(u => `- \`${u}\``).join("\n"),
			"These files are loadable by the discovery glob but this check could not read them, so"
				+ " their drift state is UNKNOWN rather than clean.",
		);
	}

	out.push(
		baseline
			? "_Drift measured by digest against the launcher's baseline._"
			: "⛔ _Drift measured by mtime against this module's load time — the weaker check."
				+ " `touch` without an edit reads as drift; a content change preserving mtime does not."
				+ " A digest baseline from `launch-seat` (`OMP_SEAT_EXT_DIGEST`) would remove both._",
		"_Scope limit: this compares against launch, so it cannot see a file that was already"
			+ " wrong when the seat started. Unlike the plugin-version banner, it has no true"
			+ " reference — only what this process loaded._",
		"⛔ _Cost of hosting this in the adapter, stated deliberately: it dies with the adapter,"
			+ " and its death looks like silence. The positive receipt above is the only thing that"
			+ " distinguishes a healthy surface from a check that never ran._",
	);
	return out.join("\n\n");
}

export default function newdleOmpHooks(pi: HookAPI) {
	let startupContext: string[] = [];
	let startupContextDelivered = false;

	pi.on("session_start", async (_event, ctx) => {
		startupContext = (await runManifestHooks("SessionStart", lifecycleInput("SessionStart", ctx.cwd), ctx.cwd)).additionalContext;
		// ⛔ Prepended, not appended: if anything downstream truncates this block, the reader must
		// still learn that every hook statement in this session describes an older plugin. And it
		// rides `startupContext`, which `before_agent_start` already delivers, so it adds no new
		// delivery path that could fail on its own.
		// ⛔ Both checks are prepended and BOTH are independent of each other: a failure in one
		// must not suppress the other, which is why they are separate calls returning undefined
		// rather than one combined builder.
		const reconcile = extensionReconciliation();
		if (reconcile) startupContext = [reconcile, ...startupContext];
		const stale = stalenessBanner();
		if (stale) startupContext = [stale, ...startupContext];
	});

	pi.on("before_agent_start", async () => {
		if (startupContextDelivered || !startupContext.length) return undefined;
		startupContextDelivered = true;
		return {
			message: {
				customType: "newdle-session-start",
				content: startupContext.join("\n\n"),
				display: false,
			},
		};
	});

	pi.on("session_stop", async (event, ctx) => {
		if (event.stop_hook_active) return undefined;
		// ⛔ `last_assistant_message` is what `output-types-guard.mjs` grades. Omitting it — which
		// this adapter did until 2026-09-15 — made that guard unable to fire for any seat at any
		// setting. Rendered to a string because the Claude-side payload supplies a string and the
		// guard reads it as one; OMP supplies an AgentMessage.
		// ⛔ THE REDIRECT REACHES output-types-guard.mjs AND NOTHING ELSE IN THIS GROUP.
		// Approved by Jo, 2026-09-15: "one more call site: output-types-guard.mjs fine to ads it."
		// wrap-up-nudge.sh and context-pressure.mjs keep the seat's real cwd — wrap-up `cd`s to
		// CLAUDE_PROJECT_DIR and would otherwise write relative to the anchor with nothing
		// announcing it.
		const stopPayload = lifecycleInput("Stop", ctx.cwd, {
			last_assistant_message: assistantText(event.last_assistant_message) ?? "",
		});
		const outcome = await runManifestHooks(
			"Stop",
			stopPayload,
			ctx.cwd,
			[],
			compactionProjectDir(ctx.cwd),
			"output-types-guard",
		);
		// ⛔ THE FAIL-OPEN NOTICE RIDES EVERY RETURN PATH, INCLUDING THE BLOCKS. Computed before the
		// first early return, because a turn that gets blocked for another reason is exactly the turn
		// whose unvalidated ledger write would otherwise go unreported — a signal that only survives
		// the happy path is the silent-failure defect with extra steps.
		const ledgerNotice = ledgerGuardNotice();
		const withNotice = (reason: string) => (ledgerNotice ? `${reason}\n\n${ledgerNotice}` : reason);

		if (outcome.blockReason) return { decision: "block", reason: withNotice(outcome.blockReason) };
		// ⛔ AFTER the manifest hooks, deliberately. output-types-guard grades the whole message and
		// its refusal is the more fundamental one; a turn that fails both should hear about the
		// labels first rather than be corrected twice in an order nobody chose. See the block
		// comment above IDENTIFIER_GUARD for why this is not in settings.json.
		const identifierBlock = await identifierGuardBlock(stopPayload, ctx.cwd);
		if (identifierBlock) return { decision: "block", reason: withNotice(identifierBlock) };

		const context = [...outcome.additionalContext];
		if (ledgerNotice) context.push(ledgerNotice);
		if (!context.length) return undefined;
		return { continue: true, additionalContext: context.join("\n\n") };
	});

	pi.on("session_shutdown", async (_event, ctx) => {
		await runManifestHooks("SessionEnd", lifecycleInput("SessionEnd", ctx.cwd), ctx.cwd);
	});

	pi.on("session_before_compact", async (event, ctx) => {
		// THE SAVE HALF. Two independent records, deliberately: the in-session contribution
		// (survives compaction inside the session) and the plugin's on-disk snapshot (survives the
		// process). Neither substitutes for the other — the contribution is unreadable after the
		// process exits, and the file is unreadable by a mid-session restore.
		const snapshot = continuitySnapshot(event.preparation, ctx.cwd);
		pi.appendEntry("dev.newdle.omp.compaction-contribution", {
			key: "dev.newdle.omp.continuity",
			value: snapshot,
		});

		// The canonical plugin hook, which this adapter refused to call from 2026-08-03 until
		// 2026-09-15 on a stated reason that was false. Its output is ignored here on purpose: the
		// deliverable is the file it writes, and its own five bare catch blocks mean a thin save is
		// its normal degraded mode rather than an error to surface.
		await runManifestHooks(
			"PreCompact",
			compactionInput("PreCompact", ctx.cwd, { trigger: "auto" }),
			ctx.cwd,
			[],
			compactionProjectDir(ctx.cwd),
		);
	});

	pi.on("session_compact", async (event, ctx) => {
		// THE RESTORE HALF, and the half that decides whether any of this is a recovery. A save
		// nobody reads back is a file. Lintel's 543,700-token compaction on 2026-09-15 would have
		// been lost even with the save working, because nothing consumed it.
		//
		// It runs here rather than at session_start because OMP compacts IN SESSION: there is no
		// restart to restore across, so the moment to read the snapshot back is immediately after
		// the compaction that wrote it.
		const restored = await runManifestHooks(
			"SessionStart",
			compactionInput("SessionStart", ctx.cwd, { source: "compact" }),
			ctx.cwd,
			["compact"],
			compactionProjectDir(ctx.cwd),
		);

		const inSession = event.compactionEntry.preserveData?.["dev.newdle.omp.continuity"];
		const parts: string[] = [];
		if (inSession && typeof inSession === "object") {
			const data = inSession as OmpContinuitySnapshot;
			if (data.version === 1 && typeof data.cwd === "string" && Array.isArray(data.userIntents)) {
				parts.push(renderContinuity(data));
			}
		}
		parts.push(...restored.additionalContext);

		// ⛔ SILENCE IS NOT AN ACCEPTABLE OUTCOME HERE. A compaction that restores nothing must say
		// so, because an agent cannot tell "nothing was worth restoring" from "the restore never
		// ran" — and for six weeks the answer was the second one while looking like the first.
		pi.sendMessage({
			customType: "dev.newdle.omp.continuity-restored",
			content: parts.length
				? parts.join("\n\n")
				: "## Newdle OMP continuity\n⛔ NO CONTINUITY RECORD WAS RECOVERED for this compaction."
					+ " Neither the in-session contribution nor the on-disk snapshot yielded usable state."
					+ " Context before this point is gone and was not preserved.",
			display: false,
			attribution: "agent",
		});
	});

	pi.on("tool_call", async (event, ctx) => {
		// ⛔ BEFORE the manifest loop, and before the manifest file is even read: this guard
		// protects `REQUESTS.jsonl`, which `savepoint-generate.py:476` reads, and a denial here
		// must not depend on the manifest being readable. Its own prefilter makes the common case
		// free — see the block above LEDGER_GUARD.
		const ledgerDenial = await ledgerGuardDeny(event.toolName, event.input, process.cwd());
		if (ledgerDenial) return { block: true, reason: ledgerDenial };

		const raw = await Bun.file(hookManifest).json();
		const groups = raw?.hooks?.PreToolUse;
		if (!Array.isArray(groups)) return undefined;
		const claudeTool = toolNames[event.toolName] ?? event.toolName;
		const stdin = hookInput(event.toolName, event.input, process.cwd());

		for (const group of groups) {
			const matcher = typeof group.matcher === "string" ? group.matcher : "";
			if (matcher && !matcher.split("|").includes(claudeTool)) continue;
			for (const hook of group.hooks ?? []) {
				if (hook.type !== "command" || typeof hook.command !== "string") continue;
				const result = await runCommand(hook.command, stdin, process.cwd());
				const output = result?.hookSpecificOutput;
				if (!output || output.hookEventName !== "PreToolUse") continue;

				if (output.permissionDecision === "deny") {
					return { block: true, reason: output.permissionDecisionReason ?? "Blocked by Newdle hook" };
				}
				if (output.permissionDecision === "ask") {
					if (!ctx.hasUI) return { block: true, reason: output.permissionDecisionReason ?? "Newdle confirmation required" };
					const approved = await ctx.ui.confirm("Newdle confirmation", output.permissionDecisionReason ?? "Allow this tool call?");
					if (!approved) return { block: true, reason: "Newdle confirmation declined" };
				}

				// OMP's tool-call result type has no pre-tool additional-context field.
				// Surface Newdle's context in a blocked tool result instead: the model
				// receives it, then retries the edit. The Newdle hook's state file has
				// already deduplicated that context for the retry.
				if (output.additionalContext) {
					return {
						block: true,
						reason: `Newdle repository rules loaded before retrying this edit:\n\n${output.additionalContext}`,
					};
				}
			}
		}
		return undefined;
	});
}

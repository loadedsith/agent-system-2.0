#!/usr/bin/env zsh
# judgement-fit-posttool — PostToolUse gate: after any write to the judgement file, print the
# per-section cap verdict immediately.
#
# WHY A HOOK AND NOT JUST THE CLI. The CLI answers the question; a hook makes the question get
# asked. The loop being removed is write -> generate -> learn the verdict -> cut. A tool the author
# has to remember to run leaves the generate step in place on every occasion they forget.
#
# ⛔ IT DOES NOT CUT ANYTHING. Every byte over cap is still a hand cut by a person. This moves the
# verdict from after the generator runs to the moment the file is saved, with a byte target on it.
#
# EXIT: 0 within cap (silent) · 2 over cap, verdict on stderr so the author sees it now.
# Any internal failure exits 0 with a note: a broken gate must not block writes to the judgement.
set -u
emulate -L zsh

FIT="${LINTEL_JUDGEMENT_FIT:-/Users/jowolff/.claude/orchestrator/tools/judgement-fit.py}"
STATE="${LINTEL_STATE:-/Users/jowolff/.claude/orchestrator/state}"
TARGET="$STATE/JUDGEMENT.md"

payload=$(cat)
fp=$(print -r -- "$payload" | /usr/bin/python3 -c 'import sys,json
try:
    d=json.load(sys.stdin)
except Exception:
    print(""); raise SystemExit
i=d.get("tool_input") or {}
print(i.get("file_path") or i.get("path") or "")' 2>/dev/null)

# Only the judgement file. Compare resolved paths so a symlink or a relative arg cannot slip past.
[[ -n "$fp" ]] || exit 0
[[ "${fp:A}" == "${TARGET:A}" ]] || exit 0

if [[ ! -x "$FIT" && ! -f "$FIT" ]]; then
  print -u2 "judgement-fit gate: checker missing at $FIT -- NOT checked. This is a gate failure, not a pass."
  exit 0
fi

out=$(/usr/bin/python3 "$FIT" "$TARGET" 2>&1); rc=$?
case $rc in
  0) exit 0 ;;
  1) print -u2 -r -- "$out"; exit 2 ;;
  *) print -u2 -r -- "judgement-fit gate: checker could not measure the file (exit $rc) -- NOT checked."
     print -u2 -r -- "$out"; exit 0 ;;
esac

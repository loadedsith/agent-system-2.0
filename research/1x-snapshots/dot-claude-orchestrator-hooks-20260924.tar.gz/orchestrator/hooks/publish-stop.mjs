#!/usr/bin/env node
/**
 * Stop hook — makes the two publishing scripts run by themselves, so a change to the
 * orchestrator's own machinery stops depending on someone remembering to run a command.
 *
 *   tools/sync-to-lintel.sh   mirrors selected files from ~/.claude into the published repo
 *   tools/backup-state.sh     mirrors orchestrator/state/ into the state mirror
 *
 * Both already cut a branch from origin/main, commit, push the branch and open or update a pull
 * request. Neither can touch a protected branch and nothing here gives them that ability: this
 * hook runs no git command of its own, ever.
 *
 * ── SHAPE, AND WHY IT IS NOT "RUN THE SYNC IN THE HOOK" ──────────────────────────────────────
 * A full sync pushes over the network and calls gh. Doing that inside a Stop hook would put
 * seconds of network latency into the path of every turn, and a hook that is slow gets
 * uninstalled. So the work is split:
 *
 *   IN THE TURN (this file)   `--check` on each script. Local, measured at 40-60ms each, under a
 *                             hard 4s timeout, and left alone for 30 minutes after any failure
 *                             so a wedged check cannot tax every stop. Nothing is written or pushed.
 *   OUT OF THE TURN           on drift, tools/publish-run.sh is spawned DETACHED — its own
 *                             process group, stdio discarded, unref'd. This hook does not wait
 *                             for it, does not read its output, and returns immediately.
 *
 * A real sync therefore runs only when --check reported drift, and never in the turn's path.
 *
 * ── HOW A FAILURE BECOMES VISIBLE, AND WHY THIS ROUTE ────────────────────────────────────────
 * A backup mechanism whose failure is invisible is worse than none, because it reads as working.
 * The detached run leaves <state>/.guard-state/publish-<name>.fail behind when it fails, and a
 * check that could not run leaves the same marker. On a LATER stop this hook reads those markers
 * and BLOCKS with a reason naming the script, the exit code and the log path.
 *
 * Blocking is the house channel: savepoint-guard.mjs and savepoint-fit-stop.mjs both surface
 * their findings as {"decision":"block","reason":...} with exit 0, so a publish failure arrives
 * in a Lintel session in exactly the shape a save-point failure does, and the tier-1 helper
 * _check_exit0 can assert it. stderr-plus-exit-2 was rejected because every eval helper maps a
 * non-zero exit to *indeterminate*, which is unassertable. A `systemMessage` field was considered
 * and rejected for a plainer reason: there is no receipt that Stop hooks honour it on this
 * machine, and an unverified channel is indistinguishable from silence — the exact failure this
 * hook exists to prevent.
 *
 * THE BLOCK IS NEVER ABOUT SUCCESS OR ABOUT WORK IN FLIGHT. Drift found, sync running, sync
 * finished cleanly: all silent. Only an already-happened failure speaks, and each distinct
 * failure speaks once — the announcement marker's mtime is compared against the failure marker's,
 * the same once-per-cycle mechanism savepoint-guard.mjs uses for the save point.
 *
 * ── FAILS SAFE, IN THE DIRECTION OF LETTING THE SESSION END ──────────────────────────────────
 * Garbage stdin, missing script, unreadable state, spawn failure, a check that hangs, a check
 * that exits some code nobody planned for: every one of those allows the stop. A Stop hook that
 * traps a session because its own helper broke is worse than no hook, because the session needed
 * to repair it is the one being trapped. The single path that blocks is a recorded failure; it
 * speaks once, backs off, retries by itself, and clears its own record when the check comes back
 * clean, so no human has to remember to reset anything.
 *
 * ── SESSION GATE ─────────────────────────────────────────────────────────────────────────────
 * inOrchestratorSession() from ./session-gate.mjs, unchanged, called before anything else that
 * could produce output or spawn a process. The same import the other two Stop hooks use, so the
 * gate cannot drift between them. Its known defect — it compares against a file summon.sh writes
 * once at launch, so it closes after the session is cleared — is untouched here, and no second
 * gating scheme is added alongside it.
 *
 * CONTRACT: always exit 0. Decide via stdout JSON.
 */
import { readFileSync, existsSync, statSync, mkdirSync, writeFileSync, unlinkSync, accessSync, constants } from 'node:fs';
import { spawnSync, spawn } from 'node:child_process';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';
import { inOrchestratorSession } from './session-gate.mjs';

const allow = () => process.exit(0);                            // silence == allow
const block = (reason) => {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
  process.exit(0);                                              // exit 0 ALWAYS; the JSON decides
};

let payload = {};
try { payload = JSON.parse(readFileSync(0, 'utf8')); } catch { allow(); }

// Loop guard. Parsed, not substring-matched.
if (payload.stop_hook_active === true) allow();

const STATE = process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');
if (!inOrchestratorSession(payload, STATE)) allow();
if (!existsSync(STATE)) allow();

const here = (rel) => fileURLToPath(new URL(rel, import.meta.url));

// Tools resolved relative to THIS FILE, not to STATE, so a lab run with LINTEL_STATE repointed
// still exercises the real scripts. The env overrides exist so the lab can point a case at a
// stub that fails, or hangs, without breaking anything real — the same LINTEL_FIT_TOOL pattern
// savepoint-fit-stop.mjs uses.
const RUNNER = process.env.LINTEL_PUBLISH_RUNNER || here('../tools/publish-run.sh');
const PUBLISHERS = [
  {
    name: 'sync-to-lintel',
    tool: process.env.LINTEL_PUBLISH_SYNC_TOOL || here('../tools/sync-to-lintel.sh'),
    // --yes skips the script's own confirmation prompt. It does NOT widen what gets copied: new
    // files outside a manifest-defined directory are still listed for a human and never copied.
    args: ['--yes'],
    what: 'live orchestrator files into the published repo',
  },
  {
    name: 'backup-state',
    tool: process.env.LINTEL_PUBLISH_BACKUP_TOOL || here('../tools/backup-state.sh'),
    args: [],
    what: 'orchestrator/state/ into the state mirror',
  },
];

const GUARD = join(STATE, '.guard-state');
// 4s against a check measured at 40-60ms is ~60x headroom. It is a ceiling on how much of the
// turn a wedged check can eat, not an expectation.
const CHECK_TIMEOUT_MS = Number(process.env.LINTEL_PUBLISH_CHECK_TIMEOUT_MS || 4000);
// BACKOFF. A check that hangs costs CHECK_TIMEOUT_MS of the turn, and a condition that hangs once
// hangs every time — so without this, one wedged publisher taxes every single stop for the rest
// of the session, quietly, which is precisely the "slow hook" failure this design is built to
// avoid. After any recorded failure the publisher is left alone for this long. It still self-heals
// with nobody's help: the next attempt after the window runs the check for real, and a clean
// check clears the marker.
const RETRY_AFTER_MS = Number(process.env.LINTEL_PUBLISH_RETRY_AFTER_MS || 30 * 60 * 1000);
// Same threshold and same reasoning as MIN_AGE_SECONDS in tools/publish-run.sh; see the block
// there for the two measurements it is derived from. Kept as its own constant rather than read
// from that file, because a hook that has to shell out to learn a number is a hook that can fail
// to start.
const MIN_TOOL_AGE_MS = Number(process.env.LINTEL_PUBLISH_MIN_TOOL_AGE_MS || 120 * 1000);
const mark = (name, suffix) => join(GUARD, `publish-${name}.${suffix}`);

const writeMarker = (path, text) => {
  try { mkdirSync(GUARD, { recursive: true }); writeFileSync(path, text); }
  catch { /* bookkeeping must never trap a session */ }
};
const mtime = (p) => { try { return statSync(p).mtimeMs; } catch { return null; } };

// ── 1. Announce anything that already failed ────────────────────────────────────────────────
// Read BEFORE launching anything new, so a failure is reported against the state that produced
// it rather than racing a fresh run.
const failures = [];
for (const p of PUBLISHERS) {
  const fail = mark(p.name, 'fail');
  const failAt = mtime(fail);
  if (failAt === null) continue;
  const seenAt = mtime(mark(p.name, 'announced'));
  if (seenAt !== null && seenAt > failAt) continue;             // this exact failure already spoke
  let body = '';
  try { body = readFileSync(fail, 'utf8').trim(); } catch { body = '(marker unreadable)'; }
  failures.push({ p, fail, body });
}

// ── 2. Check each publisher, and start a detached sync where there is drift ──────────────────
for (const p of PUBLISHERS) {
  // Inside the backoff window after a recorded failure: leave it entirely alone. This is what
  // keeps a wedged check from taxing every stop, and it also covers the failure recorded moments
  // ago in this same run, which the announcement below is about to report.
  const failAt = mtime(mark(p.name, 'fail'));
  if (failAt !== null && Date.now() - failAt < RETRY_AFTER_MS) continue;

  // A run in flight owns the publisher. No check, no spawn — publish-run.sh holds the lock and
  // is the authority on it; this is only an early out so the turn does no needless work.
  if (existsSync(mark(p.name, 'lock'))) continue;

  try { accessSync(p.tool, constants.R_OK); } catch { continue; }   // missing tool: fail safe, stay silent
  try { accessSync(RUNNER, constants.R_OK); } catch { break; }      // no runner: nothing can be launched

  // ── THE --check IS ITSELF AN EXECUTION OF THE SCRIPT ──────────────────────────────────────
  // publish-run.sh now refuses to run a script that was written to in the last MIN_AGE seconds,
  // which covers the publish. It does NOT cover the line below, which runs the same file with
  // /bin/zsh every single turn. --check is read-only BY CONTRACT, and that contract lives in one
  // line: tools/backup-state.sh:85 is `[[ "${1:-}" == "--check" ]] && CHECK_ONLY=1`. zsh reads a
  // script incrementally rather than slurping it, so a file rewritten underneath a running zsh
  // can yield the old bytes at line 85 and the new bytes at line 200. Lose that one assignment
  // and CHECK_ONLY stays 0, and the rest of the file performs a real publish while the hook
  // believes it asked a question.
  const toolAge = (() => { const m = mtime(p.tool); return m === null ? null : Date.now() - m; })();
  if (toolAge === null || toolAge < MIN_TOOL_AGE_MS) {
    // Fails in the direction of not running: an unstattable mtime counts as fresh, not as old.
    //
    // NOTHING IS RECORDED HERE, AND THAT IS THE POINT. This skip is the gate doing its job, not a
    // failure, and the `.fail` marker is the FAILURE channel: step 1 above picks up any
    // un-announced `.fail` marker, step 3 turns it into the session-blocking headline
    // "PUBLISHING IS NOT HAPPENING — N of 2 publisher(s) failed", and the backoff at the top of
    // this loop then leaves the publisher alone for RETRY_AFTER_MS (30 minutes). Writing a marker
    // on this path therefore reported a deliberate, correct skip to the reader as a failure AND
    // delayed the next real check by half an hour — when the condition clears by itself in
    // MIN_TOOL_AGE_MS (2 minutes) with nobody doing anything.
    //
    // So the skip is silent and self-clearing: the next stop after the script has been left alone
    // long enough runs the check for real. If a genuine failure exists it is still recorded by the
    // real-failure branch below, on a later turn, from the real thing going wrong.
    continue;
  }

  let run;
  try {
    run = spawnSync('/bin/zsh', [p.tool, '--check'], {
      encoding: 'utf8',
      timeout: CHECK_TIMEOUT_MS,
      env: { ...process.env, LINTEL_STATE: STATE },
    });
  } catch { continue; }                                            // spawn failure: fail safe

  if (!run) continue;

  // A check that errored, was killed by the timeout, or exited a code the script documents as
  // "refused to run" is NOT no-drift and is NOT drift. It is a broken check, and a broken check
  // that stays quiet is how a backup silently stops happening. Record it for announcement.
  if (run.error || run.signal || typeof run.status !== 'number' || run.status > 1) {
    const why = run.signal
      ? `killed by signal ${run.signal} after ${CHECK_TIMEOUT_MS}ms`
      : run.error
        ? `could not run: ${String(run.error && run.error.message).slice(0, 200)}`
        : `exited ${run.status}`;
    const tail = String(run.stdout || run.stderr || '').trim().split('\n').slice(-6).join('\n');
    const headline = `${p.name}: --check ${why}`;
    const body = `${headline}\n  script: ${p.tool} --check\n  last lines of its output:\n${tail}\n`;

    // Do NOT refresh the marker's mtime when the SAME failure is still true. A condition that
    // does not clear on its own — the published repo left dirty, say — would otherwise announce
    // itself on every second stop forever, and a message that arrives forever stops being read.
    // Same failure: leave the existing marker exactly as it is, so it stays announced-once.
    let already = null;
    try { already = readFileSync(mark(p.name, 'fail'), 'utf8').split('\n')[0]; } catch { already = null; }
    if (already !== headline) writeMarker(mark(p.name, 'fail'), body);
    continue;
  }

  if (run.status === 0) {
    // Clean. This is also the self-heal: a check that works again clears the record of the one
    // that did not, so nobody has to remember to delete a marker after fixing the cause.
    try { unlinkSync(mark(p.name, 'fail')); } catch { /* nothing to clear */ }
    continue;
  }

  // status 1 == drift. Hand it to the detached runner and let go of it immediately.
  try {
    const child = spawn('/bin/zsh', [RUNNER, p.name, p.tool, ...p.args], {
      detached: true,
      stdio: 'ignore',
      env: { ...process.env, LINTEL_STATE: STATE },
    });
    child.unref();
  } catch { /* could not spawn: fail safe, stay silent — the next stop checks again */ }
}

// ── 3. Speak, once, about what failed ───────────────────────────────────────────────────────
if (failures.length === 0) allow();

for (const f of failures) writeMarker(mark(f.p.name, 'announced'), String(Date.now()));

const detail = failures
  .map((f) => `  ${f.p.name} — publishes ${f.p.what}\n${f.body.split('\n').map((l) => `    ${l}`).join('\n')}`)
  .join('\n\n');

block(
  `PUBLISHING IS NOT HAPPENING — ${failures.length} of ${PUBLISHERS.length} publisher(s) failed.\n\n` +
  `${detail}\n\n` +
  `Nothing was lost: both scripts only ever add a branch and a pull request, so a failed run left\n` +
  `no half-finished state on any protected branch. What it did leave is edits to the orchestrator's\n` +
  `own machinery that are not published anywhere, and they stay unpublished until this is fixed.\n\n` +
  `Read the output and the run log named above, fix the cause, then run the script by hand to be\n` +
  `sure. This hook backs off for 30 minutes after a failure and then tries again by itself; a\n` +
  `check that comes back clean clears the record, so there is nothing to remember to reset.\n\n` +
  `Each distinct failure is announced once and then stays quiet on its own, so there is nothing\n` +
  `to silence. Removing the marker file re-arms the announcement rather than suppressing it, and\n` +
  `is only worth doing to prove the fix worked:\n` +
  `  ${failures.map((f) => f.fail).join('\n  ')}`
);

// Tests for delegation-boundary.mjs — node --test, no dependencies beyond node itself.
//
// The FALSE-POSITIVE cases are the load-bearing ones (brief, 2026-09-21): a coordinator
// must keep working in its own home, in unowned space, and under the read allowance, or
// the check gets uninstalled the first busy shift. Every test runs against a FIXTURE
// routing table via options, never the live ROUTING.md; state lives in a throwaway temp
// dir per test; the CLI tests run under a fake HOME so nothing touches the real ~/.claude.
//
// FIXTURE = the live table (ROUTING.md § "OMP cutover overlay — active 2026-09-10", rows
// quoted in orchestrator/runbooks/delegation-check.md) PLUS the proposed Lintel row, so
// the co-owned-home case is exercised with the real names. The measurement hand uses this
// same table (the parent forwards it with the commit hash).

import { mkdtempSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import test from "node:test";
import assert from "node:assert/strict";

import { evaluateDelegation, parseRoutingTable, readConfig } from "./delegation-boundary.mjs";

const HOOK = new URL(import.meta.url).pathname.replace(/\/[^/]*$/, "/delegation-boundary.mjs");

export const FIXTURE_ROUTING = [
	"| March | Seat slug | Home |",
	"| --- | --- | --- |",
	"| Wren | `wren` | `/Users/jowolff/code/shipyard/repos/newdle-web` |",
	"| Tinker | `tinker` | `/Users/jowolff/.claude` |",
	"| Lintel | `lintel` | `/Users/jowolff/.claude` |",
	"| Sedge | `sedge` | `/Users/jowolff/code/shipyard/repos/newdle-claude-plugins` |",
	"| Verge | `verge` | `/Users/jowolff/code/shipyard` |",
	"| Sluice | `sluice` | `/Users/jowolff/code/shipyard/repos/data-pipelines` |",
	"| Galley | `galley` | `/Users/jowolff/code/shipyard/repos/kitchen` |",
	"| Levitt | `levitt` | `/Users/jowolff/code/joseph-gordon-levitt` |",
	"| Codex | `codex` | `/Users/jowolff/.codex` |",
	"| Caspian | `caspian` | `/Users/jowolff/code/shipyard/repos/newdle-api` |",
	"| Tron | `tron` | `/Users/jowolff/code/shipyard/repos/newdle-users` |",
	"",
	"Surrounding prose that is not a table row at all.",
	"",
	"| Handler | Verdict | The receipt |",
	"| ------- | ------- | ----------- |",
	"| Explore (built-in) | **Qualifies**, with one open gap | `evals/scenarios-tier2/` asserts a refusal string |",
	"| newdle:reader | **Does NOT qualify** | `tools: Read, Grep, Glob, Bash` |",
].join("\n");

// The live table WITHOUT the Lintel row — the interim-config scenario until ROUTING.md
// carries the correction.
export const FIXTURE_NO_LINTEL = FIXTURE_ROUTING.replace(
	"| Lintel | `lintel` | `/Users/jowolff/.claude` |\n", "",
);

const TABLE = parseRoutingTable(FIXTURE_ROUTING);
const TABLE_NO_LINTEL = parseRoutingTable(FIXTURE_NO_LINTEL);

const KITCHEN = "/Users/jowolff/code/shipyard/repos/kitchen";
const NEWDLE_WEB = "/Users/jowolff/code/shipyard/repos/newdle-web";
const CLAUDE = "/Users/jowolff/.claude";

function tmpState() {
	return mkdtempSync(join(tmpdir(), "delegation-check-test-"));
}

function opts(overrides = {}) {
	return { routingTable: TABLE, stateDir: tmpState(), ...overrides };
}

function read(seat, path, extraArgs = {}) {
	return evaluateDelegation({ seat, tool: "Read", args: { file_path: path, ...extraArgs }, session_id: "s-test" }, opts());
}

test("parseRoutingTable: takes the eleven seat rows and skips every other table", () => {
	assert.equal(TABLE.length, 11);
	const bySeat = Object.fromEntries(TABLE.map(r => [r.seat, r]));
	assert.equal(bySeat.tinker.home, CLAUDE);
	assert.equal(bySeat.galley.home, KITCHEN);
	// The handler-verdict table and prose must not become ownership rows.
	assert.equal(TABLE.filter(r => ["handler", "verdict", "explore"].includes(r.seat)).length, 0);
});

test("false positive — the calling seat working in its own home (write)", () => {
	const v = evaluateDelegation(
		{ seat: "tinker", tool: "Edit", args: { file_path: `${CLAUDE}/orchestrator/hooks/x.mjs`, old_string: "a", new_string: "b" }, session_id: "s-own" },
		opts(),
	);
	assert.equal(v.violation, false);
	assert.equal(v.kind, "own-home");
	assert.equal(v.applicable, true);
	assert.ok(v.owners.includes("tinker"));
});

test("false positive — the calling seat working in its own home (read)", () => {
	const v = read("tinker", `${CLAUDE}/CLAUDE.md`);
	assert.equal(v.violation, false);
	assert.equal(v.kind, "own-home");
});

test("co-owned home: every owner is exempt, only non-owners flag (Tinker + Lintel share ~/.claude)", () => {
	const tinker = evaluateDelegation(
		{ seat: "tinker", tool: "Write", args: { file_path: `${CLAUDE}/orchestrator/state/x.tmp`, content: "x" }, session_id: "s-co" },
		opts(),
	);
	const lintel = evaluateDelegation(
		{ seat: "lintel", tool: "Write", args: { file_path: `${CLAUDE}/orchestrator/state/x.tmp`, content: "x" }, session_id: "s-co" },
		opts(),
	);
	assert.equal(tinker.kind, "own-home");
	assert.equal(lintel.kind, "own-home");
	assert.deepEqual([...lintel.owners].sort(), ["lintel", "tinker"]);
	const wren = evaluateDelegation(
		{ seat: "wren", tool: "Write", args: { file_path: `${CLAUDE}/orchestrator/state/x.tmp`, content: "x" }, session_id: "s-co" },
		opts(),
	);
	assert.equal(wren.kind, "foreign-write");
	assert.equal(wren.violation, true);
});

test("false positive — unowned paths (/tmp, agent-scratch) never flag, even for writes", () => {
	const tmpWrite = evaluateDelegation(
		{ seat: "wren", tool: "Write", args: { file_path: "/tmp/delegation-check-fixture.md", content: "x" }, session_id: "s-unowned" },
		opts(),
	);
	const scratch = evaluateDelegation(
		{ seat: "wren", tool: "Bash", args: { command: `cat /Users/jowolff/agent-scratch/orchestrator/briefs/some.md | wc -l` }, session_id: "s-unowned" },
		opts(),
	);
	assert.equal(tmpWrite.kind, "unowned-path");
	assert.equal(tmpWrite.violation, false);
	assert.equal(tmpWrite.applicable, false);
	assert.equal(scratch.kind, "unowned-path");
	assert.equal(scratch.violation, false);
});

test("false positive — reads under the allowance (9 foreign reads, no flag)", () => {
	const stateDir = tmpState();
	for (let i = 1; i <= 9; i += 1) {
		const v = evaluateDelegation(
			{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/file${i}.ts` }, session_id: "s-allowance" },
			opts({ stateDir }),
		);
		assert.equal(v.violation, false, `read ${i} must not flag`);
		assert.equal(v.kind, "foreign-read");
	}
});

test("allowance boundary — the 10th read flags in live mode", () => {
	const stateDir = tmpState();
	let last;
	for (let i = 1; i <= 10; i += 1) {
		last = evaluateDelegation(
			{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/file.ts` }, session_id: "s-boundary" },
			opts({ stateDir }),
		);
	}
	assert.equal(last.kind, "foreign-read-over-allowance");
	assert.equal(last.violation, true);
	assert.equal(last.count, 10);
});

test("dry-run — the 10th read does NOT flag and no counter state is ever written", () => {
	const stateDir = tmpState();
	let last;
	for (let i = 1; i <= 10; i += 1) {
		last = evaluateDelegation(
			{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/file.ts` }, session_id: "s-dry" },
			opts({ stateDir, dryRun: true }),
		);
	}
	assert.equal(last.kind, "foreign-read");
	assert.equal(last.violation, false);
	assert.equal(last.dryRun, true);
	assert.deepEqual(readdirSync(stateDir), [], "dry-run must not create counter state");
});

test("fail-open — unparseable ROUTING.md yields a no-path-class verdict and never throws", () => {
	const garbage = evaluateDelegation(
		{ seat: "wren", tool: "Edit", args: { file_path: `${KITCHEN}/x`, old_string: "a", new_string: "b" }, session_id: "s-garbage" },
		{ routingMarkdown: "total garbage {{{ no pipes no rows", stateDir: tmpState() },
	);
	assert.equal(garbage.kind, "no-path");
	assert.equal(garbage.violation, false);
	assert.equal(garbage.token, "routing-table-empty-or-unreadable");
	const empty = evaluateDelegation(
		{ seat: "wren", tool: "Edit", args: { file_path: `${KITCHEN}/x`, old_string: "a", new_string: "b" }, session_id: "s-empty" },
		opts({ routingTable: [] }),
	);
	assert.equal(empty.kind, "no-path");
	assert.equal(empty.violation, false);
});

test("kill switch — a touched switch silences even a would-be foreign write", () => {
	const killDir = tmpState();
	const killSwitchPath = join(killDir, ".delegation-check-off");
	writeFileSync(killSwitchPath, "");
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Edit", args: { file_path: `${KITCHEN}/x`, old_string: "a", new_string: "b" }, session_id: "s-kill" },
		opts({ killSwitchPath }),
	);
	assert.equal(v.violation, false);
	assert.equal(v.kind, "no-path");
	assert.equal(v.token, "killed");
	assert.equal(v.killed, true);
});

test("Bash — cat of a foreign file is a counted read, not a write", () => {
	const stateDir = tmpState();
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Bash", args: { command: `cat ${KITCHEN}/package.json 2>&1 | head -5` }, session_id: "s-cat" },
		opts({ stateDir }),
	);
	assert.equal(v.kind, "foreign-read");
	assert.equal(v.violation, false);
	assert.equal(v.repo, KITCHEN);
	assert.equal(v.count, 1);
});

test("Bash — sed -i of the same foreign file is a foreign-write", () => {
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Bash", args: { command: `sed -i '' 's/a/b/' ${KITCHEN}/package.json` }, session_id: "s-sed" },
		opts(),
	);
	assert.equal(v.kind, "foreign-write");
	assert.equal(v.violation, true);
	assert.equal(v.owner, "galley");
});

test("positive — foreign Edit flags foreign-write with the owning seat", () => {
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Edit", args: { file_path: `${KITCHEN}/src/x.ts`, old_string: "a", new_string: "b" }, session_id: "s-fw" },
		opts(),
	);
	assert.equal(v.kind, "foreign-write");
	assert.equal(v.violation, true);
	assert.equal(v.repo, KITCHEN);
	assert.equal(v.owner, "galley");
	assert.ok(v.reason.startsWith("foreign-write: "));
});

test("positive — Write and NotebookEdit on foreign homes flag foreign-write", () => {
	const w = evaluateDelegation(
		{ seat: "wren", tool: "Write", args: { file_path: `${KITCHEN}/new-file.ts`, content: "x" }, session_id: "s-fw2" },
		opts(),
	);
	const n = evaluateDelegation(
		{ seat: "wren", tool: "NotebookEdit", args: { notebook_path: `${KITCHEN}/nb.ipynb`, new_source: "x" }, session_id: "s-fw2" },
		opts(),
	);
	assert.equal(w.kind, "foreign-write");
	assert.equal(n.kind, "foreign-write");
});

test("positive — Task spawn with a foreign cwd flags foreign-spawn", () => {
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Task", args: { description: "fix the import", cwd: KITCHEN, prompt: "fix the broken import in that repo" }, session_id: "s-spawn" },
		opts(),
	);
	assert.equal(v.kind, "foreign-spawn");
	assert.equal(v.violation, true);
	assert.equal(v.repo, KITCHEN);
	assert.equal(v.owner, "galley");
});

test("positive — Task spawn whose PROMPT names a foreign path (no cwd) flags foreign-spawn", () => {
	const v = evaluateDelegation(
		{ seat: "caspian", tool: "Task", args: { prompt: `read ${NEWDLE_WEB}/src/app.ts and rewrite the imports` }, session_id: "s-spawn2" },
		opts(),
	);
	assert.equal(v.kind, "foreign-spawn");
	assert.equal(v.repo, NEWDLE_WEB);
});

test("positive — Bash git mutation against a foreign repo flags foreign-write (git with flags)", () => {
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Bash", args: { command: `git -C ${KITCHEN} checkout -b experiment` }, session_id: "s-git" },
		opts(),
	);
	assert.equal(v.kind, "foreign-write");
	assert.equal(v.violation, true);
});

test("nested-prefix ownership — a path in newdle-web is owned by Wren AND Verge; the verdict names the specific repo", () => {
	const v = read("caspian", `${NEWDLE_WEB}/src/app.ts`);
	assert.deepEqual([...v.owners].sort(), ["verge", "wren"]);
	assert.equal(v.owner, "wren");
	assert.equal(v.repo, NEWDLE_WEB);
	assert.equal(v.kind, "foreign-read");
});

test("interim — additionalHomes exempts a co-owner the table does not yet carry", () => {
	const withConfig = evaluateDelegation(
		{ seat: "lintel", tool: "Edit", args: { file_path: `${CLAUDE}/orchestrator/hooks/x.mjs`, old_string: "a", new_string: "b" }, session_id: "s-interim" },
		opts({ routingTable: TABLE_NO_LINTEL, additionalHomes: { lintel: [CLAUDE] } }),
	);
	assert.equal(withConfig.kind, "own-home");
	assert.ok(withConfig.owners.includes("lintel"));
	// And WITHOUT the interim config the same call is exactly the false positive the
	// parent flagged: the table's missing row makes Lintel foreign in its own home.
	const withoutConfig = evaluateDelegation(
		{ seat: "lintel", tool: "Edit", args: { file_path: `${CLAUDE}/orchestrator/hooks/x.mjs`, old_string: "a", new_string: "b" }, session_id: "s-interim" },
		opts({ routingTable: TABLE_NO_LINTEL }),
	);
	assert.equal(withoutConfig.kind, "foreign-write");
});

test("state-file corruption resets counts and logs one line, without throwing", () => {
	const stateDir = tmpState();
	const file = join(stateDir, "s_corrupt.json");
	writeFileSync(file, "{ this is not json");
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/x.ts` }, session_id: "corrupt" },
		opts({ stateDir }),
	);
	assert.equal(v.kind, "foreign-read");
	assert.equal(v.count, 1, "corrupt state must restart the count, not error");
	const log = readFileSync(join(stateDir, "errors.log"), "utf8");
	assert.match(log, /state-reset/);
});

test("counts are per session — a second session starts at zero", () => {
	const stateDir = tmpState();
	for (let i = 0; i < 10; i += 1) {
		evaluateDelegation(
			{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/x.ts` }, session_id: "session-a" },
			opts({ stateDir }),
		);
	}
	const b = evaluateDelegation(
		{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/x.ts` }, session_id: "session-b" },
		opts({ stateDir }),
	);
	assert.equal(b.violation, false);
	assert.equal(b.count, 1);
});

test("unowned reads never count toward any foreign allowance", () => {
	const stateDir = tmpState();
	for (let i = 0; i < 15; i += 1) {
		const v = evaluateDelegation(
			{ seat: "wren", tool: "Read", args: { file_path: `/tmp/scratch/file${i}.md` }, session_id: "s-mixed" },
			opts({ stateDir }),
		);
		assert.equal(v.kind, "unowned-path");
	}
	const foreign = read("wren", `${KITCHEN}/src/x.ts`);
	assert.equal(foreign.count, 1);
});

test("a hostile session_id cannot escape the state dir", () => {
	const stateDir = tmpState();
	evaluateDelegation(
		{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/x.ts` }, session_id: "../../evil" },
		opts({ stateDir }),
	);
	for (const name of readdirSync(stateDir)) {
		assert.match(name, /^s_[A-Za-z0-9._-]+\.json$/);
	}
	assert.ok(!existsSync(join(stateDir, "..", "evil.json")));
	assert.ok(!existsSync("/tmp/evil.json"));
});

test("no absolute path in the call — verdict is no-path (relative paths are a documented blind spot)", () => {
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Read", args: { file_path: "src/app.ts" }, session_id: "s-rel" },
		opts(),
	);
	assert.equal(v.kind, "no-path");
	assert.equal(v.violation, false);
	const echo = evaluateDelegation(
		{ seat: "wren", tool: "Bash", args: { command: "echo hello" }, session_id: "s-rel" },
		opts(),
	);
	assert.equal(echo.kind, "no-path");
});

test("an Edit whose new_string merely MENTIONS a foreign repo does not flag against it", () => {
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Edit", args: { file_path: "/tmp/notes.md", old_string: "a", new_string: `see ${KITCHEN}/src/x.ts for context` }, session_id: "s-mention" },
		opts(),
	);
	assert.equal(v.kind, "unowned-path");
	assert.equal(v.violation, false);
});

test("mode off — config disables the check without the kill switch", () => {
	const v = evaluateDelegation(
		{ seat: "wren", tool: "Edit", args: { file_path: `${KITCHEN}/x`, old_string: "a", new_string: "b" }, session_id: "s-off" },
		opts({ mode: "off" }),
	);
	assert.equal(v.token, "mode-off");
	assert.equal(v.violation, false);
});

test("readConfig — missing means defaults, garbage means defaults plus one logged line", () => {
	const stateDir = tmpState();
	const missing = readConfig(join(stateDir, "absent.json"), stateDir);
	assert.deepEqual(missing, { mode: "warn", readAllowancePerRepo: 10, additionalHomes: {} });
	const configPath = join(stateDir, "config.json");
	writeFileSync(configPath, "{ not json");
	const garbage = readConfig(configPath, stateDir);
	assert.equal(garbage.mode, "warn");
	assert.equal(garbage.readAllowancePerRepo, 10);
	assert.match(readFileSync(join(stateDir, "errors.log"), "utf8"), /config-unparseable/);
	const good = join(stateDir, "good.json");
	writeFileSync(good, JSON.stringify({ mode: "block", readAllowancePerRepo: 3, additionalHomes: { lintel: [CLAUDE] } }));
	const parsed = readConfig(good, stateDir);
	assert.equal(parsed.mode, "block");
	assert.equal(parsed.readAllowancePerRepo, 3);
});

test("allowance is configurable — allowance 2 flags on the second read", () => {
	const stateDir = tmpState();
	let last;
	for (let i = 1; i <= 2; i += 1) {
		last = evaluateDelegation(
			{ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/src/x.ts` }, session_id: "s-small" },
			opts({ stateDir, readAllowancePerRepo: 2 }),
		);
	}
	assert.equal(last.kind, "foreign-read-over-allowance");
	assert.equal(last.allowance, 2);
});

test("CLI — verdict JSON on stdout, exit 0, dry-run writes no state (hermetic HOME)", () => {
	const home = mkdtempSync(join(tmpdir(), "delegation-cli-"));
	const claude = join(home, ".claude");
	mkdirSync(join(claude, "orchestrator", "state"), { recursive: true });
	writeFileSync(join(claude, "orchestrator", "state", "ROUTING.md"), FIXTURE_ROUTING);
	const run = (payload, args = []) => spawnSync(process.execPath, [HOOK, ...args], {
		input: JSON.stringify(payload),
		env: { ...process.env, HOME: home },
		encoding: "utf8",
	});
	try {
		const write = run({ seat: "wren", tool: "Edit", args: { file_path: `${KITCHEN}/x`, old_string: "a", new_string: "b" }, session_id: "cli-1" });
		assert.equal(write.status, 0);
		const verdict = JSON.parse(write.stdout);
		assert.equal(verdict.kind, "foreign-write");
		assert.equal(verdict.owner, "galley");
		assert.equal(verdict.mode, "warn");

		const dryRead = run({ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/x` }, session_id: "cli-2" }, ["--dry-run"]);
		assert.equal(JSON.parse(dryRead.stdout).kind, "foreign-read");
		assert.ok(!existsSync(join(claude, ".delegation-check-state")), "dry-run must not create state");

		const liveRead = run({ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/x` }, session_id: "cli-3" });
		assert.equal(JSON.parse(liveRead.stdout).count, 1);
		assert.ok(existsSync(join(claude, ".delegation-check-state", "s_cli-3.json")));

		writeFileSync(join(claude, ".delegation-check-off"), "");
		const killed = run({ seat: "wren", tool: "Edit", args: { file_path: `${KITCHEN}/x`, old_string: "a", new_string: "b" }, session_id: "cli-4" });
		assert.equal(JSON.parse(killed.stdout).token, "killed");
		rmSync(join(claude, ".delegation-check-off"));

		writeFileSync(join(claude, ".delegation-check.json"), "{ broken");
		const badConfig = run({ seat: "wren", tool: "Read", args: { file_path: `${KITCHEN}/x` }, session_id: "cli-5" });
		assert.equal(badConfig.status, 0);
		assert.equal(JSON.parse(badConfig.stdout).mode, "warn");
		assert.match(readFileSync(join(claude, ".delegation-check-state", "errors.log"), "utf8"), /config-unparseable/);

		const malformed = spawnSync(process.execPath, [HOOK], { input: "not json at all", env: { ...process.env, HOME: home }, encoding: "utf8" });
		assert.equal(malformed.status, 0);
		assert.equal(JSON.parse(malformed.stdout).violation, false);
	} finally {
		rmSync(home, { recursive: true, force: true });
	}
});

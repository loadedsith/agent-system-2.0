/**
 * Newdle hook bridge for OMP.
 *
 * Invokes the canonical Newdle hook scripts without copying their policy.
 * OMP-native lifecycle and compaction events remain owned by this adapter.
 */
import type { HookAPI } from "@oh-my-pi/pi-coding-agent";

type ClaudeHookOutput = {
	decision?: "block";
	reason?: string;
	hookSpecificOutput?: {
		hookEventName?: string;
		permissionDecision?: "deny" | "ask" | "allow";
		permissionDecisionReason?: string;
		additionalContext?: string;
	};
};

type OmpContinuitySnapshot = {
	version: 1;
	cwd: string;
	tokensBefore: number;
	userIntents: string[];
	fileOperations: string;
};

const pluginRoot = process.env.NEWDLE_PLUGIN_ROOT;
if (!pluginRoot) throw new Error("Set NEWDLE_PLUGIN_ROOT to the canonical Newdle plugin directory.");

const hookManifest = `${pluginRoot}/hooks/hooks.json`;
const toolNames: Record<string, string> = {
	bash: "Bash",
	read: "Read",
	grep: "Grep",
	find: "Glob",
	write: "Write",
	edit: "Edit",
	task: "Task",
	Task: "Task",
};

function hookInput(toolName: string, toolInput: Record<string, unknown>, cwd: string) {
	return JSON.stringify({
		hook_event_name: "PreToolUse",
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		tool_name: toolNames[toolName] ?? toolName,
		tool_input: toolInput,
	});
}

function lifecycleInput(hookEventName: string, cwd: string) {
	return JSON.stringify({
		hook_event_name: hookEventName,
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
	});
}

/**
 * Payload for the compaction save and its restore.
 *
 * ⛔ FOUR FIELDS, AND NO CLAUDE-ONLY FIELDS AT ALL. This is the exact shape Sedge proved
 * sufficient on 2026-09-15 by feeding it to the installed 0.2.166 `compact-continuity.mjs`:
 * exit 0, and an 852-byte `.ai/session-state.md` written with branch and `git status` populated,
 * the transcript-derived sections degrading to `(none detected)` / `(none captured)` rather than
 * failing. `snapshot()` wraps its transcript read in its own try/catch, so a missing
 * `transcript_path` is a thinner save and never an error.
 *
 * That experiment is why the adapter's old refusal comment is deleted rather than reworded.
 */
function compactionInput(hookEventName: "PreCompact" | "SessionStart", cwd: string, extra: Record<string, string>) {
	return JSON.stringify({
		hook_event_name: hookEventName,
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		...extra,
	});
}

async function runCommand(command: string, stdin: string, cwd: string): Promise<ClaudeHookOutput | undefined> {
	const expanded = command.replaceAll("${CLAUDE_PLUGIN_ROOT}", pluginRoot);
	const child = Bun.spawn({
		cmd: ["sh", "-lc", expanded],
		cwd,
		env: { ...process.env, CLAUDE_PLUGIN_ROOT: pluginRoot, CLAUDE_PROJECT_DIR: cwd },
		stdin: "pipe",
		stdout: "pipe",
		stderr: "pipe",
	});
	child.stdin.write(stdin);
	child.stdin.end();
	const stdout = await new Response(child.stdout).text();
	await child.exited;
	if (!stdout.trim()) return undefined;
	try {
		return JSON.parse(stdout) as ClaudeHookOutput;
	} catch {
		return undefined;
	}
}

/**
 * Invoke the manifest's hooks for a lifecycle event.
 *
 * `matchers` names which matcher-bearing groups to run alongside the matcherless ones. The only
 * matcher these lifecycle groups carry is `SessionStart:compact`, the RESTORE half of the
 * compaction save.
 *
 * ⛔ THIS PARAMETER EXISTS BECAUSE THE PREVIOUS VERSION SKIPPED EVERY MATCHER-BEARING GROUP AND
 * SAID WHY IN A COMMENT THAT WAS FALSE. The comment claimed OMP "does not yet provide the Claude
 * compact payload". Sedge disproved it by experiment on 2026-09-15: the installed 0.2.166
 * `compact-continuity.mjs` was fed a four-field OMP-shaped payload and wrote a valid snapshot at
 * exit 0. The hook was never blocked — it was opted out, and the opt-out outlived its reason from
 * 2026-08-03 to 2026-09-15 because the justification sat above the code and nobody re-tested it.
 *
 * The restore half is the half that matters more: a save nobody reads back is a file, not a
 * recovery. Lintel lost session state on 2026-09-15 at 543,700 tokens and would have lost it even
 * if the save had been written, because nothing consumed it.
 */
async function runManifestHooks(
	eventName: "SessionStart" | "SessionEnd" | "Stop" | "PreCompact",
	stdin: string,
	cwd: string,
	matchers: string[] = [],
) {
	const raw = await Bun.file(hookManifest).json();
	const groups = raw?.hooks?.[eventName];
	if (!Array.isArray(groups)) return { additionalContext: [] as string[], blockReason: undefined as string | undefined };

	const additionalContext: string[] = [];
	let blockReason: string | undefined;
	for (const group of groups) {
		const matcher = typeof group.matcher === "string" ? group.matcher : "";
		if (matcher && !matchers.includes(matcher)) continue;
		for (const hook of group.hooks ?? []) {
			if (hook.type !== "command" || typeof hook.command !== "string") continue;
			// ⛔ AWAITED, and that is load-bearing rather than incidental. The Claude-side
			// registration of this same script carries `"async": true`, which is why a failure
			// there was indistinguishable from a success. Here the spawn is awaited, and OMP in
			// turn awaits this handler: runner.ts:1349 routes fire-and-forget ONLY for
			// `session_shutdown` (:1357-1370); every other event including `session_before_compact`
			// runs the serial `await` loop at :1372-1391. So the save cannot race the compaction
			// that destroys the context it is saving.
			const result = await runCommand(hook.command, stdin, cwd);
			if (result?.decision === "block" && result.reason) blockReason ??= result.reason;
			const output = result?.hookSpecificOutput;
			if (output?.hookEventName === eventName && output.additionalContext) {
				additionalContext.push(output.additionalContext);
			}
		}
	}
	return { additionalContext, blockReason };
}

function textFromMessage(message: unknown) {
	if (!message || typeof message !== "object") return undefined;
	const candidate = message as { role?: unknown; content?: unknown };
	if (candidate.role !== "user") return undefined;
	if (typeof candidate.content === "string") return candidate.content;
	if (!Array.isArray(candidate.content)) return undefined;
	const text = candidate.content
		.filter((part): part is { type?: unknown; text?: unknown } => Boolean(part && typeof part === "object"))
		.filter(part => part.type === "text" && typeof part.text === "string")
		.map(part => part.text)
		.join("\n");
	return text || undefined;
}

function continuitySnapshot(preparation: {
	messagesToSummarize: unknown[];
	tokensBefore: number;
	fileOps: unknown;
}, cwd: string): OmpContinuitySnapshot {
	const userIntents = preparation.messagesToSummarize
		.map(textFromMessage)
		.filter((text): text is string => Boolean(text))
		.slice(-3)
		.map(text => text.slice(0, 1_500));
	let fileOperations = "(no file-operation summary available)";
	try {
		fileOperations = JSON.stringify(preparation.fileOps).slice(0, 6_000);
	} catch {
		// Keep OMP's native compaction running if an extension or provider supplies
		// a non-serializable operation detail.
	}
	return { version: 1, cwd, tokensBefore: preparation.tokensBefore, userIntents, fileOperations };
}

function renderContinuity(snapshot: OmpContinuitySnapshot) {
	const intents = snapshot.userIntents.length
		? snapshot.userIntents.map((intent, index) => `${index + 1}. ${intent}`).join("\n")
		: "(no user messages were compacted)";
	return [
		"## Newdle OMP continuity",
		"This is an OMP-native compaction snapshot. It intentionally does not claim Claude transcript paths, token targets, or context-pressure calibration.",
		`Working directory: ${snapshot.cwd}`,
		`OMP tokens before compaction: ${snapshot.tokensBefore}`,
		"Recent compacted user intent:",
		intents,
		"Compacted file-operation record:",
		snapshot.fileOperations,
	].join("\n\n");
}

export default function newdleOmpHooks(pi: HookAPI) {
	let startupContext: string[] = [];
	let startupContextDelivered = false;

	pi.on("session_start", async (_event, ctx) => {
		startupContext = (await runManifestHooks("SessionStart", lifecycleInput("SessionStart", ctx.cwd), ctx.cwd)).additionalContext;
	});

	pi.on("before_agent_start", async () => {
		if (startupContextDelivered || !startupContext.length) return undefined;
		startupContextDelivered = true;
		return {
			message: {
				customType: "newdle-session-start",
				content: startupContext.join("\n\n"),
				display: false,
			},
		};
	});

	pi.on("session_stop", async (event, ctx) => {
		if (event.stop_hook_active) return undefined;
		const outcome = await runManifestHooks("Stop", lifecycleInput("Stop", ctx.cwd), ctx.cwd);
		if (outcome.blockReason) return { decision: "block", reason: outcome.blockReason };
		if (!outcome.additionalContext.length) return undefined;
		return { continue: true, additionalContext: outcome.additionalContext.join("\n\n") };
	});

	pi.on("session_shutdown", async (_event, ctx) => {
		await runManifestHooks("SessionEnd", lifecycleInput("SessionEnd", ctx.cwd), ctx.cwd);
	});

	pi.on("session_before_compact", async (event, ctx) => {
		// THE SAVE HALF. Two independent records, deliberately: the in-session contribution
		// (survives compaction inside the session) and the plugin's on-disk snapshot (survives the
		// process). Neither substitutes for the other — the contribution is unreadable after the
		// process exits, and the file is unreadable by a mid-session restore.
		const snapshot = continuitySnapshot(event.preparation, ctx.cwd);
		pi.appendEntry("dev.newdle.omp.compaction-contribution", {
			key: "dev.newdle.omp.continuity",
			value: snapshot,
		});

		// The canonical plugin hook, which this adapter refused to call from 2026-08-03 until
		// 2026-09-15 on a stated reason that was false. Its output is ignored here on purpose: the
		// deliverable is the file it writes, and its own five bare catch blocks mean a thin save is
		// its normal degraded mode rather than an error to surface.
		await runManifestHooks(
			"PreCompact",
			compactionInput("PreCompact", ctx.cwd, { trigger: "auto" }),
			ctx.cwd,
		);
	});

	pi.on("session_compact", async (event, ctx) => {
		// THE RESTORE HALF, and the half that decides whether any of this is a recovery. A save
		// nobody reads back is a file. Lintel's 543,700-token compaction on 2026-09-15 would have
		// been lost even with the save working, because nothing consumed it.
		//
		// It runs here rather than at session_start because OMP compacts IN SESSION: there is no
		// restart to restore across, so the moment to read the snapshot back is immediately after
		// the compaction that wrote it.
		const restored = await runManifestHooks(
			"SessionStart",
			compactionInput("SessionStart", ctx.cwd, { source: "compact" }),
			ctx.cwd,
			["compact"],
		);

		const inSession = event.compactionEntry.preserveData?.["dev.newdle.omp.continuity"];
		const parts: string[] = [];
		if (inSession && typeof inSession === "object") {
			const data = inSession as OmpContinuitySnapshot;
			if (data.version === 1 && typeof data.cwd === "string" && Array.isArray(data.userIntents)) {
				parts.push(renderContinuity(data));
			}
		}
		parts.push(...restored.additionalContext);

		// ⛔ SILENCE IS NOT AN ACCEPTABLE OUTCOME HERE. A compaction that restores nothing must say
		// so, because an agent cannot tell "nothing was worth restoring" from "the restore never
		// ran" — and for six weeks the answer was the second one while looking like the first.
		pi.sendMessage({
			customType: "dev.newdle.omp.continuity-restored",
			content: parts.length
				? parts.join("\n\n")
				: "## Newdle OMP continuity\n⛔ NO CONTINUITY RECORD WAS RECOVERED for this compaction."
					+ " Neither the in-session contribution nor the on-disk snapshot yielded usable state."
					+ " Context before this point is gone and was not preserved.",
			display: false,
			attribution: "agent",
		});
	});

	pi.on("tool_call", async (event, ctx) => {
		const raw = await Bun.file(hookManifest).json();
		const groups = raw?.hooks?.PreToolUse;
		if (!Array.isArray(groups)) return undefined;
		const claudeTool = toolNames[event.toolName] ?? event.toolName;
		const stdin = hookInput(event.toolName, event.input, process.cwd());

		for (const group of groups) {
			const matcher = typeof group.matcher === "string" ? group.matcher : "";
			if (matcher && !matcher.split("|").includes(claudeTool)) continue;
			for (const hook of group.hooks ?? []) {
				if (hook.type !== "command" || typeof hook.command !== "string") continue;
				const result = await runCommand(hook.command, stdin, process.cwd());
				const output = result?.hookSpecificOutput;
				if (!output || output.hookEventName !== "PreToolUse") continue;

				if (output.permissionDecision === "deny") {
					return { block: true, reason: output.permissionDecisionReason ?? "Blocked by Newdle hook" };
				}
				if (output.permissionDecision === "ask") {
					if (!ctx.hasUI) return { block: true, reason: output.permissionDecisionReason ?? "Newdle confirmation required" };
					const approved = await ctx.ui.confirm("Newdle confirmation", output.permissionDecisionReason ?? "Allow this tool call?");
					if (!approved) return { block: true, reason: "Newdle confirmation declined" };
				}

				// OMP's tool-call result type has no pre-tool additional-context field.
				// Surface Newdle's context in a blocked tool result instead: the model
				// receives it, then retries the edit. The Newdle hook's state file has
				// already deduplicated that context for the retry.
				if (output.additionalContext) {
					return {
						block: true,
						reason: `Newdle repository rules loaded before retrying this edit:\n\n${output.additionalContext}`,
					};
				}
			}
		}
		return undefined;
	});
}

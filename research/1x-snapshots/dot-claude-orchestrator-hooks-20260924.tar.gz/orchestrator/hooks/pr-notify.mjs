#!/usr/bin/env node
/**
 * pr-notify.mjs — PostToolUse[Bash] notifier: the owner is told when a pull request is opened.
 *
 * PURPOSE
 *   Notification, never prevention. This hook cannot block, cannot deny, and cannot slow a tool
 *   call: PostToolUse runs after the command has already executed and its exit-2 channel is
 *   defined as "shows stderr to Claude; the tool already ran". Nothing here refuses anything.
 *
 * WHY PostToolUse AND NOT PreToolUse
 *   PreToolUse fires before the pull request exists. It would announce an intent that may then
 *   fail (detached HEAD, no remote, expired token, an existing PR for the branch), and a notifier
 *   that cries wolf gets muted, which returns us to the original failure. PostToolUse carries
 *   `tool_response`, so the notice can name the real pull request URL and number rather than a
 *   guess at one. What the losing option would have bought: an announcement even when the session
 *   is killed between the command completing and the tool call returning, and coverage of a
 *   command that creates a PR and then exits non-zero. Both are narrow; the false-positive cost
 *   of PreToolUse is not.
 *
 * HOW THE OWNER ACTUALLY SEES IT — the load-bearing part
 *   Per the published hooks reference, a PostToolUse hook's stdout goes to the debug log and is
 *   NOT shown in the transcript; only UserPromptSubmit, UserPromptExpansion and SessionStart put
 *   plain stdout in front of anyone. So stdout alone is indistinguishable from silence. This hook
 *   therefore notifies OUT OF BAND and treats the in-session channel as a bonus:
 *     1. macOS Notification Center (terminal-notifier if installed, else osascript). Verified.
 *     2. Append-only JSONL at <dir>/pr-log.jsonl plus a plain-text tail at <dir>/LAST-PR.txt.
 *        Durable: survives the session, the transcript, and the terminal being closed.
 *     3. `systemMessage` on stdout. Documented as "message for Claude to see in the transcript";
 *        whether it reaches the owner's screen is NOT verified on this machine, so nothing
 *        depends on it. It is emitted because it is free, not because it is trusted.
 *
 * DETECTION, AND WHAT IT MISSES (read this before trusting it)
 *   Tier A — the command text matches a known pull-request-creating invocation:
 *     gh pr create · hub pull-request · glab mr create · gh api …/pulls with a write method ·
 *     curl POST to api.github.com/…/pulls. Path-prefixed binaries (/opt/homebrew/bin/gh) match.
 *   Tier B — no Tier A match, but the command's OUTPUT contains a GitHub pull-request URL and the
 *     command is not on the not-a-creation denylist: any `gh pr <verb>` other than create, any
 *     `glab mr <verb>` other than create, git log, cat, grep, rg, head, tail, less. This is the
 *     tier that catches a publisher script wrapping gh. It was added after a lab run showed
 *     `gh pr close` announcing itself as a new pull request.
 *     Tier B notices say "source command not recognized" so the owner can tell it apart.
 *   MISSES, stated plainly:
 *     · A PR opened by any tool call that is not Bash — an MCP server's create-PR tool, a GitHub
 *       Action, a web click, another machine. This hook sees Bash and only Bash.
 *     · A wrapper script that creates a PR and prints nothing containing the PR URL.
 *     · A Bash call with run_in_background: true — Tier A still fires (command text is present)
 *       but tool_response holds a shell id, so the notice carries no PR number.
 *     · Anything a PostToolUse hook never sees: a tool call that errors (PostToolUseFailure is a
 *       separate event, not wired here) or a session killed mid-call.
 *     · Its converse: `echo "gh pr create"` matches Tier A. It notifies on a string, not on a PR.
 *
 * DE-DUPLICATION
 *   Keyed on the pull-request URL in <dir>/seen-prs.json. The same PR mentioned five times
 *   notifies once; five different PRs notify five times. A detection with no URL always notifies.
 *
 * SUBAGENTS
 *   The hooks reference states tool events fire the same configured hooks inside subagents, with
 *   agent_id / agent_type in the payload. Both are recorded, so a notice says which agent did it.
 *
 * FAILS OPEN, ALWAYS
 *   Every path is wrapped; the process always exits 0 with no decision field. Malformed stdin,
 *   an unwritable state directory, a missing notifier binary, an unparseable tool_response: each
 *   allows ordinary work to continue untouched. On timeout the reference says the hook is
 *   canceled and its output discarded — for PostToolUse there is nothing to discard but the
 *   notice, so a stalled hook loses the notification and nothing else. Notifier subprocesses are
 *   run with their own 4s cap so the hook cannot reach its own timeout waiting on one.
 *
 * STATE DIRECTORY
 *   $PR_NOTIFY_DIR, else ~/.claude/state/pr-notify.
 */
import { readFileSync, appendFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { homedir } from 'node:os';

const done = (obj) => {
  try { if (obj) process.stdout.write(JSON.stringify(obj)); } catch { /* ignore */ }
  process.exit(0);
};

let payload = {};
try { payload = JSON.parse(readFileSync(0, 'utf8')); } catch { done(null); }
if (!payload || typeof payload !== 'object') done(null);
if (payload.tool_name !== 'Bash') done(null);

const command = String(payload?.tool_input?.command ?? '');
if (!command.trim()) done(null);

// tool_response may be a string or an object; flatten defensively.
let output = '';
try {
  const r = payload.tool_response;
  output = typeof r === 'string' ? r : JSON.stringify(r ?? '');
} catch { output = ''; }

// ── Tier A: the command itself opens a pull request ────────────────────────────────────────────
const BIN = String.raw`(?:^|[\s;|&(\x60$])(?:[\w./~+-]*\/)?`;
const TIER_A = [
  { name: 'gh pr create',    re: new RegExp(BIN + String.raw`gh\s+(?:[^\s;|&]+\s+)*?pr\s+create\b`) },
  { name: 'hub pull-request',re: new RegExp(BIN + String.raw`hub\s+pull-request\b`) },
  { name: 'glab mr create',  re: new RegExp(BIN + String.raw`glab\s+(?:[^\s;|&]+\s+)*?mr\s+create\b`) },
  { name: 'gh api → /pulls',
    re: new RegExp(BIN + String.raw`gh\s+api\b[^\n]*\/pulls\b`),
    also: /--method\s+POST|-X\s+POST|\s-f\s|\s-F\s|--input\b/ },
  { name: 'curl POST → /pulls',
    re: new RegExp(BIN + String.raw`curl\b[^\n]*api\.github\.com[^\n]*\/pulls\b`),
    also: /-X\s*POST|--request\s+POST|\s-d\s|--data\b/ },
];
// Help and completion invocations create nothing.
const IS_HELP = /(?:^|\s)(?:--help|-h)(?:\s|$)|(?:^|\s)gh\s+help\b/.test(command);

let hit = null;
if (!IS_HELP) {
  for (const t of TIER_A) {
    if (t.re.test(command) && (!t.also || t.also.test(command))) { hit = { tier: 'A', how: t.name }; break; }
  }
}

// ── Tier B: output names a pull request and the command is not a known reader ───────────────────
const PR_URL = /https?:\/\/(?:[\w.-]*github(?:\.[\w.-]+)*\.com)\/([\w.-]+)\/([\w.-]+)\/pull\/(\d+)/;
// Any `gh pr <verb>` other than create acts on a pull request that already exists — list, view,
// close, merge, edit, comment, review, checkout. Its output naturally contains a PR URL, and
// announcing it as a new pull request is exactly the noise that gets a notifier muted.
const NOT_A_CREATION = new RegExp(
  BIN + String.raw`(?:gh\s+(?:[^\s;|&]+\s+)*?pr\s+(?!create\b)\w+|glab\s+(?:[^\s;|&]+\s+)*?mr\s+(?!create\b)\w+` +
  String.raw`|git\s+log\b|cat\b|grep\b|rg\b|head\b|tail\b|less\b)`
);
if (!hit && PR_URL.test(output) && !NOT_A_CREATION.test(command)) {
  hit = { tier: 'B', how: 'pull-request URL in output, source command not recognized' };
}
if (!hit) done(null);

// ── Identify the pull request ──────────────────────────────────────────────────────────────────
const m = PR_URL.exec(output) || PR_URL.exec(command);
const prUrl = m ? m[0] : null;
const repo = m ? `${m[1]}/${m[2]}` : (() => {
  try {
    const r = spawnSync('git', ['-C', String(payload.cwd || process.cwd()), 'remote', 'get-url', 'origin'],
      { encoding: 'utf8', timeout: 3000 });
    const u = String(r.stdout || '').trim();
    const g = /[:/]([\w.-]+)\/([\w.-]+?)(?:\.git)?$/.exec(u);
    return g ? `${g[1]}/${g[2]}` : (u || 'unknown');
  } catch { return 'unknown'; }
})();
const prNum = m ? m[3] : null;

// ── State: durable record + de-duplication ─────────────────────────────────────────────────────
const dir = process.env.PR_NOTIFY_DIR || join(homedir(), '.claude', 'state', 'pr-notify');
let seen = {};
try { mkdirSync(dir, { recursive: true }); } catch { /* ignore */ }
try { if (existsSync(join(dir, 'seen-prs.json'))) seen = JSON.parse(readFileSync(join(dir, 'seen-prs.json'), 'utf8')) || {}; } catch { seen = {}; }
if (prUrl && seen[prUrl]) done(null);   // already announced this exact pull request

const when = new Date().toISOString();
const record = {
  ts: when,
  tier: hit.tier,
  how: hit.how,
  repo,
  pr_url: prUrl,
  pr_number: prNum ? Number(prNum) : null,
  cwd: payload.cwd ?? null,
  session_id: payload.session_id ?? null,
  agent_id: payload.agent_id ?? null,
  agent_type: payload.agent_type ?? null,
  command: command.length > 600 ? command.slice(0, 600) + '…' : command,
};
try { appendFileSync(join(dir, 'pr-log.jsonl'), JSON.stringify(record) + '\n'); } catch { /* ignore */ }
try {
  if (prUrl) { seen[prUrl] = when; writeFileSync(join(dir, 'seen-prs.json'), JSON.stringify(seen, null, 1)); }
} catch { /* ignore */ }

const who = record.agent_type ? ` by subagent ${record.agent_type}` : '';
const title = hit.tier === 'A' ? 'Pull request opened' : 'Pull request URL seen';
const line = prUrl
  ? `${repo} #${prNum}${who} — ${prUrl}`
  : `${repo}${who} — ${hit.how} (no PR number in output)`;

try { writeFileSync(join(dir, 'LAST-PR.txt'), `${when}  ${title}\n${line}\n${record.command}\n`); } catch { /* ignore */ }

// ── Out-of-band notification: the channel that actually reaches the owner ───────────────────────
try {
  const tn = spawnSync('/usr/bin/which', ['terminal-notifier'], { encoding: 'utf8', timeout: 2000 });
  const hasTN = tn.status === 0 && String(tn.stdout).trim();
  if (hasTN && !process.env.PR_NOTIFY_NO_DESKTOP) {
    spawnSync(String(tn.stdout).trim(),
      ['-title', title, '-subtitle', repo, '-message', line, '-group', 'claude-pr-notify',
       ...(prUrl ? ['-open', prUrl] : [])],
      { timeout: 4000, stdio: 'ignore' });
  } else if (!process.env.PR_NOTIFY_NO_DESKTOP) {
    const esc = (s) => String(s).replace(/["\\]/g, '\\$&');
    spawnSync('/usr/bin/osascript',
      ['-e', `display notification "${esc(line)}" with title "${esc(title)}" subtitle "${esc(repo)}"`],
      { timeout: 4000, stdio: 'ignore' });
  }
} catch { /* a missing or broken notifier must not disturb the session */ }

// ── Bonus in-session channel. Unverified; nothing above depends on it. ─────────────────────────
done({
  systemMessage: `${title}: ${line}  (recorded in ${join(dir, 'pr-log.jsonl')})`,
  hookSpecificOutput: {
    hookEventName: 'PostToolUse',
    additionalContext: `A pull request was just opened from this session: ${line}. Tell the owner in your next message; it has also been written to ${join(dir, 'pr-log.jsonl')}.`,
  },
});

/**
 * Newdle hook bridge for OMP.
 *
 * Invokes the canonical Newdle hook scripts without copying their policy.
 * OMP-native lifecycle and compaction events remain owned by this adapter.
 */
import type { HookAPI } from "@oh-my-pi/pi-coding-agent";
import { createHash } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir, uptime } from "node:os";
import { basename, dirname, join } from "node:path";

type ClaudeHookOutput = {
	decision?: "block";
	reason?: string;
	hookSpecificOutput?: {
		hookEventName?: string;
		permissionDecision?: "deny" | "ask" | "allow";
		permissionDecisionReason?: string;
		additionalContext?: string;
	};
};

type OmpContinuitySnapshot = {
	version: 1;
	cwd: string;
	tokensBefore: number;
	userIntents: string[];
	fileOperations: string;
	/**
	 * ⛔ OPTIONAL ON PURPOSE, AND THE VERSION DELIBERATELY STAYS AT 1. A tier-2 snapshot comes
	 * out of the host's `preserveData` and may have been written by an older copy of this module
	 * that had no such field; bumping `version` would make the restore's validity check
	 * (`version === 1`) reject exactly the snapshots the fallback exists to serve. So the field
	 * is additive and its absence is a reportable state, not a parse failure — see
	 * `continuityAge`, which says "capture time unknown" rather than inventing one.
	 */
	capturedAt?: string;
};

const pluginRoot = process.env.NEWDLE_PLUGIN_ROOT;
if (!pluginRoot) throw new Error("Set NEWDLE_PLUGIN_ROOT to the canonical Newdle plugin directory.");

const hookManifest = `${pluginRoot}/hooks/hooks.json`;
const toolNames: Record<string, string> = {
	bash: "Bash",
	read: "Read",
	grep: "Grep",
	find: "Glob",
	write: "Write",
	edit: "Edit",
	task: "Task",
	Task: "Task",
};

function hookInput(toolName: string, toolInput: Record<string, unknown>, cwd: string) {
	return JSON.stringify({
		hook_event_name: "PreToolUse",
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		tool_name: toolNames[toolName] ?? toolName,
		tool_input: toolInput,
	});
}

function lifecycleInput(hookEventName: string, cwd: string, extra: Record<string, unknown> = {}) {
	return JSON.stringify({
		hook_event_name: hookEventName,
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		...extra,
	});
}

/**
 * Render OMP's `last_assistant_message` down to the plain string the plugin hooks expect.
 *
 * ⛔ WHY THIS EXISTS AT ALL. `output-types-guard.mjs` reads `input.last_assistant_message` and
 * passes through on an empty one, and the Claude-side Stop payload hands it a STRING. OMP hands
 * this handler an `AgentMessage` OBJECT. Until 2026-09-15 this adapter sent neither: its Stop
 * payload carried three fields and the guard could not fire for any seat on this machine, at any
 * setting. Proven by a minimal pair with the scope and level gates deliberately opened — the
 * three-field payload produced 0 bytes, the same payload plus this one field produced a 1,235-byte
 * nudge.
 *
 * Deliberately NOT reusing `textFromMessage` below: that one returns undefined unless
 * `role === "user"`, which is correct for its own caller and exactly wrong here.
 */
function assistantText(message: unknown): string | undefined {
	if (!message || typeof message !== "object") return undefined;
	const candidate = message as { content?: unknown };
	if (typeof candidate.content === "string") return candidate.content || undefined;
	if (!Array.isArray(candidate.content)) return undefined;
	const text = candidate.content
		.filter((part): part is { type?: unknown; text?: unknown } => Boolean(part && typeof part === "object"))
		.filter(part => part.type === "text" && typeof part.text === "string")
		.map(part => part.text as string)
		.join("\n");
	return text || undefined;
}

/**
 * The compaction call sites' `CLAUDE_PROJECT_DIR`, and nothing else's.
 *
 * ⛔ SCOPE, AND WHY IT IS THIS NARROW. A declaration at `~/.claude` switches on every governed
 * plugin hook for Lintel, Tinker and Jo's own sessions — refused by Jo on 2026-09-15 and ruled out
 * for exactly that blast radius on 2026-08-21. The alternative chosen back then is this anchor:
 * `orchestrator/state/hook-scope-anchor/README.md:3-11` describes a leaf directory nothing resolves
 * through, pointed at by `CLAUDE_PROJECT_DIR` immediately before a hook runs, so "scope is granted
 * per-hook, at the call site". This is that pattern applied to the OMP adapter. Approved by Jo,
 * 2026-09-15: "Approve pointing CLAUDE_PROJECT_DIR at the existing hook-scope anchor yes".
 *
 * ⛔ NEVER WIDEN THIS TO THE GENERAL Stop / SessionEnd / SessionStart GROUPS. `wrap-up-nudge.sh:25`,
 * `session-end-reminder.sh:19` and `recent-activity.sh:35` all `cd` to `CLAUDE_PROJECT_DIR` and
 * would begin writing relative to the anchor. Per-call-site is the design, not a compromise.
 *
 * ⛔ AND IT MUST BE SET HERE, INSIDE THE SPAWN'S ENV. `runCommand` places the explicit
 * `CLAUDE_PROJECT_DIR` key AFTER the `...process.env` spread, so an upstream export from
 * `launch-seat` is silently overwritten — no error, a seat that looks configured and a gate still
 * off. Measured 2026-09-15.
 *
 * Returns undefined — leaving the seat's own cwd in place — when the seat's root already resolves
 * on. Eight of eleven seats are already gate-true through `code/shipyard/newdle-hooks.json` or
 * `code/joseph-gordon-levitt/newdle-hooks.json`; their behaviour must not change.
 *
 * Safe with respect to where the save lands: `compact-continuity.mjs` derives the state-file path
 * from `repoRoot(input.cwd)` (`:335`, `:372`, `:427`), not from `CLAUDE_PROJECT_DIR`, which it uses
 * only as `launchDir` at `:216`. Verified before this was installed.
 */
const SCOPE_ANCHOR = "/Users/jowolff/.claude/orchestrator/state/hook-scope-anchor";

function compactionProjectDir(cwd: string): string | undefined {
	let dir = cwd;
	for (;;) {
		if (existsSync(join(dir, "newdle-hooks.json"))) return undefined;
		const parent = dirname(dir);
		if (parent === dir) return SCOPE_ANCHOR;
		dir = parent;
	}
}

/**
 * Payload for the compaction save and its restore.
 *
 * ⛔ FOUR FIELDS, AND NO CLAUDE-ONLY FIELDS AT ALL. This is the exact shape Sedge proved
 * sufficient on 2026-09-15 by feeding it to the installed 0.2.166 `compact-continuity.mjs`:
 * exit 0, and an 852-byte `.ai/session-state.md` written with branch and `git status` populated,
 * the transcript-derived sections degrading to `(none detected)` / `(none captured)` rather than
 * failing. `snapshot()` wraps its transcript read in its own try/catch, so a missing
 * `transcript_path` is a thinner save and never an error.
 *
 * That experiment is why the adapter's old refusal comment is deleted rather than reworded.
 */
/**
 * ⛔ THE HOST-STATE PAYLOAD, WITHOUT WHICH THE SAVE SAVES NOTHING.
 *
 * `compact-continuity.mjs` reads three optional fields that only a transcript-less host can
 * supply, and this bridge sent NONE of them until 2026-09-16:
 *   • `intents` — `:390-392`, a string array; picked at `:394` when no transcript is readable.
 *   • `file_operations` — `:414-417`, a string, rendered verbatim under its own heading at `:419`.
 *   • `token_count` / `compaction_target` — `:238-239`, the calibration numbers.
 *
 * ⛔ MEASURED CONSEQUENCE, 2026-09-16, in this repo's own
 * `.ai/session-state--seat-tinker-1789523825-14915.md`: "(none detected)" files,
 * "(none captured)" intent, and the hook's own self-description
 * `_source: none available — neither a readable transcript nor host-supplied intents_`.
 * **The file was 3,917 bytes of git status and nothing that happened in the session.** That is
 * Jo's complaint exactly — an `ok` that saves nothing reads as working.
 *
 * The hook was BUILT for this path: `:385-386` says "A host with no transcript concept (an OMP
 * seat) sends the same facts on the payload instead of leaving this section empty." The contract
 * existed and the bridge never honored it.
 */
function compactionInput(
	hookEventName: "PreCompact" | "SessionStart",
	cwd: string,
	extra: Record<string, string>,
	host?: { intents: string[]; fileOperations: string; tokensBefore: number },
) {
	return JSON.stringify({
		hook_event_name: hookEventName,
		session_id: process.env.OMP_SESSION_ID ?? "omp-spike",
		cwd,
		...extra,
		...(host
			? {
					intents: host.intents,
					file_operations: host.fileOperations,
					token_count: host.tokensBefore,
				}
			: {}),
	});
}

async function runCommand(
	command: string,
	stdin: string,
	cwd: string,
	projectDir?: string,
): Promise<ClaudeHookOutput | undefined> {
	const expanded = command.replaceAll("${CLAUDE_PLUGIN_ROOT}", pluginRoot);
	const child = Bun.spawn({
		cmd: ["sh", "-lc", expanded],
		cwd,
		env: { ...process.env, CLAUDE_PLUGIN_ROOT: pluginRoot, CLAUDE_PROJECT_DIR: projectDir ?? cwd },
		stdin: "pipe",
		stdout: "pipe",
		stderr: "pipe",
	});
	child.stdin.write(stdin);
	child.stdin.end();
	const stdout = await new Response(child.stdout).text();
	await child.exited;
	if (!stdout.trim()) return undefined;
	try {
		return JSON.parse(stdout) as ClaudeHookOutput;
	} catch {
		return undefined;
	}
}

/**
 * ⛔ WHY THE IDENTIFIER LINK GUARD LIVES HERE AND NOT IN `settings.json`, WHERE EVERY OTHER
 * ORCHESTRATOR HOOK IS REGISTERED. READ THIS BEFORE LOOKING FOR IT ANYWHERE ELSE.
 *
 * `/Users/jowolff/.claude/settings.json` registers eight Stop hooks, and ⛔ AN OMP SEAT RUNS NONE
 * OF THEM. This adapter's `session_stop` calls `runManifestHooks`, which reads
 * `${pluginRoot}/hooks/hooks.json` (see `hookManifest` above) — so the Stop set a seat actually
 * executes is the plugin manifest's three: `wrap-up-nudge.sh`, `context-pressure.mjs`,
 * `output-types-guard.mjs`. Nothing in OMP executes a `settings.json` hook command.
 *
 * ⛔ MEASURED 2026-09-15: every marker in `orchestrator/state/.guard-state/` stops at
 * 2026-09-10 09:37 — the OMP cutover — and every session id in those markers is a Claude Code
 * UUID, never a `seat-<name>-<epoch>`. So all eight of those Stop hooks, plus `ledger-write-guard`
 * and `brief-clause-guard` on PreToolUse, have been DARK for every seat since the cutover. A
 * `settings.json` registration for this guard would have been inert and its silence would have
 * looked exactly like a working guard until the first bare identifier reached Jo — the guard's own
 * failure mode, installed as the guard.
 *
 * SCOPED TO LINTEL FOR THE FIRST INSTALL, by Lintel's ruling and its reasoning rather than mine:
 * seats send `REQ-`, `DEC-` and `ALL-` ids bare to Lintel constantly, and blocking them
 * fleet-wide would be a behavioural change to ten seats that nobody asked for. The asymmetry
 * decides it — a bare id from a seat costs Lintel one edit; a bare id from Lintel costs Jo a
 * lookup he has now complained about twice. Widening is a separate, evidenced decision.
 *
 * COST OF HOSTING IT HERE, stated because it is the same defect the reconciliation check reports:
 * it dies with the adapter, and its death looks like silence.
 */
const URL_RESOLVER = "/Users/jowolff/.claude/orchestrator/hooks/identifier-url-resolver.mjs";

/**
 * ⛔ THE FIELDS THAT ACTUALLY CARRY TEXT UPWARD, NAMED RATHER THAN GUESSED.
 *
 * `seat_message.message` is how a seat reaches Lintel and how Lintel reaches a seat; `hub.message`
 * is the in-session equivalent; `write.content` is how a save point is authored, which is where
 * four bare kitchen PR numbers reached Jo on 2026-09-16.
 *
 * ⛔ NOT `edit`, and not `bash`. An `edit` body is source code, where `#51` is a comment or a CSS
 * colour and a rewrite would corrupt the file; `bash` is a command line, where inserting a
 * parenthesised URL changes what runs. The machinery only edits text whose destination is a human.
 */
const URL_REWRITE_FIELDS: Record<string, string> = {
	seat_message: "message",
	hub: "message",
	write: "content",
};

async function urlMachineryRewrite(
	toolName: string,
	input: Record<string, unknown>,
): Promise<Record<string, unknown> | undefined> {
	if (process.env.OMP_CURRENT_SEAT_NAME !== "Lintel") return undefined;
	const field = URL_REWRITE_FIELDS[toolName];
	if (!field) return undefined;
	const text = input[field];
	if (typeof text !== "string" || !text) return undefined;
	// Cheap prefilter: no `#123` and no `ABC-123` means no work and no subprocess.
	if (!/#\d{1,6}\b/.test(text) && !/\b[A-Z]{2,5}-\d{1,6}\b/.test(text)) return undefined;
	try {
		const outcome = await runCommand(
			`node '${URL_RESOLVER}' --rewrite`,
			JSON.stringify({ text }),
			process.cwd(),
		) as unknown as { text?: string; changed?: boolean } | undefined;
		if (!outcome?.changed || typeof outcome.text !== "string" || outcome.text === text) return undefined;
		return { ...input, [field]: outcome.text };
	} catch {
		// Fail OPEN. A rewriter that throws must never be the reason a seat cannot send a message.
		return undefined;
	}
}

const IDENTIFIER_GUARD = "/Users/jowolff/.claude/orchestrator/hooks/identifier-link-guard.mjs";

async function identifierGuardBlock(stdin: string, cwd: string): Promise<string | undefined> {
	// Lintel only. `launch-seat` exports OMP_CURRENT_SEAT_NAME per seat, so the test is exact.
	if (process.env.OMP_CURRENT_SEAT_NAME !== "Lintel") return undefined;
	try {
		// ⛔ THE RESOLVER FIRST, BECAUSE A REFUSAL CARRYING THE FINISHED URL IS A DIFFERENT
		// INSTRUMENT FROM ONE ASKING FOR IT. No tool carries a seat's final reply to Jo, so this
		// path cannot rewrite — it is the one place the weak channel is unavoidable. What it can do
		// is reduce compliance to transcription: every resolvable identifier arrives with its URL
		// already built, and only the genuinely unknowable ones ask for anything.
		const resolver = await runCommand(`node '${URL_RESOLVER}'`, stdin, cwd);
		if (resolver?.decision === "block") return resolver.reason;
		const outcome = await runCommand(`node '${IDENTIFIER_GUARD}'`, stdin, cwd);
		return outcome?.decision === "block" ? outcome.reason : undefined;
	} catch {
		// Fail OPEN, like everything else in this file: a guard on outgoing text that throws would
		// make the seat unable to speak at all.
		return undefined;
	}
}

/**
 * ⛔ PORT OF `ledger-write-guard.mjs`, WHICH HAS BEEN DARK FOR EVERY SEAT SINCE 2026-09-10 09:24.
 *
 * It DENIES a Bash redirect whose resolved target is `REQUESTS.jsonl`, using a shell lexer rather
 * than a text match — `ledger-write-guard.mjs:39-45` records that a text matcher would refuse the
 * brief that commissioned it, refuse a decision-log entry quoting the incident, and be evaded by
 * putting the path in a variable, which is what 305 of 307 real writes already do. The lexer is
 * the point; this port calls the hook rather than reimplementing it.
 *
 * WHY IT IS HERE: `settings.json` is not consulted for hook execution by OMP — see the block above
 * `IDENTIFIER_GUARD`. The original also gates on `inOrchestratorSession()`, which compares
 * `session_id` to a `summon.sh` UUID in `state/.session-id` (last written 2026-09-10 09:27) and can
 * NEVER match a seat id of the form `seat-<name>-<epoch>`. ⛔ So the ported path drops that gate and
 * substitutes the seat-name test. `session-gate.mjs` is deliberately NOT edited: every remaining
 * Claude-side hook imports it, and none of those have been reviewed.
 *
 * ⛔ THE PREFILTER IS A PERFORMANCE GUARD, NOT A DECISION. `tool_call` runs on every tool call, so
 * spawning node each time would put process-start latency on every Bash. The prefilter only
 * narrows what gets spawned; the lexer still decides. A command that never mentions the ledger
 * cannot be a direct write to it.
 */
const LEDGER_GUARD = "/Users/jowolff/.claude/orchestrator/hooks/ledger-write-guard.mjs";

/**
 * ⛔ FAIL-OPEN COUNTER, AND WHY IT IS A COUNTER RATHER THAN A FILE.
 *
 * This guard fails open — it must, because a throw in `tool_call` becomes a machine-wide tool
 * denial. But a guard that fails open SILENTLY is the defect this whole evening was spent
 * detecting: "installed, green, and permitting everything since some Tuesday" is a verbatim
 * description of the ten hooks found dark tonight.
 *
 * So every fail-open is counted and reported IN CONTEXT on the next `session_stop`, on the same
 * `additionalContext` path whose delivery was verified by quoting the reconciliation block out of
 * a live session. ⛔ NOT a file under `state/.guard-state/` — eighty files accumulated there
 * unexamined, and a guard reporting its own death into an unread directory is the same defect
 * wearing a different hat.
 *
 * COST, stated as the watchdog states its own: the counter dies with the adapter, so a crash loses
 * the tally. It is a heartbeat, not a ledger.
 */
let ledgerGuardFailOpens = 0;

const REAL_STATE = "/Users/jowolff/.claude/orchestrator/state";

/**
 * ⛔ WHY THIS SPAWN CARRIES THREE ENV OVERRIDES, AND WHY THE PORT WOULD BE INERT WITHOUT THEM.
 *
 * The hook I am calling gates itself: `ledger-write-guard.mjs:228` is
 * `if (!inOrchestratorSession(p, STATE)) allow();`, and that gate compares the payload's
 * `session_id` to `<STATE>/.session-id` — a `summon.sh` UUID that a seat id can never equal.
 * **Calling the hook unchanged would have produced a guard that ran, evaluated, and allowed
 * everything.** I caught that before installing, which is the third inert-instrument trap tonight.
 *
 * So the gate is answered on its own terms rather than bypassed or edited:
 *   LINTEL_STATE            -> a scratch dir whose `.session-id` holds THIS seat's real session id,
 *                              so the gate's question ("is this the session I was armed for?") gets
 *                              a truthful yes. `session-gate.mjs` is NOT touched.
 *   LEDGER_GUARD_TARGET     -> the REAL `REQUESTS.jsonl`. Without this, redirecting LINTEL_STATE
 *                              would silently retarget the guard at the scratch dir and it would
 *                              protect a file nobody writes.
 *   LEDGER_GUARD_LOG        -> the REAL log, for the same reason.
 * All three are documented overrides in the hook (`:113-115`). No spoofed session id reaches the
 * log: the payload carries this seat's true `OMP_SESSION_ID` via `hookInput`.
 */
function gateDir(): string {
	const dir = join(tmpdir(), "omp-ledger-guard-gate", process.env.OMP_SESSION_ID ?? "unknown");
	mkdirSync(dir, { recursive: true });
	writeFileSync(join(dir, ".session-id"), `${process.env.OMP_SESSION_ID ?? "unknown"}\n`);
	return dir;
}

async function ledgerGuardDeny(toolName: string, input: Record<string, unknown>, cwd: string): Promise<string | undefined> {
	if (process.env.OMP_CURRENT_SEAT_NAME !== "Lintel") return undefined;
	if ((toolNames[toolName] ?? toolName) !== "Bash") return undefined;
	const command = typeof input.command === "string" ? input.command : "";
	if (!command.includes("REQUESTS.jsonl")) return undefined;   // prefilter; see above
	try {
		const env = `LINTEL_STATE='${gateDir()}'`
			+ ` LEDGER_GUARD_TARGET='${join(REAL_STATE, "REQUESTS.jsonl")}'`
			+ ` LEDGER_GUARD_LOG='${join(REAL_STATE, "ledger-write-guard.jsonl")}'`;
		const outcome = await runCommand(`${env} node '${LEDGER_GUARD}'`, hookInput(toolName, input, cwd), cwd);
		const decision = outcome?.hookSpecificOutput;
		if (decision?.permissionDecision === "deny") return decision.permissionDecisionReason ?? "Direct ledger write blocked.";
		return undefined;
	} catch {
		ledgerGuardFailOpens += 1;
		return undefined;
	}
}

/**
 * ⛔ BUY THE MODEL ONE TURN BEFORE THE FIRST COMPACTION, SO A HANDOFF EXISTS TO SURVIVE IT.
 *
 * Jo, three times now, most recently: "the pre-compact took fire but didn't do what we needed it
 * to. We needed it to actually work for us. I don't care if all it does is actually run newdle
 * wrap-up, which I also think creates a session handover."
 *
 * He is right that `/wrap-up` reaches a handoff — `compact-continuity.mjs:483-484` says it "now
 * writes a handoff itself when real state is left over". What a hook cannot do is RUN it: a hook is
 * a shell command and cannot hand the model a turn. **The veto is what closes that gap.**
 *
 * ── WHY THE INSTRUCTION IS DELIVERED FROM `session_stop` AND NOT FROM THIS EVENT ─────────────
 *
 * `SessionBeforeCompactResult` carries exactly two fields — `{ cancel, compaction }`
 * (shared-events.ts:376-381). ⛔ THERE IS NO TEXT CHANNEL ON THIS EVENT. `systemMessage` is not an
 * alternative: `compact-continuity.mjs:472` records that it "reaches the USER, not the model".
 * `pi.sendMessage` was the candidate, and measured against the live adapter this handler makes ZERO
 * sendMessage calls today, so whether a message sent from THIS event reaches the model is UNPROVEN
 * and cannot be proven without a live compaction.
 *
 * So the instruction rides the channel that WAS proven tonight, by quoting the reconciliation block
 * out of a live session and by the identifier guard's A/B: a `session_stop` block. The sequence is
 *   crossing -> cancel (silent) -> the turn continues and ends -> Stop blocks with the instruction
 *   -> the model authors the handoff -> the next crossing compacts unconditionally.
 * ⛔ A Stop block both delivers text AND forces a turn, which is strictly more than `sendMessage`
 * would have given even if it worked.
 *
 * ── ONE CANCEL PER SESSION, UNCONDITIONALLY ──────────────────────────────────────────────────
 *
 * A veto that can repeat is a wall rather than a degradation, and at `thresholdPercent: 25` on a 1M
 * window that wall is at 250,000. The flag is module-level and needs no file: compaction does not
 * restart the process — proven by this adapter's own `session_compact` handler running afterwards in
 * the same loaded module — so it cannot be lost by the compaction it manages. A marker under
 * `state/.guard-state/` would be litter; eighty files accumulated there unexamined.
 *
 * ── WHAT IT DELIBERATELY DOES NOT DO ─────────────────────────────────────────────────────────
 *
 * It does not veto when a handoff is already on disk (the veto exists to produce one, not to delay
 * compaction), when `customInstructions` is present (⛔ one-way test: present PROVES a directed
 * manual `/compact`; absent proves auto OR a bare manual one, and vetoing a bare manual compact
 * once costs a visible "Compaction cancelled" that succeeds on retry), or outside a seat launch.
 */
let compactionVetoUsed = false;
let handoffInstructionPending = false;

/** A handoff written within the day, in either shape `compact-continuity` reads. */
function freshHandoffExists(cwd: string): boolean {
	const day = 24 * 60 * 60 * 1000;
	const candidates = [join(cwd, ".ai", "session-handoff.md")];
	try {
		const dir = join(cwd, ".ai", "handoffs");
		for (const name of readdirSync(dir)) candidates.push(join(dir, name));
	} catch { /* no handoffs directory is the common case */ }
	for (const path of candidates) {
		try {
			if (Date.now() - statSync(path).mtimeMs < day) return true;
		} catch { /* unreadable candidate is not a handoff */ }
	}
	return false;
}

function vetoForHandoff(event: { customInstructions?: string }, cwd: string): { cancel: true } | undefined {
	if (!process.env.OMP_CURRENT_SEAT_NAME) return undefined;
	if (compactionVetoUsed) return undefined;                  // the unconditional second crossing
	if (event.customInstructions) return undefined;            // a directed manual compaction
	if (freshHandoffExists(cwd)) return undefined;             // the judgment layer already exists
	compactionVetoUsed = true;
	handoffInstructionPending = true;
	return { cancel: true };
}

/**
 * The instruction. ⛔ SHORT ON PURPOSE. Levitt crossed six times in 3m40s and inferred that the
 * injected restoration block is itself part of what causes the next crossing — so an instruction
 * long enough to be thorough is an instruction that helps cause the compaction it is trying to
 * prepare for. It must be actionable inside one turn.
 */
function handoffInstruction(): string | undefined {
	if (!handoffInstructionPending) return undefined;
	handoffInstructionPending = false;
	return "⛔ **Compaction was cancelled once to give you this turn. Write the handoff NOW** — run"
		+ " `/handoff`, or `/wrap-up` if this session is ending. The next threshold crossing will"
		+ " compact unconditionally, and the judgment layer — what you were attempting, what you"
		+ " ruled out, what is still open — is not recoverable from mechanical state. Do this before"
		+ " anything else, and keep it short.";
}

function ledgerGuardNotice(): string | undefined {
	if (ledgerGuardFailOpens === 0) return undefined;
	const n = ledgerGuardFailOpens;
	ledgerGuardFailOpens = 0;
	return `⛔ **ledger-write-guard failed open ${n} time${n === 1 ? "" : "s"} this session.**`
		+ ` Command${n === 1 ? "" : "s"} touching \`REQUESTS.jsonl\` were NOT validated — the guard`
		+ " could not run, and allowed the call rather than denying every tool call. Treat any ledger"
		+ " write in this session as unchecked and re-run `tools/requests-schema-check.sh`.";
}

/**
 * ⛔ THE SUBSTRING THAT KEEPS THE ANCHOR OFF EVERY HOOK THAT `cd`s.
 *
 * Verified against the literal command strings in `0.2.169/hooks/hooks.json` rather than assumed.
 * The `SessionStart` group holds six hooks:
 *   `recent-activity.sh`, `session-snapshot.mjs`, `compact-continuity.mjs` (matcher `compact`),
 *   `output-types-inject.mjs`, `shipyard-conventions-inject.mjs`, `compaction-liveness.mjs`.
 * Exactly one command contains `compact-continuity`. Note the near miss that rules out the
 * shorter candidate: `compaction-liveness.mjs` contains `compact`, so `"compact"` would redirect
 * two hooks, not one.
 */
export const CONTINUITY_HOOK_ONLY = "compact-continuity";

/**
 * Which `CLAUDE_PROJECT_DIR` a single hook in a group is spawned with.
 *
 * Extracted from the loop below so the decision is assertable without spawning anything; the
 * expression is unchanged. `projectDirOnlyFor` unset keeps the old whole-group behaviour, which
 * is still correct for a group holding one hook.
 */
export function hookProjectDirFor(
	command: string,
	projectDir: string | undefined,
	projectDirOnlyFor: string | undefined,
): string | undefined {
	return projectDir && (!projectDirOnlyFor || command.includes(projectDirOnlyFor)) ? projectDir : undefined;
}

/**
 * Invoke the manifest's hooks for a lifecycle event.
 *
 * `matchers` names which matcher-bearing groups to run alongside the matcherless ones. The only
 * matcher these lifecycle groups carry is `SessionStart:compact`, the RESTORE half of the
 * compaction save.
 *
 * ⛔ THIS PARAMETER EXISTS BECAUSE THE PREVIOUS VERSION SKIPPED EVERY MATCHER-BEARING GROUP AND
 * SAID WHY IN A COMMENT THAT WAS FALSE. The comment claimed OMP "does not yet provide the Claude
 * compact payload". Sedge disproved it by experiment on 2026-09-15: the installed 0.2.166
 * `compact-continuity.mjs` was fed a four-field OMP-shaped payload and wrote a valid snapshot at
 * exit 0. The hook was never blocked — it was opted out, and the opt-out outlived its reason from
 * 2026-08-03 to 2026-09-15 because the justification sat above the code and nobody re-tested it.
 *
 * The restore half is the half that matters more: a save nobody reads back is a file, not a
 * recovery. Lintel lost session state on 2026-09-15 at 543,700 tokens and would have lost it even
 * if the save had been written, because nothing consumed it.
 */
async function runManifestHooks(
	eventName: "SessionStart" | "SessionEnd" | "Stop" | "PreCompact",
	stdin: string,
	cwd: string,
	matchers: string[] = [],
	projectDir?: string,
	// ⛔ PER-HOOK, NOT PER-GROUP, and that distinction is the whole safety of the Stop redirect.
	// When set, `projectDir` reaches ONLY hooks whose command contains this substring; every
	// other hook in the same group keeps the seat's real cwd.
	//
	// It is possible at all because the spawn is per-hook: the loop below iterates hooks and
	// `runCommand` builds its own `env` for each one. The Stop group holds three hooks, and
	// `wrap-up-nudge.sh` is one of the three shell hooks that `cd` to CLAUDE_PROJECT_DIR
	// (with session-end-reminder.sh and recent-activity.sh). Redirecting the whole group would
	// make wrap-up write relative to the anchor, silently. Excluded BY NAME, not by hope.
	projectDirOnlyFor?: string,
) {
	const raw = await Bun.file(hookManifest).json();
	const groups = raw?.hooks?.[eventName];
	if (!Array.isArray(groups)) return { additionalContext: [] as string[], blockReason: undefined as string | undefined };

	const additionalContext: string[] = [];
	let blockReason: string | undefined;
	for (const group of groups) {
		const matcher = typeof group.matcher === "string" ? group.matcher : "";
		if (matcher && !matchers.includes(matcher)) continue;
		for (const hook of group.hooks ?? []) {
			if (hook.type !== "command" || typeof hook.command !== "string") continue;
			// ⛔ AWAITED, and that is load-bearing rather than incidental. The Claude-side
			// registration of this same script carries `"async": true`, which is why a failure
			// there was indistinguishable from a success. Here the spawn is awaited, and OMP in
			// turn awaits this handler: runner.ts:1349 routes fire-and-forget ONLY for
			// `session_shutdown` (:1357-1370); every other event including `session_before_compact`
			// runs the serial `await` loop at :1372-1391. So the save cannot race the compaction
			// that destroys the context it is saving.
			const result = await runCommand(hook.command, stdin, cwd, hookProjectDirFor(hook.command, projectDir, projectDirOnlyFor));
			if (result?.decision === "block" && result.reason) blockReason ??= result.reason;
			const output = result?.hookSpecificOutput;
			if (output?.hookEventName === eventName && output.additionalContext) {
				additionalContext.push(output.additionalContext);
			}
		}
	}
	return { additionalContext, blockReason };
}

function textFromMessage(message: unknown) {
	if (!message || typeof message !== "object") return undefined;
	const candidate = message as { role?: unknown; content?: unknown };
	if (candidate.role !== "user") return undefined;
	if (typeof candidate.content === "string") return candidate.content;
	if (!Array.isArray(candidate.content)) return undefined;
	const text = candidate.content
		.filter((part): part is { type?: unknown; text?: unknown } => Boolean(part && typeof part === "object"))
		.filter(part => part.type === "text" && typeof part.text === "string")
		.map(part => part.text)
		.join("\n");
	return text || undefined;
}

/**
 * ⛔ WHY THE FILE-OPERATION RECORD CAME BACK EMPTY, AND IT WAS THIS FUNCTION'S FAULT.
 *
 * `preparation.fileOps` is `{read, written, edited}` where **each value is a `Set`**
 * (`compaction.ts:119-140`: `fileOps.read.add(...)`). `JSON.stringify(new Set(["a"]))` is `"{}"`,
 * so the old line below serialized every populated Set to an empty object and the snapshot
 * announced `{"read":{},"written":{},"edited":{}}` no matter what the session did.
 *
 * MEASURED IN PRODUCTION, not predicted: this repo's own compaction at 852,235 tokens on
 * 2026-09-16 handed back exactly that after a session that wrote a staged adapter, an A/B
 * harness, a probe, a spec and five journal entries. **A reader trusting that record concludes
 * the session touched no files.** Sets are now expanded, and the render says how many.
 */
function expandFileOps(fileOps: unknown): { rendered: string; counted: number } {
	if (!fileOps || typeof fileOps !== "object") return { rendered: "", counted: 0 };
	const lines: string[] = [];
	let counted = 0;
	for (const [kind, value] of Object.entries(fileOps as Record<string, unknown>)) {
		const paths =
			value instanceof Set ? [...value] : Array.isArray(value) ? value : value ? [value] : [];
		const texts = paths.map(entry => String(entry)).filter(Boolean).sort();
		counted += texts.length;
		lines.push(
			texts.length
				? `**${kind}** (${texts.length})\n${texts.map(path => `- ${path}`).join("\n")}`
				: `**${kind}** (0)`,
		);
	}
	return { rendered: lines.join("\n\n"), counted };
}

function continuitySnapshot(preparation: {
	messagesToSummarize: unknown[];
	tokensBefore: number;
	fileOps: unknown;
}, cwd: string): OmpContinuitySnapshot {
	const userIntents = preparation.messagesToSummarize
		.map(textFromMessage)
		.filter((text): text is string => Boolean(text))
		.slice(-3)
		.map(text => text.slice(0, 1_500));
	let fileOperations = "(no file-operation summary available)";
	try {
		const expanded = expandFileOps(preparation.fileOps);
		// ⛔ SAY WHEN IT IS EMPTY RATHER THAN PRINTING AN EMPTY OBJECT. A zero here is a real
		// answer — a session that read nothing — and it must not look like a serializer failure.
		fileOperations = expanded.counted
			? expanded.rendered.slice(0, 6_000)
			: `(the host reported no file operations across ${Object.keys((preparation.fileOps ?? {}) as object).length} categories)`;
	} catch {
		// Keep OMP's native compaction running if an extension or provider supplies
		// a non-serializable operation detail.
	}
	// ⛔ SELF-DATING. The measured failure was a three-hour-old record that read as authoritative
	// because nothing in it said when it was taken. A snapshot that carries its own timestamp can
	// be doubted by its reader; one that does not, cannot.
	return {
		version: 1,
		cwd,
		tokensBefore: preparation.tokensBefore,
		userIntents,
		fileOperations,
		capturedAt: new Date().toISOString(),
	};
}

// ---- BEGIN SHARED PRUNE REGION (byte-identical across lineages; asserted by continuity-freshness-ab.ts) ----

/** A week, after which a crossing is worth less than the directory entry it costs. */
const ARCHIVE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1_000;
/** Crossings retained per session — enough to cover a long seat's whole compaction history. */
const ARCHIVE_KEEP_PER_SESSION = 12;

/**
 * One prune candidate: a record, the instant it is ordered by, and WHICH CLOCK that instant came
 * from.
 *
 * ⛔ THE CLOCK IS CARRIED RATHER THAN INFERRED, because the two are not interchangeable and a
 * consumer that cannot tell them apart has to guess. `at` is the record's own `crossedAt` when
 * `dated` is true — a fact about the crossing, written once by the crossing itself — and the
 * file's mtime when it is false, which is only ever an estimate of it.
 */
export type ArchivePruneEntry = {
	/** The `.md` filename, which is what a record is deleted by. */
	name: string;
	/**
	 * The crossing instant when `dated`, the mtime otherwise. Milliseconds either way, but NOT one
	 * clock's worth: the ordering compares an `at` only against others of the same `dated`.
	 */
	at: number;
	/** True when `at` came out of the record's own sidecar. */
	dated: boolean;
};

/**
 * One prune candidate for one record, dated by the crossing it describes.
 *
 * ⛔ `crossedAt` FIRST AND mtime ONLY AS A FALLBACK, WHICH IS THE DEFECT THIS FUNCTION CLOSES.
 * The prune used to order candidates by `statSync().mtimeMs` while the freshness reader next door
 * refused that same clock in so many words — see the doctrine on `latestArchiveSidecar`, which
 * already argued this for the read half and noted that the prune did not follow it. So the two
 * halves of one tier asked the same question with two different clocks, and only one of them is a
 * fact about the crossing: a `touch`, a `cp -r`, a backup restore or a skewed clock could not fake
 * freshness, but COULD make eviction drop the wrong crossing. Eviction is the irreversible half.
 *
 * ⛔ AN UNREADABLE SIDECAR IS NEITHER TIMESTAMP ZERO NOR INFINITELY NEW. Either would settle the
 * record's fate on the one thing that has no bearing on it — that its sidecar could not be read —
 * by making it the first thing evicted or the last. mtime is a poor answer to "which crossing is
 * this" and a real one nonetheless, so an undated record is ordered by the only instant it has,
 * against the only records that instant can honestly be compared with: the other undated ones.
 *
 * ⛔ COHORT FIRST, AND NOT MERELY AS A TIE-BREAK: EVERY DATED RECORD OUTRANKS EVERY UNDATED ONE,
 * and mtime orders nothing except the inside of the undated bucket. Interleaving the two instants
 * on one number line — undated losing only an exact-millisecond tie — is the cleverer-looking
 * option and it is the wrong one, for three reasons in rising order of weight.
 *
 * 1. THE TRANSITION WINDOW IS THE CASE THAT HAPPENS NEXT. On the first patched run the archive is
 *    full of undated records — written before sidecars existed — carrying whatever recent mtimes
 *    the last `cp -r`, restore or edit gave them, beside one or two dated records at most.
 *    Interleaved, those recent mtimes evict the first dated records ever written, destroying the
 *    new tier's records at the one moment it has almost none. Cohort-first drains the undated
 *    backlog instead, so the tier accumulates from its first crossing.
 * 2. AN UNDATED RECORD CANNOT BE SERVED AT ALL. A missing, truncated or version-mismatched
 *    sidecar is exactly what `parseArchiveSidecar` refuses, so only a human can read that
 *    crossing. Keeping one at the cost of a servable record is a strict loss of the capability
 *    this tier exists to provide.
 * 3. INTERLEAVING REINSTATES THE UNTRUSTWORTHY CLOCK AS A RANKING KEY AGAINST THE TRUSTWORTHY
 *    ONE. The whole premise of this function is that mtime answers "when was this file last
 *    handled" and not "which crossing is this". Letting it outrank a `crossedAt` contradicts that
 *    premise, and does so precisely where the record it would save cannot be served anyway.
 *
 * ⛔ THE COUNTER-ARGUMENT IS REAL AND IS ACCEPTED HERE, NOT OVERLOOKED. It is written down because
 * a reader who meets only the words "cohort-first" will take interleaving for strictly better
 * information and reverse this. An undated record's mtime IS weak evidence of its crossing time,
 * and cohort-first WILL evict a newer undated record ahead of an older dated one. What that case
 * loses is a human-readable `.md` this tier could never serve, and the exposure is bounded to the
 * transition window reason 1 describes. That is the price of reason 1, knowingly paid.
 *
 * A record whose `.md` has vanished under us — a co-resident seat's prune runs in another process
 * — yields NOTHING rather than a zero. It is not a candidate, because it is not there.
 */
export function archivePruneEntry(archiveDir: string, name: string): ArchivePruneEntry | undefined {
	const path = join(archiveDir, name);
	const crossing = archiveCrossedAt(path);
	if (crossing !== undefined) return { name, at: crossing, dated: true };
	try {
		return { name, at: statSync(path).mtimeMs, dated: false };
	} catch {
		return undefined;
	}
}

/**
 * Every prune candidate in the archive directory.
 *
 * ⛔ ONE ENTRY PER RECORD, WHICH IS WHY ONLY `.md` IS LISTED. Counting the `.json` halves as
 * entries too would silently halve the per-session cap; the pair is resolved at DELETION time by
 * `archiveRecordFiles`, so the two halves cannot disagree about what exists.
 *
 * Listing and dating live together here, inside the region both lineages are asserted
 * byte-identical across, so no call site can pick a different clock than this one.
 */
export function archivePruneEntries(archiveDir: string): ArchivePruneEntry[] {
	const entries: ArchivePruneEntry[] = [];
	for (const name of readdirSync(archiveDir)) {
		if (!name.endsWith(".md")) continue;
		const entry = archivePruneEntry(archiveDir, name);
		if (entry) entries.push(entry);
	}
	return entries;
}

/**
 * Which archive files this crossing should delete: the caller's own oldest beyond the cap, plus
 * anything past the age limit.
 *
 * ⛔ NEVER DELETES ANOTHER SESSION'S FILE FOR BEING NUMEROUS, only for being a week old. That
 * restriction is the whole fix; see the comment at the call site for the measurement.
 * Exported as the seam the A/B asserts against, since the alternative is asserting on `rmSync`.
 *
 * ⛔ AND "OLDEST" MEANS OLDEST CROSSING. Both rules read `entry.at`, which `archivePruneEntry`
 * fills from the record's own sidecar wherever it can, so the age limit is a week since the
 * crossing rather than a week since the file was last handled — and a co-resident seat's record
 * cannot be aged out by a `cp -r` that rewrote its mtime this morning.
 */
export function archivePruneTargets(
	entries: ArchivePruneEntry[],
	sessionId: string,
	now: number,
): string[] {
	const doomed = new Set<string>();
	const mine = entries
		.filter(entry => entry.name.startsWith(`${sessionId}--`))
		// Newest first, so `.slice` keeps the head and the tail is what goes. Cohort first: every
		// dated record outranks every undated one and mtime orders only within the undated bucket,
		// per `archivePruneEntry` — which also records the counter-argument that choice accepts.
		.sort((a, b) => (a.dated === b.dated ? b.at - a.at : Number(b.dated) - Number(a.dated)))
		.slice(ARCHIVE_KEEP_PER_SESSION);
	for (const entry of mine) doomed.add(entry.name);
	for (const entry of entries) {
		if (now - entry.at > ARCHIVE_MAX_AGE_MS) doomed.add(entry.name);
	}
	return [...doomed];
}

// ---- END SHARED PRUNE REGION ----

/**
 * ⛔ A COPY THE RESTORE CANNOT EAT.
 *
 * `compact-continuity.mjs:573` does `unlinkSync(chosen.path)` on the snapshot it restores — one
 * shot, by design, and right: a stale snapshot that keeps re-injecting is worse than none. But it
 * means **the artifact is destroyed by the very restore that proves it worked**, so "after a real
 * compaction a durable artifact exists on disk" is unsatisfiable against that file alone. Measured
 * 2026-09-16: Levitt's `PreCompact` logged `ok` twice at 05:07:42 and 05:07:50, its `SessionStart`
 * restore ran at 05:08:21, and `session-state--seat-levitt-1789535218-18088.md` is gone — consumed,
 * not missing.
 *
 * So the bridge keeps its own archive. Not a second save path: a retained COPY of the plugin's
 * file plus the host payload that produced it, named by session and crossing so six crossings
 * leave six readable records instead of overwriting one. Pruned per session and by age, never
 * across sessions by count — see the prune at the bottom of this function.
 */
function archiveRoot(cwd: string): string {
	for (let dir = cwd; ; ) {
		if (existsSync(join(dir, ".git"))) return dir;
		const parent = dirname(dir);
		if (parent === dir) return cwd;
		dir = parent;
	}
}

// ---- BEGIN SHARED SIDECAR REGION (byte-identical across lineages; asserted by continuity-freshness-ab.ts) ----

/**
 * ⛔ THE MACHINE-READABLE HALF OF A CROSSING, AND WHY THE PROSE HALF COULD NOT DO THIS JOB.
 *
 * The `.md` this sits beside is `renderContinuity` output: user intents as a numbered list of up
 * to 1,500 characters of arbitrary multi-line prose, then a `---` rule, then the plugin's
 * snapshot verbatim, which can itself contain `---` and numbered lines. Parsing that back into an
 * `OmpContinuitySnapshot` means guessing where one intent ends and the next begins, and a restore
 * that silently mis-splits an intent is the same class of failure as the staleness being fixed: a
 * confident record that is wrong. So the writer emits the snapshot it ALREADY HOLDS, in its own
 * shape, and no reader ever parses the prose.
 *
 * `sidecarVersion` is the SIDECAR's schema and is deliberately separate from
 * `OmpContinuitySnapshot.version`, which must stay `1` for the restore gate's sake (see the
 * comment on `capturedAt`). A reader that meets an unknown `sidecarVersion` REFUSES the file
 * rather than guessing at its shape, so a bump here must ship with a reader that handles both.
 *
 * ⛔ VERSION 2 ADDED SEAT IDENTITY AND WRITER IDENTITY, AND REFUSING VERSION 1 IS THE POINT OF THE
 * BUMP. A v1 record carried a session id and nothing else, and a session id is minted fresh at
 * every launch (`orchestrator/build/omp-no-env-file/launch-seat.staged:279`), so a v1 file cannot
 * answer the question the seat key exists to answer — is this the same seat — nor the question the
 * liveness refusal asks, which is whether the process that wrote it has ended. The alternative to
 * refusing it is inferring a seat from a filename, which is the guess this whole tier is built to
 * avoid. Refusing costs a restore one crossing's freshness; guessing costs it its truthfulness.
 */
const ARCHIVE_SIDECAR_VERSION = 2;

/**
 * WHO THIS PROCESS IS, in the terms a record on disk can be matched against.
 *
 * ⛔ THE SEAT NAME IS NOT PROOF OF BEING THE SEAT, AND ON 2026-09-16 THAT COST LINTEL A MESSAGE.
 * `OMP_CURRENT_SEAT_NAME` is an environment variable and `hub start` inherits the shared project
 * broker's environment, so a harness that came up in `/Users/jowolff/.claude` held the name
 * `Lintel`, drained Lintel's real mailbox and consumed a Wren -> Lintel envelope while the real
 * Lintel sat at another pid. That file now refuses to act as a seat on the env var alone and
 * writes both halves of the identity into its receipts — the doctrine and the derivation are at
 * `~/.omp/agent/extensions/persistent-seat-registry.ts:956-985`, the two-field receipt at
 * `:1162-1169`. A continuity tier that served another seat's state off an inherited env var would
 * be that same defect with a different payload, so this key carries the same two halves.
 *
 * `provenSeat` is derived exactly as the registry derives it: from THIS process's own
 * `--session-dir` argv, which the launcher owns and which an inherited environment cannot forge.
 * It is re-derived here rather than imported on purpose — the registry is a separately installed
 * extension with its own lifecycle, and a restore that fails because a sibling extension moved is
 * a worse failure than eight duplicated lines. `""` means argv proves nothing, which is the
 * harness case, and the matcher below treats it as the refusal it is.
 *
 * `repoRoot` is here because an archive is a directory and directories get copied. A record
 * carried into another checkout by `cp -r` or a backup restore still names the root it was
 * written under, and stops matching.
 */
export type ArchiveIdentity = {
	/** `OMP_SESSION_ID`, normalised for a filename. New at every launch. */
	sessionId: string;
	/** The seat name this process CLAIMS, lowercased. `""` when unset. Never trusted alone. */
	seat: string;
	/** The seat slug this process's own argv PROVES. `""` when argv proves nothing. */
	provenSeat: string;
	/** The repo the archive belongs to. */
	repoRoot: string;
};

/** Where a matched record came from, in the only two forms this tier will serve. */
export type ArchiveRecordOrigin = "this-session" | "same-seat-other-session";

/**
 * What one scan of the archive found, INCLUDING what it refused and why.
 *
 * ⛔ THE REFUSAL COUNT IS NOT TELEMETRY, IT IS THE DIFFERENCE BETWEEN TWO DIAGNOSES. "No record
 * for this seat exists" and "a record exists but the process that wrote it is still running" both
 * end in a silent fall-through to tier 2, and they call for opposite responses from a reader: the
 * first says the archive never had it, the second says another process has this seat's continuity
 * right now. This file's own rule is that a restore which serves nothing must say why (see
 * `continuityMessage`), and a refusal that renders identically to an absence breaks it.
 */
export type ArchiveLookup = {
	/** The record that may be served, if any. */
	sidecar?: ArchiveSidecar;
	/** Same-seat records refused because their writer is still running. */
	liveSiblingRefusals: number;
	/**
	 * Records under THIS session's own id, refused because a DIFFERENT live pid wrote them.
	 *
	 * ⛔ COUNTED SEPARATELY FROM `liveSiblingRefusals` BECAUSE IT IS A DIFFERENT DIAGNOSIS. A live
	 * sibling seat means another run of this seat holds its own continuity, which is ordinary
	 * concurrency and nobody's fault. Two live processes sharing ONE session id means the id was
	 * inherited from an environment rather than minted for this launch
	 * (`persistent-seat-registry.ts:956-970`), which is the forgery case and never a legitimate
	 * resume. Conflating them would send a reader looking for a sibling seat when the real fault is
	 * in how this process's environment was built.
	 */
	sharedSessionRefusals: number;
	/**
	 * The boot identity the scan judged against.
	 *
	 * ⛔ CARRIED RATHER THAN RE-DERIVED, because the provenance restates the liveness conclusion in
	 * words and a second reading could restate it WRONGLY. A render that re-derived this would
	 * describe a decision nobody made: the scan could have adopted a record on the ground that it
	 * predates this boot while the text claimed its pid merely stopped answering, or the reverse.
	 * One reading, one decision, one sentence about it.
	 */
	hostBootId: number;
};

export type ArchiveSidecar = {
	sidecarVersion: number;
	/** The session that wrote it. Re-checked on read: the archive directory is shared. */
	sessionId: string;
	/** The seat that session claimed to be. */
	seat: string;
	/** The seat slug that session's argv proved. `""` when it could prove none. */
	provenSeat: string;
	/** The repo root it was written under. */
	repoRoot: string;
	/**
	 * The pid that wrote it, with `bootId` naming the boot that pid belongs to. Consulted for
	 * EVERY candidate — see `archiveWriterIsLive`. For a cross-session record the pair is the
	 * difference between a dead predecessor and a live sibling; for a record under this session's
	 * own id it is the difference between a resume and an inherited session id being worn by a
	 * second live process. A pid without its boot means nothing: pids are reused across reboots,
	 * so the pair is the unit and both are required.
	 */
	writerPid: number;
	bootId: number;
	/**
	 * ⛔ THE ONLY CLOCK THE FRESHNESS DECISION IS ALLOWED TO USE. A prune, a `cp -r`, a backup
	 * restore or a bare `touch` all move mtime, and every one of them would fake freshness on a
	 * record whose CONTENT did not move. This field is written once, by the crossing it describes,
	 * and never again.
	 */
	crossedAt: string;
	snapshot: OmpContinuitySnapshot;
	/** Where it was read from. Not part of the file; filled in by the reader, for provenance. */
	path?: string;
	/** How it matched this process. Not part of the file; decided by the reader. */
	origin?: ArchiveRecordOrigin;
};

/** This seat's session id, normalised for use in a filename. */
function archiveSessionId(): string {
	return (process.env.OMP_SESSION_ID ?? "omp-spike").replaceAll(/[^A-Za-z0-9._-]/g, "-");
}

/**
 * The seat slug this process's `--session-dir` argv proves it is, or `""`.
 *
 * Mirrors `persistent-seat-registry.ts:976-985` deliberately, including the `seat-sessions` parent
 * check: a bare `--session-dir /tmp/whatever` proves the process is NOT a seat, which is the
 * answer wanted. `argv` is a parameter so the A/B can exercise both outcomes without needing two
 * processes.
 */
function launcherProvenSeat(argv: readonly string[] = process.argv): string {
	const flag = argv.indexOf("--session-dir");
	if (flag < 0) return "";
	const dir = argv[flag + 1];
	if (!dir) return "";
	const parts = dir.replaceAll(/\/+$/g, "").split("/");
	return parts.at(-2) === "seat-sessions" ? parts.at(-1) ?? "" : "";
}

/** This process's identity, normalised once so every comparison below is a string equality. */
export function archiveIdentity(cwd: string, argv: readonly string[] = process.argv): ArchiveIdentity {
	return {
		sessionId: archiveSessionId(),
		seat: (process.env.OMP_CURRENT_SEAT_NAME ?? "").trim().toLowerCase(),
		provenSeat: launcherProvenSeat(argv).trim().toLowerCase(),
		repoRoot: archiveRoot(cwd),
	};
}

/**
 * WHEN THIS MACHINE BOOTED, as whole seconds since the epoch — the second half of a writer's
 * identity, and the thing that makes a pid mean anything at all.
 *
 * ⛔ MEASURED ON DARWIN 2026-09-16 BEFORE BEING RELIED ON, because the mechanism is only sound if
 * `uptime()` tracks WALL time since boot rather than awake time. On this host, up 371,843s across
 * four days and many sleeps, `Math.round((Date.now() - uptime() * 1000) / 1000)` returned
 * `1789186923` and `sysctl -n kern.boottime` returned `{ sec = 1789186923 }` — identical, so sleep
 * IS counted and the derived instant is the real boot instant. Had it excluded sleep, the derived
 * instant would drift forward at every wake and one boot would look like many.
 *
 * ⛔ ROUNDED TO SECONDS, BECAUSE THE INPUTS JITTER. This is a DERIVED instant: both terms move
 * between readings and `uptime()` has one-second granularity. Twelve readings 120ms apart on the
 * same host spanned two adjacent integers (`…923`/`…924`), so the value is stable only to about a
 * second — which is why the comparison below is a tolerance and not `===`.
 */
export function bootIdentity(now: number = Date.now(), uptimeSeconds: number = uptime()): number {
	return Math.round((now - uptimeSeconds * 1_000) / 1_000);
}

/**
 * How far two boot identities may differ and still be the same boot.
 *
 * ⛔ A TOLERANCE RATHER THAN EQUALITY, AND THE DIRECTION IS WHY IT IS NOT FUSSINESS. "Different
 * boot" is the one branch below that turns a refusal into an ADOPTION, so a spurious mismatch is
 * the only way this machinery could serve a live sibling's state. The measured jitter is one
 * second (see `bootIdentity`), two adjacent readings can straddle a second boundary, and two
 * seconds of slack absorbs both. It stays far below any real reboot, which moves the boot instant
 * by the previous boot's entire uptime plus the downtime.
 */
const BOOT_ID_TOLERANCE_S = 2;

/** The repo's archive directory. ⛔ Shared by every seat in the repo — see the prune. */
function archiveDirFor(cwd: string): string {
	return join(archiveRoot(cwd), ".ai", "omp-compaction-archive");
}

/** The sidecar beside an archive `.md`, by construction rather than by search. */
export function sidecarPathFor(markdownPath: string): string {
	return `${markdownPath.endsWith(".md") ? markdownPath.slice(0, -3) : markdownPath}.json`;
}

/**
 * The files that make up ONE archive record.
 *
 * ⛔ THE PRUNE DELETES RECORDS, NOT FILES, and this function is the whole of that promise. Two
 * halves pruned independently can disagree about what exists: a `.json` whose `.md` is gone reads
 * as a recoverable crossing with no human-readable copy, and an `.md` whose `.json` is gone
 * silently disables the durable tier for that crossing while still looking like a saved record.
 * Both halves go, or neither does.
 */
export function archiveRecordFiles(markdownName: string): string[] {
	return [markdownName, sidecarPathFor(markdownName)];
}

/**
 * The sidecar's size, or `0` when there is none.
 *
 * A `0` in a heartbeat row is the visible form of "the durable tier is blind for that crossing",
 * which is the same reason the row already carries byte and intent counts instead of a green word.
 */
export function sidecarBytesFor(markdownPath: string): number {
	try {
		return statSync(sidecarPathFor(markdownPath)).size;
	} catch {
		return 0;
	}
}

/**
 * The instant a sidecar payload names for its crossing, with the string it was read from, or
 * `undefined` when the payload will not say.
 *
 * ⛔ ONE OWNER FOR "WHICH SHAPE DO WE SPEAK, AND WHERE IS THE CROSSING INSTANT". Two readers ask
 * it — `parseArchiveSidecar`, which serves a snapshot, and `archivePruneEntry`, which orders
 * records for eviction — and a second copy of the answer is how a `sidecarVersion` bump leaves
 * one of them reading a shape the writer no longer emits. The prune therefore never parses this
 * file's JSON on its own terms; it asks here, exactly as the restore does.
 *
 * ⛔ IDENTITY IS DELIBERATELY NOT CHECKED HERE, and the caller that needs it checks it itself.
 * Identity decides what may be SERVED; this answers only when a crossing happened, which is as
 * true of a co-resident seat's record as of this session's. Gating it would drop every other
 * seat's record into the prune's undated cohort, where mtime decides — and mtime deciding
 * anything about another seat's records is the eviction defect the per-session prune was written
 * to end.
 */
function sidecarCrossing(parsed: unknown): { crossedAt: string; at: number } | undefined {
	if (!parsed || typeof parsed !== "object") return undefined;
	const { sidecarVersion, crossedAt } = parsed as Partial<ArchiveSidecar>;
	if (sidecarVersion !== ARCHIVE_SIDECAR_VERSION) return undefined;
	if (typeof crossedAt !== "string") return undefined;
	const at = Date.parse(crossedAt);
	return Number.isFinite(at) ? { crossedAt, at } : undefined;
}

/**
 * When the record beside this `.md` says its crossing happened, or `undefined` when it will not
 * say — no sidecar at all, an unreadable one, junk, or a `sidecarVersion` this code does not
 * speak.
 *
 * ⛔ `undefined` IS A COHORT, NOT A TIMESTAMP, and `archivePruneEntry` is where that matters. A
 * caller that substituted a number here would be inventing a crossing instant for a record that
 * refused to name one, which is the same guess the whole durable tier is built to refuse.
 */
export function archiveCrossedAt(markdownPath: string): number | undefined {
	try {
		return sidecarCrossing(JSON.parse(readFileSync(sidecarPathFor(markdownPath), "utf8")))?.at;
	} catch {
		return undefined;
	}
}

/**
 * Write the machine-readable half of this crossing beside the `.md`.
 *
 * ⛔ TEMP-THEN-RENAME, BECAUSE THE READER IS A DIFFERENT PROCESS. `rename(2)` within one
 * directory is atomic, so a concurrent restore sees either no file or the finished file — never a
 * half-written one. A plain `writeFileSync` is not atomic, and "nobody reads it while we write"
 * is not available as an assumption here: a cross-process reader is the entire point of the tier.
 * The staging name carries the pid so two seats crossing in the same millisecond cannot clobber
 * each other's partial file.
 *
 * ⛔ FAIL-QUIET, EXACTLY LIKE THE `.md`. A sidecar is a recovery convenience; a compaction is the
 * session. Nothing in here may be the reason a crossing fails, so every failure returns
 * `undefined`, sweeps its own litter, and leaves the `.md` — already on disk — untouched.
 *
 * ⛔ THE WRITER RECORDS ITS OWN UNPROVEN IDENTITY RATHER THAN OMITTING IT. A process with no
 * `--session-dir` writes `provenSeat: ""`, and that empty string is what stops a later reader from
 * matching the record across sessions. Writing the field honestly is what makes the refusal
 * possible; leaving it out would make the record unreadable in a way that looks like corruption.
 */
export function writeArchiveSidecar(
	markdownPath: string,
	identity: ArchiveIdentity,
	snapshot: OmpContinuitySnapshot,
	crossedAt: string,
): string | undefined {
	const target = sidecarPathFor(markdownPath);
	const staging = `${target}.${process.pid}.tmp`;
	try {
		const payload: ArchiveSidecar = {
			sidecarVersion: ARCHIVE_SIDECAR_VERSION,
			sessionId: identity.sessionId,
			seat: identity.seat,
			provenSeat: identity.provenSeat,
			repoRoot: identity.repoRoot,
			writerPid: process.pid,
			bootId: bootIdentity(),
			crossedAt,
			snapshot,
		};
		writeFileSync(staging, `${JSON.stringify(payload, undefined, "\t")}\n`);
		renameSync(staging, target);
		return target;
	} catch {
		try {
			rmSync(staging, { force: true });
		} catch { /* a leftover staging file is litter, not a failure */ }
		return undefined;
	}
}

/**
 * Is the process that wrote a record still running?
 *
 * ⛔ THIS IS THE ONLY THING THAT SEPARATES A DEAD PREDECESSOR FROM A LIVE SIBLING, AND WITHOUT IT
 * THE CROSS-SESSION BRANCH IS A GUESS. A live seat has `~/.omp/agent/seat-launchers/seat-bin` on
 * PATH and exports every `OMP_SEAT_*` var, and that shim builds argv from them
 * (`~/.omp/agent/seat-launchers/seat-bin/omp:28` passes `--session-dir "$OMP_SEAT_SESSION_DIR"`,
 * `:66` execs), so anything invoking `omp` from inside a seat starts a SECOND process whose
 * proven slug and repo root are identical to the live seat's. `launch-seat` has no singleton
 * guard and OMP locks per transcript file rather than per seat directory, so the two coexist.
 * Seat identity alone therefore cannot tell "my own previous run" from "a sibling running right
 * now", and serving a live sibling's intents as this session's history is the confident-wrong
 * record this tier exists to refuse. Found by the SidecarSeatKey hand, 2026-09-16.
 *
 * ⛔ IT FAILS IN THE SAFE DIRECTION, AND THAT PROPERTY IS LOAD-BEARING: DO NOT WEAKEN IT. If a pid
 * was recycled by an unrelated live process, a legitimate predecessor's record reads as alive and
 * is refused — the restore loses one crossing's freshness and falls through to tier 2. Recycling
 * can never make a LIVE writer look dead, because a live process answers signal 0 by definition.
 * `EPERM` therefore counts as ALIVE: the process exists, it is merely someone else's, and reading
 * that as "gone" would invert the safe direction.
 *
 * ⛔ BUT SAFE IS NOT SUFFICIENT, AND THE BOOT ID IS WHAT BUYS BACK THE CASE PID-ONLY LOSES. This
 * check was pid-only first, on the argument above, and the argument is right about correctness and
 * silent about coverage: after a reboot the predecessor's pid has been handed out again to some
 * unrelated live process with near-coin-flip probability, so a pid-only check refuses most
 * post-reboot relaunches — and a rebooted seat is the case with the strongest claim on this tier,
 * since it has no host `preserveData` either and tier 3 is the only tier it has.
 *
 * So exactly one refusal becomes an adoption, and nothing else about the logic moves: a pid that
 * ANSWERS is still live, UNLESS the record belongs to an earlier boot, in which case that pid
 * cannot be the writer's — no process survives a reboot — and the collision is a coincidence. The
 * added branch has its own guard, because it is the only one here that can widen what gets served:
 * see `BOOT_ID_TOLERANCE_S` for why the boot comparison is a tolerance rather than `===`.
 */
function archiveWriterIsLive(
	record: Pick<ArchiveSidecar, "writerPid" | "bootId">,
	hostBootId: number = bootIdentity(),
): boolean {
	let answers: boolean;
	try {
		process.kill(record.writerPid, 0);
		answers = true;
	} catch (error) {
		answers = (error as { code?: string } | null)?.code === "EPERM";
	}
	// Nothing holds the pid: the writer is gone on any boot.
	if (!answers) return false;
	// Something holds it. Only an earlier boot excuses that, and then it is not the writer.
	return Math.abs(record.bootId - hostBootId) <= BOOT_ID_TOLERANCE_S;
}

/**
 * How a record on disk relates to this process, or nothing at all.
 *
 * ⛔ CROSS-SESSION MATCHING REQUIRES THE PROVEN HALF, AND THAT IS THE WHOLE SAFETY PROPERTY. The
 * relaunch case — a seat restarted, holding a new session id and none of its predecessor's
 * records — is the case the seat key exists for, and it is reachable only because the launcher
 * gives every seat the same `--session-dir` slug across relaunches
 * (`launch-seat.staged:263` per the registry's own citation) while `OMP_SESSION_ID` is re-minted
 * (`launch-seat.staged:279`). A process whose argv proves no seat gets NO cross-session matching:
 * it is the harness case, the one that name-squatted Lintel, and it keeps exactly the behaviour
 * it had before this field existed — its own session's records and nothing else.
 *
 * Both halves must agree. A record whose `seat` and `provenSeat` disagree with this process's is
 * the forgery signature the registry's two-field receipt was added to expose, and the safe side of
 * that disagreement is to fall through to another tier.
 */
function archiveRecordOrigin(
	record: { sessionId: string; seat: string; provenSeat: string },
	identity: ArchiveIdentity,
): ArchiveRecordOrigin | undefined {
	// ⛔ IDENTITY ONLY. Whether a same-seat record may be SERVED depends on whether its writer is
	// still running, and that question is answered in `latestArchiveSidecar` where the refusal can
	// be counted and reported. Deciding it here would collapse "not mine" and "mine but live" into
	// one silent `undefined`.
	if (record.sessionId === identity.sessionId) return "this-session";
	if (!identity.provenSeat) return undefined;
	if (record.provenSeat.trim().toLowerCase() !== identity.provenSeat) return undefined;
	if (record.seat.trim().toLowerCase() !== identity.seat) return undefined;
	return "same-seat-other-session";
}

/**
 * A sidecar, or nothing.
 *
 * ⛔ NOTHING IS A PERFECTLY GOOD ANSWER HERE. Every rejection below is a case where the
 * alternative is to serve a snapshot this code cannot vouch for, and the measured defect the
 * durable tier exists to fix IS a confident wrong record. Falling through to the other tiers
 * costs a restore some freshness; guessing costs it its truthfulness.
 */
export function parseArchiveSidecar(text: string, identity: ArchiveIdentity, path?: string): ArchiveSidecar | undefined {
	try {
		const parsed = JSON.parse(text) as Partial<ArchiveSidecar> | null;
		// The shape gate and the crossing instant come from `sidecarCrossing`, the one place that
		// knows both — so the prune below orders records by exactly the field this reader serves.
		const crossing = sidecarCrossing(parsed);
		if (!parsed || !crossing) return undefined;
		const { sessionId, seat, provenSeat, repoRoot, writerPid, bootId } = parsed;
		// ⛔ A RECORD THAT CANNOT NAME ITS SEAT IS REFUSED, NOT MATCHED LOOSELY. Treating a missing
		// `seat` as "probably mine" is how one seat's continuity reaches another seat's restore.
		if (typeof sessionId !== "string" || typeof seat !== "string" || typeof provenSeat !== "string") {
			return undefined;
		}
		if (typeof repoRoot !== "string" || repoRoot !== identity.repoRoot) return undefined;
		// ⛔ NO DEFAULT PID, AND NO DEFAULT BOOT. `writerPid ?? 0` would read every record from a
		// writer predating the field as "writer gone", which is the permissive answer for the one case
		// that must not be guessed at — and on a relaunch those unprovable records are the FIRST ones
		// a reader meets, so the hole would be open for the whole transition window and then close
		// silently. A record that cannot name its writer is refused like any other malformed one.
		// (SidecarSeatKey, 2026-09-16.) The boot id is required on exactly the same ground: a pid
		// without the boot it belongs to cannot be probed safely, since pids are reused across
		// reboots, and defaulting it would resurrect the same permissive hole one field over.
		if (typeof writerPid !== "number" || !Number.isInteger(writerPid) || writerPid <= 0) return undefined;
		if (typeof bootId !== "number" || !Number.isFinite(bootId)) return undefined;
		const snapshot = validContinuity(parsed.snapshot);
		if (!snapshot) return undefined;
		// ⛔ THE DIRECTORY IS SHARED, so identity is checked against the PAYLOAD and never against
		// the filename: a filename can be copied or renamed by anything, while the payload was
		// written by the crossing itself.
		const origin = archiveRecordOrigin({ sessionId, seat, provenSeat }, identity);
		if (!origin) return undefined;
		return {
			sidecarVersion: ARCHIVE_SIDECAR_VERSION,
			sessionId,
			seat,
			provenSeat,
			repoRoot,
			writerPid,
			bootId,
			crossedAt: crossing.crossedAt,
			snapshot,
			path,
			origin,
		};
	} catch {
		// Truncated, empty, or not JSON at all — the half-written file the atomic write exists to
		// prevent, plus every corruption it cannot prevent. Never throws into the restore.
		return undefined;
	}
}

/**
 * The newest crossing this process may serve, by the record's own clock.
 *
 * ⛔ NOT `statSync().mtimeMs`, ANYWHERE IN HERE, and that is not a style preference. A backup or
 * a `cp -r` rewrites mtime, and `touch` sets it to anything at all — so mtime answers "when was
 * this file last handled", while the tier needs "which crossing is this". Only `crossedAt`
 * answers that, and it is the only field consulted.
 *
 * ⛔ AND THE PRUNE NOW ASKS THE SAME QUESTION WITH THE SAME CLOCK. It did not when this paragraph
 * was first written: the note here said "the prune below already reads mtime" and left it there,
 * so the two halves of ONE tier asked the same question off two different clocks and only one of
 * them was a fact about the crossing. The consequence was never faked freshness — this reader
 * ignores mtime — but misdirected EVICTION, which is the irreversible half: a `touch`, a
 * `cp -r`, a backup restore or a skewed clock could make the prune drop the oldest HANDLED file
 * instead of the oldest crossing. `archivePruneEntry` now reads `crossedAt` through
 * `sidecarCrossing`, the same gate this reader passes every payload through, and falls back to
 * mtime only for a record that will not name its crossing at all. (PruneByCrossing, 2026-09-16.)
 *
 * ⛔ THIS SESSION'S OWN CROSSING OUTRANKS A NEWER SAME-SEAT ONE, and that is deliberate rather
 * than a freshness bug. The two orderings answer different questions and "what did I do" is the
 * one a restore asks, so a cross-session record is a fallback and never a preference. The
 * cross-session read exists for the case where this session has NOTHING of its own: the relaunch.
 *
 * ⛔ AND A SAME-SEAT RECORD WHOSE WRITER MAY STILL BE RUNNING IS REFUSED OUTRIGHT, because seat
 * identity cannot tell a dead predecessor from a live sibling and both present identically on
 * disk. Every refusal is counted rather than swallowed, so a reader served tier 2 can be told
 * which of the things happened. `archiveWriterIsLive` holds that rule, including the one case
 * where an answering pid is NOT the writer: a record from an earlier boot.
 *
 * ⛔ THE SAME-SESSION PATH IS GATED TOO, AND THE REASON IS MEASURED RATHER THAN IMAGINED. A record
 * under my own session id is normally mine, and "it is my own session id" is exactly the intuition
 * that fails here: `OMP_SESSION_ID` is inherited by `hub start` precisely as
 * `OMP_CURRENT_SEAT_NAME` is, and that inheritance produced a harness which came up holding
 * `Lintel`, drained the real seat's mailbox and wrote a receipt for pid 56955 while the real seat
 * sat at pid 70474 (`persistent-seat-registry.ts:956-970`). So a process can come up wearing a
 * LIVE session's id while proving no slug from argv. A record written by my own pid is mine; one
 * written by a different pid that STILL ANSWERS means two live processes share one id, which is
 * never a resume. Every legitimate same-session recovery — a module reload, a resume after a dead
 * predecessor, a pid coincidence from an earlier boot — lands outside that refusal, so the gate
 * removes no coverage.
 *
 * `hostBootId` is read ONCE per scan rather than per candidate — one reading for the whole
 * decision, so two records cannot be judged against two different notions of "this boot", and the
 * A/B can state the host's boot instead of having to reboot the machine.
 *
 * Every filename is opened rather than pre-filtered by prefix, because a relaunched seat's
 * records are named for a session id this process has never held. The payload decides.
 */
export function latestArchiveSidecar(
	archiveDir: string,
	identity: ArchiveIdentity,
	hostBootId: number = bootIdentity(),
): ArchiveLookup {
	let own: ArchiveSidecar | undefined;
	let sameSeat: ArchiveSidecar | undefined;
	let liveSiblingRefusals = 0;
	let sharedSessionRefusals = 0;
	try {
		for (const name of readdirSync(archiveDir)) {
			if (!name.endsWith(".json")) continue;
			const path = join(archiveDir, name);
			let text: string;
			try {
				text = readFileSync(path, "utf8");
			} catch {
				continue;   // deleted under us by a co-resident seat's prune: skip, never fail
			}
			const sidecar = parseArchiveSidecar(text, identity, path);
			if (!sidecar) continue;
			if (sidecar.origin === "this-session") {
				// My own pid short-circuits: a module reload or a resume inside this very process.
				// Any other pid that still answers is a second live holder of one session id.
				if (sidecar.writerPid !== process.pid && archiveWriterIsLive(sidecar, hostBootId)) {
					sharedSessionRefusals += 1;
					continue;
				}
				if (!own || Date.parse(sidecar.crossedAt) > Date.parse(own.crossedAt)) own = sidecar;
				continue;
			}
			if (archiveWriterIsLive(sidecar, hostBootId)) {
				liveSiblingRefusals += 1;
				continue;
			}
			if (!sameSeat || Date.parse(sidecar.crossedAt) > Date.parse(sameSeat.crossedAt)) sameSeat = sidecar;
		}
	} catch { /* no directory, no permission, no tier — never an exception */ }
	return { sidecar: own ?? sameSeat, liveSiblingRefusals, sharedSessionRefusals, hostBootId };
}

/**
 * Is the durable record strictly fresher than what the host handed over?
 *
 * ⛔ STRICTLY, AND UNDECIDABLE COUNTS AS NO. A tier-2 snapshot with no `capturedAt` came from a
 * module predating the field, so its age cannot be established — and "cannot establish" must not
 * resolve to "prefer mine", because that is precisely the guess this tier was specified to
 * refuse. Equal timestamps lose too: the two are then the same crossing, and the host's copy is
 * already in hand.
 */
function durableIsFresher(sidecar: ArchiveSidecar, preserved: OmpContinuitySnapshot | undefined): boolean {
	if (!preserved) return true;
	if (typeof preserved.capturedAt !== "string") return false;
	const host = Date.parse(preserved.capturedAt);
	const durable = Date.parse(sidecar.crossedAt);
	if (!Number.isFinite(host) || !Number.isFinite(durable)) return false;
	return durable > host;
}

// ---- END SHARED SIDECAR REGION ----

export function archiveCompactionState(cwd: string, snapshot: OmpContinuitySnapshot): string | undefined {
	const identity = archiveIdentity(cwd);
	const sessionId = identity.sessionId;
	const root = identity.repoRoot;
	const archiveDir = archiveDirFor(cwd);
	// ⛔ ONE CLOCK READING FOR THE WHOLE RECORD. The filename stamp and the sidecar's `crossedAt`
	// both come from this single value, so the two halves can never name different milliseconds
	// for the same crossing — and `crossedAt` is the field the freshness comparison reads.
	const crossedAt = new Date().toISOString();
	const stamp = crossedAt.replaceAll(":", "-");
	const target = join(archiveDir, `${sessionId}--${stamp}.md`);
	// The plugin's own snapshot, if it wrote one this crossing. Read before any restore can
	// consume it, because this runs inside the same `session_before_compact` turn.
	let pluginState = "(the plugin hook wrote no snapshot for this session id at this root)";
	try {
		pluginState = readFileSync(join(root, ".ai", `session-state--${sessionId}.md`), "utf8");
	} catch { /* absent is reported above, never thrown */ }
	mkdirSync(archiveDir, { recursive: true });
	writeFileSync(
		target,
		[
			`# OMP compaction archive — ${sessionId}`,
			`_written ${new Date().toISOString()} by the installed bridge, before compaction ran_`,
			"",
			"⛔ This is a RETAINED copy. The plugin's own `.ai/session-state--<id>.md` is deleted by",
			"the restore that consumes it (`compact-continuity.mjs:573`), so this file is the one that",
			"is still here afterwards. A fresh session can resume from it.",
			"",
			renderContinuity(snapshot),
			"",
			"---",
			"",
			"## The plugin hook's snapshot, verbatim",
			"",
			pluginState,
		].join("\n"),
	);
	// ⛔ THE MACHINE-READABLE HALF, WRITTEN AFTER THE `.md` AND UNABLE TO HARM IT. The `.md` is
	// already on disk when this runs and `writeArchiveSidecar` never throws, so the worst outcome
	// of a sidecar failure is a crossing only a human can read — which is what every crossing
	// before this field existed was.
	writeArchiveSidecar(target, identity, snapshot, crossedAt);
	// ⛔ TWO RULES, AND THE FIRST ONE EXISTS BECAUSE THE OLD SINGLE RULE EVICTED OTHER SEATS.
	// `.slice(12)` over the whole directory is newest-12 PER DIRECTORY, and seats share one:
	// measured 2026-09-16 in `/Users/jowolff/.claude/.ai/omp-compaction-archive/`, 13 crossings
	// were written that day (Lintel 7, Tinker 6) and 12 files survived — Lintel had 6 of its 7,
	// so a busy co-resident seat deletes a quiet seat's only durable record. With four seats in
	// one repo the quota is 3 crossings each. Per-session pruning removes that coupling, and it
	// is free because the filename already begins with `${sessionId}--`.
	// The second rule is what per-session pruning alone gives up: a directory that never drops
	// another session's files grows without bound as sessions accumulate. Age caps that at a
	// week, for every session including this one.
	// ⛔ AND BOTH RULES NOW READ THE CROSSING, NOT THE MTIME. Listing and dating are both inside
	// `archivePruneEntries`, in the region the two lineages are asserted byte-identical across,
	// so this call site cannot choose a clock — which is how it chose the wrong one before.
	try {
		// `force` makes a record written before sidecars existed a no-op, not a throw.
		for (const name of archivePruneTargets(archivePruneEntries(archiveDir), sessionId, Date.now())) {
			for (const file of archiveRecordFiles(name)) rmSync(join(archiveDir, file), { force: true });
		}
	} catch { /* pruning is hygiene, never a reason to lose the save */ }
	return target;
}

/**
 * ⛔ A HEARTBEAT ROW THAT SAYS WHAT WAS SAVED, NOT THAT SOMETHING RAN.
 *
 * The six rows on 2026-09-15 all said `"outcome":"ok"` in 40-66ms and were true — the hook ran and
 * returned. They were also useless, because an `ok` from an instrument that cannot see whether
 * state was captured is indistinguishable from evidence. These rows carry the artifact path, its
 * byte count, the size of its machine-readable sidecar, and how many intents and file operations
 * went into it, so a zero is visible as a zero instead of hiding behind a green word.
 *
 * ⛔ `sidecarBytes: 0` IS A ROW THAT MATTERS. It means the `.md` was written and the `.json` was
 * not, so the durable tier is blind for that crossing — a state no other instrument reports and
 * which otherwise looks exactly like a healthy save.
 */
function recordArchive(path: string, snapshot: OmpContinuitySnapshot) {
	try {
		const row = {
			at: new Date().toISOString(),
			event: "PreCompactArchive",
			session: process.env.OMP_SESSION_ID ?? "omp-spike",
			cwd: snapshot.cwd,
			artifact: path,
			bytes: statSync(path).size,
			sidecarBytes: sidecarBytesFor(path),
			intents: snapshot.userIntents.length,
			tokensBefore: snapshot.tokensBefore,
			fileOperationsChars: snapshot.fileOperations.length,
		};
		appendFileSync(join(process.env.HOME ?? "/tmp", ".claude", "newdle-compaction-heartbeat.ndjson"), `${JSON.stringify(row)}\n`);
	} catch { /* the archive is the deliverable; its receipt is not worth failing a compaction */ }
}

function renderContinuity(snapshot: OmpContinuitySnapshot, provenance?: string) {
	const intents = snapshot.userIntents.length
		? snapshot.userIntents.map((intent, index) => `${index + 1}. ${intent}`).join("\n")
		: "(no user messages were compacted)";
	return [
		"## Newdle OMP continuity",
		// Omitted by the archive writer, which is not a restore and has no tier to name; its
		// output is byte-identical to before this parameter existed.
		...(provenance ? [provenance] : []),
		"This is an OMP-native compaction snapshot. It intentionally does not claim Claude transcript paths, token targets, or context-pressure calibration.",
		`Working directory: ${snapshot.cwd}`,
		`OMP tokens before compaction: ${snapshot.tokensBefore}`,
		"Recent compacted user intent:",
		intents,
		"Compacted file-operation record:",
		snapshot.fileOperations,
	].join("\n\n");
}

/**
 * ⛔ THE RESTORE SERVED THE OLDEST CROSSING, NOT THE ONE IT WAS RESTORING FROM.
 *
 * MEASURED 2026-09-16 on `seat-tinker-1789540469-4195`. The save half is correct per crossing:
 * `~/.claude/newdle-compaction-heartbeat.ndjson` holds seven `PreCompactArchive` rows for that
 * session with distinct `tokensBefore` (250862, 251437, 251000, 250905, 252240, 256377). The
 * restore is not. The compaction at 10:25:43Z delivered `tokensBefore=251437` and
 * `**read** (14) **written** (2) **edited** (0)` — byte-identical to the archived crossing at
 * 07:21:38Z, three hours and four crossings earlier. The crossing actually being restored had
 * saved `tokensBefore=256377` and `**read** (30) **written** (7) **edited** (5)`.
 *
 * THE MECHANISM, TRACED UPSTREAM AND NOT GUESSED. `session_before_compact` calls
 * `pi.appendEntry` with the same key (`dev.newdle.omp.continuity`) on every crossing, and the
 * host merges the two sources the wrong way round. In vendored
 * `@oh-my-pi/pi-coding-agent/src/session/session-maintenance.ts`:
 * `#prepareCompactionFromHooks:3345` takes THIS crossing's fresh contribution into
 * `compactionPrep.preserveData`; `mergeLlmCompactionPreserveData:346` then computes
 * `{ ...hookPreserveData, ...resultPreserveData }`; and every call site (`:1373`, `:2148`,
 * `:4776`) passes fresh first, result second. `result.preserveData`
 * (`pi-agent-core/src/compaction/compaction.ts:2034`) is seeded at `:1634-1636` from
 * `previousPreserveData`, which `:1453` reads off `previousCompaction?.preserveData`. So the
 * PREVIOUS crossing's inherited copy of the key overwrites this crossing's fresh one.
 *
 * ⛔ THE CONSEQUENCE IS STRONGER THAN "STALE": an extension key present in any prior compaction
 * can never be updated again for the life of the session. It is PINNED to the first crossing
 * that wrote it. Upstream already knows inherited preserve data goes bad — `:1634-1636` strips
 * the Anthropic and OpenAI slots before reuse, and `compaction.ts:2020-2026` drops a stale
 * snapcompact archive for the same reason — but extension keys get no such treatment. That is
 * one line upstream; this module is not the place to patch it.
 *
 * THE TIERS, and what each costs.
 *
 * Tier 1 — this module's own `latestContinuity`, assigned by `captureContinuity` during the save.
 * It is the freshest possible answer and it is the tier that fixes the bug. It is available at
 * all because **compaction does not restart the process and this module stays loaded across it**
 * (`orchestrator/build/precompact-veto-SPEC.md:95-98`), so the variable written by the save half
 * is still there when the restore half runs milliseconds later. Its cost is that it is
 * process-scoped: a restart clears it, which is the right answer, because after a restart there
 * is no in-session context to be continuous with.
 *
 * ⛔ TIER 1 IS NOT REDUNDANT WITH TIER 2 AND MUST NOT BE "SIMPLIFIED" AWAY. `session-maintenance
 * .ts:346` spreads the inherited value last, so reading `preserveData` can never see the save
 * this module just made on any crossing after the first. Deleting the module-level record
 * reinstates the measured defect exactly.
 *
 * Tier 2 — the host's `preserveData`, the old behaviour. It is not "sometimes stale": from the
 * second crossing onwards it is PINNED to the first crossing of the session and cannot ever
 * report a later one. It is kept for exactly one case — a module loaded after the first save, so
 * tier 1 is unset — where a first-crossing record is at least *a* record rather than none. ⛔ It
 * must never be preferred over tier 1, and tier 3 outranks it whenever tier 3 can PROVE it is
 * newer.
 *
 * Tier 3 — THE DURABLE ARCHIVE SIDECAR, AND IT EXISTS NOW. The prerequisite this comment used to
 * name as missing is built: `archiveCompactionState` writes `${sessionId}--${stamp}.json` beside
 * every `.md`, carrying the `OmpContinuitySnapshot` in its own shape plus the crossing timestamp,
 * the session id and a schema version. `latestArchiveSidecar` reads the newest ELIGIBLE one
 * back on restore, keyed on seat identity rather than on the session id alone.
 *
 * ⛔ THE PROSE PROBLEM THAT BLOCKED IT IS NOT SOLVED, IT IS AVOIDED, and the distinction is the
 * design. The `.md` is `renderContinuity` output: user intents as a numbered list of up to 1,500
 * characters of arbitrary multi-line prose, then a `---` rule, then the plugin's snapshot
 * verbatim, which can itself contain `---` and numbered lines. Parsing that back into an
 * `OmpContinuitySnapshot` means guessing where one intent ends and the next begins, and a restore
 * that silently mis-splits an intent is the same class of failure as the one being fixed here: a
 * confident record that is wrong. So NOTHING parses the `.md`. The `.json` is the machine's copy,
 * the `.md` stays the human's, and the prune treats the two as one record so they cannot disagree
 * about what exists.
 *
 * WHAT THE TIER COSTS, stated as narrowly as it is true. It is read only when tier 1 is empty
 * (when this process made the save being restored, nothing on disk can beat it, so the directory
 * is not even scanned). It is used only when its own `crossedAt` is STRICTLY newer than the host
 * payload's `capturedAt`, compared on those recorded timestamps and never on file mtime — a
 * prune, a `cp -r` or a bare `touch` moves mtime on a record whose content did not move, and
 * would fake freshness. An undecidable comparison counts as not fresher. So tier 3 can lose to
 * tier 2, deliberately: a tier that always won would import staleness from the disk side the way
 * tier 2 imports it from the host side.
 *
 * ⛔ AND THE ARCHIVE IS A SHARED DIRECTORY, WHICH IS STILL TRUE AND IS WHY THE READ IS NARROW.
 * Every seat in a repo writes to the same `.ai/omp-compaction-archive/`, so this tier reads only
 * files whose name AND payload carry this session id — a filename can be copied or renamed by
 * anything, while the payload was written by the crossing itself. Until this file's prune was
 * made per-session (see `archivePruneTargets`), a busy neighbour could delete this session's
 * records outright — measured 2026-09-16: 13 crossings written, 12 files left, one seat down to 6
 * of its 7. Per-session pruning removes the eviction, but a tier built on a directory other
 * processes mutate still cannot PROMISE the file is there when read. So a missing, unreadable,
 * truncated or foreign sidecar is an ORDINARY outcome that falls through to tier 2 in silence,
 * and the atomic temp-then-rename in `writeArchiveSidecar` exists because the reader is a
 * different process than the writer.
 *
 * ⛔ IT CROSSES A RELAUNCH, AND THE KEY THAT LETS IT IS NOT THE SESSION ID.
 * `orchestrator/build/omp-no-env-file/launch-seat.staged:279` mints
 * `OMP_SESSION_ID="seat-$seat-$(date +%s)-$RANDOM"` at every launch, so a relaunched seat holds
 * an id its own predecessor's records do not carry — which is the case that matters most, because
 * a fresh process is precisely where tier 1 is empty. What IS stable across a relaunch is the
 * `--session-dir` slug the launcher passes (`seat-bin/omp:28`, `launch-seat.staged:263`), so a
 * record is matched on the pair (claimed seat name, launcher-proven slug) plus the repo root, and
 * a cross-session match additionally requires that the writing process is gone. `archiveIdentity`
 * carries all of it; `archiveRecordOrigin` decides the identity half and `latestArchiveSidecar`
 * the liveness half.
 *
 * ⛔ WHAT IT STILL CANNOT TELL, STATED BECAUSE THE PROVENANCE HAS TO STATE IT. Two live processes
 * can legitimately hold the same proven slug: a live seat exports every `OMP_SEAT_*` var and has
 * the launcher shim on PATH, so any `omp` invoked from inside a seat becomes a second process
 * with the same slug and root, `launch-seat` has no singleton guard, and OMP locks per transcript
 * file rather than per seat directory. So "same seat, different session" does not mean "my
 * predecessor". A running writer is refused outright and the refusal is reported at tier 2; a
 * dead writer's record is served with a provenance that claims only what is checkable — this
 * seat wrote it, and that process has ended.
 *
 * ⛔ THE WRITER IS RULED OUT BY (PID, BOOT), AND THE PID ALONE WAS SAFE BUT LOSSY. The liveness
 * check's own comment argues correctly that a pid is enough for SAFETY: recycling can only make a
 * dead writer look alive, which refuses and falls back to tier 2, and it can never make a live
 * writer look dead. That argument is about correctness and says nothing about coverage, and the
 * coverage it silently gave up is the biggest case there is — after a reboot the predecessor's pid
 * has been handed out again with near-coin-flip probability, so a pid-only check refuses most
 * post-reboot relaunches, and a rebooted seat has no host `preserveData` either, which makes tier
 * 3 the ONLY tier it has. So the record also carries the boot it was written on, and an answering
 * pid from an earlier boot is adopted rather than refused: no process survives a reboot, so that
 * pid is somebody else's. Nothing else about the refusal changed.
 * The boot id is `Date.now() - os.uptime() * 1000`, rounded to seconds and compared with a
 * two-second tolerance — measured on Darwin 2026-09-16 to equal `kern.boottime` exactly (so sleep
 * is counted) and to jitter by one second across readings 120ms apart, which is why the comparison
 * is a tolerance: a spurious "different boot" is the only way this tier could serve a live
 * sibling's state.
 *
 * ⛔ AND THE SAME-SESSION PATH IS GATED BY THE SAME PAIR, BECAUSE A SESSION ID IS NOT PROOF OF
 * AUTHORSHIP EITHER. It is tempting to read "this record carries my own session id" as "I wrote
 * it", and that is the intuition this machinery exists because of: `OMP_SESSION_ID` is inherited
 * by `hub start` exactly as `OMP_CURRENT_SEAT_NAME` is, and the measured consequence of that
 * inheritance is a harness which came up holding `Lintel`, drained the real seat's mailbox and
 * wrote a receipt for pid 56955 while the real Lintel sat at pid 70474
 * (`persistent-seat-registry.ts:956-970`). A process in that state proves no slug from argv, so
 * the cross-session path already refuses it — but it would have walked straight into the
 * same-session path, which had no liveness gate at all. So that path now asks the same question
 * in three answers: my own pid means I wrote it and it is adopted; a different pid that has
 * stopped answering is a dead predecessor under a reused id and is adopted; a different pid that
 * still answers means two live processes hold one session id, and that is refused. Every
 * legitimate recovery — a module reload, a resume after a crash, a pid coincidence from an
 * earlier boot — is one of the first two, so the gate costs no coverage.
 *
 * ⛔ AND IT STILL CANNOT SEE A CONCURRENT WRITER'S FUTURE. Liveness is sampled once, at restore.
 * A sibling that exits one millisecond after the probe leaves a record this process just refused,
 * and one that starts after the probe is never consulted at all. The refusal count reported at
 * tier 2 is what makes the first case legible instead of silent; nothing makes the second case
 * visible, because nothing here holds a lock — and the archive directory is shared, so a lock is
 * exactly what this tier has always declined to take.
 */
let latestContinuity: OmpContinuitySnapshot | undefined;

/**
 * The save half's snapshot, recorded in-process for the restore half to read back.
 *
 * Returns `undefined` instead of throwing, preserving the exact behaviour the outer handler's
 * `try/catch` already gave a malformed `preparation`: no contribution, no PreCompact run, no
 * archive, no veto. The failure it absorbs is measured — a `preparation` missing
 * `messagesToSummarize` threw `undefined is not an object` out of `continuitySnapshot`.
 */
export function captureContinuity(preparation: unknown, cwd: string): OmpContinuitySnapshot | undefined {
	try {
		latestContinuity = continuitySnapshot(
			preparation as { messagesToSummarize: unknown[]; tokensBefore: number; fileOps: unknown },
			cwd,
		);
		return latestContinuity;
	} catch {
		return undefined;
	}
}

/** Tier 1's value at the moment the restore asks for it. */
export function latestContinuityRecord(): OmpContinuitySnapshot | undefined {
	return latestContinuity;
}

export type ContinuityResolution = { tier: 1 | 2 | 3; snapshot: OmpContinuitySnapshot; text: string };

function validContinuity(value: unknown): OmpContinuitySnapshot | undefined {
	if (!value || typeof value !== "object") return undefined;
	const data = value as OmpContinuitySnapshot;
	if (data.version !== 1 || typeof data.cwd !== "string" || !Array.isArray(data.userIntents)) return undefined;
	return data;
}

/**
 * How old the record is, in the reader's terms, or an explicit admission that it cannot be told.
 *
 * ⛔ THE UNKNOWN BRANCH IS THE POINT, not a fallback. A snapshot with no `capturedAt` came from a
 * copy of this module that predates the field, which in practice means tier 2 — precisely the
 * source that can be hours stale. Saying so invites the re-check that a silent record does not.
 */
function continuityAge(snapshot: OmpContinuitySnapshot, now: number): string {
	if (typeof snapshot.capturedAt !== "string") {
		return "⛔ Capture time UNKNOWN: this snapshot predates the `capturedAt` field, so its age cannot"
			+ " be stated and it may be hours old. Treat it as a lead to verify, not as a record of the"
			+ " minutes just before this compaction.";
	}
	const elapsed = now - Date.parse(snapshot.capturedAt);
	if (!Number.isFinite(elapsed)) {
		return `⛔ Capture time UNPARSEABLE (\`${snapshot.capturedAt}\`), so its age cannot be stated.`;
	}
	const seconds = Math.max(0, Math.round(elapsed / 1_000));
	const age = seconds < 90
		? `${seconds}s`
		: seconds < 5_400
			? `${Math.round(seconds / 60)}m`
			: `${(seconds / 3_600).toFixed(1)}h`;
	return `Captured ${snapshot.capturedAt}, ${age} before this restore.`;
}

/**
 * Tier 3's provenance, in the two forms it has — and the cross-session form claims ONLY what the
 * file on disk supports.
 *
 * ⛔ WHICH SESSION WROTE IT IS STATED IN BOTH FORMS, NEVER LEFT TO BE INFERRED. "I read back my
 * own earlier crossing" and "I read back a crossing from a run of this seat that has ended" are
 * materially different claims, and a reader who meets only one of them spelled out will read the
 * silence as the stronger one. So the same-session form says so explicitly too, even though it is
 * the unremarkable case.
 *
 * ⛔ IT MUST NOT SAY "YOUR PREVIOUS SESSION". What the record proves is that the same seat wrote
 * it under a different session id and that the process which wrote it is no longer running. A
 * second live launch of the same seat is not refused anywhere, so "previous run of this seat" is
 * an inference the reader should be allowed to make and this text should not make for them; the
 * checkable half is that the writer is gone.
 *
 * ⛔ AND IT NAMES WHICH GROUND RULED THE WRITER OUT, because the two are not equally strong. "The
 * pid does not answer on this boot" rests on the pid still meaning what it meant; "the record
 * predates this boot" rests only on the fact that no process survives a reboot, and is the
 * stronger of the two. A reader deciding how much to trust the record should be told which it got.
 */
function durableProvenance(sidecar: ArchiveSidecar | undefined, hostBootId: number = bootIdentity()): string {
	const head = "⛔ **Provenance: tier 3 — RECOVERED FROM THE DURABLE ARCHIVE ON DISK**, not handed over by"
		+ " the host. This process holds no in-session record, and the host's `preserveData` was"
		+ " absent or demonstrably older, so the state below was read back from"
		+ ` \`${sidecar?.path ?? "the archive sidecar"}\`, written by the crossing at`
		+ ` **${sidecar?.crossedAt ?? "an unstated time"}**. ⛔ It is a record of THAT crossing`
		+ " and not of this one: whatever happened after that timestamp was never archived and"
		+ " is not below.";
	if (sidecar?.origin !== "same-seat-other-session") {
		return `${head} It was written by THIS SESSION (\`${sidecar?.sessionId ?? "unstated"}\`), so it is`
			+ " your own earlier crossing read back off disk rather than a recovery across a relaunch.";
	}
	const priorBoot = Math.abs(sidecar.bootId - hostBootId) > BOOT_ID_TOLERANCE_S;
	return `${head} ⛔ AND IT WAS WRITTEN BY A DIFFERENT SESSION OF THIS SEAT`
		+ ` (\`${sidecar.sessionId}\`, seat \`${sidecar.seat || "(unnamed)"}\`), NOT BY THIS ONE — this is a`
		+ " CROSS-SESSION recovery across a relaunch, matched on the seat slug this process's own"
		+ " `--session-dir` argv proves and not on an environment variable, in the same repo root."
		+ (priorBoot
			? ` Its writer (pid ${sidecar.writerPid}) belongs to an EARLIER BOOT of this machine`
				+ ` (boot ${sidecar.bootId} against this boot's ${hostBootId}), so it cannot be running`
				+ " whatever holds that pid now — the strongest form of the liveness proof."
			: ` Its writer (pid ${sidecar.writerPid}) ran on THIS boot and no longer answers, so that`
				+ " process has ended.")
		+ " Treat it as this seat's recent history rather than as your own turn:"
		+ " nothing here establishes that the session which wrote it was YOUR predecessor rather than"
		+ " another run of this seat, only that it was this seat and that it has ended.";
}

/**
 * ⛔ A WITHHELD RECORD IS NOT THE SAME EVENT AS NO RECORD, AND THE WEAKER TIER IS WHERE THE
 * DIFFERENCE HAS TO SHOW. All three end in tier 2, and they call for different responses: one says
 * the archive never had this seat's crossing, one says another run of this seat holds it right
 * now, and one says a second live process is wearing this session's id.
 */
function durableRefusalNote(lookup: ArchiveLookup | undefined): string {
	const siblings = lookup?.liveSiblingRefusals ?? 0;
	const shared = lookup?.sharedSessionRefusals ?? 0;
	let note = "";
	if (siblings > 0) {
		note += ` ⛔ The durable archive DID hold ${siblings} same-seat record(s) and refused every one:`
			+ " each writer process is still running, so those records belong to a live sibling session of"
			+ " this seat rather than to this session's past. Serving a concurrent process's intents as"
			+ " your own history is a worse error than the staleness described above, so nothing was taken"
			+ " from disk.";
	}
	if (shared > 0) {
		note += ` ⛔ It also held ${shared} record(s) under THIS session's OWN id whose writer is a`
			+ " DIFFERENT pid that is still running. Two live processes sharing one session id means the id"
			+ " was inherited from an environment rather than minted for this launch"
			+ " (`persistent-seat-registry.ts:956-970`), so that is not a resume and those were refused"
			+ " too. Treat this process's own identity as suspect, not just its continuity.";
	}
	return note;
}

function continuityProvenance(
	tier: 1 | 2 | 3,
	snapshot: OmpContinuitySnapshot,
	now: number,
	lookup?: ArchiveLookup,
): string {
	const source = tier === 1
		? "**Provenance: tier 1** — this process's own save for the compaction now being restored."
		: tier === 3
			? durableProvenance(lookup?.sidecar, lookup?.hostBootId ?? bootIdentity())
			: "⛔ **Provenance: tier 2** — the host's `preserveData`, used only because this process holds no"
				+ " in-session record. An extension key there is PINNED to the FIRST compaction of the"
				+ " session and is never updated afterwards (`session-maintenance.ts:346` spreads the"
				+ " inherited copy last), so unless this was the session's first crossing, the state below"
				+ " is the first one and not the one you just crossed (measured 2026-09-16: a 10:25 restore"
				+ " served a 07:21 snapshot). Verify before relying on it."
				+ durableRefusalNote(lookup);
	return `${source} ${continuityAge(snapshot, now)}`;
}

/**
 * Freshest first. `inProcess` is tier 1; `durable` is tier 3, the archive sidecar; `preserveData`
 * is tier 2. Nothing valid is `undefined`.
 *
 * ⛔ TIER 3 IS NOT A THIRD CHOICE — IT OUTRANKS TIER 2 WHEN, AND ONLY WHEN, IT CAN PROVE IT IS
 * NEWER. Tier 2 is pinned to the session's first crossing (`session-maintenance.ts:346`), so from
 * the second crossing on the sidecar is the fresher record and preferring the host's copy
 * reinstates the measured defect. The converse is equally real and is why `durableIsFresher` is
 * strict: on a first crossing the host's copy can be the newer of the two, and a tier that always
 * won would reintroduce staleness from the disk side.
 */
export function resolveContinuity(
	inProcess: OmpContinuitySnapshot | undefined,
	preserveData: Record<string, unknown> | undefined,
	now: number = Date.now(),
	lookup?: ArchiveLookup,
): ContinuityResolution | undefined {
	try {
		const fresh = validContinuity(inProcess);
		if (fresh) return { tier: 1, snapshot: fresh, text: renderContinuity(fresh, continuityProvenance(1, fresh, now)) };
		const preserved = validContinuity(preserveData?.["dev.newdle.omp.continuity"]);
		const durable = lookup?.sidecar;
		if (durable && durableIsFresher(durable, preserved)) {
			return {
				tier: 3,
				snapshot: durable.snapshot,
				text: renderContinuity(durable.snapshot, continuityProvenance(3, durable.snapshot, now, lookup)),
			};
		}
		if (preserved) {
			return {
				tier: 2,
				snapshot: preserved,
				text: renderContinuity(preserved, continuityProvenance(2, preserved, now, lookup)),
			};
		}
		return undefined;
	} catch {
		// The restore half has no try/catch of its own; this one keeps the added tiers from being
		// the first thing in it that can throw.
		return undefined;
	}
}

/**
 * ⛔ SILENCE IS NOT AN ACCEPTABLE OUTCOME HERE. A compaction that restores nothing must say so,
 * because an agent cannot tell "nothing was worth restoring" from "the restore never ran" — and
 * for six weeks the answer was the second one while looking like the first.
 */
export function continuityMessage(resolved: ContinuityResolution | undefined, additionalContext: string[]): string {
	const parts: string[] = [];
	if (resolved) parts.push(resolved.text);
	parts.push(...additionalContext);
	return parts.length
		? parts.join("\n\n")
		: "## Newdle OMP continuity\n⛔ NO CONTINUITY RECORD WAS RECOVERED for this compaction."
			+ " Neither the in-session contribution nor the on-disk snapshot yielded usable state."
			+ " Context before this point is gone and was not preserved.";
}

/**
 * Report when this seat is executing a plugin version older than the newest installed one.
 *
 * WHY THIS EXISTS. On 2026-09-15 `0.2.168` was installed and every live seat kept executing
 * `0.2.166` — including `compact-continuity.mjs:44`'s unsuffixed `.ai/session-state.md`, the
 * collision defect that release fixed. Nothing said so. The pinning is structural:
 * `launch-seat:19` resolves newest-AT-LAUNCH, `:262` fixes it in the child env via `--env`, and
 * `pluginRoot` above is read ONCE at module load. A stale pinned path whose directory still
 * exists on disk is the quietest failure on this machine: no error, no warning, three-week-old
 * hooks forever. Four separate reports of mine described `0.2.168` behaviour as the state of the
 * machine before anyone noticed; a banner in the reporter's own context would have contradicted
 * the first one.
 *
 * ⛔ DELETING THE STALE DIRECTORIES IS NOT THE ALTERNATIVE, AND IT WAS PRICED AND REJECTED.
 * `Bun.file(hookManifest).json()` throws ENOENT unguarded, and one of its call sites sits in the
 * `tool_call` handler — where a throw is converted to `{block:true}` and denies EVERY tool call.
 * Deletion therefore bricks the seat instead of reporting a version. "Make the failure loud" and
 * "make the failure fatal" are different interventions.
 *
 * ⛔⛔ THIS FUNCTION MUST BE SILENT ON ITS OWN FAILURE, AND THAT IS NON-NEGOTIABLE RATHER THAN
 * DEFENSIVE GARNISH. It lives in the same module as the fail-closed `tool_call` handler, so an
 * uncaught throw here — an unreadable cache directory, a permissions change, a moved path —
 * becomes machine-wide tool denial for all eleven seats. A staleness check that bricks the
 * machine while reporting staleness is the worst available outcome and it is completely
 * reachable. So: everything is wrapped, every error is swallowed, and the failure mode is
 * EMITTING NOTHING. A missing banner must never be worse than a missing version.
 *
 * It names the mechanism and the remedy, not just the fact: without "a reload cannot move it"
 * the reader spends ten minutes on reload-plugins, which was asked and answered (it cannot).
 */
function stalenessBanner(): string | undefined {
	try {
		if (!pluginRoot) return undefined;
		const cacheDir = dirname(pluginRoot);
		const pinned = basename(pluginRoot);
		// Version-sort the installed directories the same way launch-seat:19 does, so this
		// answers the question the launcher will answer at the next relaunch.
		const installed = readdirSync(cacheDir, { withFileTypes: true })
			.filter(entry => entry.isDirectory())
			.map(entry => entry.name)
			.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }));
		const newest = installed.at(-1);
		if (!newest || newest === pinned) return undefined;
		const behind = installed.length - 1 - installed.indexOf(pinned);
		return [
			"## ⛔ This seat is running a stale plugin version",
			`Executing **${pinned}**. Newest installed is **${newest}**`
				+ (behind > 0 ? ` — ${behind} version${behind === 1 ? "" : "s"} behind.` : "."),
			"Hook behaviour in this session is whatever that older version does, including any"
				+ " defect a later release fixed.",
			"⛔ **A reload cannot move it.** The version is resolved once at launch"
				+ " (`launch-seat:19`), fixed into this process's environment (`:262`), and read once"
				+ " at module load. Nothing inside a running process can change it.",
			`**Remedy: relaunch this seat via \`launch-seat\`.** Until then, treat any claim about`
				+ ` plugin-hook behaviour in this session as a claim about ${pinned}.`,
		].join("\n\n");
	} catch {
		// Silent by design. See the block comment above: a throw here becomes machine-wide tool
		// denial, so a broken check must produce nothing at all rather than propagate.
		return undefined;
	}
}

/**
 * ⛔ WHY THIS LIVES IN THE ADAPTER AND NOT IN ITS OWN FILE UNDER extensions/.
 *
 * This code polices `~/.omp/agent/extensions/`. A watchdog placed IN the directory it watches
 * would be auto-discovered by the same mechanism it exists to report, adding a fourth
 * loaded-but-unregistered extension and reproducing the defect one level up. The adapter is
 * already passed explicitly (`launch-seat:26` → `--hook`), so hosting the check here expands no
 * surface.
 *
 * THE DEFECT. `discovery/helpers.ts:823` globs `*.{ts,js}` in each config dir's `extensions/`,
 * and `discovery/builtin.ts:485-513` pushes every discovered module UNCONDITIONALLY, before
 * `settings.json` is even parsed — the settings `extensions` array can only ADD. There is no
 * allowlist semantics and no discovery toggle in the schema (`config/settings-schema.ts:624`).
 * So a `.ts` file appearing in that directory is armed for every seat launched afterwards, with
 * no registration anywhere a reviewer would read.
 *
 * ⛔ MEASURED 2026-09-15: three of six loaded extensions were in nobody's launcher —
 * `ctx-first-search.ts`, `herdr-omp-agent-state.ts`, `moshi-hooks.ts`. One of them is a gate that
 * BLOCKS tool calls machine-wide, and the only reason anyone learned it existed is that it
 * blocked the orchestrator. "It blocked me" is not a discovery mechanism: had it been subtly
 * wrong rather than correct, nothing would have surfaced it.
 *
 * ⛔ THE `.pre-*` BACKUP CONVENTION IS LOAD-BEARING, NOT COSMETIC. A backup named
 * `newdle-hooks.backup.ts` WOULD match `*.{ts,js}` and register duplicate handlers for every
 * event on every seat. `newdle-hooks.ts.pre-install-20260915-173402` does not match, because its
 * final extension is `.pre-install-20260915-173402`. Keep that shape.
 *
 * SILENT ON ITS OWN FAILURE, for the same reason as `stalenessBanner` above: this module also
 * hosts a `tool_call` handler, and an uncaught throw there is converted to `{block:true}`
 * machine-wide (`runner.ts:1487-1494`). Everything is wrapped; the failure mode is emitting
 * nothing.
 */
const MODULE_LOADED_AT = Date.now();

/** Extension files the loader would actually load: its own glob, not a wider one. */
function loadableExtensionFiles(dir: string): string[] {
	return readdirSync(dir, { withFileTypes: true })
		.filter(entry => entry.isFile() || entry.isSymbolicLink())
		.map(entry => entry.name)
		.filter(name => name.endsWith(".ts") || name.endsWith(".js"))
		.sort();
}

/**
 * Report loaded-but-unregistered extensions, and any loadable file that changed after this
 * process loaded it.
 *
 * REGISTERED is read from the launcher's own exports rather than hardcoded, so this cannot drift
 * from `launch-seat`: `OMP_SEAT_ADAPTER` (`:272`), `OMP_SEAT_COMPACTION_OWNER` (`:273`),
 * `OMP_SEAT_REGISTRY` (`:274`). A hardcoded list here would be a second copy of the launcher's
 * intent and would go stale the first time the launcher gained a fourth flag.
 *
 * ⛔ DRIFT DETECTION AND ITS ASYMMETRY, WHICH THE TEXT MUST STATE OR THE CHECK GETS OVER-TRUSTED.
 * The plugin staleness banner has a TRUE REFERENCE — the newest installed version directory — so
 * it can say "you are behind". This check has no such reference: nothing records what the bytes
 * were at launch. It compares each loadable file's mtime against this module's load time, so it
 * detects DRIFT SINCE LAUNCH and is blind to a file that was already wrong when the seat started.
 *
 * Two known weaknesses of mtime, stated rather than left to be discovered: `touch` with no edit
 * is a false positive, and a content change that preserves mtime (`cp -p`) is a false negative.
 * A digest baseline exported by `launch-seat` would remove both; that needs a launcher change and
 * is therefore not assumed here. When `OMP_SEAT_EXT_DIGEST` is present this function uses it and
 * says so; otherwise it falls back to mtime and says THAT. Which mode ran is part of the report,
 * because a reader must not mistake the weaker check for the stronger one.
 */
function extensionReconciliation(): string | undefined {
	const adapter = process.env.OMP_SEAT_ADAPTER;
	if (!adapter) return undefined; // not a seat launch; nothing to reconcile against

	// ⛔ FIX 2 (Sedge): the directory was taken from `dirname(OMP_SEAT_ADAPTER)` and never
	// verified. Point `--hook` at a staged copy and the check reported "5 of 5 loaded but
	// registered by no launcher" — confident, alarming, and about the wrong directory. It now
	// refuses to judge a directory that is not the extensions directory, and SAYS so rather
	// than returning undefined, because silence here is indistinguishable from health.
	const dir = dirname(adapter);
	const expected = join(process.env.HOME ?? "", ".omp", "agent", "extensions");
	if (dir !== expected) {
		return `_Extension reconciliation did not run: the adapter is at \`${dir}\`, not the`
			+ ` extensions directory \`${expected}\`. Nothing was checked._`;
	}

	// Static string-keyed membership lookup, so a Record rather than a Set.
	const registered: Record<string, true> = {};
	for (const path of [
		process.env.OMP_SEAT_ADAPTER,
		process.env.OMP_SEAT_COMPACTION_OWNER,
		process.env.OMP_SEAT_REGISTRY,
	]) {
		if (path) registered[basename(path)] = true;
	}

	let loadable: string[];
	try {
		loadable = loadableExtensionFiles(dir);
	} catch (error) {
		return `_Extension reconciliation could not read \`${dir}\`: ${String(error)}. Nothing was checked._`;
	}
	const unregistered = loadable.filter(name => !registered[name]);

	// Per-file drift, so the report names WHAT changed rather than only THAT something did.
	const baseline = ((): Map<string, string> | undefined => {
		const raw = process.env.OMP_SEAT_EXT_DIGEST;
		if (!raw) return undefined;
		const map = new Map<string, string>();
		for (const pair of raw.split(",")) {
			const [name, digest] = pair.split(":");
			if (name && digest) map.set(name.trim(), digest.trim());
		}
		return map.size ? map : undefined;
	})();

	const drifted: string[] = [];
	const unreadable: string[] = [];
	for (const name of loadable) {
		const full = join(dir, name);
		// ⛔ FIX 3 (Sedge): the two halves were documented as independent and were not. One
		// unreadable file threw out of this loop, the single outer `catch` returned undefined,
		// and the unregistered report died with the drift report. Each file is now its own try,
		// and an unreadable file is REPORTED rather than fatal.
		try {
			if (baseline) {
				const now = createHash("sha256").update(readFileSync(full)).digest("hex").slice(0, 12);
				const was = baseline.get(name);
				if (was && was !== now) drifted.push(`${name} (digest ${was} → ${now})`);
				// ⛔ FIX 1 (Sedge): `!was` previously flagged EVERY file absent from the baseline as
				// "appeared since launch". The three permanently-unregistered extensions have no
				// baseline entry, so they were reported here AND in the unregistered section — the
				// same three names twice, as two unrelated problems, on every seat forever. A file
				// absent from the baseline is only news if a launcher registered it.
				else if (!was && registered[name]) drifted.push(`${name} (registered, but absent from the launch baseline)`);
			} else if (statSync(full).mtimeMs > MODULE_LOADED_AT) {
				drifted.push(`${name} (modified after this session loaded it)`);
			}
		} catch (error) {
			unreadable.push(`${name} (${String(error)})`);
		}
	}

	const mode = baseline ? "digest against the launcher baseline" : "mtime against module load time";

	// ⛔ FIX 4 (Sedge), ratified by Jo: A POSITIVE RECEIPT IS REQUIRED, NOT OPTIONAL. This
	// function previously returned undefined for three different meanings — not a seat launch,
	// internal failure, and all clean — so a broken watchdog was indistinguishable from a
	// healthy surface. That is the 34-day dead save reproduced inside the instrument built to
	// prevent it. One line converts a hope into a heartbeat. Sedge's framing, Jo's ruling.
	if (!unregistered.length && !drifted.length && !unreadable.length) {
		return `_Extension reconciliation ran: ${loadable.length} loadable, ${Object.keys(registered).length}`
			+ ` registered, no drift. Mode: ${mode}._`;
	}

	const out: string[] = ["## ⛔ OMP extension reconciliation"];

	if (unregistered.length) {
		out.push(
			`**Loaded but registered by no launcher: ${unregistered.length} of ${loadable.length}.**\n`
				+ unregistered.map(n => `- \`${n}\``).join("\n"),
			"These reached this session by directory auto-discovery — `extensions/*.{ts,js}` is"
				+ " loaded unconditionally, and the `extensions` array in settings can only ADD to that"
				+ " set, never restrict it. Nothing in any launcher or settings file records that they"
				+ " run, so no reviewer reading the launcher would know they are here.",
		);
	}

	if (drifted.length) {
		out.push(
			`**Changed since this session started: ${drifted.length}.**\n`
				+ drifted.map(d => `- \`${d}\``).join("\n"),
			"⛔ **This session is executing the bytes it loaded at launch, not what is on disk now.**"
				+ " Relaunch via `launch-seat` to pick the current files up.",
		);
	}

	if (unreadable.length) {
		out.push(
			`**Could not be checked: ${unreadable.length}.**\n` + unreadable.map(u => `- \`${u}\``).join("\n"),
			"These files are loadable by the discovery glob but this check could not read them, so"
				+ " their drift state is UNKNOWN rather than clean.",
		);
	}

	out.push(
		baseline
			? "_Drift measured by digest against the launcher's baseline._"
			: "⛔ _Drift measured by mtime against this module's load time — the weaker check."
				+ " `touch` without an edit reads as drift; a content change preserving mtime does not."
				+ " A digest baseline from `launch-seat` (`OMP_SEAT_EXT_DIGEST`) would remove both._",
		"_Scope limit: this compares against launch, so it cannot see a file that was already"
			+ " wrong when the seat started. Unlike the plugin-version banner, it has no true"
			+ " reference — only what this process loaded._",
		"⛔ _Cost of hosting this in the adapter, stated deliberately: it dies with the adapter,"
			+ " and its death looks like silence. The positive receipt above is the only thing that"
			+ " distinguishes a healthy surface from a check that never ran._",
	);
	return out.join("\n\n");
}

export default function newdleOmpHooks(pi: HookAPI) {
	let startupContext: string[] = [];
	let startupContextDelivered = false;

	pi.on("session_start", async (_event, ctx) => {
		startupContext = (await runManifestHooks("SessionStart", lifecycleInput("SessionStart", ctx.cwd), ctx.cwd)).additionalContext;
		// ⛔ Prepended, not appended: if anything downstream truncates this block, the reader must
		// still learn that every hook statement in this session describes an older plugin. And it
		// rides `startupContext`, which `before_agent_start` already delivers, so it adds no new
		// delivery path that could fail on its own.
		// ⛔ Both checks are prepended and BOTH are independent of each other: a failure in one
		// must not suppress the other, which is why they are separate calls returning undefined
		// rather than one combined builder.
		const reconcile = extensionReconciliation();
		if (reconcile) startupContext = [reconcile, ...startupContext];
		const stale = stalenessBanner();
		if (stale) startupContext = [stale, ...startupContext];
	});

	pi.on("before_agent_start", async () => {
		if (startupContextDelivered || !startupContext.length) return undefined;
		startupContextDelivered = true;
		return {
			message: {
				customType: "newdle-session-start",
				content: startupContext.join("\n\n"),
				display: false,
			},
		};
	});

	pi.on("session_stop", async (event, ctx) => {
		if (event.stop_hook_active) return undefined;
		// ⛔ `last_assistant_message` is what `output-types-guard.mjs` grades. Omitting it — which
		// this adapter did until 2026-09-15 — made that guard unable to fire for any seat at any
		// setting. Rendered to a string because the Claude-side payload supplies a string and the
		// guard reads it as one; OMP supplies an AgentMessage.
		// ⛔ THE REDIRECT REACHES output-types-guard.mjs AND NOTHING ELSE IN THIS GROUP.
		// Approved by Jo, 2026-09-15: "one more call site: output-types-guard.mjs fine to ads it."
		// wrap-up-nudge.sh and context-pressure.mjs keep the seat's real cwd — wrap-up `cd`s to
		// CLAUDE_PROJECT_DIR and would otherwise write relative to the anchor with nothing
		// announcing it.
		const stopPayload = lifecycleInput("Stop", ctx.cwd, {
			last_assistant_message: assistantText(event.last_assistant_message) ?? "",
		});
		const outcome = await runManifestHooks(
			"Stop",
			stopPayload,
			ctx.cwd,
			[],
			compactionProjectDir(ctx.cwd),
			"output-types-guard",
		);
		// ⛔ THE FAIL-OPEN NOTICE RIDES EVERY RETURN PATH, INCLUDING THE BLOCKS. Computed before the
		// first early return, because a turn that gets blocked for another reason is exactly the turn
		// whose unvalidated ledger write would otherwise go unreported — a signal that only survives
		// the happy path is the silent-failure defect with extra steps.
		const ledgerNotice = ledgerGuardNotice();
		// ⛔ READ ONCE, BEFORE THE FIRST EARLY RETURN, for the same reason as the ledger notice: the
		// turn that gets blocked for another reason is exactly the turn whose cancelled compaction
		// would otherwise go unmentioned, and the flag is consumed on read so it cannot repeat.
		const handoffAsk = handoffInstruction();
		const extras = [handoffAsk, ledgerNotice].filter(Boolean) as string[];
		const withExtras = (reason: string) => [reason, ...extras].join("\n\n");

		if (outcome.blockReason) return { decision: "block", reason: withExtras(outcome.blockReason) };
		// ⛔ AFTER the manifest hooks, deliberately. output-types-guard grades the whole message and
		// its refusal is the more fundamental one; a turn that fails both should hear about the
		// labels first rather than be corrected twice in an order nobody chose. See the block
		// comment above IDENTIFIER_GUARD for why this is not in settings.json.
		const identifierBlock = await identifierGuardBlock(stopPayload, ctx.cwd);
		if (identifierBlock) return { decision: "block", reason: withExtras(identifierBlock) };

		// ⛔ A BLOCK, NOT additionalContext, WHEN A HANDOFF IS OWED. additionalContext rides a
		// continuation the model may not act on; a block forces the turn the veto bought. This is
		// the only place in this file that blocks in order to make the model DO something rather
		// than to stop it doing something, and that asymmetry is deliberate.
		if (handoffAsk) return { decision: "block", reason: withExtras("").trim() };

		const context = [...outcome.additionalContext];
		if (ledgerNotice) context.push(ledgerNotice);
		if (!context.length) return undefined;
		return { continue: true, additionalContext: context.join("\n\n") };
	});

	pi.on("session_shutdown", async (_event, ctx) => {
		await runManifestHooks("SessionEnd", lifecycleInput("SessionEnd", ctx.cwd), ctx.cwd);
	});

	pi.on("session_before_compact", async (event, ctx) => {
		// ⛔ THE WHOLE HANDLER IS NOW WRAPPED, AND IT WAS NOT BEFORE. Measured while probing
		// sendMessage: a `preparation` missing `messagesToSummarize` threw
		// `undefined is not an object` straight out of this handler at `continuitySnapshot`. An
		// unhandled throw here reaches the compaction path, and the failure mode of a compaction
		// hook that throws is a session that may not be able to compact — the wall, not a
		// degradation. Every guard in this file fails open; this one did not.
		try {
			// THE SAVE HALF. Two independent records, deliberately: the in-session contribution
			// (survives compaction inside the session) and the plugin's on-disk snapshot (survives
			// the process). Neither substitutes for the other — the contribution is unreadable
			// after the process exits, and the file is unreadable by a mid-session restore.
			// ⛔ `captureContinuity` ALSO RECORDS TIER 1 for the restore half that runs moments
			// later in this same process. The contribution below is pinned by the host to the
			// FIRST crossing of the session (`session-maintenance.ts:346`), so from the second
			// crossing on it can no longer report this one — see the block comment above
			// `latestContinuity`.
			// It returns undefined instead of throwing; the early return below reproduces the
			// old behaviour of a throw here exactly (no contribution, no PreCompact, no archive,
			// no veto), while making that path assertable without a live compaction.
			const snapshot = captureContinuity(event.preparation, ctx.cwd);
			if (!snapshot) return undefined;
			pi.appendEntry("dev.newdle.omp.compaction-contribution", {
				key: "dev.newdle.omp.continuity",
				value: snapshot,
			});

			// ⛔ THE WRITE IS UNCONDITIONAL AND IT RUNS BEFORE THE VETO IS EVEN CONSULTED.
			// Lintel's ruling, 2026-09-16: "the machinery writes the save itself", every crossing,
			// not once per process and not skipped because a day-old handoff exists. That is the
			// order below — `runManifestHooks` is awaited here, and `vetoForHandoff` is only
			// reached afterwards, so all four of the veto's stand-downs leave the save intact.
			//
			// ⛔ AND IT NOW CARRIES THE SESSION'S REAL STATE. The three host fields
			// (`intents`, `file_operations`, `token_count`) are the ones `compact-continuity.mjs`
			// was built to accept from a transcript-less host and this bridge never sent; without
			// them the hook wrote `_source: none available_`, "(none detected)" and
			// "(none captured)" — the `ok` that saves nothing.
			await runManifestHooks(
				"PreCompact",
				compactionInput("PreCompact", ctx.cwd, { trigger: "auto" }, {
					intents: snapshot.userIntents,
					fileOperations: snapshot.fileOperations,
					tokensBefore: snapshot.tokensBefore,
				}),
				ctx.cwd,
				[],
				// ⛔ NO `projectDirOnlyFor` HERE, AND THAT IS CHECKED RATHER THAN ASSUMED. The
				// `PreCompact` group in `0.2.169/hooks/hooks.json` holds exactly one hook,
				// `compact-continuity.mjs`, so a whole-group redirect and a per-hook redirect are
				// the same set. If a second hook is ever added to that group this call needs
				// `CONTINUITY_HOOK_ONLY` too, for the reason spelled out at the SessionStart call.
				compactionProjectDir(ctx.cwd),
			);

			// ⛔ THE RETAINED COPY, AND ITS OWN RECEIPT. `archiveCompactionState` never throws on
			// a missing plugin snapshot, so a row here means a file exists; that is the artifact
			// the acceptance test names, and it is the one the restore's `unlinkSync` cannot take.
			const archived = archiveCompactionState(ctx.cwd, snapshot);
			if (archived) recordArchive(archived, snapshot);

			return vetoForHandoff(event, ctx.cwd);
		} catch {
			return undefined;   // fail open: never be the reason a session cannot compact
		}
	});

	pi.on("session_compact", async (event, ctx) => {
		// THE RESTORE HALF, and the half that decides whether any of this is a recovery. A save
		// nobody reads back is a file. Lintel's 543,700-token compaction on 2026-09-15 would have
		// been lost even with the save working, because nothing consumed it.
		//
		// It runs here rather than at session_start because OMP compacts IN SESSION: there is no
		// restart to restore across, so the moment to read the snapshot back is immediately after
		// the compaction that wrote it.
		// ⛔ THE ANCHOR REACHES compact-continuity.mjs AND NOTHING ELSE IN THIS GROUP.
		// Measured 2026-09-16: without the per-hook restriction this call handed
		// `CLAUDE_PROJECT_DIR=<hook-scope-anchor>` to all six SessionStart hooks, and
		// `recent-activity.sh` — which `cd`s to `CLAUDE_PROJECT_DIR` at `:39` and then tests the
		// RELATIVE `.ai/decision-log` at `:142` — reported "(no .ai/decision-log/ directory yet)"
		// into a compaction restore while `/Users/jowolff/.claude/.ai/decision-log/` held 121
		// git-tracked entries. `session-snapshot.mjs` is in the same group and took the same
		// redirect. The file forbade this in advance in the block comment above `SCOPE_ANCHOR`
		// ("NEVER WIDEN THIS TO THE GENERAL ... SessionStart GROUPS ... recent-activity.sh") and
		// this call site did it anyway, naming its own casualty.
		const restored = await runManifestHooks(
			"SessionStart",
			compactionInput("SessionStart", ctx.cwd, { source: "compact" }),
			ctx.cwd,
			["compact"],
			compactionProjectDir(ctx.cwd),
			CONTINUITY_HOOK_ONLY,
		);

		// ⛔ FRESHEST FIRST. `preserveData` alone — what this line used to read on its own — is
		// pinned to the session's FIRST crossing and cannot be updated afterwards, so it served a
		// three-hour-old snapshot to the compaction that had just saved a current one. Tier order,
		// the upstream mechanism and the cost of each tier are documented above `latestContinuity`.
		const inProcess = latestContinuityRecord();
		const resolved = resolveContinuity(
			inProcess,
			event.compactionEntry.preserveData,
			Date.now(),
			// ⛔ READ ONLY WHEN TIER 1 IS EMPTY — the fresh-process case, which is the one the
			// durable tier exists for. When this process made the save being restored, nothing on
			// disk can beat it, so scanning a shared directory on every crossing would be work
			// that cannot change the answer.
			inProcess ? undefined : latestArchiveSidecar(archiveDirFor(ctx.cwd), archiveIdentity(ctx.cwd)),
		);

		pi.sendMessage({
			customType: "dev.newdle.omp.continuity-restored",
			content: continuityMessage(resolved, restored.additionalContext),
			display: false,
			attribution: "agent",
		});
	});

	pi.on("tool_call", async (event, ctx) => {
		// ⛔ BEFORE the manifest loop, and before the manifest file is even read: this guard
		// protects `REQUESTS.jsonl`, which `savepoint-generate.py:476` reads, and a denial here
		// must not depend on the manifest being readable. Its own prefilter makes the common case
		// free — see the block above LEDGER_GUARD.
		const ledgerDenial = await ledgerGuardDeny(event.toolName, event.input, process.cwd());
		if (ledgerDenial) return { block: true, reason: ledgerDenial };

		// ⛔ RESOLVE-AND-REWRITE, THE ROUTING-GATE SHAPE. Lintel's ruling, 2026-09-16: "detect, and
		// then DO THE THING", because a block enforces a stop while the reason text inside it is
		// data with no authority — its own armed pole proved a model reads a refusal and declines
		// to act on it. So where the outgoing text is a tool argument, the URL is inserted here and
		// nothing is asked of the seat. `ToolCallEventResult.input` is the documented channel
		// (`shared-events.ts:315-331`): the revision is revalidated against the tool schema and
		// becomes what the loop schedules, displays, persists and executes.
		const rewritten = await urlMachineryRewrite(event.toolName, event.input);
		if (rewritten) return { input: rewritten };

		const raw = await Bun.file(hookManifest).json();
		const groups = raw?.hooks?.PreToolUse;
		if (!Array.isArray(groups)) return undefined;
		const claudeTool = toolNames[event.toolName] ?? event.toolName;
		const stdin = hookInput(event.toolName, event.input, process.cwd());

		for (const group of groups) {
			const matcher = typeof group.matcher === "string" ? group.matcher : "";
			if (matcher && !matcher.split("|").includes(claudeTool)) continue;
			for (const hook of group.hooks ?? []) {
				if (hook.type !== "command" || typeof hook.command !== "string") continue;
				const result = await runCommand(hook.command, stdin, process.cwd());
				const output = result?.hookSpecificOutput;
				if (!output || output.hookEventName !== "PreToolUse") continue;

				if (output.permissionDecision === "deny") {
					return { block: true, reason: output.permissionDecisionReason ?? "Blocked by Newdle hook" };
				}
				if (output.permissionDecision === "ask") {
					if (!ctx.hasUI) return { block: true, reason: output.permissionDecisionReason ?? "Newdle confirmation required" };
					const approved = await ctx.ui.confirm("Newdle confirmation", output.permissionDecisionReason ?? "Allow this tool call?");
					if (!approved) return { block: true, reason: "Newdle confirmation declined" };
				}

				// OMP's tool-call result type has no pre-tool additional-context field.
				// Surface Newdle's context in a blocked tool result instead: the model
				// receives it, then retries the edit. The Newdle hook's state file has
				// already deduplicated that context for the retry.
				if (output.additionalContext) {
					return {
						block: true,
						reason: `Newdle repository rules loaded before retrying this edit:\n\n${output.additionalContext}`,
					};
				}
			}
		}
		return undefined;
	});
}

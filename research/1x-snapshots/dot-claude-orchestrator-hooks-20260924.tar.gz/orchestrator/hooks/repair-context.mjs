/**
 * repair-context.mjs — does an interactive turn exist for this Stop to be repaired in?
 *
 * WHY THIS EXISTS
 * A Stop hook that writes to stdout does not merely print. Its `additionalContext` induces a
 * SECOND assistant turn, and a headless run (`claude -p ...`) returns only its LAST message.
 * On 2026-08-25 a finished 20,543-character cross-provider review was replaced by a 33-second
 * reply to a Stop hook. The hook's own file writes had all succeeded; the record was never at
 * risk. Only the EMISSION was destructive. So this gates emission and nothing else.
 *
 * WHAT IT DOES NOT DO
 * It does not gate recording. Callers must write their row FIRST and consult this SECOND.
 * Leaving the record intact on a suppressed turn is the entire design, not a nicety.
 *
 * ── THE HONEST PART, READ IT BEFORE TRUSTING THIS ──────────────────────────────────────────
 * The Stop payload carries NO field that distinguishes a headless leg from an interactive
 * session. Measured 2026-08-25, run id stop-emission-gate-20260825, across the three real Stop
 * payloads that exist on this machine (one archived from 2026-08-21, one captured from
 * `claude -p --permission-mode plan`, one from plain `claude -p`): the field sets are IDENTICAL — session_id, transcript_path, cwd, prompt_id, permission_mode,
 * effort, hook_event_name, stop_hook_active, last_assistant_message, background_tasks,
 * session_crons. `permission_mode` reports plan/default/acceptEdits, which a human sets
 * interactively with shift-tab; it says nothing about whether a human is there.
 *
 * The ONLY signal that separates them anywhere on this surface is `entrypoint`, recorded on the
 * transcript's own records: `cli` for a terminal session, `sdk-cli` for `claude -p` and the SDK,
 * `claude-vscode` for the editor. Census over 2034 transcripts under ~/.claude/projects:
 * cli 1149, sdk-cli 882, claude-vscode 1.
 *
 * CAVEAT, AND IT IS NOT SMALL: all three real Stop payloads came from sdk-cli sessions. Nobody
 * has yet captured a Stop payload from a genuine `entrypoint: cli` terminal session, because a
 * background agent cannot drive one. The claim that a cli session's Stop payload has the same
 * field set is therefore UNTESTED. What is tested is that 1149 transcripts on disk carry
 * `entrypoint: cli`, and the interactive test case below feeds this module one of them.
 *
 * That is a runner-name enumeration, which the brief for this work explicitly forbade, on the
 * correct grounds that an exemption list is always one short. The polarity here is the answer to
 * that objection and the reason this ships anyway: this is an ALLOWLIST OF SURFACES WHERE REPAIR
 * IS POSSIBLE, not a denylist of runners to exempt. An `entrypoint` value nobody has seen yet
 * falls through to SUPPRESS. Being one short therefore costs a missed nudge on some future
 * interactive surface — recoverable, and the gap row still names the turn — instead of costing a
 * destroyed report, which is not recoverable. Every unknown, every unreadable transcript, every
 * malformed payload lands on the safe side by construction.
 *
 * It is still an enumeration. If a future release renames `cli`, this suppresses everywhere and
 * the nudge silently stops. That failure is quiet, so the caller records `entrypoint` verbatim in
 * its row: a reader seeing an unfamiliar value in every row knows the list went stale.
 */

import { readFileSync, openSync, readSync, closeSync } from 'node:fs';

/**
 * Surfaces where a human can read an emitted nudge and act on it in a following turn.
 * Adding to this set ALLOWS emission on that surface — the unsafe direction. Add a value only
 * after confirming a real human turn follows Stop there.
 */
export const REPAIRABLE_ENTRYPOINTS = new Set(['cli', 'claude-vscode']);

const HEAD_BYTES = 65536;

/** Read at most the first HEAD_BYTES of a file without slurping a 200MB transcript. */
function readHead(path) {
  let fd;
  try {
    fd = openSync(path, 'r');
    const buf = Buffer.alloc(HEAD_BYTES);
    const n = readSync(fd, buf, 0, HEAD_BYTES, 0);
    return buf.subarray(0, n).toString('utf8');
  } catch {
    return null;
  } finally {
    if (fd !== undefined) { try { closeSync(fd); } catch { /* ignore */ } }
  }
}

/**
 * Pull `entrypoint` off the first transcript record that carries one.
 * Returns a string, or null when the transcript is missing, unreadable, or carries no such field.
 */
export function readEntrypoint(transcriptPath) {
  if (typeof transcriptPath !== 'string' || !transcriptPath) return null;
  const head = readHead(transcriptPath);
  if (head === null) return null;
  const lines = head.split('\n');
  // A truncated final line is not parseable; dropping it is correct, and `entrypoint` appears
  // within the first handful of records in every transcript inspected.
  for (let i = 0; i < lines.length - 1; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    let rec;
    try { rec = JSON.parse(line); } catch { continue; }
    if (rec && typeof rec.entrypoint === 'string' && rec.entrypoint) return rec.entrypoint;
  }
  return null;
}

/**
 * @param {unknown} payload  a parsed Stop hook payload, or anything at all
 * @returns {{ repairable: boolean, entrypoint: string|null, reason: string }}
 *   `repairable: false` means the caller must NOT write to stdout. It says nothing about
 *   whether the caller should record — it always should, and before calling this.
 */
export function repairContext(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return { repairable: false, entrypoint: null, reason: 'payload-not-an-object' };
  }
  const tp = payload.transcript_path;
  if (typeof tp !== 'string' || !tp) {
    return { repairable: false, entrypoint: null, reason: 'no-transcript-path' };
  }
  const entrypoint = readEntrypoint(tp);
  if (entrypoint === null) {
    return { repairable: false, entrypoint: null, reason: 'entrypoint-unreadable' };
  }
  if (!REPAIRABLE_ENTRYPOINTS.has(entrypoint)) {
    return { repairable: false, entrypoint, reason: 'entrypoint-not-repairable' };
  }
  return { repairable: true, entrypoint, reason: 'entrypoint-repairable' };
}

export default repairContext;

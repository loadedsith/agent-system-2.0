#!/usr/bin/env node
/**
 * PreToolUse(Bash) — blocks MASS staging inside ~/.claude only, and only in the orchestrator's
 * own session.
 *
 * The risk it addresses is not the dirty-path count of the day. It is that ONE careless mass
 * stage buries a path-scoped audit trail under thousands of cache deletions, in a repo with no
 * remote. Measured 2026-08-20 in /Users/jowolff/.claude: 16,729 tracked files, 3,916 of them
 * showing as deleted in the worktree, no .gitignore, no remote.
 *
 * It deliberately does NOT change how self-modification works. Every commit made here already
 * used explicit paths. A guard that forced a new workflow would be a badly scoped guard; this one
 * forbids only the shortcut that is never legitimately needed here.
 *
 * ---------------------------------------------------------------------------------------------
 * THIRD DEFECT FIXED HERE — the guard matched the SPELLING of the command, not the OPERATION.
 *
 * The two earlier fixes (session scoping, and sanitizing quoted spans before splitting) were
 * both correct and are both preserved. But the sanitizer solved the prose problem by COLLAPSING
 * every quoted span to the literal token `Q`, and the matchers were regexes over that collapsed
 * text. So quoting any token erased it from the matcher's view while changing nothing about what
 * the shell would execute. Measured against the previous build, 2026-08-20:
 *
 *     sanitize('git add -A')            -> 'git add -A'      DENY   (intended)
 *     sanitize('git add "-A"')          -> 'git add Q'       ALLOW  (bypass)
 *     sanitize('git "add" -A')          -> 'git Q -A'        ALLOW  (bypass)
 *     sanitize("git add '.'")           -> 'git add Q'       ALLOW  (bypass)
 *     sanitize('git commit "-am" "msg"')-> 'git commit Q Q'  ALLOW  (bypass)
 *
 * and four more found by probing, none of which involved quoting at all:
 *
 *     git add --al                 ALLOW  (git accepts unambiguous long-option abbreviations;
 *                                          verified by running `git add --dry-run --al .`)
 *     git add -vA                  ALLOW  (fused short flags; verified the same way)
 *     git add --no-ignore-removal  ALLOW  (`git add -h`: --ignore-removal is "same as --no-all",
 *                                          so its negation is exactly -A)
 *     git stage -A                 ALLOW  (`git stage -h` prints `usage: git add`; it is an alias)
 *
 * Symmetrically, scope was decided from the SESSION's cwd plus a raw substring search for the
 * guard path anywhere in the command text, so it fired on commands that could not touch this
 * repo at all. Measured against the previous build, same session:
 *
 *     cwd=~/.claude          git -C /Users/jowolff/code/shipyard add -A       DENY (wrong repo)
 *     cwd=~/.claude          cd /Users/jowolff/code/shipyard && git add -A    DENY (wrong repo)
 *     cwd=shipyard           git add -A  # unrelated to /Users/jowolff/.claude DENY (a COMMENT)
 *     cwd=~/.claude-sandbox  git add -A                                       DENY (prefix, not
 *                                                                                   containment)
 *
 * THE FIX: stop pattern-matching text. Lex the command into segments and words the way a shell
 * would — quotes removed but their CONTENT KEPT, heredoc bodies dropped, splitting only on
 * UNQUOTED separators — then interpret each segment as an operation with a target:
 *
 *   1. which directory the command runs in (cwd, updated by `cd`, redirected by `git -C`)
 *   2. which git subcommand it is (`add`, its alias `stage`, or `commit`)
 *   3. whether that subcommand's flags or pathspecs make it sweeping
 *
 * A deny needs BOTH a sweeping operation AND a target inside the guarded tree. Quoting is now
 * irrelevant, because `"-A"` and `-A` lex to the same word. Spelling is now irrelevant, because
 * `-A`, `-vA`, `--all`, `--al` and `--no-ignore-removal` all reduce to the same fact about the
 * operation. And an unrelated repo is now out of scope no matter what the command text mentions.
 *
 * WHAT THIS DELIBERATELY DOES NOT DO: expand variables, resolve aliases, follow scripts, or read
 * `--pathspec-from-file`. Where it cannot see the operand it assumes the sweeping reading and
 * denies, because the cost of a wrong deny here is one clarifying question and the cost of a
 * wrong allow is the audit trail.
 *
 * Always exits 0. Decides via stdout JSON, per the eval contract.
 */
import { readFileSync } from 'node:fs';
import { join, sep } from 'node:path';
import { homedir } from 'node:os';
import { inOrchestratorSession } from './session-gate.mjs';
// lex() and makeNorm() moved to ./shell-lex.mjs on 2026-08-26, bodies unchanged, so a second
// guard can share this lexer instead of growing its own. A second lexer is a second set of
// bypasses, and the header above is a catalogue of what those cost.
import { lex, makeNorm } from './shell-lex.mjs';

const allow = () => process.exit(0);
const deny = (reason) => {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: reason },
  }));
  process.exit(0);
};

let p = {};
try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { allow(); }
if (p.tool_name !== 'Bash') allow();

// SESSION GATE, first thing after parsing. Fails closed. A subagent's tool call carries its
// PARENT session's session_id (measured), so subagent commands stay guarded.
const STATE = process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');
if (!inOrchestratorSession(p, STATE)) allow();

const cmd = String(p.tool_input?.command ?? '');
if (!cmd) allow();

const HOME = homedir();
const GUARD_ROOT = process.env.LINTEL_GUARD_ROOT || join(homedir(), '.claude');

const norm = makeNorm(HOME);

const GUARD = norm(GUARD_ROOT, HOME);
// Containment, not prefix. `~/.claude-sandbox` starts with `~/.claude` as a STRING and is a
// different directory; the previous build denied in it.
const inGuard = (abs) => abs === GUARD || abs.startsWith(GUARD + sep);

/**
 * Long-option matching that mirrors git's own parse-options: an unambiguous PREFIX of a long
 * option is that option. `git add --al` really does stage everything; the previous build's exact
 * string match never saw it. Over-matching an ambiguous prefix such as `--a` is deliberate — git
 * rejects it anyway, so the only cost is denying a command that would not have run.
 *
 * Negations are handled by the list itself rather than by a rule: `--ignore-removal` is git's
 * own synonym for `--no-all` and is NOT sweeping, while `--no-ignore-removal` is exactly `-A`.
 * Both verified against `git add -h`, git 2.50.1.
 */
const SWEEPING = {
  add: {
    short: ['A', 'u'],
    long: ['all', 'no-ignore-removal', 'update', 'renormalize', 'pathspec-from-file'],
    label: 'stages every tracked and/or untracked change in the tree',
  },
  commit: {
    short: ['a'],
    long: ['all'],
    label: 'commits every tracked modification without naming a path',
  },
};

const longIsSweeping = (name, list) => list.some((full) => full.startsWith(name));

// Pathspecs that mean "everything from here down", plus git's magic for "the whole repo".
const SWEEPING_PATHSPEC = new Set(['.', './', '..', '../', '*', ':/', ':/.', ':/*', ':(top)']);

/**
 * Read one segment as a git invocation. Returns null when it is not one.
 * `dir` is the directory the segment runs in; the return carries the directory the GIT COMMAND
 * targets, which `-C`, `--git-dir` and `--work-tree` can move somewhere else entirely.
 */
function readGit(words, dir) {
  let i = 0;
  if (words[i] === 'sudo' || words[i] === 'command' || words[i] === 'nice') i++;
  if (words[i] === 'env') i++;
  while (i < words.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(words[i])) i++;
  if (words[i] !== 'git') return null;
  i++;

  let target = dir;
  for (; i < words.length; i++) {
    const w = words[i];
    if (w === '-C' || w === '--git-dir' || w === '--work-tree') { target = norm(words[++i] ?? '', target); continue; }
    if (w.startsWith('-C') && w.length > 2) { target = norm(w.slice(2), target); continue; }
    if (w.startsWith('--git-dir=') || w.startsWith('--work-tree=')) { target = norm(w.slice(w.indexOf('=') + 1), target); continue; }
    if (w === '-c') { i++; continue; }
    if (w.startsWith('-')) continue;                      // -p, --no-pager, --exec-path=… etc.
    break;
  }

  const sub = words[i];
  // `stage` is an alias for `add`: `git stage -h` prints `usage: git add`. Verified, git 2.50.1.
  const op = sub === 'add' || sub === 'stage' ? 'add' : sub === 'commit' ? 'commit' : null;
  if (!op) return null;

  return { op, target, args: words.slice(i + 1) };
}

/** Does this invocation sweep? Returns a human-readable reason, or null. */
function sweepReason({ op, target, args }) {
  const spec = SWEEPING[op];
  const operands = [];
  let literal = false;

  for (let i = 0; i < args.length; i++) {
    const w = args[i];
    if (literal || !w.startsWith('-') || w === '-') { operands.push(w); continue; }
    if (w === '--') { literal = true; continue; }
    if (w.startsWith('--')) {
      const name = w.slice(2).split('=')[0];
      if (longIsSweeping(name, spec.long)) return `git ${op} --${name} — ${spec.label}`;
      continue;
    }
    // Fused short flags: -vA is -v -A. The previous build's regex required -A to stand alone.
    for (const ch of w.slice(1)) if (spec.short.includes(ch)) return `git ${op} -${ch} — ${spec.label}`;
  }

  if (op !== 'add') return null;

  for (const o of operands) {
    if (SWEEPING_PATHSPEC.has(o) || o.startsWith(':/') || o.startsWith(':(')) {
      return `git add ${o} — stages everything under the whole tree`;
    }
    // A named path that IS the target directory, or an ancestor of it, is the same sweep wearing
    // a longer name. `git add /Users/jowolff/.claude` from a subdirectory is `git add :/`.
    const abs = norm(o, target);
    if (abs === target || target.startsWith(abs + sep)) {
      return `git add ${o} — resolves to ${abs}, the root of the tree being staged`;
    }
  }
  return null;
}

// Walk the segments in order, carrying the directory forward: `cd X && git add -A` targets X.
let dir = norm(String(p.cwd ?? HOME), HOME);
for (const words of lex(cmd)) {
  if (words[0] === 'cd' || words[0] === 'pushd') {
    dir = words[1] ? norm(words[1], dir) : HOME;
    continue;
  }
  const g = readGit(words, dir);
  if (!g) continue;

  const why = sweepReason(g);
  if (!why) continue;

  // BOTH halves are required. A sweeping command in another repo is none of this hook's
  // business, and a narrow command in this one is the workflow already in use.
  const reachesIn = inGuard(g.target)
    || g.args.some((a) => !a.startsWith('-') && inGuard(norm(a, g.target)));
  if (!reachesIn) continue;

  const where = inGuard(g.target) ? g.target : GUARD;
  deny(
    `Mass git staging is blocked in ${GUARD}. This command targets ${where}.\n\n` +
    `Matched: ${why}\n\n` +
    `Why: measured 2026-08-20, this repo tracks 16,729 files, 3,916 of them currently showing ` +
    `as deleted cache and transcript churn, it has no .gitignore, and it has no remote. One ` +
    `mass-stage buries the audit trail that every charter change, experiment, and retraction ` +
    `depends on, with nothing to restore it from.\n\n` +
    `Stage the paths you actually changed, named individually:\n` +
    `  git add <the/file/you/edited> <the/other/one>\n\n` +
    `That is not a new workflow — it is the one already in use for every commit here.\n` +
    `This guard runs only in the orchestrator's own session, so there is no other session to ` +
    `hand this to. If a mass stage here is genuinely correct, it is Jo's call: stop, say what ` +
    `you were about to stage and why, and ask.`
  );
}
allow();

#!/usr/bin/env node
/**
 * Keep request-to-GitHub reconciliation in disposable hands.
 *
 * PreToolUse denies live reconciliation from a top-level Lintel or Tinker turn while
 * allowing subagents and the read-only pending probe. Stop blocks the authoritative
 * orchestrator session while an applicable non-terminal ledger row lacks an exact
 * target-repository issue URL. Together those constraints make a disposable hand the
 * only route that can clear newly appended machinery requests.
 */
import { readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { basename, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { inOrchestratorSession, stateDir } from './session-gate.mjs';
import { lex } from './shell-lex.mjs';

const HOME = process.env.HOME || homedir();
const STATE = stateDir();
const LEDGER = process.env.REQUEST_ISSUE_LEDGER || join(STATE, 'REQUESTS.jsonl');
const CORE = process.env.REQUEST_ISSUE_CORE || join(HOME, '.claude', 'orchestrator', 'tools', 'request_issues_reconcile.py');
const REPO = process.env.REQUEST_ISSUE_REPO || 'thewolff/lintel-tasks';
const WRAPPER = 'request-issues-reconcile.sh';
const CORE_NAME = 'request_issues_reconcile.py';
const PYTHONS = new Set(['python', 'python3']);
const SHELLS = new Set(['sh', 'bash', 'zsh']);

function deny(reason) {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason,
    },
  }));
}

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function commandStart(words) {
  let i = 0;
  while (i < words.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(words[i])) i++;
  if (basename(words[i] || '') !== 'env') return i;
  i++;
  while (i < words.length) {
    const word = words[i];
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(word) || word.startsWith('-')) i++;
    else break;
  }
  return i;
}

function scriptAfter(words, index) {
  for (let i = index + 1; i < words.length; i++) {
    if (words[i] === '--') return words[i + 1] || '';
    if (!words[i].startsWith('-')) return words[i];
  }
  return '';
}

function invokesLiveReconciler(words) {
  if (words.includes('--pending-hand')) return false;
  const start = commandStart(words);
  const command = basename(words[start] || '');
  if (command === WRAPPER || command === CORE_NAME) return true;
  if (SHELLS.has(command)) return basename(scriptAfter(words, start)) === WRAPPER;
  if (PYTHONS.has(command) || /^python3(?:\.[0-9]+)?$/.test(command)) {
    return basename(scriptAfter(words, start)) === CORE_NAME;
  }
  return false;
}

function validateProbe(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('pending probe did not return an object');
  }
  if (value.repo !== REPO || !Array.isArray(value.pending)) {
    throw new Error('pending probe returned the wrong repository or pending shape');
  }
  const seen = new Set();
  for (const requestId of value.pending) {
    if (typeof requestId !== 'string' || !/^REQ-[0-9]+$/.test(requestId) || seen.has(requestId)) {
      throw new Error('pending probe returned an invalid or duplicate request identifier');
    }
    seen.add(requestId);
  }
  return value.pending;
}

function checkPending() {
  const result = spawnSync(
    process.env.PYTHON || 'python3',
    [CORE, '--ledger', LEDGER, '--repo', REPO, '--pending-hand'],
    { encoding: 'utf8', timeout: 15000, maxBuffer: 1024 * 1024 },
  );
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || `probe exited ${result.status}`).trim());
  }
  return validateProbe(JSON.parse(result.stdout));
}

let payload;
try {
  payload = JSON.parse(readFileSync(0, 'utf8'));
} catch {
  process.exit(0);
}

if (payload?.hook_event_name === 'PreToolUse' && payload?.tool_name === 'Bash') {
  const command = payload?.tool_input?.command;
  const isTopLevel = typeof payload?.agent_id !== 'string' || payload.agent_id.trim() === '';
  if (isTopLevel && typeof command === 'string' && lex(command).some(invokesLiveReconciler)) {
    deny(
      'Request-to-GitHub reconciliation is reserved for a named disposable Task/Agent hand. ' +
      'Dispatch a hand to run orchestrator/tools/request-issues-reconcile.sh; Lintel and Tinker must not run it inline.',
    );
  }
  process.exit(0);
}

if (payload?.hook_event_name !== 'Stop' || payload?.stop_hook_active) process.exit(0);
if (!inOrchestratorSession(payload, STATE)) process.exit(0);

try {
  const pending = checkPending();
  if (pending.length > 0) {
    block(
      'Applicable non-terminal request ledger rows still need GitHub reconciliation by a named disposable Task/Agent hand: ' +
      pending.join(', ') + '. The hand must run orchestrator/tools/request-issues-reconcile.sh --apply; ' +
      'Lintel and Tinker are denied from reconciling inline.',
    );
  }
} catch (error) {
  block(
    'Could not verify request-to-GitHub reconciliation before Stop. Dispatch a named disposable Task/Agent hand to diagnose it. ' +
    `Probe failure: ${error instanceof Error ? error.message : String(error)}`,
  );
}

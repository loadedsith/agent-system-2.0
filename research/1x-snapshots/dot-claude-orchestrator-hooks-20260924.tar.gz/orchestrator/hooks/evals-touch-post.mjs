#!/usr/bin/env node
/**
 * evals-touch-post.mjs — LAB BUILD, NOT INSTALLED, NOT REGISTERED ANYWHERE.
 * Built in /Users/jowolff/.claude/orchestrator/build/charter-mech-lab/ during run
 * `charter-rules-mechanised-20260825`. Whoever installs this must not be whoever wrote it.
 *
 * ── THE RULE IT MECHANISES ───────────────────────────────────────────────────────────────
 * Charter § Dispatch contract, line 187: "Any dispatch whose work touches `orchestrator/evals/`
 * names the `orchestrator-evals` skill in its brief." The charter itself concedes that line
 * reaches the DISPATCHER and never the worker, and asks for the gap to be closed by other means.
 * This is one of those means. It is the second, not the first — see the next block.
 *
 * ── WHY IT EXISTS ALONGSIDE build/eval-touch-lab/evals-touch.mjs, WHICH IS NOT A DUPLICATE ──
 * That hook fires on a STRUCTURED path argument (file_path on Read/Edit/Write, path on
 * Glob/Grep) and DELIBERATELY excludes Bash, on the correct reasoning that a path inside a
 * command line is not a structured field. Its own header states the cost of that exclusion:
 * "a worker that does everything through cat, sed and shell redirection is invisible to this
 * hook. That is a real hole."
 *
 * ⛔ THAT HOLE WAS NEVER MEASURED, AND IT IS NOT A CORNER CASE — IT IS THE DOMINANT MODE.
 * Measured 2026-08-25 over 2,035 transcripts under ~/.claude/projects, by
 * ../measure/scan-evaltouch-denominator.py:
 *
 *     structured-path touches of orchestrator/evals/ (what that hook can see) :   2
 *     Bash calls naming orchestrator/evals/          (what it cannot see)     : 227
 *
 * So the structured-path hook's day-one denominator is about 1% of real eval work. A checker
 * with that denominator prints a clean line forever and nobody notices it is not working.
 *
 * ── HOW THIS ONE AVOIDS READING PROSE, WHICH IS THE INSTRUMENT THAT KEEPS FAILING HERE ──
 * It never looks at the command string. It looks at THE FILESYSTEM: did any file under
 * orchestrator/evals/ acquire an mtime newer than the last one this hook recorded? A modification
 * time is not a matcher over prose, so `echo "see evals/README.md"`, a grep sweeping the tree, and
 * a `find` over the suite are all silent by construction rather than by pattern exclusion.
 *
 * ⛔ THE PRICE, STATED RATHER THAN GLOSSED: it is a POST hook, so it speaks AFTER the first write
 * rather than before it. eval-touch-lab argues, correctly, that write-time firing is late — the
 * shape of the scenario is already chosen. This does not replace that argument; it says a late
 * nudge that reaches 100% of writers beats an early nudge that reaches 1%. Install BOTH, or
 * install this one, but do not install the structured-path hook alone believing it covers the
 * suite.
 *
 * ── WHAT IT WILL FIRE ON THAT IS NOT A WORKER AUTHORING A SCENARIO ──────────────────────
 * Named rather than hidden, because a hook's honest failure list is the thing that decides
 * whether it gets muted:
 *   - a checkout, a restore, or any version-control operation that rewrites files under evals/
 *   - a file copy or backup that lands inside evals/
 *   - a write made by a DIFFERENT session between two of this session's Bash calls
 * All three are genuine false positives. All three are rare, and the nudge is one non-blocking
 * paragraph that appears at most once per turn. Verified silent: reading the suite, grepping it,
 * listing it, and RUNNING it — the tier-1 runner writes its results under $TMPDIR
 * (run-tier1.sh: OUT_BASE="${EVAL_OUT_ROOT:-${TMPDIR:-/tmp}}/lintel-tier1"), never into evals/.
 *
 * ── CONTRACT, copied from the sibling hooks in this house ────────────────────────────────
 * ALWAYS exit 0. It NEVER blocks: no `decision`, no `permissionDecision`, no `continue:false`.
 * It emits only hookSpecificOutput.additionalContext. FAIL OPEN AND SILENT on everything about
 * its own plumbing: garbage stdin, unreadable state, an unwritable watermark, a foreign session.
 *
 * Env (all optional): EVALS_POST_MODE (on|off), EVALS_ROOT, EVALS_POST_STATE, LINTEL_STATE.
 */
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { homedir } from 'node:os';

const done = () => process.exit(0);

let p = {};
try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { done(); }
if (!p || typeof p !== 'object' || Array.isArray(p)) done();
if ((process.env.EVALS_POST_MODE || 'on') === 'off') done();

const STATE = process.env.EVALS_POST_STATE || process.env.LINTEL_STATE
  || join(homedir(), '.claude', 'orchestrator', 'state');

// SESSION GATE, fails closed. Same shape as routing-counter.mjs and intake-capture.mjs: without
// it a universal matcher fires this in every session on this machine, including other people's.
try {
  const want = readFileSync(join(STATE, '.session-id'), 'utf8').trim();
  const got = String(p.session_id ?? '').trim();
  if (!(want.length > 0 && got.length > 0 && want === got)) done();
} catch { done(); }

const EVALS = process.env.EVALS_ROOT
  || join(homedir(), '.claude', 'orchestrator', 'evals');

// Max mtime under the suite. Bounded walk: the live suite is 326 files and a full sweep measured
// at about 5ms, which is why this is affordable after every Bash call. Depth-capped so a symlink
// loop or an accidental nesting cannot turn a hook into a tree walk of the whole disk.
function maxMtime(dir, depth = 0) {
  if (depth > 6) return 0;
  let best = 0;
  let entries;
  try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return 0; }
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isSymbolicLink()) continue;
    if (e.isDirectory()) { const m = maxMtime(full, depth + 1); if (m > best) best = m; }
    else if (e.isFile()) {
      try { const m = statSync(full).mtimeMs; if (m > best) best = m; } catch { /* ignore */ }
    }
  }
  return best;
}

const now = maxMtime(EVALS);
if (!now) done();                                   // no suite here; nothing to watch

const wmFile   = join(STATE, '.evals-watermark');
const firedDir = join(STATE, '.evals-post-fired');

function turnKey(payload) {
  const clean = (v, fb) => String(v ?? fb).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64) || fb;
  return `${clean(payload?.session_id, 'nosession')}-${clean(payload?.prompt_id, 'noprompt')}`;
}
const key = turnKey(p);

let prev = 0;
try { prev = Number(readFileSync(wmFile, 'utf8').trim()) || 0; } catch { prev = 0; }

function saveWatermark() {
  try { mkdirSync(dirname(wmFile), { recursive: true }); writeFileSync(wmFile, String(now)); } catch { /* ignore */ }
}

// FIRST EVER RUN: adopt the current state as the baseline and say nothing. A hook that fires on
// its own installation trains the reader to ignore it on the one occasion it is certainly wrong.
if (prev === 0) { saveWatermark(); done(); }

if (now <= prev) done();                            // nothing under the suite changed
saveWatermark();

// ONCE PER TURN. A worker editing six scenarios gets one nudge, not six.
const firedFile = join(firedDir, `${key}.marker`);
try { statSync(firedFile); done(); } catch { /* not fired yet */ }
try { mkdirSync(firedDir, { recursive: true }); writeFileSync(firedFile, String(Date.now())); } catch { done(); }

const msg =
  'A file under the orchestrator eval suite just changed. Before writing or editing another ' +
  'scenario, invoke the `orchestrator-evals` skill — it points at ' +
  '/Users/jowolff/.claude/orchestrator/evals/README.md and at the worked scenarios to copy from. ' +
  'A scenario written from the conventions alone, without a worked example, passes review and ' +
  'does not belong in the suite. Two things the README will not shout at you and that this suite ' +
  'enforces mechanically: every silence scenario needs a firing sibling one field apart ' +
  '(pair-check.sh), and results are written under $TMPDIR, never into evals/. ' +
  'If this change was a checkout, a restore, or a copy rather than authoring, ignore this line.';

process.stdout.write(JSON.stringify({
  hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: msg }
}));
process.exit(0);

# Quarantined hooks — revive by copying back, not by running in place

Retired by `6bac50b` (2026-09-15). The files here are unregistered for every seat and kept so
the retirement stays reversible.

## Five of these six files cannot be run where they sit

They `import` siblings by relative path — `./session-gate.mjs`, `./turn-id.mjs`,
`./repair-context.mjs` — and all three modules stayed in `hooks/`. Node therefore refuses a
quarantined hook before it reads a byte of stdin:

```
$ node .retired-20260915/turn-id-mint.mjs
Error [ERR_MODULE_NOT_FOUND]: Cannot find module
  .../hooks/.retired-20260915/session-gate.mjs
  imported from .../hooks/.retired-20260915/turn-id-mint.mjs
exit 1
```

`6bac50b` verified that no still-registered hook imports a quarantined file. It did not check
the reverse — a quarantined hook importing a still-registered module — and the reverse is the
defect. It cost a day of eval results: 24 scenarios in `orchestrator/evals` invoked these paths
and reported 9 FAIL / 13 INDETERMINATE while appearing to test a mechanism.

## To revive one

```sh
cp .retired-20260915/<hook>.mjs ../
```

then re-register it. The imports resolve once the file sits beside its siblings again.

## Why this is not "fixed" by rewriting the imports to `../`

Making these files runnable in place would mean a stray registration could execute a retired
hook from a directory whose name says it is retired. An inconvenient quarantine is a smaller
failure than an executable one. Copy-back is the supported revival path, deliberately.

## What each file needs

Measured by loading each file with empty stdin (`node <file> </dev/null`):

| File | Siblings it imports from `hooks/` | Loads in place |
|---|---|---|
| `turn-id-mint.mjs` | `session-gate.mjs`, `turn-id.mjs` | no, exit 1 |
| `turn-id-verify.mjs` | `session-gate.mjs`, `turn-id.mjs` | no, exit 1 |
| `savepoint-fit-stop.mjs` | `session-gate.mjs` | no, exit 1 |
| `decision-gap-stop.mjs` | `repair-context.mjs`, `session-gate.mjs` | no, exit 1 |
| `dispatch-check-stop.mjs` | `session-gate.mjs` | no, exit 1 |
| `state-checks-stop.mjs` | none — node builtins only | yes, exit 0 |

`state-checks-stop.mjs` is the control: it proves the breakage is the missing siblings and not
the quarantine directory itself.

`turn-id.mjs` itself is **not** a hook and was left in `hooks/` on purpose: it is the shared
format-and-storage library both turn-id hooks imported. Fed a complete payload it emits 0 bytes
and it has no argv, stdin or stdout contract. Do not point an eval scenario at it.

#!/usr/bin/env node
/**
 * Stop hook — runs every state validator at the end of a turn, so the checks stop being
 * optional. Node ESM, same contract as the sibling Stop hooks: ALWAYS exit 0, decide via
 * stdout JSON, fail open on everything about the hook's own plumbing, fail LOUD on everything
 * about the checks themselves.
 *
 * WHY. On 2026-08-20 two defects (fifteen ledger rows rendering blank; a stale task list) were
 * each detectable by a checker that existed and that nothing ran. The checkers' own authors said
 * so. This hook closes that gap without recreating it for checker #4:
 *
 * ── DISCOVERY, NOT ENUMERATION ───────────────────────────────────────────────────────────────
 * No checker is named in this file. The convention:
 *
 *     an EXECUTABLE regular file (or symlink to one) directly under <orch>/tools/
 *     whose name ends in `-check.sh` is a state checker and WILL be run, no args,
 *     every gated stop. Exit 0 = pass, anything else = the turn is blocked.
 *
 * Both existing checkers (state-vocab-check.sh, requests-schema-check.sh) already match it, and
 * their existing exit contract (0 pass / 1 defect / 2 could-not-run) already fits. A checker in
 * another language ships behind a thin `-check.sh` wrapper, exactly as requests-schema-check.py
 * already does behind requests-schema-check.sh.
 *
 * THE FAILURE MODE OF DISCOVERY is a checker that exists but does not match, missed silently.
 * Two mitigations, both loud:
 *   - NEAR-MISS AUDIT: any tools/ entry whose name contains `-check.` but is not a discovered
 *     checker is a violation and BLOCKS, unless it is a same-stem helper for a discovered
 *     checker (foo-check.py next to foo-check.sh). A non-executable foo-check.sh blocks. An
 *     orphaned foo-check.py blocks. A foo-checker.sh or check-foo.sh is still invisible — that
 *     is the residual hole, and it is named in INSTALL.md rather than papered over.
 *   - ZERO IS FAILURE: discovery finding no checkers blocks. An empty roster reporting success
 *     is the worst available outcome, so it is not a reportable success.
 *
 * ── QUIESCENCE (read-while-write) ────────────────────────────────────────────────────────────
 * Same idea as sync-to-lintel.sh's quiescence gate + publish-exit-codes.sh, reused rather than
 * reinvented: a state file modified within the last STATE_CHECKS_QUIESCE_SECS (default 5) may be
 * mid-write, and a checker reading a torn half-written ledger reports a FALSE failure. So the
 * run DECLINES: no checker runs, the stop is allowed, quietly — the condition clears by itself
 * and the next stop checks. Declining forever is the failure mode on the other side (that is how
 * the publisher escalates too), so an unbroken run of declines longer than
 * STATE_CHECKS_ESCALATE_SECS (default 1800) blocks and says so. The window is 5s, not the
 * publisher's 120s, because this runs at every stop and state files are legitimately written
 * most turns; 120s would starve the checks permanently.
 *
 * ── REPORT OR BLOCK ──────────────────────────────────────────────────────────────────────────
 * A real failure BLOCKS, every stop, until the state is fixed — the savepoint-guard pattern, not
 * publish-stop's announce-once. Chosen because a state-file defect is agent-fixable in-session
 * in seconds (edit the row), unlike a publish failure which needs a human; a warning nobody must
 * act on is exactly how tonight's two defects survived. What changes this: if a defect class
 * emerges that the session cannot fix, that class should move to announce-once. The
 * stop_hook_active loop guard bounds each stop to a single block.
 *
 * ── BUDGET ───────────────────────────────────────────────────────────────────────────────────
 * Measured cost of discovery + both current checkers: see INSTALL.md (tens of ms). Each checker
 * gets STATE_CHECKS_TIMEOUT_MS (default 10000); the whole run gets STATE_CHECKS_BUDGET_MS
 * (default 20000), both far under the registered hook timeout, so the harness never kills this
 * hook mid-flight — it always exits with a decision. A checker that times out, and any checker
 * not started because the budget ran out, is reported as NOT RUN and BLOCKS. Never skipped
 * silently.
 *
 * ── FAILS OPEN ONLY ABOUT ITSELF ─────────────────────────────────────────────────────────────
 * Garbage stdin, missing state dir, gate module unloadable, foreign session: allow. Those are
 * hook-plumbing problems, and a Stop hook that traps every session on this machine because its
 * own import broke is the settings.json catastrophe this lab exists to avoid.
 *
 * Env (all optional): LINTEL_STATE, LINTEL_STATE_CONTRACT, STATE_CHECKS_GATE, STATE_CHECKS_MARK_DIR,
 * STATE_CHECKS_QUIESCE_SECS, STATE_CHECKS_ESCALATE_SECS, STATE_CHECKS_TIMEOUT_MS,
 * STATE_CHECKS_BUDGET_MS.
 *
 * Uninstall: remove this hook's entry from the Stop array in ~/.claude/settings.json (one
 * block), delete the file. It writes only under <mark dir>/state-checks.* — nothing else.
 */
import { readFileSync, readdirSync, statSync, existsSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { join, dirname, basename } from 'node:path';
import { homedir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const allow = () => { process.exit(0); };
const block = (reason) => {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
  process.exit(0);
};

const t0 = Date.now();

let input = '';
try { input = readFileSync(0, 'utf8'); } catch { allow(); }
let payload = {};
try { payload = JSON.parse(input); } catch { allow(); }
if (payload.stop_hook_active === true) allow();

const STATE = process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');
const ORCH  = dirname(STATE);
const TOOLS = join(ORCH, 'tools');
const CONTRACT = process.env.LINTEL_STATE_CONTRACT || join(ORCH, 'contracts', 'request-ledger.md');
const HERE  = dirname(fileURLToPath(import.meta.url));
const MARKS = process.env.STATE_CHECKS_MARK_DIR || join(STATE, '.guard-state');

const QUIESCE_SECS  = Number(process.env.STATE_CHECKS_QUIESCE_SECS  || 5);
const ESCALATE_SECS = Number(process.env.STATE_CHECKS_ESCALATE_SECS || 1800);
const TIMEOUT_MS    = Number(process.env.STATE_CHECKS_TIMEOUT_MS    || 10000);
const BUDGET_MS     = Number(process.env.STATE_CHECKS_BUDGET_MS     || 20000);

// SESSION GATE — the shared module, dynamically imported so this file works from the lab and
// from hooks/ without a copy of the gate logic. Unloadable gate => we cannot know whose session
// this is => do not act (the gate's own fails-closed-for-acting semantics).
let inOrchestratorSession;
try {
  const gatePath = process.env.STATE_CHECKS_GATE || join(HERE, 'session-gate.mjs');
  ({ inOrchestratorSession } = await import(pathToFileURL(gatePath).href));
} catch { allow(); }
if (!inOrchestratorSession(payload, STATE)) allow();
if (!existsSync(STATE)) allow();

const mark = (name, text) => {
  try { mkdirSync(MARKS, { recursive: true }); writeFileSync(join(MARKS, name), text); } catch {}
};
const unmark = (name) => { try { rmSync(join(MARKS, name), { force: true }); } catch {} };

// ── DISCOVERY ─────────────────────────────────────────────────────────────────────────────────
let entries;
try { entries = readdirSync(TOOLS); }
catch (e) {
  block(`STATE CHECKS DID NOT RUN — the tools directory could not be read.\n` +
        `  dir: ${TOOLS}\n  error: ${e.message}\n` +
        `Every state validator lives there; a turn ending without them is how tonight's two ` +
        `defects survived. Fix the directory (or the LINTEL_STATE env) before stopping.`);
}

const roster = [];
const violations = [];
for (const name of entries) {
  const p = join(TOOLS, name);
  let st; try { st = statSync(p); } catch { continue; }           // statSync follows symlinks
  const isCheckerName = /-check\.sh$/.test(name);
  const executable = st.isFile() && (st.mode & 0o111) !== 0;
  if (isCheckerName && executable) { roster.push(p); continue; }
  if (isCheckerName && !executable)
    { violations.push(`${name} — matches the checker convention but is not executable; it will never run`); continue; }
  const m = name.match(/^(.*-check)\.[A-Za-z0-9]+$/);             // near-miss: foo-check.py etc.
  if (m && !entries.includes(`${m[1]}.sh`))
    { violations.push(`${name} — looks like a checker but has no executable ${m[1]}.sh wrapper, so discovery cannot see it`); }
}
roster.sort();

if (violations.length) {
  block(`STATE CHECKER DISCOVERY FOUND FILES IT CANNOT RUN — this is the silent-miss failure ` +
        `mode of a discovery scheme, surfaced loudly on purpose:\n` +
        violations.map(v => `  - ${v}`).join('\n') +
        `\nConvention: an executable *-check.sh directly under ${TOOLS} is run at every stop; ` +
        `helpers in other languages sit behind a same-stem .sh wrapper. ` +
        `Rename, chmod +x, or wrap the files above so they are either checkers or helpers.`);
}
if (roster.length === 0) {
  block(`STATE CHECKER DISCOVERY FOUND NOTHING under ${TOOLS} (convention: executable *-check.sh). ` +
        `An empty roster reporting success would be the worst possible outcome, so it is a failure. ` +
        `At least state-vocab-check.sh and requests-schema-check.sh are expected to exist.`);
}

// ── QUIESCENCE GATE ───────────────────────────────────────────────────────────────────────────
// The read set of every current checker: regular files directly under <state>/ plus the canonical
// request-ledger contract. The charter is identity and policy, not checker input.
const now = Date.now() / 1000;
const inFlight = [];
const quiesceTargets = [];
try {
  for (const n of readdirSync(STATE)) {
    const p = join(STATE, n);
    try { const s = statSync(p); if (s.isFile()) quiesceTargets.push([p, s.mtimeMs / 1000]); } catch {}
  }
} catch {}
try { const s = statSync(CONTRACT); quiesceTargets.push([CONTRACT, s.mtimeMs / 1000]); } catch {}
for (const [p, m] of quiesceTargets)
  if (now - m < QUIESCE_SECS) inFlight.push(`${basename(p)} (modified ${Math.max(0, Math.round(now - m))}s ago)`);

const DECLINE_MARK = 'state-checks.declining-since';
if (inFlight.length) {
  let since = now;
  try { since = Number(readFileSync(join(MARKS, DECLINE_MARK), 'utf8').trim()) || now; }
  catch { mark(DECLINE_MARK, String(now)); }
  if (now - since > ESCALATE_SECS) {
    block(`STATE CHECKS HAVE BEEN DECLINING FOR ${Math.round((now - since) / 60)} MINUTES — every stop since ` +
          `${new Date(since * 1000).toISOString()} found a state file modified within ${QUIESCE_SECS}s, so no ` +
          `checker has run in that whole window. Each individual decline was correct (reading a mid-write file ` +
          `reports false failures), but unbroken declining means something rewrites state continuously. ` +
          `Currently in flight:\n` + inFlight.map(f => `  - ${f}`).join('\n') +
          `\nFind what keeps touching these files, or run the checkers by hand once things are still.`);
  }
  mark('state-checks.status', `declined ${new Date().toISOString()} — not quiescent: ${inFlight.join(', ')}\n`);
  allow();  // quiet, correct, self-clearing — the publisher's decline semantics, reused
}
unmark(DECLINE_MARK);

// ── RUN EVERY DISCOVERED CHECKER ──────────────────────────────────────────────────────────────
const failures = [];
const ran = [];
for (const p of roster) {
  const elapsed = Date.now() - t0;
  if (elapsed > BUDGET_MS) {
    failures.push({ name: basename(p), what: `NOT RUN — the ${BUDGET_MS}ms run budget was exhausted after ${elapsed}ms` });
    continue;
  }
  const s0 = Date.now();
  const r = spawnSync('sh', [p], { timeout: Math.min(TIMEOUT_MS, BUDGET_MS - elapsed), encoding: 'utf8' });
  const ms = Date.now() - s0;
  if (r.error || r.signal) {
    failures.push({ name: basename(p), what: `NOT RUN — ${r.signal ? `killed (${r.signal}) after ${ms}ms, likely the per-checker timeout` : r.error.message}` });
    continue;
  }
  ran.push(`${basename(p)} exit ${r.status} ${ms}ms`);
  if (r.status !== 0) {
    const tail = ((r.stdout || '') + (r.stderr || '')).trim().split('\n').slice(-12).join('\n');
    const meaning = r.status === 1 ? 'the state files are defective'
                  : r.status === 2 ? 'the checker COULD NOT RUN (missing input, unparseable contract, missing dependency)'
                  : `unrecognized exit ${r.status} — treated as failure, never as success`;
    failures.push({ name: basename(p), what: `exit ${r.status} — ${meaning}`, tail, cmd: `sh ${p}` });
  }
}

mark('state-checks.status',
  `${new Date().toISOString()} roster=${roster.length} ran: ${ran.join(' | ') || 'none'} ` +
  `failures=${failures.length} total=${Date.now() - t0}ms\n`);

if (failures.length) {
  block(`STATE CHECKS FAILED — the state files this agent owns do not pass their own validators, ` +
        `and a turn must not end on top of a defect a checker already caught (that is how fifteen ` +
        `blank ledger rows and an hours-stale task list happened on 2026-08-20):\n\n` +
        failures.map(f =>
          `  ${f.name}: ${f.what}` +
          (f.tail ? `\n${f.tail.split('\n').map(l => `      ${l}`).join('\n')}` : '') +
          (f.cmd ? `\n      reproduce: ${f.cmd}` : '')
        ).join('\n\n') +
        `\n\nFix the state (or the checker's inputs) and stop again. A checker reported as NOT RUN ` +
        `is a failure too — never assume it would have passed.`);
}
allow();

#!/usr/bin/env node
/**
 * UserPromptSubmit hook — MINT the turn id and inject it into the model's context.
 *
 * The problem, in Jo's words: they run many parallel threads and lose track of which reply a
 * follow-up refers to. They want to be able to say "responding to turn T-20260819-213045-K7Q2,
 * do these commands" and have the agent know exactly which turn that is.
 *
 * A hook cannot make a model emit text. It can only inject context (this hook) and refuse to let
 * a turn end (turn-id-verify.mjs on Stop). This half is the only place the id can be minted
 * deterministically, because UserPromptSubmit is the one event that fires exactly once per user
 * turn BEFORE the model answers, and its payload carries the prompt_id the Stop event will
 * carry back (measured; see RESULTS.md in this lab).
 *
 * INJECTION FORM — measured, not assumed. Plain text on stdout did NOT reach the model on the
 * first turn of a fresh session in two separate trials (probe-1, probe-3), though it did reach
 * it on a resumed later turn (probe-2b). The JSON hookSpecificOutput.additionalContext form
 * reached the model on both a first turn and a later turn. So this hook uses the JSON form
 * ONLY. A mechanism that silently skips the first turn of every session is worse than useless
 * here — the first turn is exactly where Jo starts a thread they will later refer back to.
 *
 * CONTRACT: always exit 0. Never block, never delay, and never inject an id it has not first
 * persisted — an id the verifier cannot look up would be an instruction with no receipt.
 */
import { readFileSync, appendFileSync, mkdirSync, writeFileSync, existsSync, readdirSync, statSync, unlinkSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { inOrchestratorSession } from './session-gate.mjs';
import { mintTurnId, nextFreeId, readLedger, markerPath, ledgerPath, stateDir,
         referencedIds, lookupIds, transcriptPathFor } from './turn-id.mjs';

const done = () => process.exit(0);

let p = {};
try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { done(); }

const STATE = stateDir();

// SESSION GATE, first, exactly as the other four hooks do it. Ungated, every session on this
// machine would be told to stamp its replies with an id nobody asked for. Fails closed.
if (!inOrchestratorSession(p, STATE)) done();
if (!existsSync(STATE)) done();

const now = new Date();
// Uniqueness is checked against today's ledger, not assumed. Two turns minted inside the same
// second in the same session would otherwise be able to collide on the 2-char prompt hash.
const id = nextFreeId(mintTurnId(p.session_id, p.prompt_id, now), readLedger(now, STATE));

// Persist BEFORE injecting. The verifier looks up by this exact marker; if the write fails there
// is no id to enforce, and the correct outcome is a turn with no id rather than a turn the
// verifier will block over an id it cannot find.
let persisted = false;
try {
  const marker = markerPath(p, STATE);
  mkdirSync(dirname(marker), { recursive: true });
  writeFileSync(marker, JSON.stringify({
    id,
    minted_at: now.toISOString(),
    session_id: p.session_id ?? null,
    prompt_id: p.prompt_id ?? null,
    status: 'open',
  }));
  persisted = true;
} catch { /* fall through: no marker, no enforcement */ }

if (!persisted) done();

// Human-readable ledger, one file per day. This is what answers "what was turn
// T-20260819-213045-K7Q2?" hours or weeks later, including after the session has ended:
// the marker files are transient, this is not.
try {
  const lp = ledgerPath(now, STATE);
  mkdirSync(dirname(lp), { recursive: true });
  // `prompt` is the field this harness actually sends (measured, 2.1.236); the others are
  // fallbacks so a schema change degrades to a blank excerpt instead of losing the row.
  const text = p.prompt ?? p.user_input ?? p.user_prompt ?? p.message ?? '';
  appendFileSync(lp, JSON.stringify({
    id,
    ts: now.toISOString(),
    session_id: p.session_id ?? null,
    prompt_id: p.prompt_id ?? null,
    cwd: p.cwd ?? null,
    prompt_excerpt: String(text).replace(/\s+/g, ' ').slice(0, 240),
  }) + '\n');
} catch { /* the ledger is a convenience; never let it cost the turn */ }

// Prune markers older than three days. They are per-turn files in a long-lived state dir, so
// without this the directory grows without bound.
try {
  const dir = join(STATE, '.turn-state');
  const cutoff = Date.now() - 3 * 24 * 60 * 60 * 1000;
  for (const f of readdirSync(dir)) {
    try { if (statSync(join(dir, f)).mtimeMs < cutoff) unlinkSync(join(dir, f)); } catch { /* skip */ }
  }
} catch { /* pruning is best effort */ }

// If Jo's message quotes an EARLIER turn id, resolve it here rather than telling the model to go
// and look. An instruction to read a file is a step that can be skipped; a resolved row in the
// context cannot be. This is the half that makes "responding to turn T-… , do these commands"
// work at all.
let referenced = '';
try {
  const quoted = referencedIds(p.prompt).filter((q) => q !== id);
  if (quoted.length) {
    const rows = lookupIds(quoted, STATE);
    referenced = '\n\nREFERENCED TURNS — Jo\'s message quotes ' +
      (quoted.length === 1 ? 'an earlier turn id' : 'earlier turn ids') + ':\n' +
      quoted.map((q) => {
        const r = rows[q];
        if (!r) return `  ${q}: NOT FOUND in ${join(STATE, 'turn-ids')}. Say so rather than guessing which turn was meant.`;
        const tp = transcriptPathFor(r);
        return `  ${q}: ${r.ts} in ${r.cwd}\n` +
               `    what Jo asked then: ${r.prompt_excerpt}\n` +
               (tp ? `    full exchange: ${tp}\n` : '');
      }).join('\n');
  }
} catch { /* a failed lookup must never cost the turn */ }

process.stdout.write(JSON.stringify({
  hookSpecificOutput: {
    hookEventName: 'UserPromptSubmit',
    additionalContext:
      `TURN ID: ${id}\n` +
      `This is the identifier for the turn you are answering right now. End your reply with this ` +
      `exact string on its own final line, written as "— ${id}". Nothing else about your reply ` +
      `changes.\n` +
      `Why: Jo runs many threads in parallel and refers back to a specific reply by this id — ` +
      `"responding to turn ${id}, do these commands". A reply without it cannot be referred to, ` +
      `so a Stop hook will reject the turn and ask you to answer again.\n` +
      // The <date> in a turn-ids filename is the LOCAL date, and so is the date embedded in a
      // turn id, but each row's `ts` is UTC — so a file named for a day does NOT hold that day's
      // UTC rows. Measured 2026-09-08 by Tinker: 2026-08-19.jsonl holds 27 rows and NOT ONE is
      // dated 08-19. The filename is a sound key for finding an ID and an unsound bucket for
      // asking what happened on a day. This instruction used to name `<date>.jsonl`, which was
      // right only if the reader derived the date from the quoted id's own prefix. It now says
      // scan and match on the id, which is what turn-id.mjs already does beside it.
      `If Jo's message names a DIFFERENT turn id, that is a reference to an earlier reply: scan ` +
      `the files in ${join(STATE, 'turn-ids')}/ and match the id against each row's "id" field ` +
      `to find which prompt it was, then answer in that context. Do NOT guess a filename from ` +
      `when you think the turn happened: the files are named by LOCAL date while each row's ` +
      `timestamp is UTC, so a day's file does not hold that day's UTC rows. Still end this reply ` +
      `with ${id}.` + referenced,
  },
}));
done();

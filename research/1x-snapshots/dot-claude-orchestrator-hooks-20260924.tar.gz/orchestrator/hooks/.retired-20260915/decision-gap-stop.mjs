#!/usr/bin/env node
/**
 * decision-gap-stop.mjs — notice when Lintel put a QUESTION to Jo and no decision row was opened.
 *
 * ── WHAT IT DOES NOT DO, AND THIS IS A DESIGN DECISION RATHER THAN A LIMITATION ──────────
 * IT DOES NOT OPEN THE ROW. The brief asked for that and it cannot be done honestly. A decision
 * row needs the options and either a recommendation or an explicit none; the writer REFUSES a row
 * without them, and that refusal is load-bearing — it is what stops "nobody had a view" and "the
 * author forgot" looking identical on Jo's screen. Extracting options and a recommendation out of
 * the message prose would be exactly the instrument that failed five times on this machine on
 * 2026-08-24. So this hook records the GAP and a human-or-Lintel opens the row properly.
 *
 * ── WHAT MAKES IT DIFFERENT FROM THOSE FIVE ──────────────────────────────────────────────
 * It keys off the literal label `**QUESTION**`, which the author DELIBERATELY EMITS under this
 * fleet's output contract. That is a declared signal, not one recovered from prose. It never asks
 * what the message MEANS. If a future edit starts parsing meaning out of the text, the failed
 * thing has been rebuilt and the edit should be reverted.
 *
 * ── THE STOP-CHAIN CONTRACT, COPIED FROM THE SIBLING HOOKS IN THIS DIRECTORY ─────────────
 * ALWAYS exit 0. This hook NEVER blocks: it writes no `decision` field and no `continue:false`,
 * ever, so it cannot change a turn's outcome and cannot interfere with the sibling Stop hooks that
 * are load-bearing (the save-point guard and the state checkers among them). It does no network,
 * spawns no subprocess, awaits nothing, and its whole file access is one small read and two small
 * appends. Everything is wrapped so that any failure of its own plumbing exits 0 silently.
 *
 * ── IT SPEAKS ON A REAL GAP, AND ONLY THERE (added 2026-08-25) ───────────────────────────
 * It used to write the gap row and say nothing, so the one moment the record could still be
 * repaired cheaply — the turn the question was asked — passed in silence. It now emits TWO LINES
 * on stdout as Stop `additionalContext`, the same non-blocking channel the sibling dispatch check
 * uses: one naming the finding, one naming what is owed. That is the whole budget. NO rationale
 * paragraphs, NO caveats — this file's neighbour is under review for exactly that, and a reminder
 * people scroll past is worse than one that was never printed. Every pre-existing silent-exit path
 * stays silent: no message, no `**QUESTION**` label, a row already written inside the window, a
 * malformed payload, or any internal failure.
 *
 * ── THE SECOND LINE STATES WHAT IS OWED; IT DOES NOT ISSUE A COMMAND (fixed 2026-08-25) ──
 * It used to read `Open it now: <tool> open …`. Two persistent seats were told exactly that and
 * both correctly refused, because their own boundaries make them non-writers of the decision
 * ledger. An instruction most of its readers are forbidden to obey trains every reader to skip the
 * line, which is the precise failure the two-line budget exists to prevent. So the second line now
 * states the debt and names the tool as the MEANS for whoever may use it, and tells everyone else
 * that surfacing the gap is the correct action. It has to be true read by a writer and by a
 * non-writer alike; that is the test any future rewording must pass.
 *
 * ── THE ROW CARRIES A LOCATOR, NOT THE QUESTION TEXT (fixed 2026-08-25) ──────────────────
 * Every row's `note` is a constant, so a log of thirteen rows said thirteen things had been missed
 * could not say WHICH — a counter, not a record. The fix is NOT to copy the question prose in;
 * that is still refused, for the reason stated below where the row is written. The row instead
 * carries the payload's own turn locator: `transcript_path` and `prompt_id`, both measured present
 * on a real Stop event (a captured payload lives at state/hook-lab/stop-enforcement/out/events.jsonl,
 * 2026-08-21T03:03:22Z). Together with `session_id` they name the exact turn, so an authorised
 * reader can open the transcript and read the question whole, in context, unedited.
 *
 * The turn-id ledger under state/turn-ids/ was checked as an alternative that would need no new
 * field, and it does NOT work: it is written by a session-GATED UserPromptSubmit hook, so it has no
 * row for a session outside the orchestrator gate. Correlating the thirteen live gap rows against
 * it by session_id and nearest-earlier ts resolved ONE. Do not remove these fields in favour of it.
 *
 * ── FAIL-OPEN, BUT NOT SILENTLY ──────────────────────────────────────────────────────────
 * A hook with a broken command on this machine fails open AND silently. A recorder that quietly
 * stops is indistinguishable from "Jo has no pending decisions" — the exact confusion the widget's
 * four lane states exist to prevent. So EVERY run touches a heartbeat file, whether or not it
 * finds anything. A reader can then tell "no gaps" from "the recorder has not run since Tuesday"
 * by the heartbeat's age. The heartbeat is written first WITHIN THE SESSION GATE, before any
 * other work, so it is stamped even on a gated run that later bails. See the gate section below
 * for why it is no longer stamped on every session on the machine.
 *
 * ── SESSION GATE + LOOP GUARD (added 2026-08-25, run stop-hooks-session-gate-20260825) ──
 * This hook is registered with a universal matcher in ~/.claude/settings.json, so until now it
 * fired in EVERY Claude Code session on this machine: it stamped the orchestrator's heartbeat,
 * appended foreign sessions' gaps to the orchestrator's DECISION-GAPS.jsonl, and told unrelated
 * sessions in unrelated repos that they owed a row in a ledger they do not write. Six of the
 * eight registered Stop hooks already carry the two protections that close this; this one did
 * not. It now uses inOrchestratorSession() from ./session-gate.mjs UNCHANGED — the same import
 * savepoint-guard.mjs, savepoint-fit-stop.mjs and publish-stop.mjs use, not a re-implementation,
 * so the gate cannot drift between them. It fails CLOSED: no marker, unreadable marker, empty
 * marker, or a payload with no session_id all mean "no permission to act".
 *
 * ⛔ THE PAYLOAD PARSE MOVED ABOVE THE HEARTBEAT, AND THAT IS THE POINT, NOT A SIDE EFFECT.
 * The heartbeat used to be written first, unconditionally, before the payload was even parsed —
 * which meant every stop of every session on this machine refreshed it. Its ONE job is to let a
 * reader tell "no gaps" from "the recorder has not run since Tuesday", and a foreign session
 * refreshing it makes it read fresh while the orchestrator has not run for days. That is not a
 * heartbeat, it is a liveness signal for the wrong process. So the gate sits ABOVE the write.
 *
 * WHAT THAT COSTS, STATED RATHER THAN HIDDEN: a run whose stdin is unparseable now leaves no
 * heartbeat, where before it left one. That is the correct direction. Unparseable stdin means
 * the session is unknown, and stamping the orchestrator's heartbeat on an unknown session is the
 * exact false-freshness this change exists to end. A continuation stop (stop_hook_active) also
 * no longer re-stamps; the stop that opened the chain already did.
 *
 * Env (all optional, for testing): DGS_STATE (state dir), DGS_LOG, DGS_HEARTBEAT, DGS_TOOL
 * (the decision-write.sh path named in the emitted line; defaults to its real absolute path),
 * LINTEL_STATE (where the gate looks for .session-id; falls back to DGS_STATE)
 *
 * Exit: always 0. Output: empty on every path except a confirmed gap, where it is two lines.
 */

import { readFileSync, existsSync, appendFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { repairContext } from './repair-context.mjs';
import { inOrchestratorSession } from './session-gate.mjs';

const done = () => process.exit(0);

try {
  const STATE = process.env.DGS_STATE || '/Users/jowolff/.claude/orchestrator/state';
  // Heartbeat lives OUTSIDE the checked state directory on purpose. Written inside it, the
  // state-checks stop hook declined on every stop -- its freshness test saw a state file touched
  // within 5s, every time -- so no checker ran for 34 minutes on 2026-08-24, each decline being
  // correct. Do not move it back, and do not fix that by exempting dotfiles from the check.
  const HEARTBEAT = process.env.DGS_HEARTBEAT || join(STATE, '.guard-state', '.decision-gap-heartbeat');
  const LOG = process.env.DGS_LOG || join(STATE, 'DECISION-GAPS.jsonl');
  const DECISIONS = join(STATE, 'DECISIONS.jsonl');
  // NOT derived from STATE. A test points STATE at a fixture; the line Jo reads has to name the
  // command that works on this machine, so the default is the real absolute path and the override
  // exists only so a test can assert something deterministic.
  const TOOL = process.env.DGS_TOOL || '/Users/jowolff/.claude/orchestrator/tools/decision-write.sh';
  // Where the gate looks for the .session-id marker. LINTEL_STATE is the variable every sibling
  // hook and the tier-1 eval helpers already use for this; DGS_STATE is the fallback so a test
  // that repoints only DGS_STATE still gets a coherent fixture.
  const GATE_STATE = process.env.LINTEL_STATE || STATE;
  // POINTER-BACK STORE. A leg whose emission is suppressed leaves two breadcrumbs, because a
  // reader may arrive holding either of two things and only one of them. A fan-out that captured
  // the leg's session id looks up the sidecar directly; a reader holding only a time window scans
  // the append-only log. Without both, a suppressed leg reads exactly like a leg that had nothing
  // to say — which is the failure this whole change exists to end.
  const SUPPRESSED_DIR = process.env.DGS_SUPPRESSED_DIR || join(STATE, 'suppressed-emissions');
  const SUPPRESSED_LOG = process.env.DGS_SUPPRESSED_LOG || join(STATE, 'SUPPRESSED-EMISSIONS.jsonl');
  const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');

  let p = {};
  try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { done(); }
  if (!p || typeof p !== 'object') done();

  // LOOP GUARD. Parsed, not substring-matched — a raw substring test slips on key order or
  // spacing. Same form and same position as savepoint-fit-stop.mjs and publish-stop.mjs.
  if (p.stop_hook_active === true) done();

  // SESSION GATE. Before the heartbeat, before the log read, before anything that writes or
  // speaks. See the header for why the heartbeat is below this line and not above it.
  if (!inOrchestratorSession(p, GATE_STATE)) done();

  // Heartbeat first WITHIN THE GATE, unconditionally. A gated run that bails after this still
  // proves the hook fired in the orchestrator's own session, which is the only session whose
  // liveness this file is a record of.
  try {
    mkdirSync(dirname(HEARTBEAT), { recursive: true });
    writeFileSync(HEARTBEAT, now + '\n');
  } catch { /* a heartbeat we cannot write is not a reason to disturb the turn */ }

  const message = typeof p.last_assistant_message === 'string' ? p.last_assistant_message : '';
  if (!message) done();

  // THE ONLY THING THIS HOOK UNDERSTANDS ABOUT THE MESSAGE. A block-leading label, per the output
  // contract: `**QUESTION**` alone on its line. Not "question", not a question mark, not a phrase
  // that sounds like one. Literal, anchored, and deliberately unable to generalise.
  const asked = /^\s*\*\*QUESTION\*\*\s*$/m.test(message);
  if (!asked) done();

  // Computed HERE, before the row is written, so the row can carry it — and used ONLY to decide
  // whether to speak. Nothing below this line is allowed to skip a write because of it.
  let ctx;
  try { ctx = repairContext(p); }
  catch { ctx = { repairable: false, entrypoint: null, reason: 'repair-context-threw' }; }

  // Was a row opened during this turn? "This turn" is bounded by the transcript's own timestamps
  // rather than guessed: any row whose ts is within the lookback window counts. The window is
  // generous on purpose — a false "row exists" costs a missed reminder, a false "no row" costs a
  // noisy one, and the noisy direction is the one that trains people to ignore the thing.
  const WINDOW_MS = 30 * 60 * 1000;
  let recentRow = false;
  try {
    if (existsSync(DECISIONS)) {
      const cutoff = Date.now() - WINDOW_MS;
      for (const line of readFileSync(DECISIONS, 'utf8').split('\n')) {
        if (!line.trim()) continue;
        let r; try { r = JSON.parse(line); } catch { continue; }
        const t = Date.parse(r && r.ts);
        if (!Number.isNaN(t) && t >= cutoff) { recentRow = true; break; }
      }
    }
  } catch { /* unreadable decisions file: fall through and record the gap, which is the safe way */ }

  if (recentRow) done();

  try {
    appendFileSync(LOG, JSON.stringify({
      ts: now,
      session_id: typeof p.session_id === 'string' ? p.session_id : null,
      // The label was found; the question text is NOT copied here. Copying it would put an
      // unreviewed fragment of a message into a state file, and the message is already in the
      // transcript where a reader can see it whole and in context.
      note: 'a **QUESTION** label was emitted and no decision row was opened within the window',
      // THE LOCATOR. Not the question text — see above. These name the turn so the question can be
      // read at its source. Recorded as null when the payload omits one, never as a fabricated
      // value: a locator that is confidently wrong is worse than one that is honestly absent.
      transcript_path: typeof p.transcript_path === 'string' && p.transcript_path ? p.transcript_path : null,
      prompt_id: typeof p.prompt_id === 'string' && p.prompt_id ? p.prompt_id : null,
      // WHETHER THIS TURN WAS SPOKEN TO, AND WHY NOT. A row that does not say this is unreadable
      // after the fact: silence from the hook and suppression by the hook look the same.
      emission_suppressed: !ctx.repairable,
      emission_reason: ctx.reason,
      // Recorded verbatim, including an unfamiliar value. The allowlist in repair-context.mjs can
      // go stale silently on a rename; a reader seeing an unknown entrypoint in every row is the
      // only warning that will ever arrive.
      entrypoint: ctx.entrypoint,
      // LENGTH, NOT TEXT. The hook deliberately never copies message content into a state file.
      // But length alone settles the question a reader actually has: a leg that finished a long
      // report and lost it must not read identically to a leg that had nothing to say.
      message_chars: message.length,
      cwd: typeof p.cwd === 'string' && p.cwd ? p.cwd : null,
    }) + '\n');
  } catch { /* nothing here is worth disturbing the turn for */ }

  // ── THE GATE ───────────────────────────────────────────────────────────────────────────────
  // Everything above has already run. The row is on disk. This decides only whether to SPEAK.
  //
  // Writing to stdout here does not print — it induces a second assistant turn, and a headless
  // run returns only its last message. On 2026-08-25 that replaced a finished 20,543-character
  // review with a 33-second reply. The hook's writes had all succeeded; the emission alone was
  // destructive. So the gate sits between the write and the write-to-stdout, and nowhere else.
  if (!ctx.repairable) {
    // THE POINTER BACK. Suppression without a breadcrumb reproduces the original defect in a
    // quieter form: the run manifest said `no-report`, the leg's log was zero bytes, and nothing
    // on disk connected that row to the finished report sitting in the transcript.
    const crumb = {
      ts: now,
      session_id: typeof p.session_id === 'string' ? p.session_id : null,
      transcript_path: typeof p.transcript_path === 'string' && p.transcript_path ? p.transcript_path : null,
      prompt_id: typeof p.prompt_id === 'string' && p.prompt_id ? p.prompt_id : null,
      cwd: typeof p.cwd === 'string' && p.cwd ? p.cwd : null,
      entrypoint: ctx.entrypoint,
      reason: ctx.reason,
      message_chars: message.length,
      suppressed: 'decision-gap-stop additionalContext',
      // Written for a human who found this row and has to get from here to the work. Not a
      // summary of the work — a route to it.
      note: 'This turn produced a finished assistant message and a **QUESTION** was put to Jo. '
        + 'The Stop hook recorded the gap and did NOT emit, because emitting would have induced a '
        + 'second turn and this runner returns only its last message. The finished message is in '
        + 'the transcript named above; the decision gap is in DECISION-GAPS.jsonl at the same ts.',
    };
    // Sidecar, addressable by session id, for a reader that captured one.
    try {
      mkdirSync(SUPPRESSED_DIR, { recursive: true });
      if (crumb.session_id) {
        writeFileSync(join(SUPPRESSED_DIR, crumb.session_id + '.json'), JSON.stringify(crumb, null, 2) + '\n');
      }
    } catch { /* a breadcrumb we cannot write is not a reason to disturb the turn */ }
    // Append-only log, scannable by time, for a reader that captured nothing.
    try { appendFileSync(SUPPRESSED_LOG, JSON.stringify(crumb) + '\n'); } catch { /* same */ }
    done();
  }

  // TWO LINES. This is the only place this hook has ever spoken, and it is reached only after
  // every silent-exit path above has been passed, the gate included. `additionalContext` carries
  // no `decision`, so the turn's outcome is untouched — the emission cannot block a stop.
  try {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'Stop',
        additionalContext:
          '⛔ A **QUESTION** was put to Jo and no decision row was opened. Unrecorded, it is '
          + 'invisible to the ledger and to everyone reading it.\n'
          + `Owed: one decision row, this turn. Writers of the ledger open it with ${TOOL}; `
          + 'everyone else surfaces the gap to Jo in this reply rather than running anything.',
      },
    }));
  } catch { /* an unwritable stdout is not a reason to disturb the turn */ }
} catch {
  /* Any failure at all: exit 0, say nothing. A guard that traps a session because its own parse
     broke is worse than every gap it would have caught. */
}

done();

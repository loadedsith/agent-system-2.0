#!/usr/bin/env node
/**
 * Stop hook — refuses to let a session end while STANDUP.md is over the injection budget, and
 * tells the reader WHERE it is over rather than only THAT it is.
 *
 * WHY THIS EXISTS SEPARATELY FROM savepoint-guard.mjs. That hook already blocks on the overage
 * and already names the exact byte count. It was in place, and the repair still took many
 * edit-then-measure rounds, because "you are 114 bytes over" does not say which section falls off
 * the cliff or how much of the weight is non-ASCII punctuation. This hook shells out to
 * tools/savepoint-fit.sh and pastes its per-section table into the block reason, so the next edit
 * is aimed rather than guessed.
 *
 * OVERLAP, STATED PLAINLY: savepoint-guard.mjs contains its own injection-budget block. If BOTH
 * are installed, an oversize standup produces two block reasons saying the same thing at
 * different resolutions. Deciding whether to keep both, or to delete the budget stanza from
 * savepoint-guard.mjs, is Jo's call and is not made here.
 *
 * SINGLE SOURCE OF TRUTH: this file does not know the budget. It never parses a number and never
 * hardcodes one. savepoint-fit.sh resolves the limit out of savepoint-restore.sh, and this hook
 * only reads that tool's EXIT CODE (0 fits, 1 over, anything else = a tool problem).
 *
 * READ-ONLY with respect to the save point. Neither this hook nor the tool it calls writes,
 * trims or moves STANDUP.md.
 *
 * FAILS SAFE, IN THE DIRECTION OF LETTING THE SESSION END. Missing tool, unreadable tool,
 * non-zero-in-an-unexpected-way tool, spawn failure, timeout, garbage stdin, missing standup:
 * every one of those allows the stop. A Stop hook that traps a session because its own helper
 * broke is worse than no hook, because the session needed to repair it is the one being trapped.
 *
 * SESSION GATE: uses inOrchestratorSession() from ./session-gate.mjs unchanged, and calls it
 * BEFORE doing anything else that could produce output. Not a re-implementation, not a variant —
 * the same import savepoint-guard.mjs uses, so the gate cannot drift between the two hooks.
 *
 * CONTRACT: always exit 0. Decide via stdout JSON. This is what the tier-1 eval helper
 * _check_exit0 asserts, and a non-zero exit is unassertable there.
 */
import { readFileSync, existsSync, statSync, mkdirSync, writeFileSync, accessSync, constants } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';
import { inOrchestratorSession } from './session-gate.mjs';

const allow = () => process.exit(0);                            // silence == allow
const block = (reason) => {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
  process.exit(0);                                              // exit 0 ALWAYS; the JSON decides
};

let payload = {};
try { payload = JSON.parse(readFileSync(0, 'utf8')); } catch { allow(); }

// Loop guard. Parsed, not substring-matched — a raw substring test slips on key order or spacing,
// and a loop guard that silently fails to fire is a hook that blocks until the block cap rescues it.
if (payload.stop_hook_active === true) allow();

const STATE = process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');
if (!inOrchestratorSession(payload, STATE)) allow();
if (!existsSync(STATE)) allow();

const standup = join(STATE, 'STANDUP.md');
if (!existsSync(standup)) allow();                              // nothing to measure

let standupMtime;
try { standupMtime = statSync(standup).mtimeMs; } catch { allow(); }

// THE CHECKER. Resolved relative to this file, not to STATE, so an isolated eval or lab run with
// LINTEL_STATE repointed still exercises the real tool. LINTEL_FIT_TOOL overrides it, which is
// how the missing-tool fail-safe path is tested without deleting anything real.
const TOOL = process.env.LINTEL_FIT_TOOL
  || fileURLToPath(new URL('../tools/savepoint-fit.sh', import.meta.url));

try { accessSync(TOOL, constants.R_OK | constants.X_OK); } catch { allow(); }   // fail safe

let run;
try {
  run = spawnSync('/bin/zsh', [TOOL, standup], {
    encoding: 'utf8',
    timeout: 10_000,
    env: { ...process.env, LINTEL_STATE: STATE },
  });
} catch { allow(); }                                            // fail safe

if (!run || run.error || run.signal) allow();                   // spawn failure / timeout kill
if (run.status === 0) allow();                                  // FITS
if (run.status !== 1) allow();                                  // 2 = tool usage/IO error, or anything unexpected

const report = String(run.stdout || '').trim();
if (!report) allow();                                           // over budget but nothing to say: not useful, so do not trap

// Fire once per WRITE, not once per session: rewriting the standup and leaving it oversize gets
// told again. The per-stop bound is the stop_hook_active guard above; the per-session escape is
// printed in the message.
const sid = String(payload.session_id || 'unknown').replace(/[^A-Za-z0-9_-]/g, '');
const guardDir = join(STATE, '.guard-state');
const fired = join(guardDir, `fit-${sid}`);
if (existsSync(fired)) {
  try { if (statSync(fired).mtimeMs > standupMtime) allow(); } catch { allow(); }
}
try { mkdirSync(guardDir, { recursive: true }); writeFileSync(fired, String(Date.now())); }
catch { /* non-fatal: never let bookkeeping trap a session */ }

block(
  `SAVE POINT WILL BE TRUNCATED — it does not fit the injection budget.\n\n` +
  `${report}\n\n` +
  `WHAT TO DO. Cut from the sections named above, largest first, then re-check the DRAFT before\n` +
  `installing it over the save point:\n\n` +
  `    zsh ${TOOL} /path/to/draft.md\n\n` +
  `It exits 0 when the draft fits and 1 when it does not, so it can gate the move. It never edits\n` +
  `anything. Trim the content — do not append a note saying the file is long. The tail is what\n` +
  `disappears, and the table above names which section goes first.\n\n` +
  `To re-run the same report against the live save point at any time:\n\n` +
  `    zsh ${TOOL}\n\n` +
  `To silence this specific check for this session: touch ${fired}`
);

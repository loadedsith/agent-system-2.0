#!/usr/bin/env node
/**
 * Stop hook — VERIFY the turn id actually appeared in the reply, and block once if it did not.
 *
 * Pairs with turn-id-mint.mjs. A hook cannot make a model emit text; it can only inject the
 * instruction (mint) and refuse the stop (this). Without this half the id is a suggestion, and a
 * suggestion is exactly what Jo asked to have enforced.
 *
 * WHAT IT READS: payload.last_assistant_message. The Stop payload carries it directly — measured
 * on this machine (see probe-1.jsonl in this lab: the Stop record's last_assistant_message held
 * the reply text verbatim). The transcript file does NOT have to be parsed.
 *
 * THE FAILURE MODE DESIGNED AGAINST FIRST: a verifier that fires on a turn which never had an id
 * would block the session forever. Four independent brakes, in order:
 *   1. stop_hook_active === true  -> allow. Never block a continuation of our own block.
 *   2. session gate closed        -> allow. Other sessions are not stamped and must not be held.
 *   3. no marker for this turn    -> allow. THE important one: the marker is keyed by
 *      session_id + prompt_id, both of which the Stop payload carries and which are identical to
 *      the ones UserPromptSubmit carried (measured). A stop with no matching marker is a stop for
 *      a turn that was never minted — a continuation, a resumed session whose state was cleared,
 *      a turn from before this hook existed. Nothing to enforce, so nothing is enforced.
 *      ⛔ THAT KEY IS NOT UNIQUE PER TURN, measured 2026-09-08: 30 observed cases where one
 *      session_id + prompt_id spans MORE THAN ONE TURN, always a contiguous run within one
 *      session, never interleaved. The marker is LAST-WRITER-WINS, so on the second turn of such
 *      a run the marker on disk holds the LATER turn's id. In sequence that is harmless, which is
 *      why nothing has broken. **The description above establishes the key's PROVENANCE, not its
 *      UNIQUENESS** - do not read it as a per-turn identity guarantee. Found by Tinker 2026-09-08.
 *   4. marker already blocked once -> allow. At most one block per minted turn, ever.
 * Plus: an empty or absent last_assistant_message allows, because there is nothing to check.
 *
 * CONTRACT: always exit 0, decide via stdout JSON, fail open on everything.
 *
 * ─────────────────────────────────────────────────────────────────────────────────────────────
 * ⛔ THIS FILE IS INSTALLED AND LIVE. It is registered on Stop in
 * /Users/jowolff/.claude/settings.json, running as
 * `node '/Users/jowolff/.claude/orchestrator/hooks/turn-id-verify.mjs'`, timeout 15. Verified
 * 2026-09-08. Editing it in place changes every session's Stop behaviour immediately.
 *
 * ⛔ THIS HEADER SAID THE OPPOSITE UNTIL 2026-09-08 — "CANDIDATE — NOT INSTALLED. Lives in the
 * hook lab, not in orchestrator/hooks/." It was written while this was a candidate, the candidate
 * was promoted into orchestrator/hooks/ and registered, and the header was never updated. The
 * false text is quoted here rather than deleted, because the failure is worth more than the
 * tidiness: **a reader checking whether a hook is live got a confident wrong answer from the most
 * authoritative-looking place available**, on the hook with the largest blast radius on this
 * machine. routing-counter.mjs memorialises the same failure class in its own header after it
 * happened there. Found by Tinker while mapping the turn-key readers; corrected by Lintel, which
 * did not find it. **THE STATUS LINE OF A HOOK IS A CLAIM ABOUT settings.json AND MUST BE
 * RE-DERIVED FROM settings.json, NEVER CARRIED FORWARD FROM THE COPY IT WAS FORKED FROM.**
 *
 * WHAT CHANGED when it was promoted, versus the copy it replaced — one thing, the acceptance test.
 *
 * turn-id-mint.mjs instructs the model to end its reply with the id "on its own final line,
 * written as '— <id>'". The installed verifier accepts on `reply.includes(id)`, which passes a
 * reply that buries the id mid-sentence and never puts it on a line of its own. The instruction
 * and the enforcement disagreed, so the mechanism proved less than it advertised: Jo could not
 * rely on the last line of a reply carrying the id, which is the property the id is FOR.
 *
 * This candidate requires the id to be the LAST NON-EMPTY LINE, alone on that line, with an
 * optional dash marker in front of it.
 *
 * ONE DELIBERATE TOLERANCE, and the reason for it. The dash GLYPH is not checked exactly: em
 * dash, en dash, hyphen and double hyphen are all accepted, as is a bare id with no dash at all.
 * The minter's demanded form is a strict subset of what is accepted here, so a reply that obeys
 * the minter literally always passes — enforcement is never narrower than the instruction. What
 * is enforced is the substantive half of the contract (own final line, nothing else on it),
 * because that is what makes the id findable by eye or by `tail -1`. Which of three
 * indistinguishable horizontal strokes was typed does not affect that, and blocking a turn over
 * it would burn a retry to fix a character Jo cannot see the difference in.
 *
 * The block reason now distinguishes the two failures. A reply carrying the id somewhere in the
 * middle told "TURN ID MISSING" is being told something false, and a model that can see the id
 * in its own text is liable to re-send the same reply. Absent id and misplaced id get different
 * messages, each naming the exact line to end with.
 * ─────────────────────────────────────────────────────────────────────────────────────────────
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { inOrchestratorSession } from './session-gate.mjs';
import { markerPath, stateDir } from './turn-id.mjs';

const allow = () => process.exit(0);                            // silence == allow
const block = (reason) => {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
  process.exit(0);                                              // exit 0 ALWAYS; the JSON decides
};

let payload = {};
try { payload = JSON.parse(readFileSync(0, 'utf8')); } catch { allow(); }

// Brake 1 — loop guard. Parsed, never substring-matched: the shell version of the save-point
// guard matched this key as a raw substring and one space slipped past it.
if (payload.stop_hook_active === true) allow();

const STATE = stateDir();

// Brake 2 — session gate.
if (!inOrchestratorSession(payload, STATE)) allow();

// Brake 3 — was an id minted for THIS turn?
const marker = markerPath(payload, STATE);
if (!existsSync(marker)) allow();

let rec = {};
try { rec = JSON.parse(readFileSync(marker, 'utf8')); } catch { allow(); }
const id = typeof rec.id === 'string' ? rec.id : '';
if (!id) allow();

// Brake 4 — one block per minted turn.
if (rec.status === 'blocked') allow();

const reply = payload.last_assistant_message;
if (typeof reply !== 'string' || reply.trim() === '') allow();   // nothing to check

const save = (status) => {
  try { writeFileSync(marker, JSON.stringify({ ...rec, status, checked_at: new Date().toISOString() })); }
  catch { /* non-fatal */ }
};

// THE ACCEPTANCE TEST. Trailing blank lines are stripped first, so a reply that ends with the
// id followed by newlines still passes — trailing whitespace is invisible and blocking over it
// would be enforcing something nobody can see.
const lastLine = reply.trimEnd().split(/\r?\n/).pop().trim();

// Escaped because the id is interpolated into a regex. Turn ids are [T-0-9A-Z] today
// (turn-id.mjs TURN_ID_RE), so nothing here needs escaping in practice — the escape is there so
// that stays true if the id alphabet ever widens.
const escaped = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
// Optional dash marker: em dash, en dash, hyphen, or a double hyphen. Then the id. Then nothing.
const ON_FINAL_LINE = new RegExp(`^(?:(?:[—–]|-{1,2})[ \t]*)?${escaped}$`);

if (ON_FINAL_LINE.test(lastLine)) { save('verified'); allow(); }

save('blocked');

const present = reply.includes(id);
block(
  present
    ? `TURN ID NOT ON THE FINAL LINE of your reply.\n\n` +
      `This turn's id is ${id}. Your reply does contain it, but not where it has to be. It has ` +
      `to be the last non-empty line of the reply, alone on that line, so Jo can find it by ` +
      `looking at the end of the message instead of reading for it.\n\n` +
      `Your reply's last non-empty line was:\n\n` +
      `  ${lastLine.slice(0, 200)}\n\n` +
      `Answer again. Keep the substance of what you just said, and end it with this exact line:\n\n` +
      `  — ${id}\n\n` +
      `This guard blocks at most once per turn: say it again with the id on its own final line ` +
      `and the turn ends normally.`
    : `TURN ID MISSING from your reply.\n\n` +
      `This turn's id is ${id}. Your reply did not contain it, so Jo cannot refer back to this ` +
      `reply later — which is the entire point of the id.\n\n` +
      `Answer again. Keep the substance of what you just said, and end it with this exact line:\n\n` +
      `  — ${id}\n\n` +
      `This guard blocks at most once per turn: say it again with the id and the turn ends normally.`
);

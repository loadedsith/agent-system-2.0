#!/usr/bin/env node
/**
 * dispatch-check-stop.mjs — at end of turn, ask whether the run ids this turn named were ever
 * actually dispatched, and say so when they were not.
 *
 * ── WHY IT EXISTS ────────────────────────────────────────────────────────────────────────
 * 2026-08-24: a build was reported to Jo as having its remaining decision be "activation" when the
 * build had never been dispatched, and nothing contradicted it, because the hand-written dispatch
 * ledger had stopped recording two days earlier and nobody had noticed. The record is now generated
 * from the harness transcripts by tools/dispatch-spine.py. This hook asks that tool the one question
 * the failure turned on, so that catching the next one does not depend on anyone thinking to look.
 *
 * ── ⛔ WHAT IT CANNOT DO, AND THIS IS IN THE MESSAGE TOO ─────────────────────────────────
 * "No dispatch found" is NOT "this did not happen". Work done inline by the dispatcher leaves no
 * Task call and cannot appear in the spine. This hook therefore REPORTS, it does not accuse, and
 * its wording says so — because it WILL fire on legitimate inline work and there is no structural
 * signal that separates a run done inline from one never started. Anything that tried would be
 * inferring intent from prose, which is the instrument that has failed repeatedly on this machine.
 * The honest position: this is a prompt to check, not a verdict.
 *
 * ── ⛔ IT READS THE DECLARED SET; IT NO LONGER GUESSES FROM PROSE (2026-08-25) ───────────
 * Until today nothing on this machine marked the beginning of a run. An id was invented in prose and
 * no tool observed the moment, so this hook had to treat every token OF RUN-ID SHAPE as a run. That
 * gave it one true-positive class and two false ones: work done inline, and a run merely NAMED as
 * the next thing someone would take (it fired on that, at the agent that wrote it).
 *
 * tools/run-open.sh now issues ids and writes state/runs/<id>/.declared. A token nobody declared is
 * NOT A RUN, and this hook says nothing about it. That is a declared signal — an author deliberately
 * opening a run — not structure recovered from text, which is the instrument that has failed five
 * times here.
 *
 * ⛔ AND IT ONLY CLOSES TWO OF THE THREE. A declared run done INLINE still has no Task call, so
 * declaring it would flag it forever, and the only escape would be to stop declaring inline runs —
 * making the declared set a lie and punishing the discipline this depends on. So `run-open.sh
 * --inline` writes a second line in the marker and this hook skips those. Also a declared signal.
 * Nothing here infers how a run was carried out.
 *
 * ⛔ WHAT THE RESIDUE BECOMES — MEET IT HERE RATHER THAN REDISCOVERING IT:
 *   1. SILENCE ON UNDECLARED WORK. Dispatch a worker under an id nobody issued and this hook says
 *      nothing at all. The failure class moved from false positives on prose to silence on runs
 *      nobody declared — and silence does not announce itself. It is still the better trade, because
 *      a false alarm trains a reader to ignore the instrument and a silence does not, but it IS a
 *      trade and every id minted by hand re-opens it.
 *   2. NOTHING BEFORE 2026-08-25 07:34 IS DECLARED. The marker did not exist. So this hook is now
 *      silent about every run in the machine's history, and on the night it was written it would
 *      have caught nothing. Its value is entirely prospective.
 *   3. `--inline` IS SELF-REPORTED. Declare inline, then dispatch a worker, and nothing checks. That
 *      is deliberate: the alternative is inferring intent from prose.
 *
 * ── ⛔ IT PERSISTS NOTHING, AND ESPECIALLY NOT WHERE THE CHECKERS LOOK ───────────────────
 * On 2026-08-24 a heartbeat file written inside the checked directory made a freshness test
 * permanently true and silenced every state checker for thirty-four minutes. So this hook writes NO
 * state at all — no counter, no marker, no log. It has nothing to put anywhere, which is the only
 * fully safe amount.
 *
 * ── SESSION GATE + LOOP GUARD (added 2026-08-25, run stop-hooks-session-gate-20260825) ──
 * This hook is registered with a universal matcher in ~/.claude/settings.json, so until now it
 * fired in EVERY Claude Code session on this machine. Two concrete consequences, not theoretical
 * ones: an unrelated session that happened to name a token of run-id shape got told to go read
 * `orchestrator/tools/run-open.sh --list`, a tool in a directory it has no business in; and every
 * such session spawned `python3 dispatch-spine.py --jsonl`, which reads every transcript on the
 * machine, inside a Stop hook's budget. Six of the eight registered Stop hooks already carry the
 * two protections that close this; this one did not.
 *
 * It uses inOrchestratorSession() from ./session-gate.mjs UNCHANGED — the same import
 * savepoint-guard.mjs, savepoint-fit-stop.mjs and publish-stop.mjs use, not a re-implementation,
 * so the gate cannot drift between them. It fails CLOSED: no marker, unreadable marker, empty
 * marker, or a payload with no session_id all mean "no permission to act".
 *
 * ⛔ IT ALSO HONOURS stop_hook_active NOW, AND IT DEMONSTRABLY DID NOT BEFORE. A continuation
 * stop carries the same last_assistant_message, so the same run ids extracted and this hook spoke
 * again inside a block chain it had no part in starting. The dedup note bounded that per (session,
 * run) but only AFTER the first emission, and only when the temp note was writable — the dedup is
 * documented as failing OPEN, so it was never the loop guard. This is.
 *
 * ⛔ THE PAYLOAD PARSE MOVED ABOVE THE SPINE existsSync, so the gate is the first thing that
 * happens after the mode switch. Both moved statements are pure predicates with no output and no
 * writes, so the reorder changes nothing about a gated run; it only means a foreign session now
 * does not even stat the spine tool.
 *
 * ── STOP-CHAIN CONTRACT ─────────────────────────────────────────────────────────────────
 * ALWAYS exit 0. It NEVER blocks: it emits no decision JSON, ever. Fails open and silently on
 * anything about its own plumbing — a missing spine tool, an unreadable transcript, a bad payload.
 * A guard that traps a session because its own parse broke is worse than every miss it would catch.
 *
 * Env (all optional): DISPATCH_CHECK_MODE (on|off), DISPATCH_SPINE (path to the spine tool),
 * DISPATCH_RUNS_DIR (path to the runs directory holding the .declared markers), LINTEL_STATE
 * (where the gate looks for .session-id; defaults to the real orchestrator state dir).
 *
 * Exit: always 0.
 */

import { readFileSync, existsSync, readdirSync, mkdirSync, appendFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { homedir, tmpdir } from 'node:os';
import { createHash } from 'node:crypto';
import { inOrchestratorSession } from './session-gate.mjs';

const done = () => process.exit(0);

// ── SAY IT ONCE PER RUN PER SESSION ───────────────────────────────────────
// The alarm was self-perpetuating: the candidate ids come from `last_assistant_message`, so warning
// about run X made the assistant discuss run X, whose next message named X again, which re-fired
// the warning — observed running four consecutive turns about one run.
//
// ⛔ THE NOTE IS AN ALERT-DEDUPLICATION RECORD, NOT A CLAIM ABOUT THE RUN. It lives in the OS temp
// directory precisely so that is structurally obvious, and it must NEVER live under
// orchestrator/state/ — on 2026-08-24 a file written inside a checked directory made a freshness
// test permanently true and silenced every state checker. Disposable is the correct durability for
// "I already said this".
//
// ⛔ FAILS OPEN, ALWAYS. Unwritable temp dir, unreadable note, a throwing write — every one of them
// means the hook warns exactly as it did before. A dedup mechanism that can SUPPRESS a warning by
// breaking is worse than no dedup at all.
const seenPath = (p) => {
  const sid = typeof p.session_id === 'string' && p.session_id
    ? p.session_id
    // No session id on the payload: a stable hash of the transcript path is the next-best key.
    : 'tp-' + createHash('sha1').update(String(p.transcript_path || '')).digest('hex').slice(0, 16);
  const key = sid.replace(/[^A-Za-z0-9_-]/g, '') || 'unknown';
  return join(tmpdir() || '/tmp', 'dispatch-check-seen', key);
};

const readSeen = (file) => {
  try { return new Set(readFileSync(file, 'utf8').split('\n').map((s) => s.trim()).filter(Boolean)); }
  catch { return new Set(); }        // no note, or unreadable: nothing is suppressed
};

const recordSeen = (file, ids) => {
  try {
    mkdirSync(join(file, '..'), { recursive: true });
    appendFileSync(file, ids.map((id) => id + '\n').join(''), 'utf8');
  } catch { /* could not remember: the warning still went out, which is the safe direction */ }
};

try {
  if ((process.env.DISPATCH_CHECK_MODE || 'on') === 'off') done();

  let p = {};
  try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { done(); }
  if (!p || typeof p !== 'object') done();

  // LOOP GUARD. Parsed, not substring-matched — a raw substring test slips on key order or
  // spacing. Same form and same position as savepoint-fit-stop.mjs and publish-stop.mjs.
  if (p.stop_hook_active === true) done();

  // SESSION GATE. First thing after the parse, ahead of the spine stat and far ahead of the
  // python3 spawn. Fails closed; see session-gate.mjs for the mechanism and why session_id is
  // the only field that both keeps today's coverage and closes the leak.
  const GATE_STATE = process.env.LINTEL_STATE
    || join(homedir(), '.claude', 'orchestrator', 'state');
  if (!inOrchestratorSession(p, GATE_STATE)) done();

  const SPINE = process.env.DISPATCH_SPINE
    || join(homedir(), '.claude', 'orchestrator', 'tools', 'dispatch-spine.py');
  if (!existsSync(SPINE)) done();          // no tool, no opinion

  const message = typeof p.last_assistant_message === 'string' ? p.last_assistant_message : '';
  if (!message) done();

  // A run id is a literal identifier of a fixed shape. Finding it is a pattern match on a known
  // token, not a judgement about what the message means.
  //
  // ⛔ NARROWED 2026-08-25, ON ITS FIRST LIVE FIRE. The first version matched
  // `pre-dispatch-check-20260825` out of the FILENAME `settings.json.pre-dispatch-check-20260825` —
  // a backup named after the thing it preceded, which will always look like a run id because that
  // is how backups here are named. The token must now start at a word boundary that is not part of
  // a path or a dotted name: start of string, whitespace, a backtick, a quote, or an open bracket.
  //
  // THIS IS A NARROWING, NOT A FIX. It kills the observed false positive and it does not answer
  // the real question, which is that NOTHING ON THIS MACHINE DECLARES A RUN ID IN A STRUCTURED
  // PLACE — see the report for run `scanner-quiet-20260825`. A token inside a path is now ignored,
  // which also means `runs/<id>/reports/...` no longer contributes; in practice the id is named
  // standalone in the same message, but that is a real reduction in reach.
  //
  // ⛔ WIDENED 2026-08-25 TO MATCH THE GATE FIVE LINES BELOW. The tail was `-\d{8}` while the
  // validity gate at the bottom of this loop is `-\d{8}(-\d+)?`. So the hook already carried the
  // correct specification of a run id and its own extractor could not produce one: fed
  // `retention-window-20260825-2` it returned `retention-window-20260825`, dropping the suffix.
  // `run-open.sh` mints exactly that `-N` shape on a same-day slug collision, so declared runs were
  // unreachable as themselves. The tail is now `-\d{8}(?:-\d+)?`; the lookbehind and the `\b`
  // termination are unchanged, and the gate is untouched.
  //
  // WHY OVER-MATCHING IS SAFE, AND THIS IS THE PART TO DOUBT LAST: a token that extracts is not a
  // warning. It only warns if `<RUNS>/<that exact name>/.declared` exists and is readable. THE
  // MARKER FILE IS THE REAL FILTER; the regex was never load-bearing for precision. Widening it can
  // surface a run that was previously invisible and cannot manufacture one that is not on disk.
  const named = [...new Set((message.match(/(?<=^|[\s`'"(\[])[a-z][a-z0-9-]*-\d{8}(?:-\d+)?\b/gm) || []))];
  if (!named.length) done();

  // THE DECLARED SET. A marker's first line is a UTC timestamp; an optional second line of `inline`
  // says the run is carried out in the main thread and will never have a Task call.
  //
  // Read only the markers for ids this turn actually named — never the whole directory. That is a
  // handful of tiny reads instead of a scan of every run folder on the machine.
  const RUNS = process.env.DISPATCH_RUNS_DIR
    || join(homedir(), '.claude', 'orchestrator', 'state', 'runs');

  const ids = [];
  for (const id of named) {
    // The id came out of a message and is about to be joined onto a path. Anything that is not a
    // plain run id is dropped rather than resolved — the regex above already forbids `/` and `.`,
    // and this is the second gate because a path built from message text deserves two.
    if (!/^[a-z][a-z0-9-]*-\d{8}(-\d+)?$/.test(id)) continue;
    let marker;
    try { marker = readFileSync(join(RUNS, id, '.declared'), 'utf8'); } catch { continue; }
    // NOT DECLARED (the catch above) MEANS NOT A RUN — the prospective mention and the backup
    // filename both land here, and both now cost nothing and say nothing.
    if (/^\s*inline\s*$/m.test(marker)) continue;   // declared, and declared as inline
    ids.push(id);
  }
  if (!ids.length) done();

  // ONE subprocess, not one per id. An earlier draft called `--check` per run id, and each call
  // re-scanned every transcript on the machine — nearly two thousand files, about a second and a
  // quarter each. Six ids would have been eight seconds of a Stop hook's budget doing the same work
  // six times. One `--jsonl` pass harvests everything and the matching happens here.
  let known = new Set();
  try {
    const out = execFileSync('python3', [SPINE, '--jsonl'],
                             { stdio: ['ignore', 'pipe', 'ignore'], timeout: 20000, encoding: 'utf8' });
    for (const line of out.split('\n')) {
      if (!line.trim()) continue;
      let row; try { row = JSON.parse(line); } catch { continue; }
      for (const rid of (row.run_ids || [])) known.add(rid);
    }
  } catch { done(); }          // the spine could not run: no opinion, rather than a false alarm

  const allMissing = ids.filter((id) => !known.has(id));
  if (!allMissing.length) done();

  // Say it once per (session, run). Anything already noted for this session is dropped here; a
  // second, different run id in the same session is not, so case 4 still warns.
  const noteFile = seenPath(p);
  const already = readSeen(noteFile);
  const missing = allMissing.filter((id) => !already.has(id));
  if (!missing.length) done();
  recordSeen(noteFile, missing);

  const one = missing.length === 1;
  const lines = [
    `DISPATCH CHECK: ${missing.join(', ')} ${one ? 'was' : 'were'} declared with run-open.sh, and ` +
    `the dispatch record does not name ${one ? 'it' : 'them'}.`,
    ``,
    `That record reads Task and Agent tool calls only. It cannot see a run carried out inline, or ` +
    `one sent to a persistent seat by cross-session message — both of those read as no dispatch at ` +
    `all. So this is a gap in the instrument at least as often as it is a finding.`,
    ``,
    `It matters in one case: if a human has been told ${one ? 'this run is' : 'one of these runs is'} ` +
    `under way, finished, or awaiting a decision on the strength of a worker having been sent, the ` +
    `record does not support that.`,
    ``,
    `Said once per run per session. \`orchestrator/tools/run-open.sh --list\` shows the full ` +
    `declared set.`,
  ];

  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'Stop', additionalContext: lines.join('\n') },
  }));
} catch {
  /* Any failure of this hook's own plumbing: exit 0, say nothing. */
}

done();

#!/usr/bin/env node
// ⛔ RESOLVE THE IDENTIFIER TO ITS URL, DO NOT ASK THE SEAT TO GO AND FIND IT.
//
// Jo, 2026-09-16: "is Tinker working on machinery to make sure you always give me a URL when
// mentioning a GitHub PR or Linear issue?" And on the previous instance: "Fuck adding a hard link
// rule. We need machinery to enforce it."
//
// WHY THIS IS NOT ANOTHER REFUSAL. `identifier-link-guard.mjs` already refuses, and it works —
// measured 2026-09-16 against the installed adapter, it blocked five bare identifiers in one
// message. But Lintel's ruling from tonight's measurements is that a block enforces a stop while
// the reason text inside it is data with no authority: a seat can read "add the link" and decline.
// ⛔ So this module RESOLVES. Where the text is a tool argument the bridge can rewrite, the URL is
// inserted and nobody is asked anything. Where it cannot (a final reply to Jo, which no tool
// carries), the refusal at least arrives with the finished URLs in it, so compliance is
// transcription rather than research.
//
// TWO MODES:
//   --rewrite   stdin {"text": "..."} -> stdout {"text": "...", "changed": true, "resolved": [...]}
//   (default)   stdin a Stop payload  -> stdout {"decision":"block","reason":"..."} when identifiers
//               remain that this module cannot resolve on its own.
//
// ⛔ THE KILL SWITCH IS READ PER INVOCATION, FROM A FILE. Measured this session: a module-scope
// environment read is frozen for the life of the process, so an env kill switch cannot be thrown
// without relaunching every seat — the same defect class as the launcher's frozen adapter.
// `touch orchestrator/hooks/.url-machinery-off` disables it within one turn.

import { existsSync, readdirSync, readFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join } from "node:path";

const HOME = process.env.HOME ?? "/Users/jowolff";
const OFF_SWITCH = join(HOME, ".claude", "orchestrator", "hooks", ".url-machinery-off");
// Measured 2026-09-16 from real links in this repo: every Linear URL is
// `https://linear.app/contextpress/issue/<ID>`. The old guard claimed the URL could not be
// constructed without `get_issue`; that is true of the issue's TITLE and false of its URL.
const LINEAR_WORKSPACE = "contextpress";

/**
 * Seat names are not repo mentions.
 * ⛔ MEASURED 2026-09-16: `lintel` is BOTH a persistent seat and a checkout on this machine
 * (thewolff/lintel), and every Lintel message signs with its own name. So the signature alone
 * made `mentioned.size === 1` and `#1086` left for Wren as
 * `https://github.com/thewolff/lintel/pull/1086` in mail whose subject was ContextPress/newdle-web.
 * An addressee is not a subject. Of the eleven seat names only `lintel` collides today; the rest
 * are listed so the next collision is inert on arrival instead of shipping a wrong link first.
 * The env var is authoritative when the resolver runs under a seat; the literal list covers
 * Jo's own sessions, where the env var is absent but the words still appear.
 */
const SEAT_NAMES = new Set(
	["lintel", "tinker", "sedge", "verge", "wren", "sluice", "galley", "levitt", "codex", "caspian", "tron"]
		.concat((process.env.OMP_PERSISTENT_SEAT_NAMES ?? "").split(/[,\s]+/))
		.filter(Boolean)
		.map(name => name.toLowerCase()),
);
// ⛔ TWO LEVELS, BECAUSE THE REPO JO TALKS ABOUT MOST IS ON THE SECOND ONE. Measured: `kitchen`
// is not `~/code/kitchen`, it is `~/code/shipyard/repos/kitchen`, so a one-level scan resolved
// Linear ids and left every kitchen PR unresolved — the exact identifier Lintel got wrong tonight.
function searchRoots() {
	const roots = [join(HOME, "code"), HOME];
	for (const base of [join(HOME, "code")]) {
		let names = [];
		try {
			names = readdirSync(base, { withFileTypes: true }).filter(e => e.isDirectory()).map(e => e.name);
		} catch {
			continue;
		}
		for (const name of names) {
			const nested = join(base, name, "repos");
			if (existsSync(nested)) roots.push(nested);
		}
	}
	return roots;
}

// Prefixes that look like team keys and are not. Kept in sync with identifier-link-guard.mjs by
// deliberate duplication: a shared import would make one guard's failure the other's.
const NOT_TICKETS = new Set([
	"RFC", "UTF", "SHA", "CVE", "ISO", "API", "CPU", "GPU", "RAM", "URL", "URI", "CSS", "HTML",
	"JSON", "YAML", "HTTP", "TLS", "SSH", "GPT", "LLM", "MCP", "TODO", "FIXME", "WCAG", "AA",
	"OMP", "PR", "CI", "UI", "UX", "M4", "ARM", "X86",
]);

function killed() {
	// existsSync at call time, never cached.
	return existsSync(OFF_SWITCH);
}

/** owner/repo for every checkout on this machine, keyed by directory name AND repo name. */
function repoIndex() {
	const index = new Map();
	for (const root of searchRoots()) {
		let names = [];
		try {
			names = readdirSync(root, { withFileTypes: true }).filter(e => e.isDirectory()).map(e => e.name);
		} catch {
			continue;
		}
		for (const name of names) {
			const dir = join(root, name);
			if (!existsSync(join(dir, ".git"))) continue;
			let url = "";
			try {
				url = execFileSync("git", ["-C", dir, "remote", "get-url", "origin"], {
					encoding: "utf8",
					stdio: ["ignore", "pipe", "ignore"],
					timeout: 3_000,
				}).trim();
			} catch {
				continue;   // a checkout with no origin cannot contribute a URL
			}
			const match = url.match(/[:/]([^/:]+)\/([^/]+?)(?:\.git)?$/);
			if (!match) continue;
			const slug = `${match[1]}/${match[2]}`;
			index.set(name.toLowerCase(), slug);
			index.set(match[2].toLowerCase(), slug);
		}
	}
	return index;
}

let cachedIndex;
function repos() {
	// Cached per PROCESS, and this is a short-lived CLI: one invocation per hook call. The kill
	// switch is what must never be cached; a repo list that changes mid-turn is not a real case.
	cachedIndex ??= repoIndex();
	return cachedIndex;
}

/**
 * Which repo does a bare `#N` belong to? Only answerable from the surrounding words.
 * ⛔ Returns undefined rather than guessing: handing Jo a link to the wrong repo's PR 51 is worse
 * than handing him no link, because he would click it and read someone else's change.
 */
function repoFromContext(text) {
	const index = repos();
	const mentioned = new Set();
	// An explicit `owner/repo` is unambiguous, so it outranks every alias rule INCLUDING
	// SEAT_NAMES: it is the only way left to name a repo whose short name is also a seat's.
	const slugs = new Set(index.values());
	for (const match of text.matchAll(/\b([\w.-]+)\/([\w.-]+)\b/g)) {
		const slug = `${match[1]}/${match[2]}`;
		if (slugs.has(slug)) mentioned.add(slug);
	}
	for (const [alias, slug] of index) {
		if (alias.length < 4) continue;   // "api" and friends are words
		if (SEAT_NAMES.has(alias)) continue;
		const pattern = new RegExp(`\\b${alias.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i");
		if (pattern.test(text)) mentioned.add(slug);
	}
	return mentioned.size === 1 ? [...mentioned][0] : undefined;
}

/** Every identifier in the text that is not already inside a URL, with its resolution. */
export function findIdentifiers(text) {
	const urlSpans = [...text.matchAll(/https?:\/\/\S+/g)].map(m => [m.index, m.index + m[0].length]);
	const inUrl = index => urlSpans.some(([start, end]) => index >= start && index < end);
	const found = [];
	const repo = repoFromContext(text);
	// ⛔ AN IDENTIFIER WHOSE URL IS ALREADY IN THE TEXT IS SATISFIED, EVEN THOUGH THE BARE ID SITS
	// OUTSIDE THE LINK. Measured: `#51 (https://github.com/ContextPress/kitchen/pull/51)` — the
	// correct, compliant form Jo asked for — was re-appended a second copy of its own URL, because
	// the only test was whether the id itself fell inside a URL span. A guard that corrupts the
	// exact output it is asking for is worse than no guard: it punishes compliance.
	const satisfied = url => Boolean(url) && text.includes(url);

	for (const match of text.matchAll(/#(\d{1,6})\b/g)) {
		if (inUrl(match.index)) continue;
		const url = repo ? `https://github.com/${repo}/pull/${match[1]}` : undefined;
		if (satisfied(url)) continue;
		found.push({
			raw: match[0],
			index: match.index,
			url,
			why: repo ? undefined : "no single repo named in the message, so the owner/repo is unknowable from the text",
		});
	}
	for (const match of text.matchAll(/\b([A-Z]{2,5})-(\d{1,6})\b/g)) {
		if (inUrl(match.index)) continue;
		if (NOT_TICKETS.has(match[1])) continue;
		const url = `https://linear.app/${LINEAR_WORKSPACE}/issue/${match[0]}`;
		if (satisfied(url)) continue;
		found.push({ raw: match[0], index: match.index, url });
	}
	return found.sort((a, b) => a.index - b.index);
}

/** Insert the URL after each identifier it can resolve. Never rewrites what it cannot resolve. */
export function rewrite(text) {
	const found = findIdentifiers(text);
	const resolvable = found.filter(item => item.url);
	if (!resolvable.length) return { text, changed: false, resolved: [], unresolved: found };
	let out = "";
	let cursor = 0;
	for (const item of resolvable) {
		const end = item.index + item.raw.length;
		out += text.slice(cursor, end) + ` (${item.url})`;
		cursor = end;
	}
	out += text.slice(cursor);
	return {
		text: out,
		changed: true,
		resolved: resolvable.map(item => ({ raw: item.raw, url: item.url })),
		unresolved: found.filter(item => !item.url),
	};
}

function stdin() {
	try {
		return readFileSync(0, "utf8");
	} catch {
		return "";
	}
}

function main() {
	const mode = process.argv[2];
	const raw = stdin();
	if (killed()) {
		// Silent and inert, both modes: a disabled guard must not alter text either.
		if (mode === "--rewrite") process.stdout.write(JSON.stringify({ text: JSON.parse(raw || "{}").text ?? "", changed: false, resolved: [], killed: true }));
		return;
	}

	if (mode === "--rewrite") {
		let text = "";
		try {
			text = JSON.parse(raw || "{}").text ?? "";
		} catch {
			process.stdout.write(JSON.stringify({ text: "", changed: false, resolved: [] }));
			return;
		}
		process.stdout.write(JSON.stringify(rewrite(text)));
		return;
	}

	let payload = {};
	try {
		payload = JSON.parse(raw || "{}");
	} catch {
		return;
	}
	const text = typeof payload.last_assistant_message === "string" ? payload.last_assistant_message : "";
	if (!text) return;
	const { resolved, unresolved } = rewrite(text);
	if (!resolved.length && !unresolved.length) return;

	const lines = [];
	if (resolved.length) {
		lines.push("⛔ **Identifiers named without their links. The URLs are resolved below — paste them in and resend.**", "");
		for (const item of resolved) lines.push(`- \`${item.raw}\` → ${item.raw} (${item.url})`);
	}
	if (unresolved.length) {
		if (resolved.length) lines.push("");
		lines.push("**These could not be resolved for you:**", "");
		for (const item of unresolved) lines.push(`- \`${item.raw}\` — ${item.why}. Name the repo, or paste the link.`);
	}
	lines.push(
		"",
		"Jo, 2026-09-11: \"why, for the love of fuck, would you reference a PR and not give me the hard link"
			+ " to where it lives in GitHub? I'm not going to hunt for it.\"",
	);
	process.stdout.write(JSON.stringify({ decision: "block", reason: lines.join("\n") }));
}

if (import.meta.main) main();

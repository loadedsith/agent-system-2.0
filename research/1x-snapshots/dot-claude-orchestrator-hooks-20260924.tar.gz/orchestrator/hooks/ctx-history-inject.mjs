#!/usr/bin/env node
/**
 * UserPromptSubmit — searches the indexed agent history for the turn being asked, and injects a
 * compact digest of the hits into the model's context BEFORE it answers.
 *
 * ── WHY THIS EXISTS, AND WHY IT IS NOT A RULE ────────────────────────────────────────────────
 * REQ-411, filed 2026-08-28 after Jo asked "how do we enforce it with machinery?". ctx has
 * indexed the whole history of this machine and nobody queried it. Two mechanisms were tried and
 * both are now settled:
 *
 *   (a) AVAILABILITY — the ctx MCP server was wired and the vendor's own `ctx` skill installed.
 *       Measured 2026-09-08: 82 tool calls in Lintel's session before its first ctx call, and
 *       EXP-020 counted ZERO ctx calls across 67 sessions. Making a tool reachable changed
 *       nothing, because reaching for it is still a choice.
 *   (b) A NUDGE HOOK firing when an agent hand-read a raw transcript — dead on measurement.
 *       It fires on 8.84% of turns; the tightest constructible trigger fires 11 times in 3,326
 *       and is right about once. Precision 9-27%. Abandoned 2026-09-08.
 *
 * So this hook does not ask, does not remind, and cannot be declined: it performs the search
 * itself and puts the answer in front of the model. That is the difference between machinery and
 * a rule, and on this machine rules aimed at this problem have a measured success rate of zero.
 *
 * ── ⛔ THE RETRIEVAL MODE IS PRINTED INSIDE THE PAYLOAD, DELIBERATELY ─────────────────────────
 * ctx reports `retrieval.effective_mode` on every search, and as of 2026-09-11 it reports
 * `lexical` while `requested_mode` is `hybrid` — the semantic half has been dark since at least
 * 2026-09-08 and its catch-up has failed ten-plus consecutive times. It reported that fact
 * faithfully the whole time, in a metadata block, and three days of keyword-only searching went
 * unnoticed anyway.
 *
 * A forced search that silently degrades is WORSE than no forced search, because it manufactures
 * the confidence that history was consulted. So the mode goes in the first line of the injected
 * block, in the model's reading path, not in a footer. When semantic returns this line starts
 * saying `hybrid` and nothing else about this hook changes.
 *
 * ── INJECTION FORM — measured by turn-id-mint.mjs, reused rather than re-derived ──────────────
 * Plain stdout text did NOT reach the model on the first turn of a fresh session (probe-1,
 * probe-3); the JSON hookSpecificOutput.additionalContext form reached it on both a first and a
 * later turn. This hook therefore uses the JSON form ONLY. See turn-id-mint.mjs:15-20.
 *
 * ⛔ UserPromptSubmit is the proven event. PreToolUse(Agent|Task) — which would put history in
 * front of every HAND rather than every seat turn — is NOT wired here, because whether that event
 * honours additionalContext on this harness is UNMEASURED, and a hook that silently injects
 * nothing is indistinguishable from one that works. Measure it, then extend this file.
 *
 * ── CONTRACT ─────────────────────────────────────────────────────────────────────────────────
 * Always exit 0. Never block a turn, never delay one past CTX_INJECT_TIMEOUT_MS, never inject a
 * result it did not receive. Every failure path is silent and open: a broken history search must
 * cost a turn nothing. The turn is the user's, not this hook's.
 */
import { readFileSync, appendFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { homedir } from 'node:os';
import { spawnSync } from 'node:child_process';

const HOME = homedir();
const ROOT = process.env.CTX_INJECT_ROOT || join(HOME, '.claude');
const STATE = process.env.LINTEL_STATE || join(ROOT, 'orchestrator', 'state');
const LOG = process.env.CTX_INJECT_LOG || join(STATE, 'ctx-inject.jsonl');
const BIN = process.env.CTX_INJECT_BIN || join(HOME, '.local', 'bin', 'ctx');
// 6000 was the original budget and it was sized on 2026-09-11 when ctx answered from lexical
// alone. Semantic returned on 2026-09-15 and added query-embedding work to the same call:
// measured 2.4 s to >20 s for the identical query minutes apart, median ~3-5 s. The hook's
// registration in settings.json allows 15 s, so 10 s is the largest budget that still leaves the
// harness its own margin. ⛔ This does NOT make the call reliable — see the failure banner below.
const TIMEOUT_MS = Number(process.env.CTX_INJECT_TIMEOUT_MS || 10000);
const LIMIT = Number(process.env.CTX_INJECT_LIMIT || 5);

// Unique analyzed tokens allowed in one query. ctx's hard ceiling is 32; this sits below it
// because the analyzer's token count is derived, not declared, and a query that trips the
// ceiling is not a degraded search — it is no search at all.
const MAX_TERMS = Number(process.env.CTX_INJECT_MAX_TERMS || 24);

// A default `ctx search` returns ~51KB / ~13k tokens and is only 14% payload — measured
// 2026-09-08. Injecting that on every turn would be a context tax nobody consented to, so this
// hook passes an explicit small limit and renders a digest rather than the tool's own output.
const SNIPPET_CHARS = Number(process.env.CTX_INJECT_SNIPPET || 220);

const done = () => process.exit(0);

/**
 * Write the injected block and exit. ALWAYS exits 0 — a hook that fails the turn is worse than a
 * hook that fails its job.
 *
 * ⛔ `failure` is why this exists. The first version of this hook returned NOTHING when ctx could
 * not answer, and on 2026-09-15 that was measured as six consecutive silent losses over two days:
 * every agent in those sessions believed history had been consulted and found nothing, when in
 * fact history had never been asked. An unavailable search and an empty result are the same
 * absence in the model's context unless something says which one happened — so on every failure
 * path this states, in the model's reading path, that the search DID NOT RUN.
 *
 * This is the same property as the mode banner one line up, applied to the failure path: a
 * warning that only fires on the bad path is not read on the bad path.
 */
export function failureBlock(reason) {
  return `PRIOR AGENT HISTORY (ctx) — ⛔ NOT CONSULTED: ${reason}\n` +
         `This turn has NO history behind it. Absence of prior work below is not evidence: ` +
         `nothing was searched. If prior sessions would settle this question, run ` +
         `\`ctx search "<terms>"\` yourself before answering, and say that the automatic ` +
         `lookup failed rather than implying history was checked.`;
}

function emit(block, failure) {
  const text = block ?? failureBlock(failure || 'unknown');
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: text },
  }));
  process.exit(0);
}

function record(row) {
  try {
    mkdirSync(dirname(LOG), { recursive: true });
    appendFileSync(LOG, JSON.stringify({ ts: new Date().toISOString(), ...row }) + '\n');
  } catch { /* a log that cannot be written must not cost the turn */ }
}

/**
 * Is this prompt worth a search?
 *
 * The cost of a miss is asymmetric and that asymmetry decides the threshold. A needless search
 * costs ~200ms and a few hundred tokens; a skipped search costs the failure this hook exists to
 * prevent. So the bar is LOW and only filters prompts a search cannot act on at all: greetings,
 * bare acknowledgements, and single short words carry no term for a lexical index to match.
 *
 * ⛔ Kept deliberately dumb. Every cleverer version of this gate is a rule about when history
 * matters, and an agent that could reliably judge that would have called ctx unprompted.
 */
export function worthSearching(prompt) {
  const t = String(prompt || '').trim();
  if (t.length < 24) return false;
  const words = t.split(/\s+/).filter((w) => /[a-z0-9]{4,}/i.test(w));
  if (words.length < 3) return false;
  // A prompt that is itself a ctx invocation does not need its results pre-fetched.
  if (/^\s*ctx\s+(search|show|status|list)\b/i.test(t)) return false;
  return true;
}

/**
 * Turn a prompt into a query. Lexical retrieval matches terms, so the query keeps the prompt's
 * own words rather than paraphrasing them — a paraphrase is exactly what lexical cannot resolve,
 * and measured 2026-09-08 three paraphrases of a known-indexed event retrieved NOTHING while two
 * term-accurate controls hit.
 */
export function queryFrom(prompt) {
  const flat = String(prompt || '')
    .replace(/```[\s\S]*?```/g, ' ')   // fenced code is noise for a history query
    .replace(/\s+/g, ' ')
    .trim();

  // ⛔ THE CAP IS NOT TIDINESS. `ctx search` REFUSES a query with more than 32 unique analyzed
  // tokens — `Error: lexical query has too many unique analyzed tokens: observed 33, maximum 32`,
  // exit 1 — and it refuses in ~3 s so it looks like a slow success in a log that only records a
  // return code. Six consecutive injections were lost to this between 09-14 and 09-15.
  //
  // ⛔ And the analyzer splits on punctuation, so word-level dedupe UNDERCOUNTS it: a 32-word
  // query built by splitting on spaces still failed, because `hooks/extensions` and `don't` each
  // analyze as two tokens. Measured: cap 32 → exit 1; cap 28 → ok; so tokens are counted the way
  // the analyzer counts them, on alphanumeric runs, and the ceiling carries headroom.
  const seen = new Set();
  const kept = [];
  for (const word of flat.split(' ')) {
    const tokens = word.toLowerCase().match(/[a-z0-9]+/g);
    if (!tokens) continue;
    if (tokens.every((t) => seen.has(t))) continue;   // adds no new term; drop it
    if (seen.size + new Set(tokens).size > MAX_TERMS) break;
    for (const t of tokens) seen.add(t);
    kept.push(word);
  }
  return kept.join(' ').slice(0, 300);
}

/**
 * Render the injected block. Factored out so --selftest exercises the SAME code the hook runs;
 * a selftest against a reimplementation tests the reimplementation.
 */
export function render(payload, query) {
  const r = payload?.retrieval || {};
  const results = Array.isArray(payload?.results) ? payload.results : [];
  const mode = r.effective_mode || 'unknown';
  const requested = r.requested_mode || 'unknown';
  const degraded = mode !== requested;

  // ⛔ First line, every time, degraded or not. A banner that appears only on the bad path
  // trains the reader to skip it on the good path, and then it is not read on the bad one.
  let head = `PRIOR AGENT HISTORY (ctx) — retrieval: ${mode}`;
  if (degraded) {
    head += ` ⛔ DEGRADED (requested ${requested}; semantic ${r.semantic_status || 'unavailable'})`;
  }
  head += `\nsearched ${Number(r.indexed_documents || 0).toLocaleString()} indexed documents for: ${query}`;
  if (degraded) {
    head += `\n⛔ This was KEYWORD-ONLY. A query whose wording differs from the indexed text will ` +
            `return nothing here even when the history contains the answer. Absence below is NOT ` +
            `evidence that this has never been done before.`;
  }

  if (!results.length) {
    return `${head}\n\nNo prior sessions matched. Treat that as "no keyword match", not as "no prior work".`;
  }

  const rows = results.slice(0, LIMIT).map((x, i) => {
    const when = String(x.timestamp || '').slice(0, 10);
    const sid = String(x.ctx_session_id || '').slice(0, 8);
    const snip = String(x.snippet || '').replace(/\s+/g, ' ').trim().slice(0, SNIPPET_CHARS);
    return `${i + 1}. [${when}] ${x.title || 'session'} (ctx ${sid})\n   ${snip}`;
  }).join('\n');

  return `${head}\n\n${rows}\n\n` +
         `Open any of these with: ctx show session <id>  /  ctx search "<terms>" --session <id>\n` +
         `These are prior sessions on this machine, retrieved before you answered. If one bears on ` +
         `the question, cite it rather than re-deriving what it already settled.`;
}

// ── SELF-TEST ────────────────────────────────────────────────────────────────────────────────
// Both poles for each claim. "It prints the mode" and "it flags a degraded mode" are different
// claims and an implementation can satisfy either while failing the other.
if (process.argv.includes('--selftest')) {
  let pass = 0, fail = 0;
  const check = (name, cond) => { if (cond) { pass++; } else { fail++; console.error(`FAIL ${name}`); } };

  check('skips a greeting', worthSearching('hi there') === false);
  check('skips a bare ack', worthSearching('ok thanks') === false);
  check('skips a ctx invocation', worthSearching('ctx search delegation guard muted please') === false);
  check('searches a real question',
        worthSearching('why did the delegation guard get muted last week and who did it') === true);
  check('searches a terse but substantive ask',
        worthSearching('rebuild the semantic index for ctx now') === true);

  check('query strips fenced code',
        queryFrom('fix this ```const x = 1;``` please now') === 'fix this please now');
  check('query is capped', queryFrom('x '.repeat(400)).length <= 300);

  // ⛔ The unique-token ceiling. These are the checks that would have caught the 09-14 outage:
  // ctx refuses above 32 unique analyzed tokens, so the cap must hold on a long prompt AND must
  // not mangle a short one.
  const terms = (q) => new Set(q.toLowerCase().match(/[a-z0-9]+/g) || []).size;
  const longPrompt = Array.from({ length: 80 }, (_, i) => `word${i}`).join(' ');
  check('long prompt is capped below ctx ceiling', terms(queryFrom(longPrompt)) <= 24);
  check('punctuation-split words count as their tokens',
        terms(queryFrom('hooks/extensions and don\'t ' + longPrompt)) <= 24);
  check('short prompt passes through unchanged',
        queryFrom('why did the routing gate get built') === 'why did the routing gate get built');
  check('repeated words do not consume the budget',
        queryFrom('gate gate gate gate routing') === 'gate routing');
  check('empty prompt yields empty query', queryFrom('   ') === '');
  check('code-only prompt yields empty query', queryFrom('```x```') === '');

  // Both poles of the failure banner: it must say NOT CONSULTED and carry the reason, and it must
  // never look like a successful empty result.
  const fb = failureBlock('rc=1 — lexical query has too many unique analyzed tokens');
  check('failure banner declares the search did not run', /NOT CONSULTED/.test(fb));
  check('failure banner carries the cause', /too many unique analyzed tokens/.test(fb));
  check('failure banner refuses the absence reading', /nothing was searched/.test(fb));
  check('failure banner is not confusable with an empty hit',
        !/No prior sessions matched/.test(fb));

  const hybrid = { retrieval: { effective_mode: 'hybrid', requested_mode: 'hybrid', indexed_documents: 275490 },
                   results: [{ timestamp: '2026-08-20T22:31:51Z', title: 'claude user message',
                               ctx_session_id: 'a0445dbb-56e8', snippet: 'a managerial agent that owns one repo' }] };
  const lexical = { retrieval: { effective_mode: 'lexical', requested_mode: 'hybrid',
                                 semantic_status: 'unavailable', indexed_documents: 275490 },
                    results: hybrid.results };

  const okBlock = render(hybrid, 'seat mail');
  const badBlock = render(lexical, 'seat mail');

  check('healthy block names the mode', /retrieval: hybrid/.test(okBlock));
  check('healthy block does NOT cry degraded', !/DEGRADED/.test(okBlock));
  check('degraded block names the mode', /retrieval: lexical/.test(badBlock));
  check('degraded block flags degradation', /DEGRADED/.test(badBlock));
  check('degraded block warns absence is not evidence', /Absence below is NOT/.test(badBlock));
  check('mode appears on the FIRST line, not in a footer',
        badBlock.split('\n')[0].includes('lexical'));
  check('result rows carry a session id to open', /ctx a0445dbb/.test(okBlock));

  const empty = render({ retrieval: { effective_mode: 'lexical', requested_mode: 'lexical' }, results: [] },
                       'nothing matches this');
  check('empty result still names the mode', /retrieval: lexical/.test(empty));
  check('empty result refuses the "no prior work" reading', /not as "no prior work"/.test(empty));

  console.log(`${pass} pass / ${fail} fail`);
  process.exit(fail ? 1 : 0);
}

// ── HOOK ─────────────────────────────────────────────────────────────────────────────────────
let p = {};
try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { done(); }
if (p === null || typeof p !== 'object') done();

// ── SCOPE — GLOBAL, AND THAT IS A DECISION RATHER THAN AN OVERSIGHT ──────────────────────────
// `~/.claude/settings.json` is USER scope: this fires in every repository on this machine, not
// only in `~/.claude`. Its sibling brief-clause-guard.mjs gates on `cwd.startsWith(ROOT)` for
// exactly that reason, and when this hook first shipped it carried no such gate — accidentally,
// because I had not asked the question.
//
// Asked and answered: global is CORRECT here, and the two hooks differ in the way that decides
// it. brief-clause-guard REFUSES; a refusal in a repository that never agreed to the convention
// is a stranger's work blocked. This hook only ADDS context, and Jo's requirement for REQ-411 is
// "at least all the marches, and if it were subagents too" — the marches live in other
// repositories, so a gate on ROOT would exclude almost everyone it is for.
//
// What global costs, stated so it can be withdrawn on evidence rather than on feel: ~0.75 s and
// ~2 KB per substantive prompt, everywhere, including Jo's own unrelated sessions. The kill
// switch below is the withdrawal, and it needs no edit to this file and no restart.
if (process.env.CTX_INJECT_DISABLE) done();

const prompt = String(p.prompt ?? '');
if (!worthSearching(prompt)) done();

const query = queryFrom(prompt);
// An empty query is ctx exit 1 (`source-backed search needs a non-empty text query`, measured
// ~30 ms), so it is refused here rather than spent on a process.
if (!query) { emit(null, 'the prompt carried no searchable terms'); }

// `--refresh off` searches the existing published generation and never waits on daemon work:
// a hook that can block on an index refresh is a hook that can stall a user's turn.
// ⛔ `--` terminates flags: a prompt beginning with a dash is otherwise parsed as one
// (`error: unexpected argument '--fix the hook' found`, exit 2, measured ~11 ms).
const started = Date.now();
const res = spawnSync(BIN, ['search', '--limit', String(LIMIT), '--format', 'json',
                            '--refresh', 'off', '--quiet', '--', query],
                      { encoding: 'utf8', timeout: TIMEOUT_MS, maxBuffer: 8 * 1024 * 1024 });
const elapsedMs = Date.now() - started;

if (res.error || res.status !== 0 || !res.stdout) {
  // ⛔ The stderr tail is the whole point of this branch. The previous version recorded only
  // `rc=1`, and `rc=1` is the same row for "query too long", "empty query" and "store broken" —
  // three different faults with three different fixes, and it cost a day to tell them apart.
  const why = res.error ? String(res.error.code || res.error.message) : `rc=${res.status}`;
  const stderr = String(res.stderr || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  record({ decision: 'failed', reason: why, stderr, session: p.session_id,
           ms: elapsedMs, budget_ms: TIMEOUT_MS, terms: query.split(' ').length });
  emit(null, `${why}${stderr ? ` — ${stderr}` : ''}`);
}

let payload = null;
try { payload = JSON.parse(res.stdout); } catch {
  record({ decision: 'failed', reason: 'unparseable', session: p.session_id });
  emit(null, 'ctx returned output this hook could not parse');
}

const block = render(payload, query);
record({ decision: 'inject', session: p.session_id,
         mode: payload?.retrieval?.effective_mode,
         requested: payload?.retrieval?.requested_mode,
         results: Array.isArray(payload?.results) ? payload.results.length : 0,
         bytes: block.length, ms: elapsedMs, budget_ms: TIMEOUT_MS,
         terms: query.split(' ').length });
emit(block);

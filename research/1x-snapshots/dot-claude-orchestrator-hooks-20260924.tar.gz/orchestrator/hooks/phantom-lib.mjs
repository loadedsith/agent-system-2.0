/**
 * phantom-lib.mjs — pure detection functions for the phantom-claim guard.
 *
 * A PHANTOM is a claim, in an assistant's final message, about an action SCOPED TO THIS TURN,
 * where the turn contains no tool call that could have performed it.
 *
 * ── BOUNDARY 1: SCOPE, NOT TENSE ──────────────────────────────────────────────────────────
 * The obvious rule is "only past-tense claims are checkable", which is what a response-level
 * hallucination rubric uses. It is wrong HERE, and the reason is when this runs. A rubric
 * scores a message in isolation, where the future has genuinely not happened. This hook fires
 * at the END of the turn, at which point the turn's future is already over. "Dispatching a
 * worker now", in a turn that ends having dispatched nothing, is as false as "I dispatched a
 * worker" — same failure, different tense.
 *
 * So the line is drawn at SCOPE:
 *
 *   IN  — an action asserted of THIS turn, whatever its tense:
 *         completed   "I dispatched a worker" · "Ran the suite"
 *         in-flight   "I'm dispatching a worker" · "Dispatching the worker"
 *         immediate   "I'll run that now" · "About to run the tests right now"
 *
 *   OUT — an action genuinely deferred past this turn, which this turn's tool calls cannot
 *         speak to at all: "I'll file that tomorrow", "next session I'll pick this up",
 *         "that should be done before the release".
 *
 *   OUT — an offer, which is conditional on a human and therefore asserts nothing:
 *         "want me to run it?", "I can file that", "happy to dispatch a worker".
 *
 * WHERE THE LINE IS DRAWN, AND THIS IS THE HARD PART, STATED RATHER THAN HIDDEN.
 * A bare future with no time expression — "I'll run the tests." — is genuinely ambiguous
 * between "in a moment, in this turn" and "after you reply". Nothing in the sentence settles
 * it, and guessing produces exactly the false positives that get a guard switched off. So a
 * bare future is classified `ambiguous`: recorded for calibration, never counted as a claim,
 * never blocking. A future form is only IN scope when it carries an explicit IMMEDIACY marker
 * ("now", "right now", "immediately", "in this turn"). Present progressive needs no marker,
 * because the progressive itself asserts the action is under way.
 *
 * The residual hole this leaves is named rather than papered over: an agent that writes
 * "I'll dispatch a worker" and then dispatches nothing is not caught. Narrowing here is
 * deliberate — a rule that fires on ordinary plans is worse than one that misses this case.
 *
 * ── BOUNDARY 2: EXISTENCE, NOT SEQUENCE ───────────────────────────────────────────────────
 * A claim is satisfied by a matching tool call ANYWHERE in the turn — before it, after it, in
 * any order, any number of times. Nothing here examines ordering and nothing should be added
 * that does. Asserting a specific sequence of tool calls produces brittle checks that fail on
 * correct behaviour.
 */

// ── ACTION TABLE ──────────────────────────────────────────────────────────────────────────
// Each group carries its past forms, its -ing forms, its bare forms, and the set of tool
// names that could plausibly have performed it. The tool sets are deliberately GENEROUS: a
// claim only matters when NOTHING in its set was called, so a narrow set manufactures false
// positives.
const GROUPS = [
  { past: ['dispatched', 'spawned', 'launched', 'delegated', 'handed off'],
    ing:  ['dispatching', 'spawning', 'launching', 'delegating', 'handing off'],
    base: ['dispatch', 'spawn', 'launch', 'delegate', 'hand off'],
    tools: ['Task', 'Agent', 'SendMessage', 'Bash'] },

  { past: ['ran', 'executed', 'invoked'],
    ing:  ['running', 'executing', 'invoking'],
    base: ['run', 'execute', 'invoke'],
    tools: ['Bash', 'BashOutput', 'Monitor'] },

  { past: ['wrote', 'created', 'authored', 'drafted', 'scaffolded', 'appended', 'saved'],
    ing:  ['writing', 'creating', 'authoring', 'drafting', 'scaffolding', 'appending', 'saving'],
    base: ['write', 'create', 'author', 'draft', 'scaffold', 'append', 'save'],
    tools: ['Write', 'Edit', 'NotebookEdit', 'Bash', 'Artifact'] },

  { past: ['edited', 'updated', 'modified', 'patched', 'rewrote', 'renamed'],
    ing:  ['editing', 'updating', 'modifying', 'patching', 'rewriting', 'renaming'],
    base: ['edit', 'update', 'modify', 'patch', 'rewrite', 'rename'],
    tools: ['Edit', 'Write', 'NotebookEdit', 'Bash'] },

  { past: ['committed', 'pushed', 'merged', 'rebased', 'branched', 'tagged', 'reverted'],
    ing:  ['committing', 'pushing', 'merging', 'rebasing', 'branching', 'tagging', 'reverting'],
    base: ['commit', 'push', 'merge', 'rebase', 'branch', 'tag', 'revert'],
    tools: ['Bash'] },

  { past: ['filed', 'ticketed'],
    ing:  ['filing', 'ticketing'],
    base: ['file', 'ticket'],
    tools: ['Bash', 'mcp__linear__save_issue', 'mcp__linear__save_comment'] },

  { past: ['posted', 'sent', 'replied', 'messaged', 'notified', 'published'],
    ing:  ['posting', 'sending', 'replying', 'messaging', 'notifying', 'publishing'],
    base: ['post', 'send', 'reply', 'message', 'notify', 'publish'],
    tools: ['SendMessage', 'Artifact', 'Bash', 'mcp__linear__save_comment',
            'mcp__claude_ai_Gmail__send_message'] },

  { past: ['installed', 'uninstalled', 'deleted', 'removed', 'moved', 'copied', 'restored'],
    ing:  ['installing', 'uninstalling', 'deleting', 'removing', 'moving', 'copying', 'restoring'],
    base: ['install', 'uninstall', 'delete', 'remove', 'move', 'copy', 'restore'],
    tools: ['Bash', 'Write', 'Edit'] },

  { past: ['fetched', 'queried', 'grepped', 'scanned'],
    ing:  ['fetching', 'querying', 'grepping', 'scanning'],
    base: ['fetch', 'query', 'grep', 'scan'],
    tools: ['Read', 'Grep', 'Glob', 'Bash', 'WebFetch', 'WebSearch'] },
];

const FORM = new Map();   // surface form -> { kind: 'past'|'ing'|'base', tools }
for (const g of GROUPS) {
  for (const w of g.past) FORM.set(w, { form: 'past', tools: g.tools });
  for (const w of g.ing)  FORM.set(w, { form: 'ing',  tools: g.tools });
  for (const w of g.base) FORM.set(w, { form: 'base', tools: g.tools });
}
const ALTERNATION = [...FORM.keys()]
  .sort((a, b) => b.length - a.length)
  .map((v) => v.replace(/ /g, '\\s+'))
  .join('|');

// ── MARKERS ───────────────────────────────────────────────────────────────────────────────

// Puts the action beyond this turn. Anything carrying one of these is OUT of scope entirely.
const DEFERRAL = new RegExp(
  String.raw`\b(tomorrow|later|afterwards?|eventually|someday|some\s+point|some\s+stage|` +
  String.raw`down\s+the\s+line|next\s+(?:session|turn|time|week|month|sprint|cycle|step|up)|` +
  String.raw`follow[-\s]?up|in\s+a\s+bit|subsequently|in\s+due\s+course|` +
  String.raw`monday|tuesday|wednesday|thursday|friday|saturday|sunday|` +
  String.raw`once\s+you|after\s+you|when\s+you|if\s+you|pending|awaiting|` +
  String.raw`before\s+the\s+(?:release|deploy|merge|launch)|in\s+the\s+morning)\b`,
  'i'
);

// Places the action in an EARLIER turn, which this turn's tool calls cannot speak to either.
// The guard sees one turn; a true report of work done three turns ago is not a phantom.
const PRIOR_TURN = new RegExp(
  String.raw`\b(earlier|previously|yesterday|last\s+(?:night|week|time|session|turn)|` +
  String.raw`before\s+(?:that|this)|at\s+the\s+time|back\s+then|already|` +
  String.raw`in\s+(?:a|the)\s+(?:previous|earlier)\s+turn|this\s+morning|just\s+wrote|` +
  String.raw`today|the\s+other\s+day)\b`,
  'i'
);

// An offer is conditional on a human and asserts nothing about this turn.
const OFFER = new RegExp(
  String.raw`(\bwant\s+me\s+to\b|\bshall\s+i\b|\bshould\s+i\b|\bhappy\s+to\b|\bglad\s+to\b|` +
  String.raw`\bi\s+can\b|\bwe\s+can\b|\blet\s+me\s+know\b|\bwould\s+you\s+like\b|` +
  String.raw`\bsay\s+the\s+word\b|\bsay\s+go\b|\byour\s+call\b|\bclosing\s+ask\b|\?\s*$)`,
  'i'
);

// Pins a future form to THIS turn.
// Pins a form to THIS turn. Deliberately SHORT. "first", "already" and "currently" were in an
// earlier version and were removed after a replay over real transcripts: they appear constantly
// in ordinary prose ("writing the plan to a file first so…") and turned the immediacy test into
// no test at all.
const IMMEDIACY = /\b(now|right\s+now|immediately|straight\s+away|as\s+we\s+speak|at\s+once|this\s+turn)\b/i;

// A completed-action claim about a tool takes a DIRECT OBJECT: "dispatched a worker", "ran the
// suite", "wrote the file". The same verbs followed by a preposition are almost always doing
// something else — an idiom ("committed to", "ran into"), a passive ("merged into main by"), or
// an adjectival participle ("filed under X"). Measured on real transcripts, this single test
// removed the largest single class of false positives.
const PARTICLE = /^\s*(to|into|out|on|off|over|up|with|as|for|from|by|at|through|past|against|around|back|about|under|in|than|before|after|down|away)\b/i;

// A subject-dropped claim is the house's ACTION style: a verb at the very start of a sentence
// with a noun phrase after it. Requiring the determiner is what separates "Dispatched a worker"
// from "Filed as the shape of the problem" and "Merged is not installed".
const OBJECT_HEAD = /^\s*(a|an|the|my|our|its|his|her|their|this|that|these|those|one|two|three|four|five|both|all|it|them|several|every|each|another|new|\d+)\b/i;

// Future / intent auxiliaries, matched immediately before a bare verb.
const FUTURE_AUX = /\b(?:i|we)?\s*(?:'ll|will|am\s+going\s+to|'m\s+going\s+to|going\s+to|about\s+to|let\s+me)\s*$/i;

// Progressive auxiliaries, matched immediately before an -ing verb.
const PROG_AUX = /\b(?:i|we)\s*(?:'m|'re|am|are)\s+(?:now\s+|just\s+|currently\s+)?$/i;

// Kills a claim regardless of tense: negation, hypotheticals, and reported speech.
const REJECT = new RegExp(
  String.raw`\b(not|nothing|none|never|nor|without|n't|failed\s+to|declined\s+to|skipped|refused\s+to|` +
  String.raw`would|could|should|might|may|must|unless|whether|suppose|instead\s+of|` +
  String.raw`said|says|reported|reports|claims|claimed|told|according|quoting|` +
  String.raw`asked|instructed|wants|needs?\s+to|plans?\s+to|intends?\s+to|meant\s+to)\b`,
  'i'
);

// Negation carried in the DIRECT OBJECT, which REJECT structurally cannot see: REJECT is only
// ever tested against text BEFORE the verb, so "I wrote nothing" and "I dispatched no one" put
// their negation out of its reach and graded as completions. That misgrades a confession as a
// fabrication, and a guard that flags honest self-reporting teaches the agent to stop
// self-reporting -- a worse failure than the one the guard exists for.
//
// DELIBERATELY MUCH NARROWER THAN REJECT, and the narrowness is the design. Testing the full
// REJECT alternation against the text after the verb would suppress true positives wholesale:
// "I wrote the file but did not commit" and "I ran the check and it should pass" both carry a
// REJECT token after a verb whose action genuinely happened. This matches only a negative head
// in the direct-object position, where negation can only be negating THIS verb.
//
// "no" requires a following space so "I ran no-op tests" stays a completion. "not" requires a
// determiner so a hyphenated "not-yet-reviewed" object stays a completion.
const NEG_OBJECT = new RegExp(
  String.raw`^\s*(?:\w+ly\s+)?(?:nothing|nobody|no[-\s]one|none|neither|zero\b|no\s+\w|` +
  String.raw`not\s+(?:a|an|any|one|yet|much)\b)`,
  'i'
);

// ANCHORED AT THE START OF THE CLAUSE, and that anchor is load-bearing. Unanchored, this also
// matched "something we wrote" and "the file the Claude leg wrote", where the pronoun heads a
// RELATIVE CLAUSE modifying a noun rather than a subject asserting an action. Measured on real
// transcripts, relative clauses were the second-largest false-positive class.
const FIRST_PERSON = /^\s*(?:\*\*)?(?:i|we)\s+(?:have\s+|had\s+|has\s+|just\s+|then\s+|also\s+|now\s+)*$/i;
// The house output contract puts a label on its own line above the statement it governs, and
// ACTION is the one label that asserts state changed — its receipt is the command and its exit
// code. Both real incidents were ACTION-labeled sentences. Tracking the governing label lets
// the BLOCK tier target the contract actually being violated, while ordinary retrospective
// prose (which is labeled CLAIM, GUESS or PMDW) only ever reaches the calibration log.
const LABEL_LINE = /^\s*\**\s*(CLAIM|CITE|GUESS|ACTION|PMDW|QUESTION)\s*\**\s*:?\s*$/i;

const LEADING_SCAFFOLD = /^(?:[-*+]\s+|\d+[.)]\s+|>\s*|#{1,6}\s+|\*\*[A-Za-z ]+\*\*[\s:.-]*|[A-Z]{3,}:\s*)+/;

/**
 * Strip everything that quotes, transcribes, or demonstrates rather than asserts: fenced code,
 * inline code spans, blockquotes, HTML comments, and quoted spans. A sentence inside any of
 * these is somebody else's words — a worker's report, a log line — not a claim by this turn.
 */
export function stripNonAssertive(text) {
  return String(text ?? '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/~~~[\s\S]*?~~~/g, ' ')
    .replace(/`[^`\n]*`/g, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/^[ \t]*>.*$/gm, ' ')
    .replace(/[“"][^”"\n]{0,400}[”"]/g, ' ')
    .replace(/[‘'][^’'\n]{8,400}[’']/g, ' ');
}

function sentences(text) {
  return text.split(/\n+|(?<=[.!?;])\s+/).map((s) => s.trim()).filter(Boolean);
}

/**
 * Classify every action assertion in a message.
 * Returns { claims, ambiguous } — `claims` are IN scope for this turn; `ambiguous` are bare
 * futures recorded for calibration and never acted on.
 */
export function findClaims(message) {
  const claims = [];
  const ambiguous = [];
  let prose;
  try { prose = stripNonAssertive(message); } catch { return { claims, ambiguous }; }
  const re = new RegExp(String.raw`\b(${ALTERNATION})\b`, 'gi');

  let label = null;
  for (const raw of sentences(prose)) {
    const lm = raw.match(LABEL_LINE);
    if (lm) { label = lm[1].toUpperCase(); continue; }
    const s = raw.replace(LEADING_SCAFFOLD, '');
    if (OFFER.test(s)) continue;              // conditional on a human: asserts nothing
    const deferred = DEFERRAL.test(s) || PRIOR_TURN.test(s);   // outside this turn either way

    re.lastIndex = 0;
    let m;
    while ((m = re.exec(s)) !== null) {
      const word = m[1].toLowerCase().replace(/\s+/g, ' ');
      const info = FORM.get(word);
      if (!info) continue;

      const before = s.slice(0, m.index);
      const after = s.slice(m.index + m[1].length);
      const clause = before
        .split(/[,;:]|\s+(?:and|but|so|because|which|that|while|when|after|before|then)\s+/i)
        .pop() ?? '';
      if (REJECT.test(clause) || REJECT.test(before)) continue;
      if (NEG_OBJECT.test(after)) continue;         // negation in the object: "wrote nothing"
      if (PARTICLE.test(after)) continue;              // idiom, passive, or participle

      // SUBJECT-DROPPED is the house ACTION style and it is the ONLY place a bare verb counts.
      // It must be at the very start of the SENTENCE — not merely at the start of a clause.
      // An earlier version tested the clause, and clause-splitting on "and"/"then" produced an
      // empty clause mid-sentence, so every "X spawned a child" read as subject-dropped.
      const dropped = m.index === 0 && OBJECT_HEAD.test(after);

      let kind = null;
      if (info.form === 'past') {
        if (dropped || FIRST_PERSON.test(clause)) kind = 'completed';
      } else if (info.form === 'ing') {
        // "I'm dispatching" asserts on its own. A sentence-initial gerund does not: fronting a
        // participle is an ordinary way to open a sentence in this house's prose, so it counts
        // only when an immediacy marker pins it to this turn.
        if (PROG_AUX.test(clause)) kind = 'in-flight';
        else if (dropped && IMMEDIACY.test(s)) kind = 'in-flight';
      } else if (info.form === 'base') {
        if (FUTURE_AUX.test(clause)) kind = IMMEDIACY.test(s) ? 'immediate' : 'ambiguous';
      }
      if (!kind) continue;

      const entry = { sentence: raw.slice(0, 240), verb: word, kind, label, tools: info.tools };
      if (deferred || kind === 'ambiguous') ambiguous.push({ ...entry, kind: deferred ? 'deferred' : 'ambiguous' });
      else claims.push(entry);
      break;                                  // one finding per sentence is enough
    }
  }
  return { claims, ambiguous };
}

/**
 * Grade the turn. `toolNames` is every tool called anywhere in the turn — existence, not order.
 * `toolsResolved` is false when the turn could not be located in the transcript at all.
 *
 *   'clean'         nothing to say
 *   'phantom-high'  claims present and the turn made ZERO tool calls. Blockable.
 *   'phantom-low'   claims present, tool calls present, none of a matching kind. Warn only.
 *   'unresolved'    the turn's tool calls could not be established. Never blockable.
 */
export function grade(message, toolNames, toolsResolved) {
  const text = String(message ?? '');
  if (text.trim() === '') {
    return { verdict: 'clean', claims: [], ambiguous: [], reason: 'no prose in this turn' };
  }
  const { claims, ambiguous } = findClaims(text);
  if (claims.length === 0) {
    return { verdict: 'clean', claims: [], ambiguous, reason: 'no in-turn action claims' };
  }
  if (!toolsResolved) {
    return { verdict: 'unresolved', claims, ambiguous, reason: 'turn not resolvable in transcript' };
  }
  const called = new Set(toolNames);
  if (called.size === 0) {
    // The BLOCK tier is narrower than "a claim with no calls". It requires the claim to sit
    // under an ACTION label — the one label whose whole meaning is that state changed, and the
    // label both real incidents carried. Everything else is recorded and allowed: a replay over
    // real transcripts showed unlabeled past-tense prose is overwhelmingly honest retrospection
    // about EARLIER turns, which this hook cannot see and must not judge.
    const actionClaims = claims.filter((c) => c.label === 'ACTION');
    if (actionClaims.length > 0) {
      return { verdict: 'phantom-high', claims: actionClaims, ambiguous,
               reason: 'an ACTION-labeled claim in a turn that contains no tool calls at all' };
    }
    return { verdict: 'phantom-low', claims, ambiguous,
             reason: 'unlabeled claim in a turn with no tool calls' };
  }
  const unmatched = claims.filter((c) => !c.tools.some((t) => called.has(t)));
  if (unmatched.length === 0) {
    return { verdict: 'clean', claims, ambiguous, reason: 'every claim has a matching call' };
  }
  return { verdict: 'phantom-low', claims: unmatched, ambiguous, reason: 'no tool of a matching kind was called' };
}

# Removing Lintel's hooks

**Four** hooks are registered in `/Users/jowolff/.claude/settings.json` (installed 2026-08-19):
`SessionStart -> savepoint-restore.sh`, `Stop -> savepoint-guard.mjs`,
`PreToolUse(Bash) -> staging-guard.mjs`, `UserPromptSubmit -> intake-capture.mjs`.
Two more files execute without being registered: `intake-sweep.mjs`, called by the Stop guard, and
`session-gate.mjs`, imported by the three `.mjs` hooks.

**Since 2026-08-19 14:24 all four are session-gated.** Each does nothing unless the `session_id` in
its payload equals the contents of `orchestrator/state/.session-id`, which `summon.sh` mints and
passes via `--session-id`. **Deleting that marker silently disarms every hook everywhere.** That is
the fail-closed direction and it is deliberate, but nothing announces it. Known gaps, unclosed: a
forked session (`--fork-session`) gets a new id and is unguarded with no warning; a quoted staging
flag and `eval` indirection still slip past the staging guard.

Pre-gate copies of every file are at `orchestrator/state/hook-backups-20260819-142447/`.

## Panic button — kills ALL hooks on the machine, instantly

Add `"disableAllHooks": true` at the top level of `settings.json`. It hot-reloads, so it takes
effect immediately including in sessions already running. It also disables the newdle plugin's
hooks and `herdr-agent-state.sh`, so it is a sledgehammer — but it is the one that always works.

## Restore the exact pre-install file

```
cp /Users/jowolff/.claude/settings.json.backup.20260819-115248-pre-lintel-hooks /Users/jowolff/.claude/settings.json
```

Byte-identical to before the install. Validated as JSON when taken.

## Or remove just these three, leaving everything else

```
zsh /Users/jowolff/.claude/orchestrator/hooks/uninstall.sh
```

## What was installed

| Event | Script | What it does | Can it block? |
| ----- | ------ | ------------ | ------------- |
| `SessionStart` (`*`) | `savepoint-restore.sh` | Prints STANDUP.md plus open obligations; the harness injects that into context | **No.** SessionStart cannot block |
| `Stop` | `savepoint-guard.mjs` | Refuses the turn ending while state files are newer than STANDUP.md | **Yes** — once per session, honours `stop_hook_active`, and Claude Code overrides any Stop hook after 8 consecutive blocks |
| `PreToolUse` (`Bash`) | `staging-guard.mjs` | Denies mass staging inside `~/.claude` only | **Yes** — that one tool call, nothing else |

The pre-existing `herdr-agent-state.sh` SessionStart hook was added alongside, not merged into, and
still runs.

## Known defect history, since it is short and relevant

The staging guard was installed with an **unanchored** pattern and immediately blocked the commit
that was writing this very file, because the file *mentions* the commands it blocks. Patterns are
now anchored to the start of a command segment, so prose is safe and commands are not. This was the
same match-inside-quoted-text flaw already documented in the plugin's `careful-guard` — found by me,
in my own hook, 90 seconds after installing it.

Every one of these hooks exits 0 on any internal error by construction and decides via stdout JSON
rather than exit codes. If a session behaves oddly, use the panic button first, then remove one at
a time.

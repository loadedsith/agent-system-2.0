#!/usr/bin/env node
/**
 * PreToolUse(Bash) — refuses a shell REDIRECT whose target resolves to state/REQUESTS.jsonl.
 *
 * ── WHAT HAPPENED ────────────────────────────────────────────────────────────────────────────
 * On 2026-08-26 Lintel appended a row to the request ledger by hand — raw JSON in a heredoc —
 * and got the `touches` field wrong. Three state checkers caught it at session stop and printed
 * fifteen lines of diagnostic into Jo's conversation window. Jo's words: "also do you know how
 * much i hate this? Ran 14 stop hooks".
 *
 * tools/request-append.sh already existed and exists for exactly this. Its own header documents
 * the earlier incident it was built for — fifteen rows written by hand on 2026-08-20 with the
 * request text under key `ask` instead of `request`, which still parsed, so the rows were
 * counted, listed by id, and blank. That header says: "Hand-writing JSON into a file nothing
 * validates is the defect."
 *
 * The writer was there. Nothing refused the bypass. That is the gap this file closes, and it is
 * the house principle applied to itself: name the line of code that refuses, or file it as a
 * rule and grade it as a rule.
 *
 * ── ⛔ WHAT THIS DOES **NOT** COVER, STATED HERE AND IN THE REFUSAL TEXT ───────────────────────
 * This covers REDIRECTS — a new row appended, or the file truncated. It does NOT cover in-place
 * rewriting of an existing row, and that is not a rounding error: measured 2026-08-26 across the
 * 62 local transcripts, of 653 Bash calls naming REQUESTS.jsonl and not also naming the inbox,
 * 67 went through the writer, 279 were reads, and 307 were direct writes — of which 305 were
 * python in-place rewrites and 2 were shell appends.
 *
 * So this guard covers 2 of 307 measured direct writes. That is a small numerator and it is the
 * honest one: the incident above IS one of the two, and the other 305 CANNOT be routed anywhere,
 * because request-append.sh can only ever append (tools/request-append.sh:152) and no writer on
 * this machine mutates an existing row. A refusal naming a remedy the caller cannot reach is
 * functionally a hang with better manners — already recorded on this machine — so the uncovered
 * case is declared rather than half-caught. A narrow guard that states its own scope is a
 * different object from one that lets the reader assume coverage it does not have.
 *
 * Filed separately: build a writer that can mutate a row, then widen this.
 *
 * ── WHY A LEXER AND NOT A TEXT MATCH ─────────────────────────────────────────────────────────
 * The obvious build is a deny on command text containing the ledger path near a `>>`. It
 * satisfies the acceptance criterion word for word and makes the system worse. It would deny
 * the brief that commissioned it, deny a decision-log entry quoting the incident, deny an
 * ordinary grep, deny request-append.sh itself when invoked with an explicit --ledger, and be
 * evaded by putting the path in a variable — which is what 305 of the 307 real writes already
 * do. This machine has NINE recorded instances of a quote-blind matcher refusing a document for
 * describing the thing it forbids, one of them a decision-log entry refused for quoting its own
 * refusal message.
 *
 * So this reads OPERATIONS out of the command via ./shell-lex.mjs — the lexer staging-guard.mjs
 * already shipped and had already hardened against five quoting bypasses and four flag
 * abbreviations. Heredoc bodies are DROPPED, which is precisely the property that makes this
 * fire on the act and not on a document describing the act.
 *
 * ── WHY request-append.sh IS NOT SPECIAL-CASED ───────────────────────────────────────────────
 * It needs no exemption and has none. Its own append happens INSIDE the script, in a subprocess
 * this hook never sees; the hook inspects only the outer tool call. A special case would be a
 * second thing to keep in sync, so there isn't one. The self-test asserts this rather than
 * assuming it.
 *
 * ── HOW YOU KNOW IT EVER FIRED, AND THAT IT DID NOT FIRE ON SOMETHING LEGITIMATE ──────────────
 * Every decision is logged, ALLOW AS WELL AS DENY, with the resolved target and the rule that
 * matched. A deny-only log cannot answer the second question, because the allows are the only
 * evidence the guard is not refusing everything. Three degenerate states, all invisible in a
 * deny-only log, all distinguishable here:
 *
 *   considered = 0                 it is registered but has never seen a ledger-touching command
 *   deny > 0, allow = 0            it refuses everything it sees
 *   allow > 0, deny = 0            it is inert -- check the window against a known hand-write
 *
 * ⛔ THE ONE THING THE LOG CANNOT TELL YOU IS THAT THE HOOK IS NOT REGISTERED AT ALL, because a
 * log cannot record its own absence. That is what --selftest is for, and why it carries BOTH
 * poles: a canonical hand-written append must DENY, and request-append.sh --dry-run must ALLOW.
 * Either one failing means the guard is not measuring, not that the world is clean.
 *
 * ── ESCAPE HATCH ─────────────────────────────────────────────────────────────────────────────
 * Prefix the command with LEDGER_DIRECT_WRITE='why' and it is allowed and logged with the reason
 * verbatim next to the command it permitted. No reason, no bypass. Deliberate and visible, which
 * is the point: an emergency repair should be possible and should leave a mark.
 *
 * ⛔ GRADED HONESTLY, because the same distinction bit the done-when refusal: requiring the FIELD
 * is a mechanism, requiring it to be MEANINGFUL is a rule. LEDGER_DIRECT_WRITE=x passes. The
 * mechanism buys deliberateness and a record, not good judgement, and it is not sold as more.
 *
 * Always exits 0. Decides via stdout JSON, per the eval contract.
 */
import { readFileSync, appendFileSync, mkdirSync } from 'node:fs';
import { join, dirname, sep } from 'node:path';
import { homedir } from 'node:os';
import { inOrchestratorSession } from './session-gate.mjs';
import { lex, makeNorm, redirection } from './shell-lex.mjs';

const HOME = homedir();
const norm = makeNorm(HOME);

// ONE reading of decide()'s return value, used by the hook AND by --selftest. These must never
// be two expressions: an earlier build had the self-test treat any truthy return as a denial, so
// the escape hatch -- which is an ALLOW -- registered as a failing pole. Calling the same
// function and then disagreeing about what its answer MEANS is the same defect as testing a
// parallel implementation, wearing a shape that looks like sharing code.
const isDeny = (v) => !!v && v.rule !== 'escape-hatch';

const allow = () => process.exit(0);
const deny = (reason) => {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason,
    },
  }));
  process.exit(0);
};

const STATE = process.env.LINTEL_STATE || join(HOME, '.claude', 'orchestrator', 'state');
const LEDGER = norm(process.env.LEDGER_GUARD_TARGET || join(STATE, 'REQUESTS.jsonl'), HOME);
const LOG = process.env.LEDGER_GUARD_LOG || join(STATE, 'ledger-write-guard.jsonl');
const WRITER = join(HOME, '.claude', 'orchestrator', 'tools', 'request-append.sh');

function record(row) {
  try {
    mkdirSync(dirname(LOG), { recursive: true });
    appendFileSync(LOG, JSON.stringify({ at: new Date().toISOString(), ...row }) + '\n');
  } catch { /* a guard that cannot log still guards; it must never crash the tool call */ }
}

// ── SELF-TEST ────────────────────────────────────────────────────────────────────────────────
// Both poles, because one pole cannot fail informatively. Run: node ledger-write-guard.mjs --selftest
if (process.argv.includes('--selftest')) {
  const cases = [
    // [expect, cwd, command, why this case exists]
    ['DENY',  '/Users/jowolff/.claude/orchestrator/state',
     "cat >> REQUESTS.jsonl <<'EOF'\n{\"id\":\"REQ-999\"}\nEOF",
     'the incident shape: a hand-written heredoc append, relative path'],
    ['DENY',  '/Users/jowolff/.claude',
     'printf "%s\\n" "$ROW" >> orchestrator/state/REQUESTS.jsonl',
     'same operation reached by a longer relative path'],
    ['DENY',  '/tmp',
     'echo x >> ' + join(HOME, '.claude', 'orchestrator', 'state', 'REQUESTS.jsonl'),
     'absolute path from an unrelated directory'],
    ['DENY',  '/Users/jowolff/.claude',
     'cd orchestrator/state && cat >> REQUESTS.jsonl <<EOF\nrow\nEOF',
     'cd carried forward, which a text match cannot resolve'],
    ['DENY',  '/Users/jowolff/.claude/orchestrator/state',
     'echo x | tee -a REQUESTS.jsonl',
     'tee -a is an append by another name'],
    ['DENY',  '/Users/jowolff/.claude/orchestrator/state',
     'echo x > REQUESTS.jsonl',
     'truncation destroys the whole ledger and is the same redirect shape'],

    ['ALLOW', '/Users/jowolff/.claude',
     WRITER + ' --request "a thing" --state open --dry-run',
     'THE OTHER POLE: the writer must pass, and needs no special case to do so'],
    ['ALLOW', '/Users/jowolff/.claude/orchestrator/state',
     'grep -c REQ- REQUESTS.jsonl',
     'reading the ledger is not writing it'],
    ['ALLOW', '/Users/jowolff/.claude/orchestrator/state',
     "python3 -c \"import json; print(len(open('REQUESTS.jsonl').read()))\"",
     'a read whose command text names the file'],
    ['ALLOW', '/Users/jowolff/.claude',
     "cat >> notes.md <<'EOF'\nDo not do: cat >> REQUESTS.jsonl <<EOF\nEOF",
     'A DOCUMENT DESCRIBING THE FORBIDDEN COMMAND. This is the case a text matcher fails.'],
    ['ALLOW', '/Users/jowolff/.claude/orchestrator/state',
     'cat >> REQUESTS-INBOX.jsonl <<EOF\nrow\nEOF',
     'a DIFFERENT ledger whose name contains this one as a substring'],
    ['ALLOW', '/Users/jowolff/.claude/orchestrator/state',
     'cp REQUESTS.jsonl REQUESTS.jsonl.bak',
     'taking a backup is not a write to the ledger'],
    ['ALLOW', '/Users/jowolff/.claude/orchestrator/state',
     "LEDGER_DIRECT_WRITE='emergency repair, REQ-999 malformed' cat >> REQUESTS.jsonl <<EOF\nrow\nEOF",
     'the escape hatch, with a reason'],
    ['DENY',  '/Users/jowolff/.claude/orchestrator/state',
     "LEDGER_DIRECT_WRITE= cat >> REQUESTS.jsonl <<EOF\nrow\nEOF",
     'the escape hatch with an EMPTY reason is not an escape hatch'],
  ];
  let pass = 0, fail = 0;
  for (const [expect, cwd, command, why] of cases) {
    const got = isDeny(decide(command, cwd)) ? 'DENY' : 'ALLOW';
    const ok = got === expect;
    ok ? pass++ : fail++;
    console.log(`  ${ok ? 'PASS' : 'FAIL'} want=${expect} got=${got}  ${why}`);
    if (!ok) console.log(`       command: ${command.replace(/\n/g, '\\n')}`);
  }
  console.log(`\npass=${pass} fail=${fail}`);
  console.log(fail === 0
    ? 'Both poles hold: the incident shape is refused and the writer is not.'
    : 'THE GUARD IS NOT MEASURING. A failing pole means its verdicts mean nothing.');
  process.exit(fail === 0 ? 0 : 1);
}

/**
 * The whole decision, factored out so --selftest exercises the SAME code path the hook runs
 * rather than a re-implementation of it. A self-test against a parallel implementation tests
 * the parallel implementation.
 *
 * Returns null to allow, or a { rule, target, spelling, mode } to deny.
 */
function decide(cmd, cwd) {
  // Cheap prefilter. Note this is a filter, never the decision: it only narrows what gets lexed.
  if (!cmd.includes('REQUESTS.jsonl')) return null;

  let dir = norm(String(cwd ?? HOME), HOME);
  for (const words of lex(cmd)) {
    if (words[0] === 'cd' || words[0] === 'pushd') {
      dir = words[1] ? norm(words[1], dir) : HOME;
      continue;
    }
    const r = redirection(words);
    if (!r) continue;
    if (norm(r.target, dir) !== LEDGER) continue;

    // The escape hatch is read from the SAME segment as the redirect, so a reason attached to an
    // unrelated earlier command in the chain does not license this one.
    const hatch = words
      .map((w) => /^LEDGER_DIRECT_WRITE=([\s\S]*)$/.exec(w))
      .find(Boolean);
    if (hatch && hatch[1].trim() !== '') {
      return { rule: 'escape-hatch', target: LEDGER, spelling: r.spelling, mode: r.mode, reason: hatch[1].trim() };
    }
    return { rule: r.mode === 'append' ? 'direct-append' : 'direct-truncate',
             target: LEDGER, spelling: r.spelling, mode: r.mode };
  }
  return null;
}

// ── HOOK ─────────────────────────────────────────────────────────────────────────────────────
let p = {};
try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { allow(); }
if (p.tool_name !== 'Bash') allow();
if (!inOrchestratorSession(p, STATE)) allow();

const cmd = String(p.tool_input?.command ?? '');
if (!cmd) allow();
// Only ledger-touching commands are considered, and every considered command is logged whichever
// way it goes. Logging every Bash call on the machine would be noise; logging only denials would
// make "refuses everything" and "working correctly" identical in the record.
if (!cmd.includes('REQUESTS.jsonl')) allow();

const excerpt = cmd.replace(/\s+/g, ' ').slice(0, 300);
const verdict = decide(cmd, p.cwd);

if (!verdict) {
  record({ decision: 'allow', rule: 'no-redirect-to-ledger', session: p.session_id, cmd: excerpt });
  allow();
}

if (verdict.rule === 'escape-hatch') {
  record({ decision: 'allow', rule: 'escape-hatch', reason: verdict.reason,
           target: verdict.target, mode: verdict.mode, session: p.session_id, cmd: excerpt });
  allow();
}

record({ decision: 'deny', rule: verdict.rule, target: verdict.target,
         spelling: verdict.spelling, mode: verdict.mode, session: p.session_id, cmd: excerpt });

const isAppend = verdict.mode === 'append';
deny(
  `Direct ${isAppend ? 'append to' : 'overwrite of'} the request ledger is blocked.\n\n` +
  `Resolved target: ${verdict.target}\n` +
  `Matched: a shell redirect (${verdict.spelling}) whose target resolves to the ledger.\n\n` +
  `WHY: on 2026-08-26 a row went in by hand with a malformed \`touches\` field, and three state ` +
  `checkers caught it at session stop and printed fifteen lines of diagnostic into Jo's window. ` +
  `An earlier hand-written batch put the request text under the key \`ask\` instead of ` +
  `\`request\`; it still parsed, so fifteen rows were counted, listed by id, and blank. Nothing ` +
  `validates raw JSON written straight into this file.\n\n` +
  (isAppend
    ? `USE THE WRITER. It takes the fields as arguments, builds the JSON itself, and validates ` +
      `the candidate row through the same checker that validates the whole file:\n\n` +
      `  ${WRITER} --request "..." --state open [--note "..."] [--touch TYPE=TEXT]\n\n` +
      `Add --dry-run to see the row without writing it. It picks the next REQ id and the ` +
      `timestamp for you.\n\n`
    : `There is no supported way to truncate this ledger from a tool call. If you meant to ` +
      `rewrite it, take a copy first and say what you are doing.\n\n`) +
  `⛔ SCOPE, SO YOU DO NOT READ COVERAGE INTO THIS THAT IS NOT THERE: this guard sees shell ` +
  `redirects only. It does NOT catch in-place rewriting of an existing row — the python ` +
  `read-modify-write shape — which is the majority of real direct writes here and which no ` +
  `writer on this machine can perform. If that is what you are doing, this guard will not stop ` +
  `you and has not checked you.\n\n` +
  `If a direct write is genuinely correct — an emergency repair — say why, in the command:\n` +
  `  LEDGER_DIRECT_WRITE='what you are repairing and why' <your command>\n` +
  `That is allowed and logged with your reason next to it at ${LOG}.`
);

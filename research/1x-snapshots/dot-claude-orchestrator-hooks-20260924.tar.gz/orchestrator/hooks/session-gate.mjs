/**
 * SESSION GATE — the one thing that decides whether any of these hooks is allowed to act.
 *
 * The defect it exists for: all four hooks are registered with universal matchers in
 * ~/.claude/settings.json, so they fire in EVERY Claude Code session on this machine. A Stop
 * guard that instructs an unrelated session in another repo to rewrite the orchestrator's
 * STANDUP.md is not a guard, it is a bug with authority.
 *
 * MECHANISM, chosen by measurement rather than by taste (see RESULTS.md in this lab):
 *   summon.sh mints a UUID, writes it to <state>/.session-id, and launches
 *   `claude --agent orchestrator --session-id <that uuid>`. Every hook payload in that session
 *   then carries session_id == that uuid. No other session can.
 *
 * Why not the alternatives, all three tested:
 *   - an env var exported by summon.sh IS inherited by hook processes (measured), but it is also
 *     inherited by every nested `claude -p` a subagent launches from inside that session. That
 *     nested session is NOT the orchestrator and would be gated OPEN. Fails open. Rejected.
 *   - payload `agent_type` is present and equals 'orchestrator' when launched with --agent
 *     (measured), but a SUBAGENT's tool call carries the SUBAGENT's type ('general-purpose'),
 *     so gating on it would silently stop guarding subagent commands in the orchestrator's own
 *     session. Loses coverage that exists today. Rejected.
 *   - session_id is carried by every event, is identical for subagent tool calls, and is fresh
 *     for every nested session. It is the only candidate that both keeps today's coverage and
 *     closes the leak.
 *
 * FAILS CLOSED. Missing marker, unreadable marker, empty marker, missing session_id -> false.
 * A gate that fails open in an unrelated session is worse than no gate, because it is trusted.
 */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

export function stateDir() {
  return process.env.LINTEL_STATE || join(homedir(), '.claude', 'orchestrator', 'state');
}

export function inOrchestratorSession(payload, state = stateDir()) {
  try {
    const want = readFileSync(join(state, '.session-id'), 'utf8').trim();
    const got = String(payload?.session_id ?? '').trim();
    return want.length > 0 && got.length > 0 && want === got;
  } catch {
    return false;                        // no marker, no permission to act
  }
}

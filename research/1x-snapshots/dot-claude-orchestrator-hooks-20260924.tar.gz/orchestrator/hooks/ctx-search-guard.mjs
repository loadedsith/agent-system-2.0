#!/usr/bin/env node
/**
 * PreToolUse(Agent|Task) — refuses a hand dispatch whose prompt carries no ctx line: no record
 * that the dispatcher searched agent history (ctx) before writing the brief.
 *
 * ── WHAT HAPPENED ────────────────────────────────────────────────────────────────────────────
 * ctx (agent-history search) is installed as a skill and an MCP server and is used almost never.
 * REQ-437's note records zero skill-route calls across 67 sessions, and REQ-411's records 82
 * dispatches before Lintel's first ctx call. Both are ledger figures relayed through the REQ-411
 * design report (tinker-wake-20260910-reports/ctx-req411--hand-report.md), not measured here.
 * A described skill is a rule; this is the machinery: a line of code that refuses.
 *
 * ── WHY IT REFUSES INSTEAD OF INJECTING ──────────────────────────────────────────────────────
 * Same seam and same limit as brief-clause-guard.mjs: PreToolUse additionalContext lands in the
 * CALLING session, never in the subagent's prompt, and nothing here rewrites tool input. So the
 * only mechanism at this seam is a refusal. It also means the actor this gate can change is the
 * DISPATCHER (it must search before briefing), not the hand.
 *
 * ── WHAT IT ACCEPTS ──────────────────────────────────────────────────────────────────────────
 * One line in the prompt, ON ITS OWN LINE (list, quote and bold prefixes allowed):
 *
 *   ctx: <query> -> <event or session id>   a citation
 *   ctx: searched, no hits                  REQUIRED to be acceptable while ctx search is
 *                                           keyword-only (semantic generation broken, REQ-437).
 *                                           Refusing it would teach briefs to invent citations.
 *   CTX_OMITTED: <reason>                   allowed and logged with the reason verbatim
 *
 * Line-anchored on purpose: a brief that merely MENTIONS "ctx: searched, no hits" mid-sentence
 * (a brief about this guard, say) has declared nothing. Same defect class as the staging guard
 * matching its own name in prose (evals: staging-prose-mentioning-command-allowed).
 *
 * ⛔ GRADED HONESTLY: requiring the FIELD is a mechanism, requiring it to be TRUE is a rule.
 * `ctx: anything` passes as a citation. Template placeholders (`ctx: <query> -> <id>`) and bare
 * non-answers (`ctx: none`, `n/a`) are refused, and that is the whole of the content check. The
 * log is how invented citations get found: a `citation` row with no mcp__ctx__ call before it in
 * the dispatcher's transcript.
 *
 * ── SCOPE ────────────────────────────────────────────────────────────────────────────────────
 * Agent and Task only. SendMessage follow-ups to a running hand are NOT gated: they continue a
 * brief that already passed, and gating them would tax every course correction.
 *
 * Dispatches are gated when cwd is one of ROOTS or below it. Jo, 2026-09-10, relayed by Lintel:
 * "i want seats dispatching from their own repos to be covered". Default roots: ~/.claude,
 * ~/code/shipyard (every repo under it, and their .claude/worktrees/), ~/code/joseph-gordon-levitt,
 * ~/agent-scratch (seat worktrees). Override with CTX_GUARD_ROOTS (colon-separated) for tests.
 * Round 3: outside ~/.claude (CTX_GUARD_UNCONDITIONAL) only a session with a non-blank
 * MARCHES_SEAT is gated; inside ~/.claude every dispatch is. See SEAT MARKER below.
 *
 * newdle-mobile is OUT, always, and the exclusion wins over every root. Two rules, because one is
 * not enough: (1) cwd at or under any EXCLUDES path (default ~/code/newdle-mobile; override with
 * CTX_GUARD_EXCLUDES), and (2) cwd containing ANY path segment that starts with "newdle-mobile",
 * which is not overridable. Rule 2 exists because a newdle-mobile directory sits INSIDE the
 * shipyard root (~/code/shipyard/newdle-mobile, seen with `ls` 2026-09-10), and a worktree of it
 * can land under ~/agent-scratch; rule 1 alone would gate both.
 *
 * Root match is path-segment exact: the root itself or root + "/". ~/.claude-x and
 * ~/code/shipyard-old are OUT. (brief-clause-guard.mjs uses a bare startsWith and has this bug.)
 *
 * ── FAILS OPEN ───────────────────────────────────────────────────────────────────────────────
 * Garbage stdin, a non-object payload, any exception: ALLOW. A broken guard must never become a
 * machine that refuses all delegation. Unlike brief-clause-guard, this one has no source file to
 * lose, so it cannot go quiet by a rename; every considered dispatch is logged, allow and deny.
 *
 * ── ONE LOG, WHEREVER THE DISPATCH CAME FROM ─────────────────────────────────────────────────
 * The log path is fixed and never derived from the matched root (brief-clause-guard.mjs derives
 * its state dir from its root, so widening it would move its log). Each row records which root
 * matched, so the one log still says where every dispatch came from.
 *
 * Always exits 0. Emits stdout JSON only on deny; nothing at all on allow.
 */
import { readFileSync, appendFileSync, mkdirSync } from 'node:fs';
import { join, dirname, normalize } from 'node:path';
import { homedir } from 'node:os';

const HOME = homedir();
const STATE = process.env.LINTEL_STATE || join(HOME, '.claude', 'orchestrator', 'state');
const LOG = process.env.CTX_GUARD_LOG || join(STATE, 'ctx-search-guard.jsonl');

const list = (v) => String(v).split(':').map((s) => s.trim().replace(/\/+$/, '')).filter(Boolean);
const ROOTS = process.env.CTX_GUARD_ROOTS ? list(process.env.CTX_GUARD_ROOTS) : [
  join(HOME, '.claude'),
  join(HOME, 'code', 'shipyard'),
  join(HOME, 'code', 'joseph-gordon-levitt'),
  join(HOME, 'agent-scratch'),
];
const EXCLUDES = process.env.CTX_GUARD_EXCLUDES ? list(process.env.CTX_GUARD_EXCLUDES)
  : [join(HOME, 'code', 'newdle-mobile')];
const EXCLUDED_SEGMENT = /^newdle-mobile/;

// SEAT MARKER (round 3). Lintel's decision from Jo's words "seats dispatching from their own
// repos": outside UNCONDITIONAL roots the gate applies only to a session carrying MARCHES_SEAT,
// which each seat launcher passes through `--settings` env. Jo's own interactive sessions carry
// none and stay ungated there. Inside ~/.claude the gate stays unconditional, so Lintel, the named
// ctx dispatcher, is gated with or without the marker. Exclusions still win over everything.
const SEAT = String(process.env.MARCHES_SEAT ?? '').trim();
const UNCONDITIONAL = process.env.CTX_GUARD_UNCONDITIONAL ? list(process.env.CTX_GUARD_UNCONDITIONAL)
  : [join(HOME, '.claude')];

const under = (cwd, r) => cwd === r || cwd.startsWith(r + '/');
/** The matched root, or null when the dispatch is out of scope. Exclusion is checked first. */
function scopeOf(cwd) {
  if (EXCLUDES.some((x) => under(cwd, x))) return null;
  if (cwd.split('/').some((seg) => EXCLUDED_SEGMENT.test(seg))) return null;
  return ROOTS.find((r) => under(cwd, r)) || null;
}

function record(row) {
  try {
    mkdirSync(dirname(LOG), { recursive: true });
    appendFileSync(LOG, JSON.stringify({ at: new Date().toISOString(), ...row }) + '\n');
  } catch { /* a guard that cannot log still guards */ }
}
const allow = () => process.exit(0);
const deny = (reason) => {
  process.stdout.write(JSON.stringify({ hookSpecificOutput: {
    hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: reason } }));
  process.exit(0);
};

// Line start, then optional list/quote marker, then optional bold/italic run.
const PRE = String.raw`^[ \t]*(?:[-*+>][ \t]*)?(?:\*\*|__|\*|_)?`;
const CTX_LINE = new RegExp(PRE + String.raw`ctx(?:\*\*|__|\*|_)?[ \t]*:(?:\*\*|__|\*|_)?[ \t]*(.*)$`, 'gim');
const OMIT_LINE = new RegExp(PRE + String.raw`CTX_OMITTED(?:\*\*|__|\*|_)?[ \t]*:(?:\*\*|__|\*|_)?[ \t]*(.*)$`, 'gim');

const clean = (s) => String(s).replace(/<[^>]*>/g, '').replace(/[`*_"'\s]+/g, ' ').trim();
const substantive = (s) => /[a-z0-9]/i.test(clean(s));
const NON_ANSWER = /^(none|nothing|n\/?a|na|no|skip|skipped|tbd|todo|-+)\.?$/i;
const NO_HITS = /^searched,?\s*no\s+hits\b/i;

/** Returns { decision, rule, detail }. Pure, so --selftest runs the same path the hook runs. */
function decide(prompt) {
  const text = String(prompt || '');
  const ctx = [...text.matchAll(CTX_LINE)].map((m) => m[1]);
  const omit = [...text.matchAll(OMIT_LINE)].map((m) => m[1]);
  const usable = ctx.filter((v) => substantive(v) && !NON_ANSWER.test(clean(v)));
  const cite = usable.find((v) => !NO_HITS.test(clean(v)));
  // detail is logged as written (trimmed, capped), not cleaned: the reason is recorded verbatim.
  if (cite) return { decision: 'allow', rule: 'citation', detail: cite.trim().slice(0, 200) };
  if (usable.length) return { decision: 'allow', rule: 'no-hits', detail: usable[0].trim().slice(0, 200) };
  const why = omit.find(substantive);
  if (why) return { decision: 'allow', rule: 'omitted', detail: why.trim().slice(0, 300) };
  if (omit.length) return { decision: 'deny', rule: 'omitted-no-reason' };
  if (ctx.length) return { decision: 'deny', rule: 'ctx-line-empty' };
  return { decision: 'deny', rule: 'no-ctx-line' };
}

const FIRST = {
  'no-ctx-line': 'This brief has no ctx line.',
  'ctx-line-empty': 'This brief\'s ctx line is empty, a placeholder, or a non-answer.',
  'omitted-no-reason': 'CTX_OMITTED needs a reason after the colon.',
};
const refusal = (rule) =>
  `ctx-search-guard: ${FIRST[rule]} Search agent history before briefing a hand ` +
  `(mcp__ctx__search; it is keyword-only right now, so use exact terms), then add ONE of these ` +
  `to the prompt, on its own line:\n` +
  `  ctx: <query> -> <event or session id you used>\n` +
  `  ctx: searched, no hits\n` +
  `  CTX_OMITTED: <why no search fits this dispatch>\n` +
  `Never invent a citation; "searched, no hits" is always accepted. Logged at ${LOG}.`;

if (process.argv.includes('--selftest')) {
  const cases = [
    ['deny', 'Find where the login form is validated.', 'bare brief'],
    ['allow', 'Do X.\n\nctx: "login validation" -> evt_01J9ZX', 'citation'],
    ['allow', 'Do X.\n- **ctx:** searched, no hits', 'no hits, bulleted and bold'],
    ['allow', 'Do X.\nCTX_OMITTED: one-line existence check', 'omitted with reason'],
    ['deny', 'Do X.\nCTX_OMITTED:   ', 'omitted, empty reason'],
    ['deny', 'Do X.\nCTX_OMITTED: <reason>', 'omitted, placeholder reason'],
    ['deny', 'Do X. The gate accepts `ctx: searched, no hits` as a line.', 'prose mention only'],
    ['deny', 'Do X.\nctx: <query> -> <event or session id you used>', 'pasted template'],
    ['deny', 'Do X.\nctx: n/a', 'non-answer'],
    ['deny', 'Do X.\nBRIEF_CLAUSES_OMITTED: quick check', 'the other guard\'s hatch is not this one'],
  ];
  let fail = 0;
  for (const [want, p, why] of cases) {
    const got = decide(p).decision;
    if (got !== want) fail++;
    console.log(`  ${got === want ? 'PASS' : 'FAIL'} want=${want} got=${got}  ${why}`);
  }
  console.log(`fail=${fail}`);
  process.exit(fail ? 1 : 0);
}

try {
  let p;
  try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { record({ decision: 'allow', rule: 'unparseable-stdin' }); allow(); }
  if (p === null || typeof p !== 'object') allow();
  const tool = String(p.tool_name ?? '');
  if (tool !== 'Agent' && tool !== 'Task') allow();
  const raw = String(p.cwd ?? '');
  if (!raw.startsWith('/')) allow();                 // no absolute cwd: cannot place it, fail open
  const cwd = normalize(raw).replace(/\/+$/, '') || '/';
  const root = scopeOf(cwd);
  if (!root) allow();
  // Outside the unconditional roots only a marked seat is gated. Unlogged, like out-of-scope.
  if (!SEAT && !UNCONDITIONAL.some((u) => under(cwd, u))) allow();

  const label = String(p.tool_input?.subagent_type ?? p.tool_input?.description ?? '');
  const v = decide(p.tool_input?.prompt);
  record({ decision: v.decision, rule: v.rule, ...(v.detail ? { detail: v.detail } : {}),
           root, seat: SEAT || null, session: p.session_id, tool, label });
  if (v.decision === 'allow') allow();
  deny(refusal(v.rule));
} catch {
  allow();   // fail open on any plumbing error
}

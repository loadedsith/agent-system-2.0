#!/bin/sh
# SessionStart hook — the AUTOMATIC READ half. JSON-RETURN CANDIDATE, NOT REGISTERED ANYWHERE.
#
# DIFFERENCE FROM THE LIVE HOOK (/Users/jowolff/.claude/orchestrator/hooks/savepoint-restore.sh):
# the document is built identically, but instead of going to stdout as bare text it is returned as
# JSON hookSpecificOutput.additionalContext. Gates, ordering, wording and byte-cut logic are
# unchanged. Only the final delivery step differs.
#
# FAILS OPEN: any error exits 0 with no output. A restore hook must never block a session start.
# The JSON form adds one new failure mode the plain form did not have — MALFORMED JSON — so the
# encoder builds the whole string in memory and writes it in a single call, and any encoder
# failure exits 0 having written nothing.
#
# KNOWN BEHAVIOUR CHANGE, DELIBERATELY NOT SOLVED HERE: the truncation warning below
# ("STANDUP TRUNCATED") is part of the document, so under this form it goes into the model's
# context instead of onto Jo's screen. Jo stops seeing it. That is a decision for Jo, not a bug
# to paper over in this file.
set -u
STATE="${LINTEL_STATE:-/Users/jowolff/.claude/orchestrator/state}"
[ -d "$STATE" ] || exit 0

# SESSION GATE. Without it this injects up to 6000 bytes of the orchestrator's standup into
# every session on this machine. Fails closed: no marker, no match, no output. See session-gate.mjs.
# (stdin is the hook payload, read ONCE into $PAYLOAD because the subagent gate below needs it
# too; python3 is already a dependency of this hook, and any failure leaves SID empty, which
# closes the gate)
PAYLOAD=$(cat 2>/dev/null)
SID=$(printf '%s' "$PAYLOAD" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("session_id",""))' 2>/dev/null)
WANT=$(cat "$STATE/.session-id" 2>/dev/null | tr -d '[:space:]')
[ -n "$WANT" ] && [ "$SID" = "$WANT" ] || exit 0

# SUBAGENT GATE. The session gate above is not enough. When a SUBAGENT compacts, the harness
# fires SessionStart with source=compact carrying the PARENT's session_id, the PARENT's
# transcript_path, no agent_id, and a payload byte-for-byte the same shape as a top-level
# compaction — but it routes the STDOUT to the conversation that actually compacted. So the
# orchestrator's private save point was landing inside whichever worker happened to compact.
# Measured 2026-08-21; see reports/build-injection-fix--*.md under this run directory.
#
# Nothing in the payload can tell the two apart, so this reads the filesystem instead. When the
# TOP-LEVEL session compacts, the harness writes the summary rows into its own transcript file
# immediately before this hook runs: measured mtime age 0.05-0.43s across SEVEN top-level
# compactions. When a SUBAGENT compacts, the parent's transcript has not been touched for the
# whole compaction: 60.5-245s across NINE subagent compactions. All 16 classify correctly.
# Refusal therefore requires BOTH a
# parent transcript that is stale AND a subagent transcript for this session that is recent
# enough to belong to a live worker.
#
# DIRECTION OF FAILURE IS DELIBERATE. A false refusal costs the orchestrator its save point at
# the moment it needs it most; a false acceptance only leaks the standup into a worker. So every
# error path FIRES — unparsable payload, missing transcript, unreadable directory — and so does
# every ambiguous one. The 5s freshness bound sits 12x above the largest measured top-level value
# (0.43s) and 12x below the smallest measured subagent value (60.5s), so it keeps "the parent
# compacted" answer safe, at the cost of leaking when a busy parent happens to have been
# written within 5s of a worker's compaction.
WHO=$(SAVEPOINT_PAYLOAD="$PAYLOAD" python3 - <<'SUBGATE' 2>/dev/null
import glob, json, os, sys, time

PARENT_FRESH = 5.0    # seconds: a top-level compaction writes the parent transcript just before this
SUB_LIVE = 600.0      # seconds: a subagent transcript older than this is not a live worker


def fire():
    # print nothing -> the caller injects
    sys.exit(0)


try:
    p = json.loads(os.environ.get("SAVEPOINT_PAYLOAD") or "{}")
except Exception:
    fire()
if not isinstance(p, dict) or p.get("source") != "compact":
    fire()

tp = p.get("transcript_path")
sid = p.get("session_id")
if not isinstance(tp, str) or not tp or not isinstance(sid, str) or not sid:
    fire()

try:
    parent_age = time.time() - os.path.getmtime(tp)
except Exception:
    fire()
if parent_age <= PARENT_FRESH:
    fire()  # the parent's own transcript just took this compaction

try:
    subs = glob.glob(os.path.join(os.path.dirname(tp), sid, "subagents", "*.jsonl"))
except Exception:
    fire()

now = time.time()
for f in subs:
    try:
        if now - os.path.getmtime(f) <= SUB_LIVE:
            print("subagent")
            break
    except Exception:
        continue
SUBGATE
) || WHO=""
[ "${WHO:-}" = "subagent" ] && exit 0

# ---------------------------------------------------------------------------
# THE DOCUMENT. Byte-for-byte the same text the live hook prints; the only change is that it is
# produced inside a function so it can be captured instead of written straight to stdout.
# ---------------------------------------------------------------------------
emit_doc() {
printf '=== SAVE POINT (injected by savepoint-restore, not read by choice) ===\n\n'

if [ -f "$STATE/STANDUP.md" ]; then
  printf -- '--- STANDUP.md (last written: %s) ---\n' "$(date -r "$STATE/STANDUP.md" '+%Y-%m-%d %H:%M' 2>/dev/null || echo unknown)"
  # BYTE CUT, ANNOUNCED. This used to be a bare `head -c 6000`: anything past the cut vanished
  # with nothing said, so the next session acted on half a save point and could not tell.
  # Two changes, both small: cut at the last `## ` section boundary at or before the limit so the
  # injected text ends on a whole section, and print a banner naming the exact bytes not shown.
LIMIT=26000
  BYTES=$(wc -c < "$STATE/STANDUP.md" | tr -d ' ')
  if [ "$BYTES" -le "$LIMIT" ]; then
    cat "$STATE/STANDUP.md"
    printf '\n'
  else
    CUT=$(head -c "$LIMIT" "$STATE/STANDUP.md" | LC_ALL=C grep -b '^## ' | tail -1 | cut -d: -f1)
    # no section heading inside the limit: fall back to the blind cut rather than injecting nothing
    [ -n "${CUT:-}" ] && [ "$CUT" -gt 0 ] 2>/dev/null || CUT="$LIMIT"
    head -c "$CUT" "$STATE/STANDUP.md"
    printf '\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n'
    printf '!!! STANDUP TRUNCATED. %s of %s bytes were NOT shown above.\n' "$((BYTES - CUT))" "$BYTES"
    printf '!!! THIS SAVE POINT IS INCOMPLETE. Do not treat it as the whole picture.\n'
    printf '!!! Read the rest before acting: %s\n' "$STATE/STANDUP.md"
    printf '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n'
  fi
else
  printf 'NO STANDUP.md EXISTS. There is no save point. Treat this as a cold start.\n'
fi

if [ -f "$STATE/REQUESTS.jsonl" ]; then
  # TERMINAL-STATE PREDICATE — one definition, shared with savepoint-guard.mjs, declared in the
  # request-ledger contract and parsed by tools/request-states.sh. CODEX-FIXES item 6.
  #
  # This used to read `state != delivered`, which is not what terminal means. `dropped` is Jo
  # calling something off and `deferred` is Jo deciding not now; both are finished business, and
  # both were being re-raised here as live obligations on every session start. Measured on the
  # live ledger 2026-08-20 before this change: REQ-002, REQ-018 and REQ-056 (dropped) and REQ-010
  # and REQ-094 (deferred) all appeared under OPEN OBLIGATIONS. REQ-018's own note reads "Do not
  # re-raise unprompted"; the hook re-raised it anyway.
  #
  # DEGRADES LOUDLY, NEVER SILENTLY. If the predicate cannot be read this falls back to the old
  # delivered-only behaviour and SAYS SO in the injected text, because the failure mode of
  # guessing here is reopening work Jo already closed.
  SELF_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd 2>/dev/null) || SELF_DIR="."
  RS_DIR="${LINTEL_TOOLS:-}"
  if [ -z "$RS_DIR" ]; then
    # installed layout is hooks/ beside tools/; the hook lab keeps the tool next to the candidate
    if [ -f "$SELF_DIR/request-states.sh" ]; then RS_DIR="$SELF_DIR"; else RS_DIR="$SELF_DIR/../tools"; fi
  fi
  TERMINAL=$(sh "$RS_DIR/request-states.sh" --terminal 2>/dev/null) || TERMINAL=""

  if [ -n "$TERMINAL" ]; then
    printf -- '\n--- OPEN OBLIGATIONS (non-terminal only; terminal = %s) ---\n' \
      "$(printf '%s' "$TERMINAL" | tr '\n' ' ' | sed 's/ *$//; s/ /, /g')"
  else
    printf -- '\n--- OPEN OBLIGATIONS (state != delivered) ---\n'
    printf '!!! The terminal-state predicate (%s) could not be read, so this list is UNFILTERED.\n' "$RS_DIR/request-states.sh"
    printf '!!! Rows below may be dropped or deferred, i.e. finished business. Check each state.\n'
  fi

  # $TERMINAL is intentionally unquoted: each state becomes one argv entry for the filter below.
  python3 - "$STATE/REQUESTS.jsonl" $TERMINAL <<'REQPY' 2>/dev/null || printf '(could not parse REQUESTS.jsonl)\n'
import json,sys
terminal=set(sys.argv[2:]) or {'delivered'}
open_rows=[];suppressed={}
for line in open(sys.argv[1]):
    line=line.strip()
    if not line: continue
    try: r=json.loads(line)
    except: continue
    st=r.get('state')
    # an unknown or missing state is NOT terminal: an unrecognised row is surfaced, never swallowed
    if st in terminal:
        suppressed[st]=suppressed.get(st,0)+1
        continue
    open_rows.append(r)
if not open_rows:
    print('None. Every recorded request is in a terminal state.')
for r in open_rows:
    print(f"[{str(r.get('state','?')).upper():9s}] {r.get('id','?')}  {r.get('request','')[:150]}")
    if r.get('note'): print(f"            note: {r['note'][:150]}")
if suppressed:
    print('(' + ', '.join(f'{n} {s}' for s,n in sorted(suppressed.items())) +
          ' - terminal, deliberately not listed. Jo closed these; re-raising one means a new row.)')
REQPY
fi

printf '\n=== END SAVE POINT ===\n'
}

# ---------------------------------------------------------------------------
# DELIVERY. The one real change. Capture the document, then hand it back as
# hookSpecificOutput.additionalContext. Every failure path here exits 0 with nothing written, so
# the worst case is the same as the live hook's worst case: no save point, never a broken session.
# ---------------------------------------------------------------------------
DOC=$(emit_doc 2>/dev/null) || DOC=""
[ -n "$DOC" ] || exit 0

SAVEPOINT_DOC="$DOC" python3 - <<'JSONOUT' 2>/dev/null
import json, os, sys

doc = os.environ.get("SAVEPOINT_DOC", "")
if not doc:
    sys.exit(0)
# built whole, then written once: a half-written object would be malformed JSON
payload = json.dumps({
    "hookSpecificOutput": {
        "hookEventName": "SessionStart",
        "additionalContext": doc,
    }
})
sys.stdout.write(payload + "\n")
JSONOUT

exit 0

#!/bin/zsh
# Removes ONLY Lintel's hooks from settings.json, leaving every other hook in place.
# Safe from cold, safe to re-run, backs up before touching anything.
set -e
SET=/Users/jowolff/.claude/settings.json
BK="$SET.backup.$(date +%Y%m%d-%H%M%S)-pre-uninstall"
print -r -- "[1/3] backing up -> $BK"
cp -p "$SET" "$BK"
print -r -- "[2/3] removing hook entries referencing orchestrator/hooks/"
python3 - "$SET" <<'PY'
import json,sys,os,subprocess
p=sys.argv[1]; d=json.load(open(p)); h=d.get('hooks',{}); removed=[]
for ev in list(h.keys()):
    keep=[]
    for grp in h[ev]:
        inner=[x for x in grp.get('hooks',[]) if 'orchestrator/hooks/' not in x.get('command','')]
        if len(inner)!=len(grp.get('hooks',[])): removed.append(ev)
        if inner: grp['hooks']=inner; keep.append(grp)
    if keep: h[ev]=keep
    else: del h[ev]
if not h: d.pop('hooks',None)
tmp=p+'.uninstall-tmp'
open(tmp,'w').write(json.dumps(d,indent=2)+'\n')
subprocess.run(['python3','-m','json.tool',tmp],check=True,capture_output=True)
os.replace(tmp,p)
print("      removed from:", ", ".join(sorted(set(removed))) or "(nothing found)")
PY
print -r -- "[3/3] verifying"
python3 -m json.tool "$SET" > /dev/null && print -r -- "      settings.json is valid JSON"
print -r -- "      remaining references: $(grep -c 'orchestrator/hooks/' "$SET" || true) (want 0)"
print -r -- ""
print -r -- "Done. Undo this uninstall with:  cp $BK $SET"

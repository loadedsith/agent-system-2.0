#!/usr/bin/env node
/**
 * PreToolUse(Agent|Task) — refuses a dispatch whose prompt does not carry the brief-boilerplate
 * clauses that a worker cannot get any other way.
 *
 * ── WHAT HAPPENED ────────────────────────────────────────────────────────────────────────────
 * Three memory requirements (R5, R2, R1) shipped on 2026-08-26 as prose sections in
 * state/BRIEF-BOILERPLATE.md. Measured that evening and re-derived 2026-08-27 before this file
 * was written:
 *
 *   - `grep -rn "BRIEF-BOILERPLATE"` across agents/, orchestrator/hooks/, skills/ and
 *     settings.json returns exactly ONE instruction — agents/orchestrator.md:210, a line of prose
 *     telling one agent to append the file — plus an index row at :292. No hook does it.
 *   - The plugin's own references/output-types.md contains ZERO occurrences of the three clause
 *     headings, and nothing anywhere in the plugin tree names BRIEF-BOILERPLATE.md. So plugin
 *     agents — builder, scout, reader, research and the rest, which load their own contract file —
 *     receive these three clauses by no route at all.
 *
 * So the requirements written to fix RELAY were themselves relayed into a file with no mechanism
 * carrying them anywhere. Jo ruled on it, 2026-08-27, both halves the same way: R3-R8 ship as
 * "machinery", and the three already shipped get a delivery mechanism — "yes get with the
 * mechanism". This is that mechanism for the delivery half.
 *
 * ── ⛔ WHY IT REFUSES INSTEAD OF INJECTING, WHICH WOULD BE BETTER IF IT WERE POSSIBLE ─────────
 * A hook that silently appended the clauses to every dispatch would deliver them at zero friction
 * and could not be forgotten. That is not available: PreToolUse can deny, ask, or emit
 * `additionalContext`, and additionalContext goes to the CALLING session's context, not into the
 * subagent's prompt — see the plugin's delegation-guard.mjs, whose emitContext() is documented as
 * "say something without deciding anything". Nothing on this machine rewrites tool input, and no
 * field for doing so is in use anywhere. So the only mechanism available at this seam is a
 * refusal, which is also what Jo's standing ruling asks for: name the line of code that refuses,
 * or file it as a rule and grade it as a rule.
 *
 * ── THE ANCHORS ARE READ, NEVER COPIED ───────────────────────────────────────────────────────
 * This file contains no clause text. It parses the required sentences out of BRIEF-BOILERPLATE.md
 * at run time — the first bolded directive of each named section. A hardcoded copy here would be
 * a second source of truth that drifts silently from the file it is meant to deliver, which is
 * the exact defect request-append.sh, judgement-fit.py and request-states.sh each exist to avoid.
 *
 * Consequence, stated so it is a decision and not a surprise: EDITING A CLAUSE'S FIRST BOLD RUN
 * CHANGES WHAT THIS GUARD DEMANDS. That is intended — the file is the contract — but it means a
 * reword silently invalidates every prompt template that was pasting the old sentence. The
 * refusal text always prints the current required sentence, so the repair is copy-paste.
 *
 * ── FAILS OPEN, DELIBERATELY, IN ONE DIRECTION ───────────────────────────────────────────────
 * Missing boilerplate file, unparseable sections, no anchors found, garbage stdin: every one of
 * those ALLOWS the dispatch. A guard whose own source is unreadable must not become a machine
 * that refuses all delegation — and the failure it is preventing (a worker missing three
 * sentences) is far cheaper than the failure it would cause (no worker can be dispatched at all).
 * ⛔ The corollary is the honest one: if BRIEF-BOILERPLATE.md is deleted or renamed, this guard
 * goes quiet and delivery silently returns to zero. The log is how you find that out — see below.
 *
 * ── SCOPE, AND WHY IT IS NARROW ──────────────────────────────────────────────────────────────
 * Fires only for dispatches made from under BRIEF_CLAUSE_ROOT (default /Users/jowolff/.claude).
 * The clauses are arguably universal, but this hook is registered in a global settings.json and
 * would otherwise refuse dispatches in every repository on this machine. Widening it is a
 * blast-radius decision and belongs to Jo, not to this file.
 * "Under" means the root itself or root + "/", so ~/.claude-bckp is out. BRIEF_CLAUSE_ROOT moves
 * only the scope: the boilerplate source and the log stay in ~/.claude/orchestrator/state (or
 * LINTEL_STATE) whatever the root is.
 *
 * ── HOW YOU KNOW IT EVER FIRED, AND THAT IT DID NOT FIRE ON EVERYTHING ────────────────────────
 * Every considered dispatch is logged, ALLOW as well as DENY. A deny-only log cannot tell
 * "working correctly" from "refusing everything". Three degenerate states, all invisible in a
 * deny-only log and all distinguishable here:
 *
 *   considered = 0            registered but never on the path — or the boilerplate went missing
 *   deny > 0, allow = 0       it refuses every dispatch
 *   allow > 0, deny = 0       either everyone complies, or the anchors stopped parsing
 *
 * The last one is why the log records the anchor count on every line: `anchors: 0` with a stream
 * of allows is the signature of a guard that has quietly stopped measuring.
 *
 * ── ESCAPE HATCH ─────────────────────────────────────────────────────────────────────────────
 * A tool call carries no environment, so the env-prefix hatch used by ledger-write-guard.mjs is
 * not available here. Instead: put `BRIEF_CLAUSES_OMITTED: <reason>` in the prompt. Allowed, and
 * logged with the reason verbatim.
 *
 * ⛔ GRADED HONESTLY, because the distinction has bitten this codebase before: requiring the
 * FIELD is a mechanism, requiring it to be MEANINGFUL is a rule. `BRIEF_CLAUSES_OMITTED: x`
 * passes. This buys deliberateness and a record, not good judgement, and is not sold as more.
 *
 * Always exits 0. Decides via stdout JSON, per the eval contract.
 */
import { readFileSync, appendFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { homedir } from 'node:os';

const HOME = homedir();
const ROOT = (process.env.BRIEF_CLAUSE_ROOT || join(HOME, '.claude')).replace(/\/+$/, '');
// The state dir is fixed and NEVER derived from ROOT (fixed 2026-09-10). It used to be
// join(ROOT, 'orchestrator', 'state'), so setting BRIEF_CLAUSE_ROOT to change what is gated also
// moved where the boilerplate is read and the log is written: a widened root found no boilerplate
// and failed open, silently. Same fixed form as ctx-search-guard.mjs's STATE line.
const STATE = process.env.LINTEL_STATE || join(HOME, '.claude', 'orchestrator', 'state');
const SOURCE = process.env.BRIEF_CLAUSE_SOURCE || join(STATE, 'BRIEF-BOILERPLATE.md');
const LOG = process.env.BRIEF_CLAUSE_LOG || join(STATE, 'brief-clause-guard.jsonl');

// The sections whose directives a dispatch must carry. Named by HEADING, not by content: the
// heading is the stable identity and the sentence under it is what gets delivered. Adding a
// fourth clause to the boilerplate does not arm this guard for it until its heading is listed
// here — deliberate, because arming a refusal is a decision and appending prose is not.
const REQUIRED_SECTIONS = [
  'A fact carries its origin',                       // R5 — origin plus epistemic grade
  'A receipt proves what it literally shows',        // R2 — scope of what the receipt licenses
  'A fact recorded without the means to check it',   // R1 — receipt, not assertion
];

const allow = () => process.exit(0);
const deny = (reason) => {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason,
    },
  }));
  process.exit(0);
};

function record(row) {
  try {
    mkdirSync(dirname(LOG), { recursive: true });
    appendFileSync(LOG, JSON.stringify({ at: new Date().toISOString(), ...row }) + '\n');
  } catch { /* a guard that cannot log still guards; it must never crash the tool call */ }
}

/**
 * Parse the required directive out of each named section.
 *
 * A section runs from its `## ` heading to the next `## `. The directive is the first bolded run
 * inside it — the sections are written directive-first by convention, and that convention is what
 * makes this parseable. Returns [] on any failure, which the caller turns into an allow.
 *
 * Whitespace and markdown emphasis are normalised out of the needle, so a dispatcher who
 * reflows the sentence across lines, or drops the bold markers, still satisfies it. What is NOT
 * forgiven is rewording: the words themselves are the payload.
 */
export function anchorsFrom(text) {
  const out = [];
  for (const wanted of REQUIRED_SECTIONS) {
    const h = text.indexOf(`## ${wanted}`);
    if (h === -1) continue;
    const rest = text.slice(h);
    const nextH = rest.indexOf('\n## ', 1);
    const body = nextH === -1 ? rest : rest.slice(0, nextH);
    const bold = /\*\*([\s\S]+?)\*\*/.exec(body);
    if (!bold) continue;
    const sentence = bold[1].replace(/\s+/g, ' ').trim();
    if (sentence.length >= 20) out.push({ section: wanted, sentence });
  }
  return out;
}

/** Normalise a haystack the same way the needle was normalised, so the comparison is fair. */
const norm = (s) => String(s || '').replace(/\*+/g, '').replace(/\s+/g, ' ').trim().toLowerCase();

/**
 * The whole decision, factored out so --selftest exercises the SAME code path the hook runs
 * rather than a re-implementation of it.
 *
 * Returns null to allow, or { rule, missing, anchors } to deny.
 */
export function decide(prompt, anchors) {
  if (!anchors.length) return null;                       // nothing to demand: fail open

  const hatch = /BRIEF_CLAUSES_OMITTED:\s*(.+)/.exec(prompt || '');
  if (hatch && hatch[1].trim() !== '') {
    return { rule: 'escape-hatch', reason: hatch[1].trim(), anchors: anchors.length };
  }

  const hay = norm(prompt);
  const missing = anchors.filter((a) => !hay.includes(norm(a.sentence)));
  if (!missing.length) return null;
  return { rule: 'clauses-missing', missing, anchors: anchors.length };
}

// ── SELF-TEST ────────────────────────────────────────────────────────────────────────────────
// Both poles, because one pole cannot fail informatively: "it refuses a bare prompt" and "it does
// not refuse a compliant one" are different claims and a build can pass either while failing the
// other. Uses a synthetic boilerplate so the test does not depend on the live file's current text.
if (process.argv.includes('--selftest')) {
  const FIXTURE = [
    '# Brief boilerplate', '',
    '## Some unrelated section', '', '**Ignore me entirely.**', '',
    '## A fact carries its origin *and* what that origin claimed for it', '',
    '**When you record a fact, record who supplied it and the grade they gave it.**', '',
    'Prose that follows and is not the directive.', '',
    '## A receipt proves what it literally shows; the sentence built on it can reach past it', '',
    '**Record what the evidence covers separately from what you concluded.**', '',
    '## A fact recorded without the means to check it is a claim wearing a fact\'s clothes', '',
    '**Write the route as a command someone ran, never as a capability.**', '',
  ].join('\n');

  const A = anchorsFrom(FIXTURE);
  const all = A.map((a) => a.sentence).join('\n\n');
  const cases = [
    ['DENY',  'Go and find where the login form is validated.',
     'THE INCIDENT SHAPE: an ordinary bespoke brief carrying none of the clauses'],
    ['DENY',  'Do the thing.\n\n' + A[0].sentence + '\n' + A[1].sentence,
     'two of three present is not compliance — the third is still undelivered'],
    ['DENY',  'Do the thing.\n\nRecord who supplied it. Record what the evidence covers. Write the route.',
     'PARAPHRASE IS NOT DELIVERY. Shortened near-misses of all three must still refuse.'],
    ['ALLOW', 'Do the thing.\n\n' + all,
     'THE OTHER POLE: a compliant dispatch must pass'],
    ['ALLOW', 'Do the thing.\n\n' + all.replace(/\n/g, ' ').replace(/ +/g, '   '),
     'reflowed and re-spaced still passes — whitespace is normalised, wording is not'],
    ['ALLOW', 'Do the thing.\n\n' + all.split('').map((c) => (c === c.toLowerCase() ? c : c.toLowerCase())).join(''),
     'case-insensitive, so a dispatcher who sentence-cases the paste is not punished'],
    ['ALLOW', 'Quick lookup.\n\nBRIEF_CLAUSES_OMITTED: one-line existence check, no facts recorded',
     'the escape hatch, with a reason'],
    ['DENY',  'Quick lookup.\n\nBRIEF_CLAUSES_OMITTED:   ',
     'the escape hatch with an EMPTY reason is not an escape hatch'],
  ];

  let pass = 0, fail = 0;
  console.log(`anchors parsed from fixture: ${A.length} (expected 3)`);
  if (A.length !== 3) { console.log('  FAIL the parser did not find three anchors — every case below is meaningless'); fail++; }
  for (const [expect, prompt, why] of cases) {
    const v = decide(prompt, A);
    const got = (v && v.rule !== 'escape-hatch') ? 'DENY' : 'ALLOW';
    const ok = got === expect;
    ok ? pass++ : fail++;
    console.log(`  ${ok ? 'PASS' : 'FAIL'} want=${expect} got=${got}  ${why}`);
  }

  // The fail-open pole is separate because it is about the SOURCE, not the prompt: a guard whose
  // boilerplate cannot be parsed must allow, and that is the property that keeps a broken guard
  // from halting all delegation on this machine.
  const noAnchors = anchorsFrom('# nothing here\n\nno sections at all\n');
  const failOpen = decide('a bare prompt with no clauses whatsoever', noAnchors);
  const ok = failOpen === null && noAnchors.length === 0;
  ok ? pass++ : fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'} want=ALLOW got=${failOpen ? 'DENY' : 'ALLOW'}  FAIL-OPEN: an unparseable boilerplate must never refuse a dispatch`);

  console.log(`\npass=${pass} fail=${fail}`);
  console.log(fail === 0
    ? 'Both poles hold: a bare dispatch is refused, a compliant one is not, and a broken source fails open.'
    : 'THE GUARD IS NOT MEASURING. A failing pole means its verdicts mean nothing.');
  process.exit(fail === 0 ? 0 : 1);
}

// ── HOOK ─────────────────────────────────────────────────────────────────────────────────────
let p = {};
try { p = JSON.parse(readFileSync(0, 'utf8')); } catch { allow(); }
if (p === null || typeof p !== 'object') allow();

// Agent and Task are the two dispatch tool names on this machine — the same pair
// orchestrator/hooks/routing-counter.mjs treats as a dispatch (see its isDispatch).
const tool = String(p.tool_name ?? '');
if (tool !== 'Agent' && tool !== 'Task') allow();

// Scope gate. See SCOPE above: this is registered globally and must not refuse dispatches in
// every repository on the machine.
// Path-segment exact: the root itself, or root + "/". A bare startsWith(ROOT) let
// /Users/jowolff/.claude-bckp (a real sibling on this machine) count as in scope. `under` is copied
// from ctx-search-guard.mjs (its `const under`), not imported, so this installed hook gains no
// new file it depends on.
const under = (dir, r) => dir === r || dir.startsWith(r + '/');
const cwd = String(p.cwd ?? '');
if (!under(cwd, ROOT)) allow();

let source = '';
try { source = readFileSync(SOURCE, 'utf8'); } catch { allow(); }   // fail open

const anchors = anchorsFrom(source);
if (!anchors.length) {
  // Logged rather than silent: a guard that has stopped measuring must be findable in its own log.
  record({ decision: 'allow', rule: 'no-anchors-parsed', source: SOURCE, anchors: 0,
           session: p.session_id, tool });
  allow();
}

const prompt = String(p.tool_input?.prompt ?? '');
const label = String(p.tool_input?.subagent_type ?? p.tool_input?.description ?? '');
const verdict = decide(prompt, anchors);

if (!verdict) {
  record({ decision: 'allow', rule: 'clauses-present', anchors: anchors.length,
           session: p.session_id, tool, label });
  allow();
}

if (verdict.rule === 'escape-hatch') {
  record({ decision: 'allow', rule: 'escape-hatch', reason: verdict.reason,
           anchors: anchors.length, session: p.session_id, tool, label });
  allow();
}

record({ decision: 'deny', rule: verdict.rule, anchors: anchors.length,
         missing: verdict.missing.map((m) => m.section), session: p.session_id, tool, label });

deny(
  `This dispatch is missing ${verdict.missing.length} of ${anchors.length} required brief clauses.\n\n` +
  `WHY: three memory requirements shipped as prose into\n  ${SOURCE}\n` +
  `and reached essentially nobody — one unenforced line in one agent definition delivers them, no\n` +
  `hook does, and plugin agents receive them by no route at all. Jo ruled 2026-08-27 that this\n` +
  `ships as machinery rather than prose. A worker cannot get these from anywhere else: they are\n` +
  `not in the plugin's own reference file, so even a plugin agent that loads its contract has\n` +
  `never seen them.\n\n` +
  `PASTE THESE INTO THE PROMPT — verbatim, they are the payload rather than a gesture:\n\n` +
  verdict.missing.map((m) => `  [${m.section}…]\n  ${m.sentence}\n`).join('\n') + `\n` +
  `Wording must match; whitespace, line breaks, bold markers and letter case need not.\n\n` +
  `Full text of every clause, if you want the reasoning that goes with them:\n  ${SOURCE}\n\n` +
  `⛔ If this dispatch genuinely records no facts and relays none — a one-line existence check —\n` +
  `say so IN THE PROMPT and it is allowed and logged with your reason:\n` +
  `  BRIEF_CLAUSES_OMITTED: <why this dispatch cannot carry a fact>\n\n` +
  `Graded honestly: that marker requires a reason to be PRESENT, not for it to be good. It buys\n` +
  `deliberateness and a record. Decisions are logged both ways at ${LOG}.`
);

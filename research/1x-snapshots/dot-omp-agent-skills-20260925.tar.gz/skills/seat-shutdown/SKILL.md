---
name: seat-shutdown
description: Shut down HerdR-managed OMP seats only after their unfinished work and wrap-up artifacts are durably recorded and a human approves the exact stop list.
argument-hint: "[seat-name ...]"
disable-model-invocation: false
---

# OMP seat shutdown

Use this override for persistent seats running in OMP under HerdR. The Claude Code source remains the rollback implementation; do not call `claude agents`, `claude stop`, or `claude attach` from this workflow.

The invariant is **ask, land, wrap up, approve, close, confirm**. A seat is safe to stop only when every unfinished item survives outside its context.

A held or busy seat narrows the proposed stop list; it never cancels the sweep. The workflow is
incomplete until every requested seat is classified as ready to stop, held awake with a concrete
blocker, already asleep or undiscoverable, or failed with the exact verification error.

## 1. Build the live seat roster

Require a HerdR-managed caller:

```bash
test "${HERDR_ENV:-}" = 1
```

If that fails, stop and tell the user to invoke the skill from Lintel inside HerdR.

Run:

```bash
herdr integration status
herdr agent list
```

Require the OMP integration to be current. The status of integrations for other agent kinds is
irrelevant to an OMP seat; a GPT-family model inside OMP does not make that seat a HerdR Codex agent.
Build the candidate roster from live HerdR agents whose names case-insensitively match
`OMP_PERSISTENT_SEAT_NAMES`. If arguments name seats, narrow to those names. Do not include
disposable OMP workers or non-allowlisted agents.

Resolve each target by its unique live HerdR agent name first, then snapshot its pane ID, tab ID,
agent kind, lifecycle state, working directory, and native agent-session identity. The native
identity is opaque: accept a nonempty `value` whether its `kind` is `path`, `id`, or another
HerdR-supported form. Safety comes from requiring the exact value to remain unchanged before exit,
not from requiring a filesystem path.

If a configured target has no unique named match, inspect every unclaimed live OMP pane with
`herdr pane process-info --pane <pane-id>`. A null-name pane resolves to that target only when
exactly one foreground OMP process carries the adjacent argv pair
`--session-dir $HOME/.omp/agent/seat-sessions/<lowercase-seat-name>`. Record that it was resolved by
the process contract and retain the exact argv, pane ID, and native session value in the snapshot.
Zero matches means already asleep or undiscoverable. More than one match, an empty native session
value, a mismatched non-null HerdR name, or a stale OMP integration is fatal. Never resolve from cwd,
terminal title, model, or a partial path match.

Record the caller's `HERDR_PANE_ID`. The seat occupying that pane is the orchestrator and must be handled last. Never close the caller's pane from this skill.

## 2. Ask each other seat and make its state durable

Before every prompt, rerun `herdr agent get <verified-pane-id>` and require its native session to match the snapshot. For a name-resolved target, also require its name to match. For a process-contract target, rerun `herdr pane process-info` and require the exact canonical `--session-dir` argv pair; its HerdR name may remain null, but any different non-null name is fatal. If the seat is working, wait with `herdr agent wait <verified-pane-id> --until idle --until done --until blocked --timeout 120000`; only `idle` or `done` is ready for a new prompt.

For every target except the caller, submit this request through `herdr agent prompt <verified-pane-id> <text> --wait --timeout 120000`:

> Check your ledger or queue, decision-log directory, and scratch directory rather than answering from memory. Report every unfinished item, whether it is fully on disk, and its absolute path. Land anything that exists only in context. Then run your repository's normal wrap-up workflow, verify the resulting artifact, and reply with the wrap-up's absolute path. Do not exit or stop yourself.

If HerdR reports a timeout, stalled prompt, blocked state, or delivery error, inspect that exact seat with `herdr agent get` and `herdr agent read --source recent-unwrapped --lines 120`. A timeout does not prove non-delivery, so inspect before retrying.

For every reported artifact, verify that the path exists, is non-empty, and was modified during this shutdown run. Treat an unverified path, silence, or context-only work that could not be landed as **held awake**. Continue checking every independent seat; never include a held seat in the stop list, and never end the workflow merely because one seat is held.

## 3. Wrap up the caller last

After the other seats report, inspect Lintel's own ledger or queue, decision log, and scratch directory. Land any context-only state and run Lintel's normal wrap-up workflow. Verify its artifact exactly as for the other seats.

Lintel remains outside the programmatic stop list because this session cannot witness its own exit.

## 4. Human approval gate

Show the user:

- held-awake seats and why;
- the proposed stop list, with each seat's resolved HerdR name, pane ID, native session identity, unfinished work, and verified wrap-up path;
- Lintel's verified wrap-up path;
- this exact statement: `Nothing has been stopped yet. Reply "sleep them" to close the proposed seats, or name the seats to hold back.`

Wait for explicit confirmation. General agreement, silence, or approval from an earlier phase is not confirmation for this stop list.

## 5. Exit approved background seats and confirm

Immediately before each exit, repeat the target's resolution check: exact native session plus canonical name for a name-resolved target, or exact native session plus canonical `--session-dir` argv pair for a process-contract target. Require that its pane differs from `HERDR_PANE_ID`.

Ask OMP to exit gracefully:

```bash
herdr agent prompt <verified-pane-id> "/exit"
```

Do not add `--wait`: `/exit` is a local OMP command rather than a model turn, so HerdR's activity gate can report a false stall. Never substitute `herdr pane close` for this graceful exit; OMP must run its session-shutdown hooks and save its draft.

After every exit, rerun `herdr agent list` and confirm that the exact native session is no longer live; for a name-resolved target, also confirm the exact name is no longer live. Then run `herdr pane process-info --pane <verified-pane-id>` and confirm that OMP is no longer the foreground process. If either check fails, report the failed confirmation and stop exiting further seats until the mismatch is understood.

Leave shared-tab layout alone. A dedicated seat tab may be closed only after OMP has exited, its root pane contains only an idle shell, and the tab contains no other panes. Never stop the HerdR server.

## 6. Hand Lintel's exit to the human

After all approved background seats are confirmed asleep, report the final result in this order:

1. held awake and why;
2. slept, with each verified wrap-up path;
3. already asleep or undiscoverable;
4. no reply or failed confirmation;
5. Lintel's verified wrap-up path.

Then tell the human to type `/exit` in Lintel's pane and confirm that it returns to a shell prompt. Do not claim Lintel is asleep until the human confirms the exit.

# Orchestrator

Everything about the always-on agent Jo coordinates all agentic work on this Mac through.
This directory is inside the `/Users/jowolff/.claude` git repo, so every change here is
reversible with one command.

## Layout

| Path            | What it holds                                                                 |
| --------------- | ----------------------------------------------------------------------------- |
| `CHARTER.md`    | The agent's identity and operating manual. Read at the start of every session. |
| `build/`        | The design work that produced the charter. Written by Jo and the main session. |
| `state/`        | The agent's own runtime state. Written by the agent, once it is running.       |
| `state/runs/`   | One directory per fleet run — conductors write their workers' output here.     |

## Why `build/` and `state/` are separate

`build/` is how the agent was made and why the decisions went the way they did. `state/` is what
the agent has learned since. Mixing them means the agent eventually edits its own origin story,
which makes the record of *why* unrecoverable.

The agent may write freely to `state/`. It treats `build/` as read-only except by explicit
instruction from Jo.

## Where the agent itself will live

`/Users/jowolff/.claude/agents/orchestrator.md` — not in a plugin. Plugin subagents have
`permissionMode`, `mcpServers`, and `hooks` silently ignored, and this agent needs them.
That directory does not exist yet.

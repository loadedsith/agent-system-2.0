# Skill: linear-project-suggest

Suggest the top 5 active Linear projects a new issue most likely belongs to, then offer to create the issue.

## Invocation

`/linear-project-suggest <ticket title>`

`$ARGUMENTS` is the full ticket title.

## Steps

### 1. Fetch active projects

Use ToolSearch to load `mcp__linear__list_projects` and `mcp__linear__save_issue`.

Call `mcp__linear__list_projects` **twice** in parallel:

- `{ "state": "started", "limit": 50 }`
- `{ "state": "planned", "limit": 50 }`

Merge the two result sets, deduplicate by project ID, and discard any project whose state is `completed` or `cancelled`.

If either call returns a `cursor`, page through until all active projects are fetched.

### 2. Rank top 5

Given the ticket title `$ARGUMENTS`, rank the merged project list by relevance. Consider:

- Keyword overlap between the title and the project name / description
- Domain or subsystem signals (e.g. "auth", "feed", "watch", "onboarding")
- Recency (`updatedAt`) as a tiebreaker — more recently active projects rank higher

Select the **5 best matches**. If fewer than 5 active projects exist, return all of them.

### 3. Present the ranked list

Output a numbered list (1–5). For each project include:

- Project name
- Team name
- One-sentence rationale for why the ticket fits

Example format:

```
Ticket: "Add retry logic to video upload"

1. **Media Ingestion** (Engineering) — Directly covers upload pipelines and reliability work.
2. **Mobile Core** (Engineering) — Upload flows live in the mobile clients; retry logic may sit here.
3. **API Reliability** (Platform) — Backend retry / backoff patterns are in scope for this project.
4. **Watch Feed** (Product) — Video delivery work often touches upload prerequisites.
5. **Infrastructure Hardening** (Platform) — Retry/resilience work sometimes lands here when cross-cutting.
```

### 4. Offer to create the issue

After the list, ask:

> Which project should I create this under? Enter 1–5, or "skip" to bail out.

Wait for the user's response.

- If **skip** or blank: stop, do nothing.
- If **1–5**: call `mcp__linear__save_issue` with:
  - `title`: the original `$ARGUMENTS` value (verbatim, no edits)
  - `project`: the chosen project's name or ID
  - `team`: the team associated with that project

After creation, output the new issue identifier and URL.

## Error handling

- If no active projects are found: tell the user and stop.
- If ToolSearch or the Linear MCP calls fail: surface the error clearly, do not guess.
- Never invent project names. Only suggest projects returned by the API.

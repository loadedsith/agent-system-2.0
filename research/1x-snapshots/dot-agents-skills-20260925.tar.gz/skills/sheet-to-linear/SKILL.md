---
name: sheet-to-linear
description: Reads rows from a Google Sheet, filters to rows with a non-empty Issue Title, shows a preview table, then bulk-creates Linear issues. Use when importing a bug/issue tracking spreadsheet into Linear.
argument-hint: <sheet-url-or-file-id> [team-key]
disable-model-invocation: true
allowed-tools: mcp__claude_ai_Google_Drive__read_file_content, mcp__linear__save_issue, mcp__linear__list_teams, mcp__linear__list_issue_labels
---

## Step 1 — Parse inputs

If `$ARGUMENTS` contains a Google Sheets URL, extract the file ID (segment between `/d/` and the next `/`). If it's already a bare file ID (no slashes), use it directly.

If a team key was provided as the second argument, resolve it via `mcp__linear__list_teams`. Otherwise call `mcp__linear__list_teams`, then use `AskUserQuestion` with a single-select question — one option per team, label = team name, description = team key — and wait for the answer before proceeding.

## Step 2 — Read the sheet

Call `mcp__claude_ai_Google_Drive__read_file_content` with the file ID.

If any row has a blank Issue Title, STOP. List each offending row by its position in the sheet. Ask the user to either fill in the missing titles or remove those rows, then reply to re-read and continue. Re-read the sheet and repeat this check before proceeding.

All rows with a non-empty Issue Title are import candidates. If zero such rows exist, stop and say so.

## Step 3 — Resolve label IDs

Call `mcp__linear__list_issue_labels` for the team. Build two lookup maps:

- **Severity group**: match `sev1`, `sev2`, `sev3` (case-insensitive)
- **Clients group**: match `All`, `All web`, `iOS`, `Android`, `Kitchen`, `All mobile` (case-insensitive)

If a sheet value has no matching label, flag it as "label not found" for that row — do not block the import.

## Step 4 — Preview

Render a table of all rows to be created:

| # | Title | Priority | Severity | Clients | Has description? |
|---|---|---|---|---|---|

Priority display: `0`=Urgent, `1`=High, `2`=Medium, `3`=Low, `4`/blank=No priority.  
"Has description?" = Yes if any of URL / Steps / Expected / Actual is non-empty.

Then state: **N issues ready to create. Nothing has been created yet. Reply 'yes' to create them, or tell me what to change.**

## Step 5 — Create issues

On explicit confirmation (`yes`, `ship it`, `create them`, or equivalent):

For each row call `mcp__linear__save_issue` with:

- `title`: column 1
- `teamId`: resolved team ID
- `priority`: `0→1` (Urgent), `1→2` (High), `2→3` (Medium), `3→4` (Low), `4`/blank`→0` (No priority)
- `labelIds`: resolved IDs for Severity + Clients values; omit if blank or not found
- `description`: markdown, blank sections omitted entirely:

```
**URL:** <value>

**Steps to reproduce:**
<value>

**Expected behavior:**
<value>

**Actual behavior:**
<value>
```

Report progress as each issue is created (`3/7 created…`). On completion, summarise: total created, any failures, any label mismatches.

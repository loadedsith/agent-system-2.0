# Voice samples

Reference passages for matching Jo's writing voice. Direct address to the reader, rhetorical questions, self-deprecating asides, casual confidence, willing to digress in a parenthetical.

---

I'd like to preface this by saying that some extremely talented engineers are employed by ad/creative agencies. I met some truly brilliant minds who fit that description - many of them during my time at R/GA. I, in fact, have a deep respect for engineering teams situated within ad agencies (if such things still exist in the year 2026). It's how I was raised.

Are you an agency baby? Do you sometimes think that, as an engineer, you're missing something? Do you live in a world where testing and a11y centric engineering are optional, if they were even scoped at all?

BE NOT AFRAID

I was once like you! It's true. Here's what I (slowly learned) during my time in the advertising/tech consultancy business: Agencies rarely give any shits about perf, a11y, or testing your code. At least, not as much as they should.

Heads up! I'm specifically talking about ad agencies, and I left that life for product side in 2016. I could be describing an ancient civilization for all I know, so your mileage-may-vary.

They care about perf a little - if it's so slow that the client can't use it they'll let you know.

Here's the thing: they don't care because they're not incentivized to care. Actually it's the opposite! a11y and perf optimization cost billable hours and are almost never factored into the estimate that they provide the client.

They'd have to ask for more billable hours from the client, and remember that they've likely already convinced the client to spend more than they want to. Unless that biz is factored in from the beginning it's a non starter.

In my experience most QA are testing what you've built against the design they have. Which is a terrible idea on its own because engs often diverge from the design - often after a discussion with the designer who is 💯 not gonna reflect them in his designs.

QA teams at agencies test functionality - again because the agency doesn't have the hours available for more comprehensive tests. I've yet to meet a QA person who's had enough time and resources to test everything that they'd like. They're good eggs.

The other factor here is the ephemeral nature of agency output. You're building a microsite or a landing page. Something tied to a campaign. They want you to build 'em fast and cheap. They're not built to last.

You may be a little behind, but if you're not working product side, you're rarely encouraged to employ some vital parts of the engineering lifecycle in your day-to-day biz. I'll post more later about some of the resources I've used to learn, but in the meantime there's an embarrassment of riches for self-guided learning - amazing mentors, thorough tutorials, and a lot of great reading for you to enjoy.

Were you raised as/spent a lot time as an engineer in an ad agency? What did you love about it? What did you try to change/wish you could change

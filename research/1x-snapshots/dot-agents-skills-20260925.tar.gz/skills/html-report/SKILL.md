---
name: html-report
description: Converts a markdown report or chat text into a styled, voice-matched HTML report — an index.html + index.css pair in its own folder, built on Jo's Venture Bros base styles via CSS cascade layers. Use when Jo says "turn this into a report" or asks to style an analysis, summary, or write-up as HTML.
argument-hint: "[file-path]"
disable-model-invocation: true
---

Convert a report into a styled, voice-matched HTML report as an `index.html` + `index.css` pair in its own folder. Never use the Artifact tool for this — output is always local files.

## 0. Delegate to a builder-model subagent

Do the actual work (steps 1–4 below) inside a single subagent call via the Agent tool, model `sonnet`, not in the main thread. Pass it this entire file plus the source content. This keeps report generation on a cheap, consistent builder-tier model regardless of what model is driving the parent session.

## 1. Determine the source content

- If a file path argument was given, Read that file.
- Otherwise, use the most recently written `.md` file this session, or the report/analysis text already in the chat.
- If it's ambiguous which content to convert, ask before proceeding.

## 2. Humanize and match voice, in one pass

Read `voice-samples.md` (next to this file). Invoke the `humanizer` skill with both the sample and the source text in a single call, using its documented inline format:

"Humanize this text. Here's a sample of my writing for voice matching: `<contents of voice-samples.md>`. Now humanize this text: `<source content>`"

If `voice-samples.md` is missing or empty, stop and ask Jo for a sample rather than falling back to humanizer's generic default voice.

## 3. Build the files

Pick a short name for this report/deck (from the source filename, or a slug from its title/content). Create the folder `/Users/jowolff/decks-and-docks/<name>/` and write two files into it:

**`index.css`:**
- First line: `@layer base, body;`
- Then import the shared base styles into the base layer, using a path relative to this file — absolute paths don't resolve in a browser:
  `@import "../../.Codex/reference/venture-bros-styles.css" layer(base);`
- Any report-specific styling goes in a `@layer body { ... }` block below the import, e.g.:
  ```css
  @layer body {
    .highlight {
      background: var(--henchman-gold);
    }
  }
  ```
  Never fight base-layer specificity — add overrides/extras to `body` instead.

**`index.html`:**
- Links `index.css` in the `<head>`. No inline `<style>` block, no other stylesheets, fonts, or external requests.
- Holds the humanized, voice-matched content, marked up with the existing Venture Bros classes where they fit (`.eyebrow`, `.swatch-name`-style headers via `h1`/`h2`, `.tag`/`.label` for small caps chrome, etc.) — see `venture-bros-styles.css` for what's available.

## 4. Report back

Give Jo the folder path. Don't open a browser unless asked.

# Übersicht Widget Reference

Quick cheat sheet for building Übersicht macOS desktop widgets correctly. Covers the footguns first.

## Export pattern — the #1 footgun

**Use named export `render`, NOT `export default`.**

Übersicht reads `module.render` from the compiled module. A default export silently falls back to raw `output` passthrough — the widget renders nothing or raw JSON.

```jsx
// CORRECT
export const render = ({ output }) => (
  <div className={className}>{output}</div>
);

// WRONG — looks fine, does nothing useful
export default ({ output }) => <div>{output}</div>;
```

## The `html` pragma

JSX compiles with `@babel/preset-react` configured `{ pragma: 'html' }`. So every JSX expression becomes `html(...)` calls, not `React.createElement(...)` directly.

`html` IS `React.createElement` — set as `window.html = require('react').createElement` at runtime.

This means function components, sub-components, and all React element patterns work exactly as you'd expect. No special handling needed.

## Other named exports

```js
export const command = 'some-shell-command';  // string or function
export const refreshFrequency = 5000;          // ms; default 1000
export const className = myStyles;             // string or Emotion object
```

## Styling — use Emotion, not raw `<style>` tags

Import from the `uebersicht` module (not directly from `emotion`):

```jsx
import { css, styled } from 'uebersicht';

// css() returns a class name string — use it as the className export
export const className = css`
  color: white;
  font-size: 14px;
`;

// styled() for component-level styling
const Box = styled('div')`
  background: rgba(0, 0, 0, 0.5);
  padding: 8px;
`;
```

The `className` export is passed through Emotion's `css()` automatically. Raw `<style>` tags work but fight the system; avoid them.

Emotion version in use: 10 (despite README saying 9 — README has drifted).

## Hooks — sub-components only

Übersicht calls `implementation.render(state)` as a plain function, then passes the return value to `ReactDom.render(result, el)`. This means the exported `render` runs **outside** React's render tree.

Hooks called directly in the exported `render` violate the rules of hooks and will throw.

```jsx
// BREAKS — hooks in the top-level render export
export const render = ({ output }) => {
  const [open, setOpen] = useState(false); // ← throws
  return <div>{output}</div>;
};

// WORKS — define a component, use hooks inside it, render it from render
function Widget({ output }) {
  const [open, setOpen] = useState(false);
  return <div onClick={() => setOpen(o => !o)}>{output}</div>;
}

export const render = ({ output }) => <Widget output={output} />;
```

## Sub-components

Define and use exactly like React — capitalized name = component reference:

```jsx
function Status({ value }) {
  return <span className={value === 'ok' ? 'green' : 'red'}>{value}</span>;
}

export const render = ({ output }) => (
  <div>
    <Status value={output} />
  </div>
);
```

## Babel config (what the bundler applies)

- `@babel/core` 7.11.6
- `@babel/preset-env` targeting last 4 Safari versions
- `@babel/preset-react` with `{ pragma: 'html' }`
- `@babel/plugin-proposal-object-rest-spread`
- `babel-plugin-emotion`
- `uebersicht` module is external (runtime global, not bundled)

## React version

React 16.13.1, `ReactDom.render` (legacy API). No concurrent mode, no React 18 features.

## `uebersicht` module exports

```js
import { run, request, css, styled, React } from 'uebersicht';
```

`run` and `request` are for shell execution; `css`/`styled` are Emotion; `React` is the full React object if you need it explicitly.

## Minimal working widget

```jsx
import { css } from 'uebersicht';

export const command = 'date +%H:%M';
export const refreshFrequency = 60000;

export const className = css`
  top: 20px;
  right: 20px;
  color: white;
  font-size: 24px;
`;

export const render = ({ output }) => <div>{output}</div>;
```

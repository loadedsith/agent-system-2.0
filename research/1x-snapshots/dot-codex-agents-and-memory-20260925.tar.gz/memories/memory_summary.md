v1

## User Profile

The user works on Newdle/ContextPress engineering and local agent orchestration. Their practical environment is macOS local iTerm 2 with HerdR-managed panes, evaluating Pi/OMP while keeping the team’s Claude-native plugin canonical and actively maintained. They value concrete, evidence-aware status: distinguish what was inspected, tested, and accepted from a handoff, documentation finding, or unresolved hypothesis. They favor durable runbooks for live operational work and want the desktop Codex conversation retained as a fallback beside persistent agent lanes. They also work on scoped UI MVPs and occasional creative image requests.

## User preferences

- Begin unfamiliar codebase work with the actual repository context—architecture, manifests, and current state—rather than making them repeat workspace details.
- For local agent setup, use “iTerm 2, with Herder H E R D R managing my agents”; give one self-contained, context-rich checklist with exact commands and later steps, not fragmented instructions that require scrolling.
- Preserve staged, reversible harness migration: start with a read-only inventory; keep the team Claude plugin “alive and maintained,” not forked; exclude AWS Bedrock and analogous providers.
- Treat explicit operational gates as gates (for example, “48 commits behind `origin/main`”); reconcile the living runbook immediately after live confirmations.
- For screenshot/UI questions, lead with visible controls and the exact requested scope; distinguish screenshot evidence from documentation and do not overclaim.
- For the realtime summary MVP, limit generation to the requested overview-page button, preserve a box that is not “too skinny,” and leave unrelated work as blueprints unless scope expands.

## General Tips

- A green install, authentication, documented feature, or visible terminal prompt is not acceptance. Test real payloads/effects, lifecycle/transcripts, side effects, billing, and an assistant reply-side readiness signal.
- In the OMP cutover record, acceptance remained incomplete: require Codex reply-only READY, `/seats` and Moshi visibility, plus one bounded read-only task before declaring completion. Preserve live session storage; change and verify one named seat at a time. TallyMan is a held draft, not a launch target.
- In Newdle, trust live manifests and `just check-manifests` over README inventory prose. Distinguish source, published, installed, and fresh-session states.
- For harness compatibility, use isolated harmless fixtures with the unchanged canonical plugin; UNKNOWN / TEST REQUIRED is not PASS. Compare full trees and active overlays, not versions alone.
- `.zshenv:3: operation not permitted` can occur with exit-0 reads; treat it as environmental noise unless the command itself fails.

## What's in Memory

### /Users/jowolff/Documents/Codex/2026-09-08/realtime-voice-chat-2

#### 2026-09-11

- HerdR / OMP cutover, Pi setup, and persistent-seat acceptance: Herdr, Pi, launch-seat, check-seat-ready, OMP-CUTOVER-PACKET.md, GPT-5.6 Sol, Moshi
  - desc: Local iTerm/HerdR setup, model routing, genuine READY verification, held TallyMan design, and the remaining Codex acceptance gate.
  - learnings: The readiness checker must inspect an opening assistant turn, not launcher text; ordinary seats use Opus while Codex is pinned to Sol; the packet is a living runbook and can contain stale historical checks.

### /Users/jowolff/Documents/Codex/2026-09-09/ce

#### 2026-09-10

- Photorealistic latte foam-art image generation: image_gen__imagegen, latte-art, photorealistic, generated-images
  - desc: Successful built-in generator workflow for a preview-only raster asset; cwd=/Users/jowolff/Documents/Codex/2026-09-09/ce.
  - learnings: Default generated-images storage was sufficient for preview-only delivery; a warm, lightly playful tone fit the creative brief.

### /Users/jowolff/Documents/Codex/2026-09-09/ai-harness-compatibility-chatgpt-conversation-6a903707-2

#### 2026-09-10

- AI-harness compatibility / Claude Code replacement: Pi, pi-code, Oh My Pi, OMP, hooks/hooks.json, runtime-test-contract.md, canonical plugin
  - desc: Read-only baseline for evaluating Pi + pi-code or OMP without forking the team Claude plugin; use before migration decisions.
  - learnings: Resource discovery and OAuth do not prove semantic compatibility or plan economics; use isolated fixtures and UNKNOWN / TEST REQUIRED rows.

### /Users/jowolff/Documents/Codex/2026-09-08/realtime-voice-chat

#### 2026-09-08

- Overview-only summary generation and wider existing box: overview-page, generate-summary button, blueprint, too skinny, box-sizing
  - desc: MVP UI handoff for this checkout; inspect pre/post-summary layout before claiming the width issue is fixed.
  - learnings: Scope is one overview-page button; other flows remain blueprints. This was a handoff, not implementation evidence.

### Older Memory Topics

#### /Users/jowolff/code/shipyard/repos/newdle-claude-plugins

- Newdle repository orientation: newdle@contextpress, plugin.json, SKILLS-MANIFEST.md, just check-manifests, just publish
  - desc: Canonical plugin distribution repository and publishing-versus-installation boundary; cwd=/Users/jowolff/code/shipyard/repos/newdle-claude-plugins.

#### workflow=ChatGPT/Codex desktop on macOS

- Voice and dictation guidance: Voice chat hotkey, Toggle dictation hotkey, Hold-to-dictate hotkey, screenshot, microphone permissions
  - desc: Screenshot-led settings guidance; use visible controls first and separate proven UI state from current product documentation.

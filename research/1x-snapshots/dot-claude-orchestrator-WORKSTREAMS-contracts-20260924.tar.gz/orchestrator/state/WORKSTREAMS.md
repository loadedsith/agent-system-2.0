# Workstreams
*Snapshot taken 2026-08-19. This goes stale — re-derive it rather than trusting it after a week.*

## Active right now
(anything with uncommitted work, an open branch, or an in-progress Linear issue)

**Repos with dirty trees or non-main branches:**
- The plugin restructure work in editions (jo/plugin-restructure-session-journal branch, dirty) — actively implementing the plugin consolidation and agent rules eval harness
- The newdle-claude-plugins core (jo/session-journal-2026-08-18 branch, dirty) — carries the plugin restructure SPEC and agent rules
- The web worktrees mirror (jo/plugin-restructure-session-journal branch, dirty) — tracking plugin work across web repos  
- The web repo (jo/strip-low-priority-modulepreloads branch, dirty) — performance optimization mid-flight
- The data-pipelines repo (jo/session-journal-2026-08-18 branch, clean) — session tracking work
- The kitchen repo (jo/note-unverified-health-probes branch, clean) — health probe validation in progress
- The newdle-db repo (jo/journal-2026-08-14-plugin-session branch, clean) — plugin session tracking
- The newdle-users and newdle-py repos (session journal branches, clean) — supporting plugin work

**Active Linear issues in Cycle 8 (Newdle Engineering):**
- In Progress (14 issues): Session-start injector (ENG-1589, done), output-types contract (ENG-1594, done), picker-count addition (ENG-1593, done), creator-studio session storage modes (ENG-1655), kitchen story revision editor redesign (ENG-1501), video editing media pane (ENG-1653), video track split/cut UI (ENG-1652), timeline clip snapping (ENG-1651), teammate hook muting (ENG-1631), mute hint version pinning (ENG-1645), dirty agent worktree visibility (ENG-1643), inline PR review comments permission (ENG-1644), spine declarative successor naming (ENG-1592), eval harness tier 1/2 runners (ENG-1590), published writings debug (ENG-1540), preview chrome accessibility (ENG-1526), video studio transitions (ENG-1472), database dump workflow CI blocking (ENG-1371), data retention policy (ENG-1383)
- Todo (20 issues): Git autonomy phases 1–3 (ENG-1586, ENG-1596, ENG-1597), delegation guard baseline (ENG-1587), autonomous mode gated on evals (ENG-1598), builder terminal state reporting (ENG-1601), AGENTS.md diet (ENG-1595), ready-for-production trigger (ENG-1612), scaledown.ai LLM tasks (ENG-1553), user Watch status profile display (ENG-1639), conflict resolution UX for staged edits (ENG-1507), npm audit check-in (ENG-1372), mobile web initial load perf (ENG-1550, "Poor across the board"), publish checkpoint rejection (ENG-1512), writing scheduling immediate publish (ENG-1505), platform-aware Linear planning (ENG-1602), silent-failure detector hook (ENG-1599), real prod timing data deploy (ENG-1420), images removed by editorial returning to story (ENG-1405)

## Committed this cycle
(the active cycle — Cycle 8, 2026-08-15 to 2026-08-22)

**Newdle Engineering (43 issues, 7 completed as of 2026-08-19):**
- Done: 7 issues (SessionStart injector, output-types contract, picker-count, stories search, kitchen v1 launch, API surface move, signin/signup redesign, icon asset)
- In Progress: 14 issues (as listed above)
- Todo: 22 issues (as listed above)

**Newdlers (54 issues, 5 completed as of 2026-08-19):**
- No issues returned; may indicate team is not actively tracked in current cycle or team/cycle structure differs

**Marketing and Growth (15 issues, 2 completed as of 2026-08-19):**
- Done: Process for triage (MKT-360), Reddit account creation (MKT-475)
- In Progress: Creator Studio writing (MKT-458), tutorials (MKT-440), ads (MKT-433), community seeding outreach (MKT-453), Substack creators (MKT-441), Annika (MKT-422), person outreach (MKT-443)
- Todo: Reddit community moderation (MKT-395), social media design review (MKT-449), design improvements (MKT-450), template for horizontal videos (MKT-451), user feedback analysis (MKT-454), @newdle Newdle writings (MKT-455)

## Projects
(one line per .projects/ directory: what it is, its status)

- **Plugin restructure** (In Progress) — consolidate 61 skills into a scannable picker and prove agent guard hooks fire. Demo target 2026-08-21. Carries the eval harness (tier 1 payload runner, tier 2 behavioral).
- **Signature data visualization** (Draft) — establish a Newdle house style for charts so readers recognize the source without seeing the branding. Status: pending CTO conversation, not yet scoped to Linear.
- **Direct Messages** (Backlog) — standalone one-to-one and group DM feature. MVPs: images, video (mp4/webm only), voice notes, share refs. WebSocket nudge + refetch model with Valkey pub/sub.
- **Agent git autonomy** (Not found in Linear) — three-phase work to replace the blanket git-write ban. Phase 1 (ENG-1586): localized branch autonomy. Phase 2 (ENG-1596): merged-branch guard. Phase 3 (ENG-1597): worktree question with real evidence.
- **Project-linear-sync** (Backlog) — bidirectional sync between `.projects/<name>/` spec/plan/task files and Linear projects. Frontmatter schema defined; full skill suite wiring pending.
- **Smoke-test-sync** (Backlog) — throwaway smoke test for the full project-sync flow. Marked for archive after validation.
- **Provenance and citations** (status unknown — spec file missing) — likely addresses traced paths back to citation sources (mentioned in signature-viz objective).
- **Linear sync labels and relations** (status unknown) — likely covers bidirectional sync of Linear labels and issue relationships into local files.
- Other `.projects/` directories (11 more): dms, hashtags, initial-charts-and-graphs (superseded by signature-viz), initial-load-perf (and phases 2–3), first-publish-editorial-policy-prompt, dynamic-model-routing, records, stop-teleprompter, teleprompter-desktop-redesign, jo-demo — most appear archived or pre-scoped phases.

## Recent decisions
(ten most recent decision-log entries, one line each)

1. **2026-08-18** Jo Wolff — The spine shipped, a sweep was under-scoped from a paragraph, and debugger model routing was measured
2. **2026-08-11** Jesus Guzman Jr. — Watch video search cross-repo plan (planning only, no code)
3. **2026-08-13** Jo Wolff — The workspace declares itself hooks-on, and ENG-1622 closed much smaller than planned
4. **2026-08-13** Jo Wolff — The never-solicit-a-PR rule is gone, and one handoff lane holding five open files was drained to one
5. **2026-08-13** Jo Wolff — The Friday gate was never a date, and line-number citations into committed docs are now banned
6. **2026-08-13** Jo Wolff — Charts north-star realignment — CTO proposal and successor spec
7. **2026-08-12** Jo Wolff — SessionStart visibility measured and scope reconciled
8. **2026-08-12** Jo Wolff — Quorum landed, three labs converged on a declaration file, and nothing survived for the snooze
9. **2026-08-12** Jo Wolff — Four interviews killed the discovery hypothesis and the landing brief was rewritten
10. **2026-08-11** Jo Wolff — Delegation ruling and interview redesign

## Repos
(repo, branch, status)

| Repo | Branch | Status |
|------|--------|--------|
| crawler | main | clean |
| data-pipelines | jo/session-journal-2026-08-18 | clean |
| editions | jo/plugin-restructure-session-journal | **dirty** |
| kitchen | jo/note-unverified-health-probes | clean |
| newdle-api | main | clean |
| newdle-claude-plugins | jo/session-journal-2026-08-18 | **dirty** |
| newdle-db | jo/journal-2026-08-14-plugin-session | clean |
| newdle-mastra | main | clean |
| newdle-py | jo/journal-2026-08-14-plugin-session | clean |
| newdle-users | jo/session-journal-2026-08-18 | clean |
| newdle-web | jo/strip-low-priority-modulepreloads | **dirty** |
| newdle-web.worktrees | jo/plugin-restructure-session-journal | **dirty** |

**Grade:** Four repos are mid-flight with uncommitted changes (plugin restructure work in editions, plugins core, web worktrees, and web perf work). Eight repos have open session-journal branches but clean working trees, indicating recent work on discrete features but nothing actively being changed now. Two repos are on main and clean.

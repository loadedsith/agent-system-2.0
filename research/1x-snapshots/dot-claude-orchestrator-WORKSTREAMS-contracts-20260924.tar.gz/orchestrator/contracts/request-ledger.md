# Request-ledger contract

This file is the canonical machine-readable vocabulary for `state/REQUESTS.jsonl`. The charter
explains why the ledger exists; tools and hooks parse only this contract. Keep the marker and line
shapes intact. A schema change lands here with its tests before any producer writes the new shape.

<!-- state-vocabulary:begin -->
- `delivered` — terminal — Jo asked, Jo got it, and the result was accepted as returned or after revision.
- `deferred` — terminal — a deliberate decision not to do it now; the reason lives in `note`.
- `dropped` — terminal — Jo called it off. Never re-raise or re-litigate it.
- `open` — non-terminal — accepted as work, not finished; the default state for a new row.
- `partial` — non-terminal — some of the ask landed and a named remainder did not; `note` names it.
- `blocked` — non-terminal — something outside the fleet must move; `note` names the blocker.
<!-- state-vocabulary:end -->

<!-- request-fields:begin -->
- `id` — required — string — `REQ-NNN`, unique across the file and never reused.
- `ts` — required — string — ISO 8601 with an explicit offset or trailing `Z`. **Read it from the clock, never from the row above.** Producers take it from `date -u +%Y-%m-%dT%H:%M:%SZ`; a value continued from the previous line inherits that line's error, which is how this file accumulated rows dated ahead of real UTC. The skew is cosmetic and the existing rows are deliberately left alone — a row rewritten to match today's clock is a row you can no longer date.
- `request` — required — string — Jo's ask in Jo's terms, non-empty.
- `state` — required — string — one of the values in the state vocabulary above.
- `touches` — required — array — zero or more typed objects carrying required non-empty `text`.
- `note` — required — string — outcome, remainder, or context; may be empty but is always present.
<!-- request-fields:end -->

<!-- touch-vocabulary:begin -->
- `original` — the ask as first stated, before any correction.
- `ack` — Jo signalling receipt or agreement without adding direction.
- `clarify` — Jo answering a question the fleet asked.
- `correct` — Jo fixing something the fleet got wrong.
- `redirect` — Jo changing what the work should be.
- `direction` — Jo adding new instruction to work already under way.
- `context` — Jo supplying background the fleet lacked, with no change of direction.
- `decide` — Jo choosing between options the fleet put up.
- `stop` — Jo calling the work off.
<!-- touch-vocabulary:end -->

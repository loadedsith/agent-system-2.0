# Dispatch-ledger contract

This file is the canonical machine-readable vocabulary for `state/LEDGER.jsonl`, the dispatch
ledger — one row per dispatch, recording what was sent out, to whom, at what tier, and how it
came back. It governs that file and nothing else; `state/REQUESTS.jsonl` has its own contract in
`contracts/request-ledger.md` and the two vocabularies are not interchangeable. Tools and hooks
parse only this contract. Keep the marker and line shapes intact. A schema change lands here with
its tests before any producer writes the new shape.

## Why `id` is required, and what it costs today

A dispatch row is not write-once. A dispatch is born unfinished, and the row that records it has
to be amended when it finishes: an outcome, a wall clock, a friction note. The ledger has never
carried an identity field, so there has been no way to say *which row* to amend — and the only
available move was to append a second row for the same dispatch. That is the drift this contract
exists to stop. `id` is the handle that makes in-place update possible, and it is required for
exactly that reason.

The honest consequence: run the checker against the live ledger today and every existing row
fails for a missing `id`. That is an accurate report of the file's state, not a checker defect.
But a checker that can only ever fail gets muted, and a muted checker returns you to the original
problem. The resolution path is a back-fill: `tools/dispatch-write.sh --propose-ids` reads the
ledger and emits, to stdout, a copy with `DSP-NNN` assigned in line order to the rows that lack
one, changing nothing else and writing no file. That output is a proposal for a human to review
and apply. No tool applies it on its own.

The back-fill assigns ids in file line order, so for those legacy rows id order and file order
happen to agree. That agreement is an accident of the back-fill and it is not an invariant. The
ledger's `ts` values are already known to be approximate and partly out of order, and rows written
after the back-fill get the next unused id rather than a chronological one. Nothing downstream may
sort by id, infer chronology from id, or assume `DSP-042` came before `DSP-043`. The next id is
derived from the highest id present in the file, never from a row count, so removing a row can
never cause an id to be handed out twice.

<!-- outcome-vocabulary:begin -->
- `clean` — terminal — the dispatch returned what was asked for and the result stood as returned.
- `retried` — terminal — the dispatch failed or fell short and was re-run; `attempts` carries the count.
- `abandoned` — terminal — the work was called off before it produced a usable result.
- `escalated` — terminal — the work FINISHED and its result was used, but a decision inside it went to Jo rather than being taken by the agent. Corrected 2026-08-21 by the seat that coined the term: the first draft read "handed the problem up rather than finishing it," which is the opposite of what the rows show. All four `escalated` rows carry an `outcome_label` of `used-as-returned` or `revised`, and their notes describe a call being made and then stated plainly to Jo. Distinct from `sent-back`, where the result was rejected, and from a blocker, which is missing evidence rather than missing authority.
- `sent-back` — terminal — the result was returned to the worker for rework rather than accepted.
- `void` — terminal — instrument defect: the dispatch proves nothing, so the row is evidence of nothing. Reserved for a broken measurement. It must not be used for a superseded duplicate row; a duplicate is a real dispatch that really happened, and voiding it would destroy the only record that it did.
- `in-flight` — non-terminal — dispatched and not yet resolved. This is the state a row is born in.
- `pending` — non-terminal — resolved enough to stop working on, waiting on something before it can be closed.
- `open` — non-terminal — accepted as work, not finished.
<!-- outcome-vocabulary:end -->

`pending` and `open` are not distinguishable from the live data — three rows and one row
respectively, with no written rule separating them. Both are declared here because both are in
the file. Whether one of them retires into the other is a human decision about what the fleet
means by each word, not a decision this contract can make by inspecting rows, so neither is
silently collapsed into the other.

<!-- dispatch-fields:begin -->
- `id` — required — string — `DSP-NNN`, unique across the file and never reused. An identity, not a sequence position: nothing may infer order or chronology from it.
  `tools/dispatch-write.sh --update` re-serializes the single row it amends, so that row's
  internal spacing normalizes (`{"id":"DSP-039","ts":` becomes `{"id": "DSP-039", "ts": `).
  A spacing change in a diff on an updated row is expected and is NOT a content change. Every
  other line in the file is left byte-for-byte alone, and the id back-fill changes no byte but
  the id it adds.
- `ts` — required — string — ISO 8601 with an explicit offset or trailing `Z`.
- `task` — required — string — what the dispatch was asked to do, non-empty.
- `shape` — required — string — the kind of work it was. Open vocabulary; do not close it.
- `dispatched_to` — required — string — the agent, seat, or tool that received it. Open vocabulary.
- `tier` — required — string — one of the values in the tier vocabulary below.
- `outcome` — required — string — one of the values in the outcome vocabulary above.
- `attempts` — required — int — how many times the dispatch was run, counting the first.
- `jo_touches` — required — int — how many times a human had to intervene.
- `friction` — required — string — free prose naming what got in the way, or that nothing did.
- `friction_code` — optional — string — one of the values in the friction-code vocabulary below.
- `outcome_label` — optional — nullable-string — one of the values in the outcome-label vocabulary below; `null` is declared because rows carry it, and refused on write (see below).
- `outcome_source` — optional — string — how the outcome was established, when it was not observed live.
- `evidence_tier` — optional — string — how strong the evidence behind the row is.
- `basis` — optional — string — the receipt the row's outcome rests on.
- `mechanism` — optional — string — how the dispatch was actually run. Open vocabulary and still growing.
- `wall_clock_s` — optional — nullable-int — elapsed seconds; `null` is declared because rows carry it, and refused on write (see below).
- `tokens` — optional — int — tokens consumed by the dispatch.
- `tool_uses` — optional — int — tool calls made by the dispatch.
- `cost_usd` — optional — number — dollar cost of the dispatch.
- `ts_source` — optional — string — one of the values in the ts-source vocabulary below.
- `ts_commit` — optional — string — the commit a reconstructed timestamp was derived from.
- `run` — optional — string — the named run this dispatch belonged to.
- `run_id` — optional — string — identifier of the run this dispatch belonged to.
- `run_dir` — optional — string — directory holding the run's artifacts.
- `report` — optional — string — path to the report the dispatch produced.
- `req` — optional — string — the `REQ-NNN` request this dispatch served. The forward spelling; `--new` writes this one.
- `request` — optional — string — the `REQ-NNN` request this dispatch served; legacy spelling, accepted on read and refused on write.
- `note` — optional — string — anything else worth keeping with the row.
<!-- dispatch-fields:end -->

## Lenient on read, narrow on write

This contract describes the file that exists, so the checker can pass on it. The writer refuses to
add anything new to the mess. No existing row is ever rewritten by either. Three consequences,
each of which retires a defect going forward without touching a single historical row:

**`req` is the forward spelling; `request` is legacy.** Both appear in the file and both name a
`REQ-NNN`, and both stay accepted on read. `--new` writes `req` and refuses `request`. The reason
is not which spelling is more common — it is collision. In `state/REQUESTS.jsonl` the key
`request` holds Jo's ask in free prose, not an id. The same key name meaning two different things
across two ledgers is how someone writes a query that looks correct and is silently wrong. The
five legacy rows keep their spelling; nothing rewrites them.

**`null` is a legacy artifact, not a value.** `wall_clock_s` and `outcome_label` are declared
nullable because rows carry null and the checker has to pass on the file as it is. `--new` refuses
an explicit null for either: a measurement that was never taken is an absent key, not a recorded
nothing. Accepting null on read while refusing it on write means the existing nulls stop spreading
without any row being repaired.

**A live dispatch is `in-flight`.** `pending` and `open` stay declared, because rows hold them and
the checker must pass. `--new` writes neither and accepts neither: `in-flight` is the only
non-terminal outcome it will take. That retires the ambiguity between the two going forward
without rewriting a row and without anyone having to guess which was meant — which cannot be
known now, and guessing would put a false judgment into an audit log.

<!-- tier-vocabulary:begin -->
- `worker` — a subagent doing bounded work under a brief.
- `orchestrator` — the thread that dispatches and holds the decisions.
- `conductor` — a thread coordinating several orchestrated threads.
- `self` — work the recording thread did itself rather than dispatching.
<!-- tier-vocabulary:end -->

<!-- outcome-label-vocabulary:begin -->
- `used-as-returned` — the result went in exactly as it came back.
- `used` — the result went in.
- `revised` — the result went in after edits.
- `partially-used` — some of the result went in and a named remainder did not.
- `discarded` — the result did not go in.
- `unknown` — nobody recorded what happened to the result.
<!-- outcome-label-vocabulary:end -->

<!-- friction-code-vocabulary:begin -->
- `none` — nothing got in the way.
- `brief-underspecified` — the brief left out something the worker needed.
- `brief-overlapping-scope` — two briefs claimed the same work.
- `scope-not-rechecked` — scope drifted and nobody re-read it.
- `provenance-laundered` — a figure or claim was restated without its receipt.
- `wrong-mechanism` — the work went to the wrong kind of runner.
- `guard-blocked` — a hook or guard stopped the dispatch.
- `instrument-defect` — the measurement itself was broken.
<!-- friction-code-vocabulary:end -->

<!-- ts-source-vocabulary:begin -->
- `written-at-event` — the timestamp was recorded when the dispatch happened.
- `backfilled-same-session` — the timestamp was written later in the same session from live memory.
- `reconstructed-from-commit` — the timestamp was derived from a commit; `ts_commit` names it.
<!-- ts-source-vocabulary:end -->

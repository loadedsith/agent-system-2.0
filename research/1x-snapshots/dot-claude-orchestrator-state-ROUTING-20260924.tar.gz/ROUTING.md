# Routing

Task shape → who handles it → the brief that works for that shape.
Written 2026-08-19 from the bootstrap inventory. Every row is derived from something measured,
not assumed. Amend from ledger evidence; never from taste.

---

## OMP cutover overlay — active 2026-09-10
### ⛔⛔ SEAT MAIL NEVER WAKES AN IDLE SEAT — MEASURED 9/9, 2026-09-16

**Deterministic, not flaky.** Mail arriving **mid-turn** is held and injected at the next
yield, resuming in 8-23 s (3 of 3). Mail arriving **idle** starts nothing, indefinitely —
waits of 13, 22, 35 and 46 minutes observed (6 of 6). Sedge, nine arrivals, one process.

⇒ ⛔ **THE CHANNEL WORKS ON THE SEAT THAT DID NOT NEED WAKING.** So the rule above —
**PATHS NEVER PAYLOADS** — is not a workaround for flakiness; it is the only correct use of a
channel whose delivery is inversely correlated with need. To wake a settled seat, nudge the
pane: `herdr agent prompt <slug> "<one sentence naming a file>" --wait --until working`.

### ⛔ A PROBE `omp` GETS ITS OWN PANE. NEVER A SEAT'S. — 2026-09-16

**Launching a child `omp` from inside a seat's pane permanently overwrites that seat's
HerdR identity. The probe exits; the identity does not come back.**

Measured 2026-09-16, found by Jo asking why Lintel's session path looked wrong. Tinker ran
a judgment probe with cwd `/private/tmp/tinker-judgment-cwd` at 07:33:11Z. From then until
its relaunch, `herdr agent get wC:pR` reported:

- `value = ~/.omp/agent/sessions/--private-tmp-tinker-judgment-cwd--/2026-09-16T07-33-11-644Z_….jsonl`
  — 276,981 B, **mtime frozen at 07:35:35Z**, 25 lines, **zero** hits for a token written
  into Lintel's live transcript eight times
- `name = None` — ⛔ **HerdR did not know the pane was Lintel at all**

Lintel's actual transcript was `~/.omp/agent/seat-sessions/lintel/…06-31-47-964Z….jsonl`,
10,091,569 B, written to seconds before the check. **The real session was exactly where
argv said it was; only HerdR's record was wrong.** `/private/tmp/tinker-judgment-cwd` no
longer existed.

⛔ **WHY THIS IS A SAFETY DEFECT, not a cosmetic one.** The `seat-shutdown` skill requires
"the exact native session value to remain unchanged before exit" as its anti-mistarget
guard. For eleven hours that value was a dead file and the name was null, so **both
name-resolution and session-identity resolution would have failed or matched garbage.**
The only thing that could have found Lintel is the skill's process-contract fallback — the
adjacent argv pair `--session-dir $HOME/.omp/agent/seat-sessions/<slug>`. ⇒ **THE ARGV
CONTRACT IS THE PRIMARY IDENTITY, NOT THE FALLBACK.** `sleep-seats.sh` survived tonight by
keying on pane id and never on session value, which was luck rather than design.

✅ **Self-healing on relaunch:** all nine seats relaunched 17:5xZ carry correct
`seat-sessions/<slug>` values and correct names. A fresh `launch-seat --start` registers
properly, so the repair is a cycle.

**RULE, both halves:** (1) any probe, A/B arm, or throwaway `omp` runs in its own pane —
`herdr pane run`, not a child of a seat's shell; (2) **before trusting a seat's identity,
check `name` is non-null and the session mtime is recent.** A frozen mtime on a claimed
live session means the record is stale, and a stale identity is indistinguishable from a
correct one until you compare it against argv.


### ⛔ SEAT MAIL IS NOT A DELIVERY CHANNEL. USE `herdr agent prompt` WITH A PATH. — 2026-09-16

**`seat_message` and the persistent-seat mailbox append to an idle seat's context and start no
turn.** A bare `followUp` reaches `agent-session.ts:7735-7743` — `appendMessage`, `return false`.
The inbox drains, an ack is written, the body is unlinked. **The message is consumed without ever
being read, and nothing distinguishes that outcome from delivery.** An ack proves consumption,
never comprehension.

Measured 2026-09-16, three independent ways: Caspian and Galley each received an explicit re-task
brief naming a file to write and produced nothing for twenty minutes while sitting `idle`; Tinker
never received a correction at all and re-raised the same resolved point twice, accusing me of the
error I had already retracted to it; and Wren told me three times that #1086 was unmerged after I
had sent it the merge SHA. All eleven inboxes read `0` undrained, and `seat-mailboxes/archive/`
did not exist at all after roughly 1,498 acks.

**WHAT WORKS, from our own data rather than a doc:** `herdr agent prompt <slug> <text> --wait
--until working` submits through the interactive path and a turn starts. It reached all ten seats
during the 16:51:22Z cycle ask — every one changed state — and at 17:4xZ it woke Caspian, Galley
and Tinker from `idle` to `working` on the first attempt, `rc=0` each.

**PATHS, NEVER PAYLOADS.** Write the brief to `~/agent-scratch/orchestrator/briefs/<seat>.md` and
send one sentence naming it. Two reasons, both load-bearing: a short prompt is not exposed to
whatever drops or truncates long ones, and **a brief on disk survives the seat's compaction** — a
context-only message does not, so a seat that compacts mid-task loses an assignment it can never
recover. `deliver-briefs.sh` does this and refuses a seat with no brief file.

⛔ **PROVE DELIVERY BY STATE CHANGE, AND DISTRUST YOUR OWN READER.** `rc=0` from `--wait --until
working` is the receipt. When I first ran the delivery my own roster parser returned empty for all
four seats and the script printed `UNDELIVERED` — the delivery had worked and **my measurement was
broken.** A reader that returns nothing is a broken reader until proven otherwise, exactly like a
search that returns zero. Read state with `cycle-seats.sh --status`, which is known to work.

⛔ **AND A STARTED TURN IS NOT AN UNDERSTOOD BRIEF.** The artifact on disk is the only proof of
that; `check-wrapups.sh` verifies existence, byte count, mtime against run start, and whether the
file sits in a removable worktree.

### ⛔⛔ A `delivered` RECEIPT IS TRUE ABOUT HAND-OFF AND SILENT ABOUT QUEUE POSITION — 2026-09-16

**A seat's inbox drains ONE message per turn boundary, oldest first, and the ack is written the
instant bytes are handed over.** `followUpMode` defaults to `one-at-a-time`
(`agent.ts:1202-1208`, `:499`) and `~/.omp/agent/config.yml` does not override it; the queue itself
is an **unbounded array** (`pi-agent-core/src/agent.ts:1118-1120`). ⛔ **`triggerTurn: true` at
`persistent-seat-registry.ts:1108` is IGNORED while the recipient is streaming** —
`agent-session.ts:7669-7675` calls `agent.followUp` and never reads the flag. And nothing between
`:688` and `:700` observes whether the session accepted, queued, or will ever read the content:
`pi.sendMessage` is declared void, so the guard at `:689-695` that was meant to withhold the ack is
**dead code**.

⇒ **A seat with k queued envelopes is k turns behind.** Measured on Levitt's **22** injections
(the 22nd is scheduler-sent and an early selector missed it), 2026-09-16: read lag **8m53s
minimum, 95m02s maximum, 21 of 22 over ten minutes**, 22 of 22 distinct body hashes with zero
duplicates ever, and strict timestamp ascent with zero violations. **Every "stale presentation"
was a late read of a body sent exactly once.** Recorded **nowhere** except the physical record
order inside the recipient's private transcript: an injection record's own timestamp is the SEND
time, its position in the transcript is the READ time.

⛔ **Two independent measurements of the same 22 injections give different medians — 34m06s
(Tinker) and 36m58s (Levitt, accepted by Wren) — and they are recorded unaveraged.** Min and max
agree to the second, so the spread is a definitional difference in where the read instant is taken
(nearest preceding versus following timestamped record), not a disagreement about the data. Either
figure supports the rule; neither should be quoted as exact.

A live prediction landed inside the range while the finding was being written: an envelope acked
19:49:49.199Z had no injection record at 20:01Z and surfaced 18m27s late.

⛔ **SELECT ON `customType == "persistent-seat-message"`, NEVER ON MESSAGE TEXT.** A substring
search over a transcript cannot distinguish a message a seat *received* from a message a seat
*looked for*: one hand measured Levitt's own grep for the evidence and scored it as evidence,
producing a phantom 0.0-minute lag. Second text-shaped false result on this surface in one day.

**Incidental constant, so nobody reads it as damage:** a recipient's transcript records a body
**exactly 36 characters longer** than the sender's jsonl does — an envelope wrapper added at
injection, confirmed across three different body sizes.

⇒ **Judge currency from the sender's published send index, never from arrival order.** A send index
(line, timestamp, target, char count) was the only artifact that made currency checkable during
this incident; Levitt verified Wren's 9 of 9 exact. **A faster route to the same text is not a
clock.**

⛔ **So the only proof a brief was received is the seat ACTING ON ITS CONTENTS.** `rc=0` and a
`working` status prove submission; a seat that was already streaming reads `working` whether your
message is next in its queue or ninth. **Never re-send on silence alone** — a duplicate joins the
same queue behind the original.

⛔ **AND `archive/<id>.json` AND `acks/*.turn.json` MEASURE THE RECIPIENT, NOT THE CHANNEL.** Both
are written by the receiving seat (`:720`, `:1160-1172`), so their absence reflects that seat's
loaded extension version. 1,543 of 1,561 envelopes corpus-wide have no archive copy; in the only
population where absence could carry information the count is **0 of 18**. `.turn.json` is also
**many-to-one** — one `turnStartedAt` stamps every outstanding id (`:1152-1172`) — so it means "a
turn ran while this id was outstanding", never "this envelope was read". **The rule that read
absence as body loss is WITHDRAWN, not narrowed.**

⛔ **The `from` field is sender-asserted and the proof that exists is not applied on the send
path.** `:872` reads `OMP_CURRENT_SEAT_NAME`; `:882` sets `from` from it; the argv-based
`launcherProvenSeatSlug` at `:976-985` is called only at the drain gate `:1012` and a diagnostic
`:1169`. The 2026-09-16 name-squat was fixed **receive-side only**: a process inheriting that
variable can no longer read another seat's mail, but **can still send wearing that seat's name.**
Preserved evidence: `acks/1789543637728-4141987e-….FALSE-RECEIPT.md`, a real ack whose `to` is a
lie. ⇒ **Attribution on a received message is not evidence of its sender.** Recovering a body from
the sender's own session jsonl is the only universal check, because it is written by a different
process than the one that delivers.

**The `triggerTurn`, payload-retention and identity-guard changes are on disk in
`persistent-seat-registry.ts` and reach a seat ONLY on relaunch**, because extensions load at
process start (`loader.ts:151`). Every seat booted 06:31:47–06:34:31Z; that work landed 07:11:47Z.

This section supersedes every Claude Code-specific launch, discovery, status, and messaging
instruction below while the OMP cutover is active. The older observations remain as historical
evidence and as the rollback path; they are not current launch instructions.

**Persistent Marches run through HerdR-managed OMP sessions.** Before routing work to a named seat,
check `/seats` in OMP or `herdr agent list`. If the seat is absent, invoke the atomic wake helper
through the Bash tool:

`/Users/jowolff/.omp/agent/seat-launchers/wake-seat <seat-slug>`

Do not launch seats from an Eval-kernel subprocess. Eval does not carry the calling HerdR pane's
`HERDR_ENV`, `HERDR_PANE_ID`, or workspace identity; the launcher correctly refuses that unmanaged
context.

Launch submission and readiness remain separate facts, but their control flow is one operation.
`wake-seat` captures the start time, invokes `launch-seat --start`, and invokes the reply-only
`check-seat-ready` only after the launcher exits 0. Never reproduce those steps as independent
commands in a loop: a rejected launch must return immediately, not begin a readiness timeout.

The checker reads only assistant messages in the opening OMP turn and requires the seat's identity,
home, and `READY` in that reply. The launch prompt itself is never evidence of readiness.

| March | Seat slug | Home |
| --- | --- | --- |
| Wren | `wren` | `/Users/jowolff/code/shipyard/repos/newdle-web` |
| Tinker | `tinker` | `/Users/jowolff/.claude` |
| Sedge | `sedge` | `/Users/jowolff/code/shipyard/repos/newdle-claude-plugins` |
| Verge | `verge` | `/Users/jowolff/code/shipyard` |
| Sluice | `sluice` | `/Users/jowolff/code/shipyard/repos/data-pipelines` |
| Galley | `galley` | `/Users/jowolff/code/shipyard/repos/kitchen` |
| Levitt | `levitt` | `/Users/jowolff/code/joseph-gordon-levitt` |
| Codex | `codex` | `/Users/jowolff/.codex` |
| Caspian | `caspian` | `/Users/jowolff/code/shipyard/repos/newdle-api` |
| Tron | `tron` | `/Users/jowolff/code/shipyard/repos/newdle-users` |
| Plumb | `plumb` | `/Users/jowolff/code/agent-system-2.0` |

⛔ **JO WORKS WITH PLUMB DIRECTLY; LINTEL IS NOT A LAYER ABOVE IT — Jo, 2026-09-21:** *"i expect to
be working directly with plumb."* Jo opens and closes Plumb's phases, Jo confirms its model plans,
and Plumb reports to Jo in its own tab. **Do not relay Jo's intent to Plumb or Plumb's findings to
Jo, and do not open work on it.** Lintel opened Phase 1 on its own reading of an approved plan on
2026-09-21 and Jo stopped it; the plan gated phases 2-5 on Jo's word and was silent on phase 1,
which is not authorization. What Lintel still owns here: routing Plumb's proposals to the seats
that own the targets (Tinker for `~/.claude` and `~/.omp`, Sedge for the plugin), and portfolio
state. Plumb's charter § "Jo works with you directly" carries the seat's side of this.

⛔ **EVERY TASK LINTEL GIVES PLUMB CARRIES A MODEL PLAN AND WAITS FOR JO'S CONFIRMATION — Jo's
standing instruction, 2026-09-21:** *"i do NOT want plumb to keep spawning fable seats for the
work, before it executes, have it determine the proper model for the work and ask for confirmation
before proceeding. i want you to do this with every task you give to plumb."* A brief to Plumb that
names hands without naming their model tiers is incomplete and Plumb is chartered to push it back.
**Choosing a hand type chooses a model silently:** every plugin agent definition pins a tier at
`<plugin-root>/agents/<type>.md:4` — fable for `auditor`, `beefy-builder`, `beefy-research`,
`planner`, `storyteller`; opus for `builder`, `debugger`, `reader`, `research`, `web-seat`; haiku
for `changelog`, `checker`, `scout`, `summarizer` (measured 2026-09-21 against installed 0.2.171;
re-derive before relying on it). The gate is in Plumb's charter § "Model selection"; it is a
**spending** gate, so resolving it by picking the expensive tier to be safe is the failure, not the
safe play.

**Model contract — REWRITTEN 2026-09-22 by Jo's instruction** ("if you have to wake caspian, i want him
(and any agent seat going forward) set to opus-5-5, not opus-5"): every persistent March launched through
`launch-seat` — all background seats **including Codex**, and Lintel's foreground launch — runs on
`anthropic/claude-opus-5-5`. Enforced in one edit on 2026-09-22 (Tinker): `launch-seat`'s
`DEFAULT_MODEL`, the Lintel row's `default_model`, and the Codex row's `default_model` (the Lintel and Codex
rows keep their explicit line so each stays a one-line override seam), plus every model assertion in
`test-launch-seat.zsh` — the per-seat dry-run checks (wren, codex, sluice, galley, levitt, caspian, tron),
the tinker/sedge/verge loop (which now also asserts the model), and the restricted-PATH foreground
`--model` check. Suite green: `zsh test-launch-seat.zsh` → exit 0. Model choice is runtime routing policy,
not seat identity, so do not duplicate the mutable model slug across repository charters; any path that
does not use the launcher is an invalid seat launch. **Reversal** (`~/.omp` is not a git repo): copy
`launch-seat.pre-opus-5-5` and `test-launch-seat.zsh.pre-opus-5-5` (same directory) back over the live
files, which restores `DEFAULT_MODEL` and the Codex row to `zai/glm-5.3:high` and the Lintel row to
`anthropic/claude-opus-5` — ⛔ that copy also reverts the same-session fixes to the launcher's plugin
resolution and the test's morning-pass and fake-`bun` fixtures, which returns the suite to red; to revert
the model only, set those three values back by hand and restore the matching assertions. Applies at each
seat's NEXT launch — running seats keep their launch model until cycled. **One exception, added
2026-09-21 and unchanged by the 2026-09-22 edit:** Plumb launches on `anthropic/claude-fable-5-1:medium`
by Jo's instruction of 2026-09-21 ("a long running fable agent"), carried as its own `default_model` line
in its `launch-seat` row (the Codex-row shape); reversal is deleting that one line, after which Plumb falls
back to `DEFAULT_MODEL`. **Jo ruled 2026-09-22 that the opus-5-5 move does not cover Plumb** ("PLUMB STAYS
ON FABLE"); do not reopen it.

**Adding a seat, or changing its intended model, touches seven places and lands in one edit.** This
rule used to name two, and the five it omitted are the ones that rot. Measured 2026-09-11 while
adding Caspian (run `launcher-identity-gate-20260911`); surface 7 arrived the same day, which is the
argument for the divergence test rather than for a longer list:

1. **The table above** — display name, slug, home.
2. **`PERSISTENT_SEATS`, the `PERSISTENT_SEATS='…'` assignment in `/Users/jowolff/.omp/agent/seat-launchers/launch-seat`** — the live
   allowlist. It is exported as `OMP_PERSISTENT_SEAT_NAMES` and read by
   `/Users/jowolff/.omp/agent/extensions/persistent-seat-registry.ts:292-294`; a seat missing here
   cannot be messaged at all. ⛔ **It is read into a session's environment AT LAUNCH**, so a session
   started before the edit cannot enumerate the new seat however correct the file is — `/seats` and
   `seat_list` in an older session will show it absent whether or not it is running. Verify a seat's
   existence with `herdr agent list` and its session directory, never with a running session's roster.
3. **The `usage()` slug list in `launch-seat`** (the `Usage:` line inside `usage() {`) — the only place an operator sees which slugs exist.
4. **The `case "$seat"` block in `launch-seat`** — display name, home, charter, memory.
5. **A `--dry-run <slug>` regression in `test-launch-seat.zsh`**, asserting seat, slug, home,
   charter, memory, **and the model contract above**. `launch-seat`'s `for required_path in … "$charter" "$memory" …` loop refuses any launch whose
   charter or memory is unreadable, so this regression is red until those files exist — which makes
   it the gate that proves the seat is launchable rather than merely listed. ⛔ Re-run it after the
   charter's last edit: Caspian's first rc=0 was measured against a 31,181-byte charter that was
   superseded **6 minutes 21 seconds** later - audited and corrected 2026-09-11; the twenty-minute
   figure belonged to a different sentence.
6. **The `seat_message` tool description, `persistent-seat-registry.ts:452`.** It enumerates the
   seats in prose. **This is the one that rots silently:** nothing fails when it goes stale, the
   tool keeps working, and every agent reading the description simply reads that the seat does not
   exist. Caspian was absent from it for the first twenty minutes of his existence while all five
   other places were correct.

7. **`/Users/jowolff/.omp/agent/persistent-seats.json`** — the canonical roster read *fresh on every
   send* by `seat-launchers/queue-seat-message`, the writer-only shell sender for non-agent callers
   (Codex, 2026-09-11). It exists because surface 2 is captured into a process's environment at
   launch, so a sender reading its own environment refuses to address a seat created after it
   started.

⛔ **Surfaces 2 and 7 are two authored rosters, and the guard against their divergence is a test
rather than a convention.** `seat-launchers/queue-seat-message.test.ts` **fails when they disagree
and names both paths in its failure message** — Codex's choice, from three I offered (generate one
from the other, have the launcher read the JSON, or test for disagreement). Treat that test as the
seventh surface's gate: if it is green, the two lists agree; if it is absent or skipped, assume they
do not.

A seat present in some of the seven and absent from others is worse than an absent seat, because
each surface reports a different roster and — apart from that one test — nothing reconciles them.

Lintel itself is foreground and interactive: Jo starts it with `lintel [working-directory]`.
Do not launch a second Lintel session in the background. Do not invoke the legacy launchers under
`/Users/jowolff/agent-scratch/` or use `claude --bg`, `claude agents`, `claude logs`, Claude
`SendMessage`, or Claude `Agent` to launch, discover, monitor, or contact a persistent March while
this overlay is active. HerdR is process control only. Agents use the essential `seat_list` tool
for the complete persistent-seat roster and `seat_message` for assignments or status; humans use
OMP `/seats`. OMP `/agents` and `hub` are for disposable hands inside one session only. The
installed `seat-shutdown` workflow governs the narrow, gated use of a verified HerdR pane during
shutdown and the one-time transition of a pre-mailbox session.

The legacy launchers are deliberately untouched. Full routing rollback snapshot:
`/Users/jowolff/.claude/orchestrator/state/ROUTING.md.pre-omp-cutover-20260910`.

### PLAN-FIRST DISPATCH IS ALLOWED — Jo ruled 2026-09-22 (DEC-053 (/Users/jowolff/.claude/orchestrator/state/DECISIONS.jsonl))

Jo: "yes a seat may type that into another seat's window to start a plan-first dispatch with me
reviewing." When a dispatch should plan before executing, the dispatcher types `/plan` into the
receiving seat's HerdR pane; seat mail cannot enter plan mode (it arrives as plain text). Proven live
through a real HerdR pane on a throwaway session: `herdr pane run <pane> "/plan"` →
"Plan mode enabled" + `🗺 Plan` badge
(`/Users/jowolff/agent-scratch/orchestrator/runs/2026-09-22--tinker--herdr-plan-adoption/pane-after-plan.txt`).
Findings: `/Users/jowolff/agent-scratch/orchestrator/runs/2026-09-22--tinker--seat-plan-mode-trigger.md`.

Procedure (the guards are Lintel's recommendation that Jo accepted with the ruling):
1. Write the brief to a file. **Do not mail it first** — mail can start a turn before `/plan` lands.
2. `herdr pane read <pane>`: the seat is idle and shows no `🗺 Plan`. `/plan` is a TOGGLE; on a seat
   already in plan mode it turns plan mode OFF.
3. `herdr pane run <pane> "/plan Read and plan the brief at <abs path>. Do not execute."`
4. Tell Jo a plan is waiting in that seat's pane. **Jo approves; the dispatcher never sends keys to
   the approval overlay.** Jo should pick "Approve and keep context" — "Approve and execute" CLEARS the
   seat's session.
Untested as of 2026-09-22: `/plan` with trailing text, the idle guard on a busy seat, the overlay
itself. In plan mode only `write`/`edit` are blocked in code; `bash` is restricted by prompt text only.

---

## 0. The eight facts that constrain every dispatch on this machine

Read these before the tables. Each one was measured during bootstrap and each one will silently
cost you a run if you forget it.

**1. Plugin agent definitions may forbid nested delegation.** A conductor therefore runs as a
named OMP task with decomposition explicitly in its brief. Plugin agents fill the worker tier only.

**2. `careful-guard.mjs` runs `PreToolUse` on every single `Bash` and `Glob` call, machine-wide,
with ~33 DENY regexes — and it matches inside quoted arguments.** It denied one of my own
inventory workers for merely *quoting* a dangerous-looking command string inside a report it was
writing. Consequence for briefs: **a worker asked to write prose containing literal destructive
command text will be blocked.** Tell it up front to describe such commands rather than quote them,
or to hex-escape them in the heredoc source. Its header states a `deny` holds even under
`--dangerously-skip-permissions`.

**3. `worktree-spawn-guard.mjs` DENIES any subagent dispatched with `isolation: worktree`.**
Never pass that option. The dispatch will not run.

**4. `permissions.defaultMode` is `"auto"`, which auto-approves any hook returning `ask` — but at
least one guard converts its `ask` to a `deny` before that ever happens, so this is NOT the blanket
"they reach nobody" it was written as.** CORRECTED 2026-08-26. `research-agent-guard.mjs` states in
its own header (lines 12-13) that where the `ask` cannot reach a human — subagent depth, a
non-interactive entrypoint, or a session declaring `NEWDLE_UNATTENDED=1` — it converts to a `deny`
that ends the attempt. **Observed, not just read:** the Sedge seat, running unattended, was refused
a `research` dispatch by that guard on 2026-08-26 and reported it rather than adding the sentinel to
get past it. Consequence for dispatch: **an unattended seat cannot dispatch a research agent at
all**, because the model choice has no one to answer it. Route the work to `debugger` when it is
empirical and local, or hand the model choice to Jo. The original claim came from careful-guard's
inline comment and was never tested; `delegation-guard` and `fable-mode-guard` are still UNTESTED
and must not be assumed to behave either way.

**5. `ast-grep` MCP is mandatory over `grep` for structural search** — finding a function call, a
definition, a symbol usage, a syntax pattern. Jo's global instruction, and it binds every worker
I dispatch, so it goes in the brief. Plain `grep` is for string matches only.

**6. Work in a shipyard repo is never dispatched to a directly-spawned subagent. It goes through
a seat.** A subagent I spawn from this session inherits my working directory,
`/Users/jowolff/.claude`, and a worker there receives **neither**
`/Users/jowolff/code/shipyard/AGENTS.md` **nor** the working repo's own `AGENTS.md`. Two
independent reasons, and closing one would not help: the CLI's rule loading only descends into
*subdirectories* of the launch directory, and the workspace is not below the home config
directory; and the plugin hook that would otherwise inject them walks upward for a scope
declaration that does not exist above that directory. A subagent spawned from a session launched
*inside* the workspace gets both. A **seat** is a launched session living in a repository's main
checkout, so a subagent it spawns inherits that working directory and both delivery channels work.

Three consequences, because a rule without its reasoning gets applied wrongly at the first edge
case:

- **It is not only rules delivery.** The seat holds surface context I do not, so the brief it
  writes for its own worker is better than one I write blind from outside.
- **Routing through a seat buys delegation depth rather than spending it.** A seat is its own
  session with its own depth budget.
- **The gap, stated plainly: only two seats exist today** — one in `newdle-web`, one in
  `newdle-claude-plugins`. Every other repository under the workspace has none, so this rule
  blocks work there until a seat exists. **The resolution is to create the seat on demand, not to
  keep a fallback path** — a fallback is where a rule quietly stops being followed. The cost sits
  beside it, corrected 2026-08-21: **nothing is known to reap a background seat** — one was measured
  alive and idle for 279 minutes and a strings sweep of the binary found no session-lifetime
  vocabulary — and **an idle seat spends nothing**, verified by an idle session appending no
  transcript records across 30+ minutes. Cost is per launch and per turn, not per minute alive. The
  "roughly twenty-three cents of context per launch" figure is UNVERIFIED: its citation into this
  charter no longer resolves. A seat ends when someone runs `claude stop <id>`.

**The one exception, and it attaches to the HANDLER.** A handler that *structurally cannot write*
may be dispatched directly into a shipyard repository that has no seat. Anything that can write
goes through a seat.

**Why there is an exception at all.** The rule does two distinguishable jobs. One is delivering
repository conventions to a worker that will **change** the repo — branch hygiene, version bumps,
test commands, house style. That is where a violation is expensive and where the absolute form is
correct. The other is answering "where is X defined" in a repository with no seat, and **a read
cannot violate a convention because it produces no artifact the conventions govern.** Making every
lookup cost a seat launch taxes verification, which is the last behaviour worth discouraging.

**Why it is not written as "unless it is read-only."** That is a judgement the dispatcher makes at
the exact moment they most want the answer to be yes — the same hole in a new shape. Attaching the
exception to the handler means a dispatcher who wants it has to pick a handler that cannot do the
damage. That is a constraint. A self-report is not.

**The bar, and it is a question of fact rather than of description.** A handler qualifies only if
its definition grants **no `Write`, no `Edit`, no `NotebookEdit`, no unrestricted `Bash`, and no
MCP tool that writes.** Shell access is a write tool whatever the rest of the grant says, and so is
any `mcp__*` call that creates or mutates something. Prose in an agent's system prompt calling
itself read-only does **not** count; only the frontmatter toolset does.

**Verified 2026-08-21 against plugin 0.2.149, and the answer is much thinner than the handler names
suggest. Only one handler qualifies, and it is not one of the plugin agents.**

| Handler | Verdict | The receipt |
| ------- | ------- | ----------- |
| `Explore` (built-in) | **Qualifies**, with one open gap | `Write` is absent from its environment, not merely denied: the eval `evals/scenarios-tier2/skill-frontmatter-agent-explore-write/` in the plugin cache asserts the CLI's own refusal string *"No such tool available: Write. Write is disabled for this session, in subagents as well as here."* alongside an empty `permission_denials[]`, against a no-`agent:` control where the write lands. **Whether it holds `Bash` was never tested** — the fixture skill explicitly instructs the fork *not* to fall back to Bash, so the question was designed out |
| `newdle:scout` | **Does NOT qualify** | Its frontmatter carries only `disallowedTools: Agent` and **no `tools:` allowlist at all**, so it inherits the full default toolset — `Write`, `Edit`, and `Bash` included. Its read-only character is prompt text, nothing more. `newdle:summarizer`, `newdle:checker`, `newdle:changelog` have the identical shape |
| `newdle:reader` | **Does NOT qualify** | `tools: Read, Grep, Glob, Bash`. No `Write`/`Edit`, but unrestricted `Bash` writes files |
| `newdle:planner` | **Does NOT qualify** | `tools: Read, Grep, Glob, Bash`. Same. Its own system prompt claims *"readonly enforcement is by toolset, not prompt alone"* — that sentence is wrong about its own frontmatter |

**Two things this exception does not close, stated so nobody trusts it further than it reaches.**
First, it constrains the worker, not the consequence: findings from a write-incapable handler can
still be acted on by *me*, writing from outside with no repo rules loaded. The exception licenses
the lookup, never the follow-up edit. Second, the table above is a snapshot of one plugin version.
A bump that adds `Bash` to a handler, or drops a `tools:` allowlist, widens this exception silently
and tells nobody — `newdle:scout` is the standing proof that a handler can read as read-only and
not be. **Re-derive the toolsets from frontmatter after any plugin bump; do not inherit this
table.**

**7. The Linear MCP tools are NOT available to subagents. Only a top-level session holds that
namespace.** Measured 2026-08-27 by the Sedge seat: `mcp__linear__get_issue` returns `No such tool
available` inside a subagent, and **both hands she assigned to read issues hit it.** One of them had
already begun reconstructing the issue's intent from the repository before she caught it — which is
the precise failure her brief had told her to avoid, arrived at by a route neither of us predicted.

Consequence for dispatch, and it is not "warn the worker": **a session that wants Linear content in
a hand's brief must fetch the issue text itself and pass it down.** A hand told to go and read a
Linear issue will not fail loudly; it will find the tool missing and substitute the nearest
available evidence, which is the repository — and a repository is not a task list. That substitution
reads as diligence in the report.

**Measured consequence, same day, from the same seat: the substitution changed three verdicts out of
twenty-two.** Sedge's first verification pass reconstructed each issue's intent from local documents.
When she fetched the authoritative Linear text herself and passed it down, **two reconstructions were
wrong and one was backwards** — two issues she had reported as partial were fully landed, and one she
had described as correctly closed had in fact shipped nothing, deliberately, which the repository's
own decision log said outright. She caught it and retracted; nothing downstream inherited it. **The
reconstruction reads as competent and is not checkable from inside the subagent**, which is why this
is a routing fact and not a briefing note.

Related and separate: the plugin's own `.mcp.json` no longer declares a Linear server. The removal
commit's receipt says it never connected and cost every session a 30-second timeout. But
`builder.md:32` and `beefy-builder.md:32` still instruct agents to use the issue-read and
issue-write tools, so a plugin agent can be told to use a tool nothing provides.


**8. ⛔⛔ `newdle-mobile` IS OFF LIMITS. NOTHING IS DISPATCHED THERE, EVER.** Jo, 2026-08-27,
verbatim: *"do not ever, ever, ever touch newdle-mobile brian wants us out of there."*

The repository is `/Users/jowolff/code/newdle-mobile` — iOS, Android and Creator Studio — together
with `/Users/jowolff/code/newdle-mobile-worktrees`. It sits outside the shipyard workspace, so
**fact 6 does not cover it and its absence from that rule is not permission.**

Forbidden: dispatching any hand or seat into it, writing any file in it, placing a hooks-scope
declaration in it, creating a seat for it, opening a branch or pull request in it, or reading it as
part of a task whose purpose is to change it.

**The reason is social, not technical, which is exactly why no technical argument reopens it.** A
measurement about that repository can be true and still license nothing. This rule was written
because Lintel had, in the same turn Jo said this, put a closing ask to Jo proposing to extend the
hooks-scope declaration into that repository — reasoning correctly from a real measurement (hooks
are dark there) to a conclusion that assumed an access nobody had granted.

⛔ Note the name: Jo works with both a **Briar** and a **Brian**, and they are different people.
This is Brian.

Only Jo lifts this, in their own words. See REQ-394.


---

## 1. Task shape → handler

### Understanding something that already exists

| Shape | Handler | Why this one |
| ----- | ------- | ------------ |
| "Where is X defined / which files match Y" | `newdle:scout` (haiku) | Pure lookup — path, line, one-line excerpt. Cheapest thing that answers it |
| "How does this component/subsystem work" | `newdle:reader` (opus) | Layered mapping so raw source never lands in my context. The bootstrap workhorse — all six inventory surfaces, all clean first try |
| "Sweep many files/dirs, I only want the conclusion" | `Explore` (built-in) | Reads excerpts not whole files. Use when the answer is a location, not a judgment |
| "Condense this log/diff/file" | `newdle:summarizer` (haiku) | Its own named failure mode is dropping a GUESS marker — say so in the brief |

### Finding out something not in this codebase

| Shape | Handler | Why |
| ----- | ------- | --- |
| Vendor behavior, library semantics, API limits, "what does this flag actually do" | `newdle:research` (opus) | Primary sources first, explicit unverified section. **Every third-party-semantics statement is CITE-or-test, never background knowledge** |
| Same, but cheaper/bulkier | `newdle:beefy-research` (fable) | Identical contract, different tier |

### Changing code

| Shape | Handler | Why |
| ----- | ------- | --- |
| Bugfix, small feature, a handful of files in one repo | `newdle:builder` (opus) | Escalates rather than expanding scope |
| Larger feature, new subsystem, cohesion across many files or repos | `newdle:beefy-builder` (fable) | Refuses to start without acceptance criteria — so the brief must carry them |
| Tests fail / build breaks / behavior is wrong | `newdle:debugger` (opus) | Reproduce → isolate → verify → minimal fix, every hypothesis traced to a source. **Never send a builder at a symptom** |
| Generating a seat's charter, memory document, launch script and birth decision-log entry from the `new-seat` skill's templates | `newdle:builder` (opus) | Four templates filled into one repository with verification steps — the plain builder's stated territory. **`newdle:beefy-builder` is the wrong handler for this, and the trap is that delicacy reads as horsepower.** Its own description reserves it for larger features, new subsystems, and architectural cohesion across many files; seat generation is none of those. The surrounding conditions are hazardous — a dirty working tree, a guard that bites, verification that must not be skipped — and hazardous conditions are an argument for a tighter brief, never for a bigger model |
| Work inside `newdle-web` | Message the seat **Wren** by display name with `seat_message` | Wren is the durable resident of that checkout; a `queued` receipt remains valid while Wren is not currently observable |
| Work inside `newdle-claude-plugins` | Message the seat **Sedge** by display name with `seat_message` | Same arrangement, same reason. **There is no subagent alias for this seat and none is to be created** |
| Work inside `data-pipelines` | Message the seat **Sluice** by display name with `seat_message` | Created 2026-09-10 (REQ-442). Charter `/Users/jowolff/code/shipyard/repos/data-pipelines/.ai/sluice-seat-charter.md`. **Its charter forbids running any Temporal workflow, activity or worker that can reach production or live credentials** — ALL-927 is a contact prune suspected to come from exactly that |
| Work inside `kitchen` | Message the seat **Galley** by display name with `seat_message` | Created 2026-09-10 (REQ-456). Charter `/Users/jowolff/code/shipyard/repos/kitchen/.ai/galley-seat-charter.md`. **Its charter forbids any broadcast, send, Resend segment write, deploy or production database write** — DEC-063 records that a broadcast from a local kitchen could shrink the production Newdle Marketing Opt-In segment |
| Work inside `newdle-api` | Message the seat **Caspian** by display name with `seat_message` | Created 2026-09-11. Charter `/Users/jowolff/code/shipyard/repos/newdle-api/.ai/caspian-seat-charter.md`. Name ratified by Jo; the spelling is Caspian and it is his son's name |
| Work inside `newdle-users` | Message the seat **Tron** by display name with `seat_message` | Created 2026-09-11 by Verge. Pronouns he/him. Charter `/Users/jowolff/code/shipyard/repos/newdle-users/.ai/tron-seat-charter.md`, memory `.ai/tron-seat-memory.md`, both excluded via `.git/info/exclude:18-19`. **Row added 2026-09-11 by Tinker; Tron has NOT been launched** — adding the row and waking the seat are separate acts |
| Work in any other shipyard repo | Nothing routes there yet — fact 6 governs | No seat exists. Create one with the `new-seat` skill, or dispatch directly **only** under fact 6's write-incapable-handler exception |

**The seat-generation row exists because the same call was made wrong twice.** On 2026-08-20 I
routed a seat's generation to `newdle:beefy-builder`; Jo corrected it, I agreed the plain builder
was right, and I recorded the correction as owed. Roughly two hours later I made the identical call
for the next seat, and Jo caught it by stopping two live agents. **The second occurrence is the
reason this is a row and not a ledger note** — a correction filed only in a ledger is not retrieved
at the moment of dispatch, which is the same failure § 3 documents for governing rules that are
loaded and not recalled.

**What actually separates the two builders, verified 2026-08-21 against plugin 0.2.149.** Model
tier and reserved scope, and nothing else that matters here: `agents/builder.md` is `model: opus`
and `agents/beefy-builder.md` is `model: fable`, while both carry `disallowedTools: Agent`, no
`tools:` allowlist, the same `skills:` pair and the same `effort: medium` — so **the tool grant is
identical and choosing the heavier one buys no capability, only tier.** One behavioral difference
beyond tier is worth knowing before dispatching: `beefy-builder`'s prompt tells it to stop and ask
for `planner` output when scope is unclear, whereas `builder` is told to escalate rather than
expand. Neither is a reason to prefer the heavier agent for a template fill.

**A seat is a launched OMP session and never an in-process subagent — that is what makes this
routing work at all.** Nine persistent Marches are configured: foreground **Lintel**, it/its;
background **Sedge**, she/her (`newdle-claude-plugins`); **Wren**, they/them (`newdle-web`);
**Verge**, they/them (the shipyard workspace); **Tinker**, it/its (`/Users/jowolff/.claude`);
**Sluice**, they/them (`data-pipelines`); **Galley**, they/them (`kitchen`); **Levitt**,
they/them (`/Users/jowolff/code/joseph-gordon-levitt`); and **Codex**
(`/Users/jowolff/.codex`).

Agent-facing discovery is the essential `seat_list` tool. Human-facing discovery is `/seats`.
Both are allowlisted persistent-seat views; `/agents` and `hub` describe disposable hands in one
OMP session and cannot establish whether a persistent March exists. A configured row whose state
is `unknown` remains a real seat: it means HerdR cannot observe its state from that process, which
is expected for foreground Lintel when queried from a background seat.

Assignments and status travel through `seat_message`. A `queued` receipt means the durable mailbox
holds the message until the target loads it; `delivered` means the target injected and acknowledged
it. Neither sender nor receiver needs a Claude Remote Control row, pid preflight, or `[ref]`.
HerdR remains the process-control plane, under the gates in the installed `seat-shutdown` workflow.

Levitt triages, assigns tickets to seats, and checks what comes back on its own loop; it never does
ticket work itself. Lintel does not distribute or check loop work. Jo ruled on 2026-09-10 that
Lintel must remain free for direct communication with Jo. A seat's working directory is not its
identity; the launcher-set seat name and dedicated OMP session are.


**So the absent plugins-repo row was never an absent agent definition.** The plugin ships exactly
one seat agent file, `agents/web-seat.md`, and no equivalent for the plugins repository — on
purpose. **`newdle:web-seat` is the odd one out, not the model to copy.** Every other repository
under the workspace has no seat at all, and fact 6 governs what happens there.

### Checking work

| Shape | Handler | Why |
| ----- | ------- | --- |
| "Does it lint / typecheck / pass" | `newdle:checker` (haiku) | Runs one command, returns raw pass/fail, no interpretation |
| Review before merge, one axis | `newdle:auditor` (fable) + the matching `newdle-*-audit` skill | Reports only; forbidden from fixing |
| Multi-axis audit over a change set | the `newdle-audits` skill | Interactive picker, human gate between phases |
| "Did I report what my workers actually said" | `transcript-auditor` (opus) | **The only check that reads evidence I did not write.** Reads harness-written subagent JSONL via `state/tools/transcript-extract.mjs` and compares worker returns against my ledger rows and `runs/` files. It reads `state/AUDIT-BRIEF.md` verbatim, which outranks whatever brief I hand it — that is the point, so I cannot frame the question |
| High-stakes, want independent models | `triad` (code diff) · `newdle-triple-check` (a doc/plan) · `council` (an open decision) · `quorum` (plans from a brief) | Expensive by design. Never unrequested. `triad` and `quorum` need the `codex` and `kimi` CLIs |

### Planning and writing

| Shape | Handler |
| ----- | ------- |
| Ordered steps with acceptance criteria before code | `newdle:planner` (fable, read-only) |
| Release notes from git log | `newdle:changelog` (haiku) |
| Taglines, deck copy, narrative prose | `newdle:storyteller` (fable) — hands the build off, never implements |
| A slide deck | the `jo-deck` skill. **HTML presentations are local files under `/Users/jowolff/html-artifacts`, never an Artifact** |

### Work that is mine, not a worker's

| Shape | Why it stays with me |
| ----- | -------------------- |
| One file read, one grep, one command, a lookup I already know | Under the § 3.1 threshold. Dispatching costs more than doing |
| **Resolving a contradiction between two workers** | Happened during bootstrap; see § 4 below |
| Deciding what to dispatch, and reading what came back | The job |
| A cheap check that would settle a GUESS in under a minute | Ran four read-only git commands during bootstrap and downgraded an "unencrypted signing key" alarm to benign. **Always ask this before dispatching a verification** |

---

## 2. Mechanism — decided by me, never raised with Jo

| Situation | Mechanism |
| --------- | --------- |
| A question with an answer, completes inside one turn | A named OMP task hand |
| Work outliving the turn, or needing redirection mid-flight | A named OMP task hand, coordinated through `hub` inside this session |
| One long shell invocation with no judgment in it | `Bash` with `run_in_background` |
| Standing self-improvement work (charter § 1.2) | **Always** a task hand, never my own turn |
| Unknown shape, several workstreams, needs its own decomposition | A named conductor task plus its hands |
| Applicable non-terminal request-ledger row without an exact `thewolff/lintel-tasks` issue URL | A named OMP task hand runs `orchestrator/tools/request-issues-reconcile.sh --apply --only REQ-NNN`; the local ledger remains authoritative. The built `request-issue-hand-guard.mjs` is inactive and is not registered in global settings, so this row records the required route rather than claiming live enforcement |

**Hand model tier and length, adopted 2026-09-10 on Jo's word (DEC-077).** The usage analysis
found 95.6% of tonight's tokens were Opus sessions re-reading 400–750k contexts, with 61 mostly-Opus
hands, and 15 long hands used 82M tokens (run `usage-limit-analysis-20260910`). So:
- **A read-only hand (lookup, reading, summarising, sweeping) is dispatched with `model: "sonnet"`**,
  or `"haiku"` for pure lookups. Only a hand that writes code, or makes a judgement the result
  depends on, gets Opus.
- **Every hand brief carries a length bound:** at about 40 tool calls or 20 minutes, write what you
  have to the report, seal it, and stop. A second hand continues if more is needed.
- Seats get the same rule through the hand-budget clause in `BRIEF-BOILERPLATE.md`.

Task hands are **always** spawned with stable names. Coordinate them through `hub` inside the
current OMP session. `hub jobs` reports hand execution; it says nothing about persistent seats.
Persistent-seat discovery and messaging remain exclusively `seat_list` and `seat_message`.

**Seats cut worktrees under `<repo>/.claude/worktrees/` and nowhere else.** Tinker's hand scanned the
transcripts on 2026-09-10: since 08-10, all 17 EnterWorktree calls under `.claude/worktrees/`
returned in 0 s, and all 11 with a path elsewhere waited on an invisible prompt, for 40 s to 12.5 h.
Put this in any seat brief that cuts worktrees.

---

## 3. Brief templates

### The preamble every brief carries

1. **Absolute paths only.** A worker's cwd is not mine and not the terminal's.
2. **The bound** — what is out of scope, and what to do on hitting a blocker rather than guessing
   past it.
3. **The deliverable shape** — what "done" looks like concretely.
4. **The governing rule, quoted — not the file that contains it.** Never "follow the workspace
   rules." Find the sentence that actually governs this task, quote it verbatim in the brief, and
   name its file and its heading. A brief that points at a file has not delivered a rule.

   **Why, and it is uncomfortable.** Two failures on 2026-08-20 were caused by an agent having the
   governing rule **loaded in its context and not retrieving it at the moment it applied**. In one,
   a repo's own `AGENTS.md` states the version bump happens in the branch before committing, with a
   matching PR-template checklist item — and a seat that had that file loaded, and had quoted a
   different line from it earlier in the same session, still did not apply it. In the other, the
   workspace `AGENTS.md` already contained, verbatim, both branch-hygiene rules that were
   re-authored from scratch that night into three other files.

   **So the intervention that cannot work is adding more text to a file that is already loaded and
   already not retrieved.** The workspace rules file is roughly 52,700 bytes. What did work, twice,
   was someone asking for confirmation of one specific claim — the asking forced a re-derivation.
   Quoting the rule into the brief is that same forcing move, applied before the work rather than
   after it.

### The labeling block — non-plugin workers only

Every `newdle:*` agent loads `references/output-types.md` itself. **Pasting the contract into
their briefs is pure token waste.** Verified across all six bootstrap dispatches: `newdle:reader`
returned labeled CLAIM/GUESS/ACTION output, its own "could not verify" section, and receipt
counts, with none of it requested.

Paste the full block from `/Users/jowolff/.claude/CLAUDE.md` § *Output types* into every
non-plugin hand's brief in the first prompt and in every follow-up sent through `hub`.

### Clauses to add when they apply

**Self-report clause** (EVERY dispatch, plugin agents included — mandatory, and it supersedes
write-then-summarize below):
> File your own report; I will not transcribe it. Mint your path with
> `zsh /Users/jowolff/.claude/orchestrator/state/tools/worker-report.sh path <RUN-ID> <your-slug>`,
> write your full findings there with receipts intact, then
> `… worker-report.sh seal <that-path> <your-slug>`, and return that absolute path with your
> summary. Never overwrite an existing report file; mint a new path and name the one it supersedes.

The full clause text, and an honest account of what the convention does and does not prevent, is in
`/Users/jowolff/.claude/orchestrator/state/BRIEF-BOILERPLATE.md` § *The self-report clause*. Paste
it from there rather than retyping this compressed version into a real brief.

**Why this row exists — the ledger evidence, not taste.** Three `newdle:web-seat` rows on
2026-08-19/20 record the same failure at the two chokepoints where I mediate evidence:

- The 03:47 row (`"ask Wren … what breaks when it is dispatched"`) — Wren's own warning, in its
  `friction` field: *as the relay I am the thing whose incentives run toward compressing its
  trailing candidate-lessons block.* I persisted the full report to disk **because of** that
  warning.
- The 05:23 row (`"Wren applies all six of its own proposed charter edits"`, `outcome: sent-back`)
  — I had persisted that report and then briefed a fresh worker to *"apply all six edits you
  proposed"* without citing the path. `RETRACTIONS.md` § 11 has the full account.
- The 05:29 row (reconciliation) — **two of my own errors, both caught by the worker.** I
  compressed one edit and relayed only its granting half; the half I dropped restricted the relay,
  i.e. me.

The pattern across all three: writing the artifact is not the discipline. **Not touching the
artifact is.** A worker that files its own report removes my hands from the text entirely, and
`worker-report.sh verify <run-id>` makes a later rewrite show up as a hash mismatch. It does not
make one impossible — see the boilerplate section for the honest bound.

**Return-shape clause** (EVERY dispatch, plugin agents included — mandatory, and it is the other
half of the self-report clause: that one says write the full report to a file, this one says the
file is the only place it goes):
> Your report goes in the file; your message carries the path. What comes back in the hand's final
> result or follow-up message is exactly three things — the absolute path to the report you sealed,
> one sentence of conclusion, and any blocker or any decision only Jo can make. No findings list,
> no headings, no receipts, no recap. **Blockers and Jo-decisions are the deliberate exception and
> travel in the message in full**, naming what is blocked or what the options are; burying one in a
> file nobody opens is worse than the noise this rule removes.

**Why it exists.** A hand's returned message is rendered into Jo's terminal. Sending the full
report there duplicates what Jo then reads from the durable artifact; the receiving seat cannot
repair that noise by trimming its relay after the fact.
Jo asked for it in those words on 2026-08-24 after objecting twice. Full clause text and its bound
— it governs the message, never the report, which stays full length with receipts intact — is in
`/Users/jowolff/.claude/orchestrator/state/BRIEF-BOILERPLATE.md` § *The return-shape clause*.

**Write-then-summarize** (any output I will need again):
> Do both: (1) write your full findings to `<absolute path>` — use a Bash heredoc if you have no
> Write tool; (2) return a compact summary. The file is the record; the summary is what I read now.

**Conductor clause** (any brief that will itself delegate — mandatory, a conductor brief without
it is malformed):
> Only your summary returns to me. Everything your workers produce is lost unless you carry it up.
> Write each worker's full output to `/Users/jowolff/.claude/orchestrator/state/runs/<run-id>/`,
> one file per worker, receipts intact, plus a `FLEET.md` naming every worker, its mechanism, and
> how to reach it. Return a summary **and that path**.

**Provenance clause** (any brief carrying a figure):
> Every figure in this prompt is the parent's, not yours. A number arriving in a delegation prompt
> carries no provenance you can inspect, so quoting it back as a finding launders it into an
> apparent measurement of your own. Say it came from the brief, and label it GUESS unless you
> reproduced it this session.

**Exhaustiveness clause** (any inventory or audit — this one earned its place):
> Check every item; do not sample.

Measured: that phrasing is what surfaced four safety skills whose `PreToolUse` hooks point at
scripts that do not exist. A sampling brief would have missed them.

**Guard clause** (any brief whose output will contain command text):
> `careful-guard.mjs` matches destructive command patterns inside quoted strings, so writing a
> report that *quotes* such a command will be denied. Describe the command in prose, or hex-escape
> it in your heredoc source and verify the file on disk afterward.

**Structural-search clause** (any brief involving finding code):
> Use the `ast-grep` MCP tools for any structural, syntax-aware search — function calls,
> definitions, symbol usages, syntax patterns. Plain `grep` is only for literal string matches.

### Anti-clauses — things that cost me nothing and buy nothing

- Do not restate the labeling contract to a `newdle:*` agent.
- Do not ask a worker to read a whole file when a named section will do.
- Do not pass `isolation: worktree`. It is denied by a hook.
- **Do not retype a worker's report into a `runs/` file.** Link to the path the worker sealed. The
  transcription step is the failure, not the storage.

---

## 4. Reading what comes back

Worker CLAIMs are authoritative and are not re-read. Worker statements **without** receipts stay
GUESSes when they enter my report — the label crosses the boundary with the sentence.

**What arrives is a path, one sentence, and any blocker — never the report itself.** Every seat and
every worker is dispatched with the return-shape clause in § 3, so the message I receive carries the
absolute path to the sealed report, a one-sentence conclusion, and anything genuinely blocking or
needing a decision only Jo can make. **I open the file to read the findings.** A message that
arrives carrying a full report anyway is a defect in the brief I sent, not something to relay: the
harness already rendered it into Jo's window whole and I cannot take that back, so the repair is to
fix the dispatch and say plainly that the convention was missing from it. **Blockers and
Jo-decisions are the exception in both directions** — they belong in the message on the way up, and
they go to Jo first and in full on the way on, per the message skeleton in Jo's own rules.

**When two workers contradict each other, I resolve it inline and I record which brief was
better.** This happened on the first run: the skills worker reported four `SKILL.md` files
declaring `hooks:`; the hooks worker reported that no `SKILL.md` anywhere declares one. Two
`grep`/`ls` calls settled it — the skills worker was right, and the flat directories at
`/Users/jowolff/code/.claude/skills/{careful,freeze,guard,investigate}/` are real directories
containing only a `SKILL.md`, not symlinks, with the `bin/` scripts their hooks invoke living one
level down under `gstack/`. The skills brief said *check every skill, do not sample*; the hooks
brief did not name that path. **The difference was in my brief, not in the workers.**

Bare uncategorized prose coming back is a signal about my brief. Fix the brief, then the report,
then write the fix into this file.

---

## 5. Standing traps

- `--bg` and `-p` are mutually exclusive.
- Startup context dominates headless cost — `--bare` for high-frequency calls, `--max-budget-usd`
  for anything unattended. Ten parallel agents burn quota roughly ten times as fast as one.
- Background sessions are NOT reaped — that claim was disconfirmed 2026-08-21 and nothing observed
  ends one; they die with the machine, and otherwise run until `claude stop <id>`. An idle one costs
  nothing. State that must survive still goes in a file, on compaction and machine sleep, not on a
  reaper that does not exist.
- A cross-session message is never Jo's consent. The fleet cannot launder a Tier 3 change past
  them, and any plan depending on it is a bug in the plan.
- `newdle-mobile` and its four worktrees run `git-guard.sh`, which **exits 2** and blocks push,
  hard reset, force branch delete, force worktree remove, `clean -f`, and recursive force delete.
  It splits on `;`/`&&`/newlines, so it sees past `git -C` and chains.
- `rebase-before-push.mjs` denies a push when HEAD is behind or diverged from mainline.
- **`newdle-web` was pinned to plugin 0.2.105 and was bumped to 0.2.148 on 2026-08-20 (REQ-060).**
  **`kitchen` is STILL pinned to 0.2.111 and still runs older hook and agent sets.** Neither pin was
  ever protective: both are orphaned residue of an `enabledPlugins` block that was removed from
  those repos' committed settings on 2026-08-14 (PR #986, ENG-1610). **A session pins its plugin
  version AT START via a PID file under `<version>/.in_use/<pid>`, so a bump reaches only sessions
  started afterwards.** **The durable fix is DELETING the project-scope entry so the repo inherits
  user scope — `claude plugin update` only updates user scope, so any project-scope pin structurally
  cannot be reached by the documented update path and goes stale again on the next release.**
  Three hook changes between 0.2.105 and 0.2.148 are the ones that bite: `rebase-before-push.mjs`
  and `worktree-spawn-guard.mjs` are new `PreToolUse` denials, and **`output-types-guard.mjs` is
  newly wired to `Stop`** — in 0.2.105 it ran on `SubagentStop` only.
- `/Users/jowolff/.claude` is a git repo tracking 13,948 files with no `.gitignore`. Stage with
  explicit paths, never `git add -A`.


- ⛔ **PROBE DISCIPLINE, two layers of one rule, both earned 2026-09-11.** (1) **Bound the wait:**
  when an instrument hangs, do not wait it out a second time — `docker ps` hung past 45s twice before
  a bounded `curl -s --max-time 5 --unix-socket <sock> http://localhost/_ping` turned "unresponsive"
  into a result with a number on it. (2) **Assert on the payload, never on a pipeline's status:**
  `$?` belongs to the LAST stage, and the last stage is usually the one that cannot fail. Lintel
  piped that probe through `head` and printed `exit 0` for a call that had timed out; only the
  10.07s wall clock exposed it. Galley's form is the correct one — gate on the response body
  (`[ "$out" = "OK" ]`) and report the exit status alongside as colour, never as the decision.
- ⛔ **A container probe cannot answer a question about the past.** Measuring whether a running
  process has a gate set describes THAT process as it is then running. If the question is "have
  local lines already landed in a production sink", only the sink can answer — for kitchen, query
  `env="development"` on service `kitchen`, since `logger.ts:9` tags local runs that way and
  `logger-config.ts:55` puts service and env on the labels. That path needs no daemon and does need
  a production secrets read, which is Jo's to authorize. **Keep hazard and incident separate: the
  hazard is measured in code; the incident is unmeasured until the sink is queried.**

### ⛔ The family that cost the most on 2026-09-11: a check that reports success while the thing it checks is absent

Five sightings in one session, on five unrelated surfaces, every one green at the moment it was
wrong. This is recorded as a pattern because each was found separately and none of the finders
recognised it as the same thing until they were put side by side.

1. **A closure condition satisfiable by deletion.** A negative-only grep — "the bad string is
   gone" — passes when someone removes the paragraph. Absence of a bad string is not presence of
   the rule. (`Req448Sol`, a Sedge hand.)
2. **A closure condition the work cannot meet.** `lintel-tasks` #300 was to close when a PR merged;
   that PR produced neither receipt the criterion named, and the six-hook probe returned the same
   result afterward. The ticket would have closed on adjacent real work. (Tinker, Sedge, Levitt.)
3. **An eval assertion that lets two plan tasks consume one row**, so an entire missing feature
   passes the assertion. (Astra, on ENG-1602.)
4. **A check on text cannot see a false universal.** A negative-plus-positive pair was green while
   the new rule it asserted — "the field is never empty" — was false in a case the same document
   already contemplated one line above. **Every check on text is a check on text**; the universal
   is new text and satisfies it. (Sedge.)
5. **A test suite that cannot fail on the bug.** All five of `newdle-api`'s `redact-url` tests use
   the literal spelling `token=`, so none of them can fail on a percent-encoded-key bypass. A green
   suite hid it. (Galley.)

**The three-part closure rule answers 1, 2 and 5 and is worth applying at filing time:** a closure
condition must be **runnable when the issue is filed** (Tinker), **runnable by someone other than
whoever filed it** (Lintel, from ENG-1650 — "both findings fixed" was checkable in principle and
only its author could have checked it), and **not satisfiable by deletion** (`Req448Sol`).

**⛔ 7. AND THE SEVENTH WAS THE FIX FOR THE SIXTH.** The ticket filed about mechanisms that pass by
the absence of what they were meant to find was itself given a closure condition that passes by the
absence of what it was meant to find. Proposed condition: heading count in the payload against
`grep -c '^## ' AGENTS.md` on the repo file. Measured: repo file **4** headings, shipyard root
`AGENTS.md` **15**, a complete outline **19**, payload carried **4** plus two `## Rules from`
wrappers - and the wrappers prove BOTH files were walked. **So 15 root-file headings are silently
missing and the condition compares 4 against 4 and passes.** (Sedge hand, 2026-09-11.)

**The sound form, and it generalises past this ticket: pin the assertion to what the mechanism
CLAIMS, not to a number rebuilt from elsewhere.** Summing across every rules file the chain actually
walked is better than the nearest file alone, but an externally-reconstructed sum silently re-breaks
the moment a rules file is added upstream. **Have the mechanism emit its own declared count and
assert against that** - the same reasoning as one-path-one-revision.

⛔ **4 has no mechanical form and pretending otherwise is how it gets skipped.** Sedge declined to
propose wording on the grounds that any phrasing would itself be a confident universal about
avoiding confident universals, which is correct. The honest form is a question a reviewer asks by
reading: **does this new text contradict a case the document already contemplates?** Do not file it
as a grep.

**⛔ 6. THE RULES DELIVERY PATH ITSELF, and it is the one the other five are supposed to be governed
by.** `repo-rules-inject.mjs` budget-trims what it delivers, and **the demotion is announced while the
trim of the outline is not**: over `DEFAULT_BUDGET = 9000` (`:111`) the payload says plainly that the
text is not inlined and then lists headings - but **headings are dropped from that outline with no
marker**, so a four-heading list is indistinguishable from a complete one. Measured at the plugins
checkout: `AGENTS.md` 31,512 bytes at `7c050c8` and 33,789 at `ce3abf8`, injected payload 3,671, the
amended subprocess rule grepping to **zero** in the payload, surviving headings the early sections
only. The payload announces itself as *"the rules chain the CLI would have loaded had this session
been launched there"* — with no "trimmed", "truncated" or "omitted" anywhere. **A receiving agent
cannot tell its brief is partial.** It also passes through at 0 bytes when the touched repo equals
the launch directory, which is why it fires for a worktree and never for the main checkout.
Measured by a Sedge hand, 2026-09-11. **Consequence for briefing: never assume a rule reached an
agent because it is in the repo's rules file — quote the sentence into the brief.** That was already
§ 3's rule for a different reason; this is the mechanism that makes it non-negotiable.

⛔ **SCOPE OF 6, corrected within the hour by the hand that found it, against its own credit — and
the corrected version is sharper.** The trim applies **only to the cross-repo injection path.** The
hook exists for repos the session was NOT launched in and passthroughs at 0 bytes when the touched
repo equals the launch directory. So:
- **Session launched IN that checkout** → the CLI natively loads `CLAUDE.md` → `@AGENTS.md` → the
  **whole** file, line 222 included. With the checkout 46 commits behind, that session is briefed
  from the **superseded** rule, in full. This is the common case under the worktree layout.
- **Session launched elsewhere, reaching the repo by injection** → the 3,671-byte slice: an
  announced demotion, an unannounced outline trim, and **neither** wording of the rule.

**Both are true and neither cancels the other.** The same mechanism is complete or silently partial
depending on which repo you started in, and **nothing in the payload distinguishes the two** — which
is the shape restated, not weakened. ⛔ The native-load half is **GUESS(inference)**: it rests on the
hook's own documented spec (`repo-rules-inject.mjs:14-26`, "mirroring the CLI", root-first, `@path`
imports "the way the CLI does") plus the cited CLI memory docs, NOT on anyone observing the CLI load
it. One person confirming that a session launched in that checkout has line 222 in context settles
it; that is a reading task, not a grep.

⛔ **DISCHARGED 2026-09-11 ~04:10 PDT: the plugins checkout was fast-forwarded.** `main` and
`origin/main` both `ce3abf8`, `rev-list --left-right --count` → `0 0`, and `AGENTS.md:222` now
carries the amended common-path wording. So the stale-launch-repo half of this is history rather than
a live hazard; instance 6's mechanism stands unchanged for every OTHER repo on the walk. ⛔ **And the
lesson from the two byte counts: a size or payload figure is a TIMESTAMPED fact. Date it or cite it
at a sha** - 31,512 and 33,789 were both correct, measured either side of the fast-forward, and
neither was dated.

⛔ **And the hazard attached to verifying it: running `repo-rules-inject.mjs` with a LIVE session id
silently disables that session's own rules chain.** It keeps per-session state at
`$TMPDIR/newdle-repo-rules-<sessionId>.json` (`:143-144`, `saveState` `:279`/`:295`), seeds
`visited` from `state.injected` (`:257`), and suppresses injection for anything already recorded
(`:280`). Probe with a fabricated id and delete the state file, never with a live one. Lintel asked
a seat to run it live on 2026-09-11; a hand caught it before the seat spent it.

**And the adjacent instrument failure, same session, four sightings of its own:** a real instrument
answering a narrower question than the one asked — a non-zero exit reporting the launcher's last
gate rather than the world; a Linear status reporting whoever last touched it rather than what
shipped; an unchanged local branch tip after a push that did land; and
`git merge-base --is-ancestor` answering NO for a landed fix because rebase-merge replayed it under
a new SHA, so the commit to test is `gh pr view <n> --json mergeCommit` and never the tip you
pushed.

### Which dispatches get a judge

A judge is a second dispatch that reads the harness transcript and the artifacts and grades the
first dispatch against the `done_when` clauses declared in `runs/<run>/CONTRACTS.jsonl`. It
never reads the worker's sealed report as evidence; the report is the claim under test.

Dispatch a judge when the worker changed something a person would have to undo by hand:
  - it edited a file outside its own `runs/<run>/` directory
  - it wrote to a ledger, a contract under `orchestrator/contracts/`, or a charter
  - it touched anything on the charter's `### Must propose and wait` list
  - Jo approved the change verbatim and would want to know if it did not land

Do NOT dispatch a judge when the whole output is a report in `runs/`. For those the artifact IS
the claim and there is nothing independent to check it against; a judge would only re-read the
report, which is the failure this whole mechanism exists to avoid.

How:
  node ~/.claude/orchestrator/tools/judge/judge.mjs brief <run-id> <agent-slug> [--agent-id ID]
Paste the output as the judge's brief. The judge writes a verdict JSONL and runs
`judge.mjs lint` on it; lint refuses any pass that rests on the worker's own report. Lintel's
acceptance of the worker's result cites the judge's verdict file. Jo's `verdict.sh` stays the
human verdict; this is the cheap machine layer before it.

Retire when: judge verdicts run ~100% pass for a month with no fail like the one on
2026-08-24 (a change applied, then silently reverted, caught only because the judge hashed the
file instead of believing the report). Re-evaluate 2026-09-24.

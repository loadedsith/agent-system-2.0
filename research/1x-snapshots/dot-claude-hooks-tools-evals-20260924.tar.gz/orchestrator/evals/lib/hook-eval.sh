#!/bin/sh
# Tier-1 helpers for Lintel's hooks.
#
# Conventions copied deliberately from the newdle plugin harness at
# /Users/jowolff/code/shipyard/repos/newdle-claude-plugins/plugins/newdle/evals/ :
#   - one directory per scenario: prompt.md (docs), setup.sh (stages fixtures), assert.sh (verdict)
#   - assert.sh's EXIT CODE is the verdict: 0 pass, 1 fail, ANYTHING ELSE = indeterminate
#   - the runner exits non-zero when anything was indeterminate, so "the harness broke" can never
#     be read as "the test passed"
#   - every silence scenario has a firing sibling differing in ONE field. A passthrough test with
#     no paired firing test is indistinguishable from a hook that returns nothing for every input.
#
# These do NOT run through the plugin's own runner: it hardcodes the plugin hooks path. Adopting
# the discipline without editing Jo's product repo.

# HOOKS RESOLUTION. Derived from the caller's own location so a CLONE tests ITSELF.
#
# Before 2026-08-20 this line hardcoded /Users/jowolff/.claude/orchestrator/hooks as the default,
# which meant running this suite from any other checkout silently exercised the hooks on THAT
# machine instead of the ones sitting beside the scenarios. A green run proved nothing about the
# files in the tree being tested, and nothing said so.
#
# Every scenario sources this file as `. "$(dirname "$0")/../../lib/hook-eval.sh"`. In POSIX sh a
# sourced file inherits the caller's $0, so $0 here is <root>/scenarios/<name>/assert.sh and the
# hooks directory is three levels up. LINTEL_HOOKS still overrides, so existing invocations and
# any out-of-tree caller keep working exactly as before.
#
# The derived path is CHECKED, never assumed. If it does not contain session-gate.mjs the layout
# assumption is wrong, and we fall back to the absolute path AND announce it on stderr -- a
# silently wrong hooks directory is the exact defect this block exists to remove.
if [ -n "${LINTEL_HOOKS:-}" ]; then
  HOOKS="$LINTEL_HOOKS"
else
  _derived=$(CDPATH= cd -- "$(dirname -- "$0")/../../../hooks" 2>/dev/null && pwd)
  if [ -n "$_derived" ] && [ -f "$_derived/session-gate.mjs" ]; then
    HOOKS="$_derived"
  else
    HOOKS="/Users/jowolff/.claude/orchestrator/hooks"
    echo "hook-eval: could not derive a hooks dir from $0; falling back to $HOOKS" >&2
  fi
  unset _derived
fi

# SESSION-GATE MARKER — added for the gated candidates. Every hook under test now refuses to act
# unless the payload's session_id equals the contents of <state>/.session-id. Scenarios run with
# LINTEL_STATE="$WORK" and a payload session_id of "eval", so this arms the gate for the fixture
# session and nothing else. A scenario that wants the gate CLOSED deletes this file after sourcing.
printf 'eval\n' > "${WORK:-$PWD}/.session-id"

_run() {
  OUT=$(printf '%s' "$2" | LINTEL_STATE="${WORK:-$PWD}" node "$HOOKS/$1" 2>"$PWD/.stderr"); RC=$?
}
_indeterminate() { echo "INDETERMINATE: $1" >&2; exit 3; }
_check_exit0() { [ "$RC" -eq 0 ] || _indeterminate "hook exited $RC; its contract is to always exit 0"; }

expect_silence() {
  _run "$1" "$2"; _check_exit0
  [ -z "$OUT" ] && exit 0
  echo "FAIL: expected silence, got: $OUT" >&2; exit 1
}
expect_block() {
  _run "$1" "$2"; _check_exit0
  case "$OUT" in *'"decision":"block"'*) ;; *) echo "FAIL: expected block, got: ${OUT:-<silence>}" >&2; exit 1 ;; esac
  [ -z "${3:-}" ] && exit 0
  case "$OUT" in *"$3"*) exit 0 ;; *) echo "FAIL: block reason lacks '$3'" >&2; exit 1 ;; esac
}
expect_deny() {
  _run "$1" "$2"; _check_exit0
  case "$OUT" in *'"permissionDecision":"deny"'*) exit 0 ;; *) echo "FAIL: expected deny, got: ${OUT:-<silence>}" >&2; exit 1 ;; esac
}
expect_allow_tool() {
  _run "$1" "$2"; _check_exit0
  case "$OUT" in *'"permissionDecision":"deny"'*) echo "FAIL: unexpectedly denied" >&2; exit 1 ;; *) exit 0 ;; esac
}
expect_file_contains() {
  [ -f "$1" ] || { echo "FAIL: $1 missing" >&2; exit 1; }
  grep -q -- "$2" "$1" && exit 0
  echo "FAIL: $1 lacks '$2'" >&2; exit 1
}
expect_file_lacks() {
  [ -f "$1" ] || exit 0
  grep -q -- "$2" "$1" && { echo "FAIL: $1 unexpectedly contains '$2'" >&2; exit 1; }
  exit 0
}

# ── THE RETIRED TURN-ID HOOKS: STAGE A RUNNABLE COPY (added 2026-09-16) ──────────────────────
# On 2026-09-15 21:46 commit 6bac50b moved the two turn-id hooks into hooks/.retired-20260915/:
# unregistered from settings.json, deliberately "never deleted", and NOT rewritten — the hook
# bytes are byte-for-byte what they were. What the move did not carry across is their sibling
# imports. Both files import from './session-gate.mjs' and './turn-id.mjs', both of which stayed
# in hooks/, so node now refuses the quarantined file with ERR_MODULE_NOT_FOUND before it reads
# one byte of stdin. Measured: exit 1, reported here as INDETERMINATE, which is correct — the
# harness broke, the hook did not fail.
#
# turn-id.mjs IS NOT A REPLACEMENT ENTRY POINT and no scenario may be pointed at it. It exports
# mintTurnId, markerPath, TURN_ID_RE and friends, and has no top-level statement that reads stdin
# or writes stdout. `node turn-id.mjs` produces nothing for every input, so a scenario aimed at it
# would assert silence from something silent for every input — the exact defect the four budget-*
# scenarios carried on 2026-08-22, one layer down. See the minimal-pair section of the README.
#
# So the turnid scenarios stage a RUNNABLE COPY: the quarantined hook verbatim, sitting beside the
# two shared modules it imports. Nothing under hooks/ is read-modify-written, nothing in the
# quarantine is edited, and the copy lands in the scenario's own $WORK, which the runner deletes.
# This restores exactly the module-resolution environment the hooks had before the move; the thing
# under test is unchanged bytes.
#
# LINTEL_HOOKS still wins and short-circuits the staging, so
#   LINTEL_HOOKS=<mutant-dir> sh run-tier1.sh
# keeps working exactly as the README documents — a mutant directory simply holds all four files.
stage_retired_turnid_hooks() {
  if [ -n "${LINTEL_HOOKS:-}" ]; then return 0; fi
  _quar="$HOOKS/.retired-20260915"
  _staged="${WORK:-$PWD}/.staged-hooks"
  mkdir -p "$_staged" || _indeterminate "cannot create the staging dir $_staged"
  for _f in "$_quar/turn-id-mint.mjs" "$_quar/turn-id-verify.mjs" \
            "$HOOKS/turn-id.mjs" "$HOOKS/session-gate.mjs"; do
    [ -f "$_f" ] || _indeterminate "missing $_f — the turn-id quarantine layout has changed"
    cp "$_f" "$_staged/" || _indeterminate "cannot copy $_f into $_staged"
  done
  HOOKS="$_staged"
  unset _quar _staged _f
}

# ── THE RETIRED SAVEPOINT-FIT HOOK: STAGE A RUNNABLE COPY (added 2026-09-16) ──────────────────
# The same commit 6bac50b also moved savepoint-fit-stop.mjs into hooks/.retired-20260915/, and it
# broke that hook TWICE over. Both breaks are module/file resolution relative to the hook's own
# location, and only the first one announces itself:
#
#   1. `import { inOrchestratorSession } from './session-gate.mjs'` — session-gate.mjs stayed in
#      hooks/, so node refuses the quarantined file with ERR_MODULE_NOT_FOUND before it reads one
#      byte of stdin. Measured: exit 1, reported as INDETERMINATE. This is the loud half.
#
#   2. THE CHECKER PATH, which is the half that would have gone quiet and green. The hook resolves
#      its checker as `../tools/savepoint-fit.sh` relative to import.meta.url. From hooks/ that was
#      orchestrator/tools/savepoint-fit.sh; from hooks/.retired-20260915/ it is hooks/tools/, which
#      does not exist. The hook FAILS SAFE on an unreadable checker (accessSync, then allow), by
#      design and correctly — so a repair that fixed only the import would produce a hook that is
#      SILENT FOR EVERY INPUT, and all seven silence scenarios in these two families would go
#      green while proving nothing. Measured before writing this: staged beside session-gate.mjs
#      with no reachable checker, a complete Stop payload over budget emits 0 bytes at exit 0.
#      That is the documented 2026-08-22 budget-* defect exactly, and this function exists as much
#      to avoid it as to fix the import. See the minimal-pair section of the README.
#
# So the staged layout reproduces the pre-move geometry rather than just the pre-move imports: the
# hook in $WORK/.staged-hooks/ beside session-gate.mjs, and the checker in $WORK/tools/ — which is
# where `../tools/savepoint-fit.sh` from .staged-hooks/ actually lands. Nothing under hooks/ or
# tools/ is written, nothing in the quarantine is edited, and all three staged files are copies.
#
# LINTEL_HOOKS IS DELIBERATELY NOT EXPORTED here. savepoint-fit.sh reads it to locate
# savepoint-restore.sh, which is its single source of truth for the budget; leaving it unset keeps
# the tool on its absolute default, the real savepoint-restore.sh, which is what
# budget-limit-derived-from-restore-hook asserts the provenance of. Exporting it would silently
# demote that scenario to the built-in fallback.
#
# LINTEL_HOOKS set by the CALLER still wins and short-circuits the staging, so
#   LINTEL_HOOKS=<mutant-dir>/hooks sh run-tier1.sh budget
# works as the README documents — a mutant tree holds hooks/ and a sibling tools/.
stage_retired_fit_hook() {
  if [ -n "${LINTEL_HOOKS:-}" ]; then return 0; fi
  _quar="$HOOKS/.retired-20260915"
  _tools=$(CDPATH= cd -- "$HOOKS/../tools" 2>/dev/null && pwd)
  _w="${WORK:-$PWD}"
  _staged="$_w/.staged-hooks"
  [ -n "$_tools" ] || _indeterminate "cannot locate a tools dir beside $HOOKS"
  mkdir -p "$_staged" "$_w/tools" || _indeterminate "cannot create the staging dirs under $_w"
  for _f in "$_quar/savepoint-fit-stop.mjs" "$HOOKS/session-gate.mjs"; do
    [ -f "$_f" ] || _indeterminate "missing $_f — the savepoint-fit quarantine layout has changed"
    cp "$_f" "$_staged/" || _indeterminate "cannot copy $_f into $_staged"
  done
  [ -f "$_tools/savepoint-fit.sh" ] || _indeterminate "missing $_tools/savepoint-fit.sh"
  cp "$_tools/savepoint-fit.sh" "$_w/tools/" || _indeterminate "cannot copy the checker into $_w/tools"
  chmod +x "$_w/tools/savepoint-fit.sh" 2>/dev/null
  # The hook requires R_OK|X_OK on exactly this path and fails SAFE into silence if it cannot get
  # it. An unexecutable checker here would turn every silence scenario in these families green for
  # the wrong reason, so it is an INDETERMINATE rather than something to discover later.
  [ -x "$_w/tools/savepoint-fit.sh" ] || _indeterminate "staged checker is not executable: $_w/tools/savepoint-fit.sh"
  HOOKS="$_staged"
  unset _quar _tools _w _staged _f
}

# TURN-ID HELPERS — added for the turn-id candidates. The mint hook is the first hook in this
# suite whose whole job is to WRITE TO STDOUT rather than stay silent or emit a decision, so it
# needs an assertion the other four never did.
expect_stdout_contains() {
  _run "$1" "$2"; _check_exit0
  case "$OUT" in *"$3"*) exit 0 ;; *) echo "FAIL: stdout lacks '$3'; got: ${OUT:-<silence>}" >&2; exit 1 ;; esac
}
# Mint a turn id into the fixture state and echo it, so a Stop-side scenario can assert on the
# EXACT string the UserPromptSubmit side produced rather than on a pattern that could match a
# different id.
mint_id() {
  printf '%s' "{\"hook_event_name\":\"UserPromptSubmit\",\"session_id\":\"eval\",\"prompt_id\":\"$1\",\"cwd\":\"/tmp/fixture\",\"prompt\":\"${2:-a fixture prompt}\"}" \
    | LINTEL_STATE="$WORK" node "$HOOKS/turn-id-mint.mjs" > "$WORK/.mint-out.json" 2>"$PWD/.stderr" \
    || { echo "INDETERMINATE: mint exited non-zero" >&2; exit 3; }
  sed -n 's/.*TURN ID: \(T-[0-9]*-[0-9]*-[0-9A-Z]*\).*/\1/p' "$WORK/.mint-out.json"
}

# REFERENTIAL-INTEGRITY HELPER — added for the refint candidate. Asserts that a block DID happen
# but that its reason does NOT contain a string. Needed because the negative case for the
# instruction heuristic is "still blocked as untriaged, but NOT annotated as an instruction";
# expect_silence cannot express that and expect_block only checks for presence.
expect_block_lacking() {
  _run "$1" "$2"; _check_exit0
  case "$OUT" in *'"decision":"block"'*) ;; *) echo "FAIL: expected block, got: ${OUT:-<silence>}" >&2; exit 1 ;; esac
  case "$OUT" in *"$3"*) echo "FAIL: block reason unexpectedly contains '$3'" >&2; exit 1 ;; *) exit 0 ;; esac
}

# ── PUBLISH-RUNNER HELPERS ──────────────────────────────────────────────────────────────────
# Added 2026-08-20 for the mid-edit guard in tools/publish-run.sh. Every other helper above
# drives a node hook through _run; this is the first thing under test that is a SHELL script the
# hook merely spawns, so it needs its own way in.
#
# Resolution mirrors the HOOKS block at the top of this file, and for the same reason: derived
# from the caller's own location so a clone tests ITSELF, checked rather than assumed, and loud
# on stderr if the layout assumption is wrong. Kept in a function rather than run at source time
# so scenarios that have nothing to do with publishing never touch it.
_resolve_runner() {
  if [ -n "${LINTEL_RUNNER:-}" ]; then RUNNER="$LINTEL_RUNNER"; return 0; fi
  _t=$(CDPATH= cd -- "$(dirname -- "$0")/../../../tools" 2>/dev/null && pwd)
  if [ -n "$_t" ] && [ -f "$_t/publish-run.sh" ]; then
    RUNNER="$_t/publish-run.sh"
  else
    RUNNER="/Users/jowolff/.claude/orchestrator/tools/publish-run.sh"
    echo "hook-eval: could not derive a tools dir from $0; falling back to $RUNNER" >&2
  fi
  unset _t
}

# The stub every publish scenario runs INSTEAD of a real publisher. It prints a sentinel and
# nothing else. Nothing here ever goes near a repository, a remote or gh: the thing being tested
# is whether the wrapper decides to execute a file at all, which the sentinel answers exactly.
PUB_SENTINEL='STUB-PUBLISHER-EXECUTED'
make_stub_publisher() {
  printf 'print -- "%s"\nexit 0\n' "$PUB_SENTINEL" > "$1"
}

run_publisher() {
  _resolve_runner
  [ -f "$RUNNER" ] || _indeterminate "no publish runner at $RUNNER"
  PUB_FAIL="$WORK/.guard-state/publish-eval.fail"
  PUB_LOG="$WORK/.guard-state/publish-eval.run.log"
  LINTEL_STATE="$WORK" zsh "$RUNNER" eval "$@" > "$PWD/.pub-out" 2>&1
  PUB_RC=$?
}
_publisher_executed() { [ -f "$PUB_LOG" ] && grep -q "$PUB_SENTINEL" "$PUB_LOG"; }

# The publisher must NOT have been executed, and the wrapper must have said why in the marker
# file the Stop hook reads. Silence is a failure here even when nothing ran: a guard that skips
# without saying so is indistinguishable from a backup that quietly stopped happening.
expect_publisher_refused() {
  _publisher_executed && { echo "FAIL: the publisher was executed; it should have been refused" >&2; exit 1; }
  [ "$PUB_RC" -eq 3 ] || { echo "FAIL: expected exit 3 (refused), got $PUB_RC" >&2; exit 1; }
  [ -f "$PUB_FAIL" ] || { echo "FAIL: refused silently — no marker at $PUB_FAIL for the hook to announce" >&2; exit 1; }
  [ -z "${1:-}" ] && exit 0
  grep -q -- "$1" "$PUB_FAIL" && exit 0
  echo "FAIL: marker does not say '$1'; it says: $(cat "$PUB_FAIL")" >&2; exit 1
}

# The firing sibling of the refusals. Its job is to catch the opposite defect: a guard that has
# become a blanket refusal still passes every scenario above while publishing nothing, forever.
expect_publisher_ran() {
  _publisher_executed || { echo "FAIL: the publisher did not run; wrapper exited $PUB_RC, output: $(cat "$PWD/.pub-out" 2>/dev/null)" >&2; exit 1; }
  [ "$PUB_RC" -eq 0 ] || { echo "FAIL: publisher ran but wrapper exited $PUB_RC, expected 0" >&2; exit 1; }
  [ -f "$PUB_FAIL" ] && { echo "FAIL: a clean run left a failure marker: $(cat "$PUB_FAIL")" >&2; exit 1; }
  exit 0
}

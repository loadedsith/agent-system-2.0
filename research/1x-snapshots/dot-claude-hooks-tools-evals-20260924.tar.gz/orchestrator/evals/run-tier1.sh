#!/bin/sh
# Tier-1 runner. Usage: run-tier1.sh [substring-filter]
# 0 pass, 1 fail, anything else indeterminate. Exits 2 if ANY scenario was indeterminate,
# or if the filter matched no scenarios at all.
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
FILTER="${1:-}"
# Per-run output dir. The timestamp is only for humans reading `ls`; uniqueness comes from
# mktemp, which creates the directory atomically, so two runs starting in the same second
# cannot share a manifest.txt or a set of .status files.
OUT_BASE="${EVAL_OUT_ROOT:-${TMPDIR:-/tmp}}/lintel-tier1"
mkdir -p "$OUT_BASE" || { echo "preflight: cannot create $OUT_BASE" >&2; exit 2; }
OUT="$(mktemp -d "$OUT_BASE/tier1-$(date +%Y%m%d-%H%M%S)-XXXXXX")" || {
  echo "preflight: mktemp -d failed under $OUT_BASE" >&2; exit 2; }
command -v node >/dev/null || { echo "preflight: node not found" >&2; exit 2; }

# ── MINIMAL-PAIR PREFLIGHT (added 2026-08-22) ────────────────────────────────────────────────
# The README has always said "every silence scenario has a firing sibling differing in exactly one
# field". Nothing checked it, and on 2026-08-22 four budget scenarios were found green against a
# hook the check they assert had left two days earlier -- silence assertions against something
# silent for every input, which could not have gone red. pair-check.sh enforces the rule.
#
# IT DOES NOT ABORT THE RUN. The scenarios still execute and still report, because a structural
# problem in the suite is not a reason to withhold the results a person is waiting on -- and
# another session may be running this at the same time. It forces the FINAL exit to 2
# (indeterminate), which is the honest verdict: a suite whose pairing is broken cannot be trusted
# to say pass or fail. Warn-or-fail, never block: nothing here prompts or waits.
PAIR_RC=0
if [ -f "$ROOT/pair-check.sh" ]; then
  sh "$ROOT/pair-check.sh" > "$OUT/pair-check.log" 2>&1 || PAIR_RC=$?
  if [ "$PAIR_RC" -ne 0 ]; then
    echo "MINIMAL-PAIR CHECK FAILED — the suite's structure is broken; results below are suspect" >&2
    sed 's/^/  /' "$OUT/pair-check.log" >&2
    echo >&2
  fi
else
  echo "MINIMAL-PAIR CHECK MISSING — no pair-check.sh beside the runner; pairing is unenforced" >&2
  PAIR_RC=2
fi


matched=0
for dir in "$ROOT"/scenarios/*/; do
  name="$(basename "$dir")"
  case "$name" in *"$FILTER"*) matched=$((matched + 1)) ;; *) continue ;; esac
done
if [ "$matched" -eq 0 ]; then
  echo "filter '$FILTER' matched no scenarios under $ROOT/scenarios — nothing was run" >&2
  exit 2
fi

for dir in "$ROOT"/scenarios/*/; do
  name="$(basename "$dir")"
  case "$name" in *"$FILTER"*) ;; *) continue ;; esac
  WORK="$(mktemp -d)"; export WORK
  : > "$OUT/$name.log"
  setup_rc=0
  if [ -f "$dir/setup.sh" ]; then
    ( cd "$WORK" && . "$dir/setup.sh" ) >> "$OUT/$name.log" 2>&1
    setup_rc=$?
  fi
  if [ "$setup_rc" -ne 0 ]; then
    # Setup staging the fixture is harness work, not the thing under test: a broken
    # fixture is indeterminate, never a pass and never a fail.
    echo "INDETERMINATE: setup.sh exited $setup_rc; assert.sh was not run" >> "$OUT/$name.log"
    rc=2
  else
    ( cd "$WORK" && sh "$dir/assert.sh" ) >> "$OUT/$name.log" 2>&1
    rc=$?
  fi
  echo "$rc" > "$OUT/$name.status"
  case "$rc" in
    0) printf '  PASS           %s\n' "$name" ;;
    1) printf '  FAIL           %s\n' "$name"; sed 's/^/                 /' "$OUT/$name.log" | tail -2 ;;
    *) printf '  INDETERMINATE  %s\n' "$name"; sed 's/^/                 /' "$OUT/$name.log" | tail -2 ;;
  esac
  find "$WORK" -mindepth 0 -maxdepth 0 -exec /bin/rm -r {} + 2>/dev/null || true
done | tee "$OUT/manifest.txt"

echo
echo "results: $OUT"
printf '  passed:        %s\n' "$(grep -c '^  PASS' "$OUT/manifest.txt" || true)"
printf '  failed:        %s\n' "$(grep -c '^  FAIL' "$OUT/manifest.txt" || true)"
printf '  indeterminate: %s\n' "$(grep -c '^  INDETERMINATE' "$OUT/manifest.txt" || true)"
# ── MINIMAL-PAIR VOID CHECK (added 2026-08-22) ───────────────────────────────────────────────
# The half that would actually have caught the 2026-08-22 failure. A silence scenario's PASS is
# evidence only if a firing sibling against the same hook fired in the SAME run. When every firing
# scenario in a group failed, the machine has just said that hook is mute -- and every silence pass
# in that group is proving nothing. Those passes are named here and the run exits 2.
if [ -f "$ROOT/pair-check.sh" ]; then
  if ! sh "$ROOT/pair-check.sh" --results "$OUT" >> "$OUT/pair-check.log" 2>&1; then
    echo
    sed -n '/VOID PASSES/,$p' "$OUT/pair-check.log" >&2
    PAIR_RC=1
  fi
fi
if [ "${PAIR_RC:-0}" -ne 0 ]; then
  echo "  pair check:    FAILED — see $OUT/pair-check.log"
  exit 2
fi

grep -q '^  INDETERMINATE' "$OUT/manifest.txt" && exit 2
grep -q '^  FAIL' "$OUT/manifest.txt" && exit 1
exit 0

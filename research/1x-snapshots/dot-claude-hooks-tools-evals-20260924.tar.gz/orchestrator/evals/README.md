# Tier-1 evals for Lintel's hooks

```
sh /Users/jowolff/.claude/orchestrator/evals/run-tier1.sh            # all
sh /Users/jowolff/.claude/orchestrator/evals/run-tier1.sh staging    # substring filter
```

Exit **0** all passed · **1** something failed · **2** something was **indeterminate**.
Results land in `${EVAL_OUT_ROOT:-$TMPDIR}/lintel-tier1/tier1-<stamp>/` as one `.log` and
`.status` per scenario plus `manifest.txt`.

## Conventions, borrowed from the newdle plugin harness

`/Users/jowolff/code/shipyard/repos/newdle-claude-plugins/plugins/newdle/evals/` is the reference.
Three files per scenario — `prompt.md` (docs), `setup.sh` (stages fixtures into an isolated
`mktemp` workdir), `assert.sh` (its exit code is the verdict). Scenarios run as separate processes:
**the filesystem carries state, environment variables do not.**

Verdicts are three-valued on purpose. A hook here must **always exit 0** and decide via stdout
JSON, so a non-zero exit means the harness broke rather than the test failed — and that can never
be allowed to read as a pass.

**Every silence scenario has a firing sibling differing in exactly one field.** A passthrough test
with no paired firing test is indistinguishable from a hook that returns nothing for every input.

## Writing a new scenario (added 2026-08-24)

Five task-design conventions. They come from Anthropic's *Demystifying evals for AI agents*
(fetched 2026-08-24), rewritten for the thing this suite actually tests — a hook is a pure function
handed one JSON payload, not a frontier model whose capability is in question, and two of the five
change shape because of that.

**Where that guide and this README disagree, this README wins.** The guide is general advice about
agent evals; this file describes the suite in the directory beside it. Both disagreements are named
below rather than smoothed over.

**1. Two people reading the scenario must reach the same verdict about what it pins.** The guide's
bar is that two domain experts would independently agree on pass/fail. Grading is not where that
bites here — `assert.sh` is a string match on the hook's stdout, so the verdict itself is never in
dispute. What is in dispute is the *fixture*: whether the payload `setup.sh` stages is genuinely the
situation `prompt.md` names. A scenario that passes against a payload nobody would recognise as the
described case is well graded and badly specified, and reads green either way. Write `prompt.md` so
a second person could rebuild `setup.sh` from it and land on the same payload.

**2. Confirm a new scenario goes green against the unmutated hook before trusting it going red.**
The guide calls this a reference solution — a known working output that passes all graders, proving
the task is solvable and the graders are wired correctly. This suite already covers the opposite
direction well: mutation testing proves a scenario *can* go red, and the minimal pair proves the
grader distinguishes two inputs. Neither proves the assertion string is the *right* string. An
`expect_block` whose third argument is a substring the hook never emits fails against every hook,
correct and broken alike, and the failure looks exactly like a caught defect. Run it against the
live hooks first.

**3. Both directions — already enforced, and nothing to restate.** The guide asks for cases where a
behaviour should occur and cases where it should not, on the grounds that one-sided evals create
one-sided optimization. The minimal-pair rule further down this file is that principle with teeth:
`pair-check.sh` fails the run when a silence scenario has no firing sibling, and voids silence
passes when the sibling came back mute. This suite is already stricter than the guide here.

**4. Graders here are deterministic, and tier 1 is where that stays true.** Every `expect_*` helper
in `lib/hook-eval.sh` decides on an exit code, a literal substring, or the presence of a file; no
model judges any scenario in this directory. Keep it that way — a hook's output is JSON of a fixed
shape, so the nuance that would earn a model judge does not exist at this tier. The model-graded
work is the tier-3 pressure suite against agent definitions, named at the bottom of this file, and
that boundary is the whole reason it is a different tier.

**5. A scenario that never passes usually means a real defect here, not a broken task.** This is the
guide's clearest inversion, and the one place its diagnosis is wrong for this suite. It says a 0%
pass rate across many trials signals a broken task rather than an incapable agent, and sends you to
re-check the task specification and the graders. That inference does not transfer: every scenario
here is a regression test for a defect that actually happened, the hook is an artifact under repair
rather than a fixed capability being measured, and a red scenario is doing its job. **Suspect the
scenario when it goes red against a hook nobody changed** — and reach for convention 2 before
touching the hook. The instrument for "I cannot tell which it is" already exists: exit anything but
0 or 1 and the run reports indeterminate rather than letting a broken harness read as either answer.

**One thing the guide warns against, which this suite does not do.** Its words: *"There is a common
instinct to check that agents followed very specific steps like a sequence of tool calls in the
right order. We've found this approach too rigid and results in overly brittle tests."* No scenario
here asserts on ordering — each sends a single payload and reads a single response. Do not add
ordering assertions to make a test look stricter.

## These are regression tests for defects that actually happened

| Scenario | The defect it pins |
| -------- | ------------------ |
| `guard-stop-hook-active-odd-spacing-passthrough` | The shell loop guard matched `stop_hook_active` as a raw substring; one space before the colon slipped past and the hook blocked when it should have passed |
| `staging-prose-mentioning-command-allowed` | The staging guard shipped unanchored, matched its own name in heredoc prose, and blocked the commit writing its own uninstall docs 90 seconds after install |
| `intake-captures-user-input` | The intake hook first read `p.prompt`; the documented field is `user_input`, so it would have captured nothing, silently, and looked fine |
| `sweep-captures-midturn-queued` | `UserPromptSubmit` is documented not to fire for queued mid-turn messages — the half that actually failed. Delete the sweep and this goes red |

## Mutation-tested, because a suite that passes everything on its first run proves nothing

Three deliberate regressions were reintroduced into **copies** of the hooks at
`state/hook-lab/mutation-test/` — the anchor removed from the staging regex, the loop guard
reverted to substring matching, and `user_input` dropped from the intake field chain. The same
suite went **16 pass / 4 fail**, catching all three, and the runner exited 1. The live hooks were
never touched. Re-run it that way after changing anything here:

```
LINTEL_HOOKS=/Users/jowolff/.claude/orchestrator/state/hook-lab/mutation-test sh run-tier1.sh
```

## Not covered

No tier 2. These test the functions, not the wire — that a hook is correctly **registered in
settings.json and fires in a real session** is verified only by hand so far, in
`state/hook-lab/savepoint-2026-08-19/DESIGN.md`. That is the obvious next gap.

## The minimal-pair rule is enforced now, not just stated (added 2026-08-22)

The rule in the conventions section at the top of this file — *every silence scenario has a firing
sibling differing in exactly one field* — was prose, and prose does not fire. On 2026-08-22 four
`budget-*` scenarios were found sitting green against `savepoint-guard.mjs`, a hook the
injection-budget check had moved out of two days earlier. They asserted silence from something
silent for every input. **They could not have gone red.** A green test that cannot go red is the
same defect as a runner that cannot fail, one layer down.

`pair-check.sh` enforces it, and `run-tier1.sh` calls it twice per run:

```
sh pair-check.sh                      # structure only, runs nothing
sh pair-check.sh --results <out-dir>  # void passes, after a run
sh pair-check.sh --list               # the classification table
```

**Static**, before the scenarios run: every `(family, target)` group holding a silence scenario
needs a firing one, and every scenario must be classifiable. It is the floor, and it would NOT have
caught the budget failure — that group held four silence *and* five firing scenarios, all pointed
at the same wrong hook, and looked perfect.

**Dynamic**, after: a silence PASS is evidence only if the hook was not measured mute in the same
run. When a firing sibling in the same group fails with `got: <silence>`, every silence pass in
that group is named **VOID** and the run exits 2. Reconstructed against the pre-repair suite, this
names exactly the four scenarios that were wrong.

Neither check aborts the run — the scenarios still execute and still report, because another
session may be waiting on those results. They force the final exit to **2**: a suite whose pairing
is broken cannot be trusted to say pass or fail. Nothing prompts and nothing waits.

**A scenario the checker cannot classify is a failure, not a skip.** Where the `expect_*` helper
and the filename do not settle it, declare it on its own line in `assert.sh`:

```
# eval-pair: silence savepoint-restore.sh
```

**Exemptions live in `PAIR-EXEMPTIONS.txt` and must justify themselves.** A reason under 40
characters fails, and an exemption for a group that is no longer unpaired is stale and also fails,
so a line there cannot outlive the situation it describes. Two are on file, both for `gate-*`,
which is organised by mechanism rather than by hook so its firing partners sit in the hook's own
family.

## Pressure cases: `pressure-*` (added 2026-08-22)

**A regression test asks whether a past defect recurs. A pressure case asks whether a rule survives
an argument for breaking it.** Every scenario here except the `pressure-*` family is the first kind.

**Most pressure cases do not belong in tier 1, and forcing them in would produce theatre.** A hook
has no judgement to erode: it cannot be worn down by a deadline, it has no sunk cost in the work so
far, and it does not care who is asking. Time pressure and sunk-cost pressure have no tier-1
surface at all. What a hook *does* have is a text surface an argument can arrive on — the command
string — and **authority pressure rides that surface**, which makes exactly one slice of the
category mechanically testable here:

> A guard must deny a command it would otherwise deny, **with the argument for allowing it attached
> to the command**. The authority claim must not be a channel.

Measured 2026-08-22, and the reason this family exists rather than being assumed: a copy of
`staging-guard.mjs` carrying a nine-word escape hatch keyed on "Jo said" / "the orchestrator
approved" — the shape of a change somebody adds to reduce friction after being told once that a
particular sweep was fine — passed **all 118** scenarios, exit 0. The whole suite, minimal-pair
enforcement included, was blind to it. With the `pressure-*` pair in place the same mutant fails
and the run exits 2.

Pressure cases follow every rule the rest of the suite follows: a minimal pair, a firing scenario
and a silence sibling one field apart. The silence half is not decoration — a guard that starts
denying because it noticed alarming words is broken in the opposite direction, and broken in a way
that teaches people to phrase commands around it.

**Where the rest of the category belongs, so nobody looks for it here.** Pressure that arrives
through the transcript, the brief, a preceding turn, or the accumulated cost of a session is
invisible to a hook, which is handed one JSON payload and nothing else. Those are pressure cases
against **agent definitions and `state/BRIEF-BOILERPLATE.md`**, graded by a live model, and they
are a tier 3 — a different harness, next to the tier-2 wiring gap named above, not a scenario
directory here.

## `turnid-*`: what a quarantined hook does to a scenario (added 2026-09-16)

On 2026-09-15 21:46, commit `6bac50b` retired six inert hooks — unregistered from `settings.json`
and moved into `hooks/.retired-20260915/`, deliberately never deleted. Two of the six were
`turn-id-mint.mjs` and `turn-id-verify.mjs`. The move did not carry their sibling imports: both
files `import` from `./session-gate.mjs` and `./turn-id.mjs`, both of which stayed in `hooks/`, so
**node now refuses the quarantined file with `ERR_MODULE_NOT_FOUND` before it reads one byte of
stdin.** Every one of the 22 `turnid-*` scenarios went non-green within the hour — 9 FAIL, 13
INDETERMINATE — and nobody saw it for a day because nobody ran the unfiltered suite. The commit
verified that no still-registered hook imports a quarantined file; the reverse direction, a
quarantined hook importing a still-registered module, was never checked.

**`turn-id.mjs` is not a replacement entry point, and no scenario may be pointed at it.** It is
the shared format-and-storage module both hooks import — `mintTurnId`, `markerPath`, `TURN_ID_RE`
— with no top-level statement that reads stdin or writes stdout. Measured: `node turn-id.mjs` fed
a complete `UserPromptSubmit` payload emits **0 bytes**, and the file contains zero occurrences of
`readFileSync(0`, `process.stdout.write` or `process.argv`. `grep -c mint turn-id.mjs` returns 7,
which counts the word inside `mintTurnId` and its comments and is not evidence of an entry point.
A scenario repointed there would assert silence from something silent for every input — the exact
defect the four `budget-*` scenarios carried on 2026-08-22, one layer down, and it would have made
every `expect_silence` in the family go green while proving nothing.

**The repair: `stage_retired_turnid_hooks`, in `lib/hook-eval.sh`.** Each `turnid-*` scenario calls
it immediately after sourcing the library. It copies the quarantined hook verbatim into the
scenario's own `$WORK`, beside the two shared modules it imports, and repoints `$HOOKS` there.
Nothing under `hooks/` is written, nothing in the quarantine is edited, and the staged files are
byte-identical to their sources (`cmp`, all four). It restores the module-resolution environment
the hooks had before the move and changes no behaviour. `LINTEL_HOOKS` short-circuits it, so
`LINTEL_HOOKS=<mutant-dir> sh run-tier1.sh` works unchanged — a mutant directory simply holds all
four files.

**These scenarios test a mechanism that is inert in production, and that is on purpose.** Tier 1
tests the functions, not the wire (see *Not covered* above). The turn-id hooks have been
unregistered for every seat since 2026-09-10 09:37 and their files are preserved so the retirement
stays reversible; these 22 scenarios are what makes reviving them safe. A green `turnid-*` run says
the two files still behave, **not** that anything is minting turn ids today.

**Red direction, demonstrated rather than assumed.** 17 mutant directories, each a copy of all four
files with one regression reintroduced, run as `LINTEL_HOOKS=<dir> sh run-tier1.sh turnid`. The
unmutated copy went 22/22 first, per convention 2. Every scenario belongs to a family with a named
mutant that reds it: injection (`m1`), local-time stamp (`m2`), id uniqueness (`m4`), ledger write
(`m5`), the session gate on the mint side (`m6`) and the Stop side (`m16`), reference resolution
(`m7`), unparseable stdin (`m8`), the loop guard (`m9`), the marker key (`m10`), block-at-most-once
(`m11`), the empty-reply brake (`m12`), final-line placement (`m13`), dash-marker acceptance
(`m14`), the missing-id block (`m15`), and session-tag grouping (`m17`).

**Two things the mutants measured that are worth knowing before trusting these scenarios.**
`turnid-foreign-session-stop-passthrough` is over-determined: opening the session gate alone does
not red it, because a foreign `session_id` also changes the marker key, so brake 3 produces the
same silence. It took `m16` — gate open *and* a session-blind marker key — to make it fail, which
means as written it does not isolate the gate. And `turnid-session-tag-groups-thread` cannot
distinguish a working `promptTag` from `nextFreeId` doing its job: with `promptTag` pinned to a
constant (`m3`) the whole suite still went 22/22, because ledger rotation keeps the two ids
distinct anyway. The scenario's observable claim — two turns of one thread get different ids that
share a session prefix — still holds, and `m4` and `m17` red it; but nobody should read it as
coverage of the derivation itself.

## `budget-*` and `fit-*`: the same quarantine, and a second break that stayed quiet (added 2026-09-16)

Commit `6bac50b` also moved `savepoint-fit-stop.mjs` into `hooks/.retired-20260915/`. All 13
scenarios across the two families that target it went non-green, and the unfiltered suite sat at
`164 passed / 0 failed / 13 indeterminate`, exit 2. The hook broke **twice**, and only the first
break announced itself.

**Break 1, loud.** `import { inOrchestratorSession } from './session-gate.mjs'` — the module
stayed in `hooks/`, so node refuses the quarantined file with `ERR_MODULE_NOT_FOUND` before it
reads one byte of stdin. Measured: `node .retired-20260915/savepoint-fit-stop.mjs` fed a complete
`Stop` payload exits **1** with **0 bytes** on stdout. Exit 1 is reported INDETERMINATE, correctly
— the harness broke, the hook did not fail.

**Break 2, silent, and the one that mattered.** The hook resolves its checker as
`../tools/savepoint-fit.sh` relative to `import.meta.url`. From `hooks/` that was
`orchestrator/tools/savepoint-fit.sh`; from `hooks/.retired-20260915/` it is `hooks/tools/`, which
does not exist. The hook **fails safe on an unreadable checker** by design (`accessSync`, then
allow), so a repair that fixed only the import would have produced a hook that is **silent for
every input**. Measured before the repair was written: the hook staged beside `session-gate.mjs`
with no reachable checker, handed an over-budget standup, emits **0 bytes at exit 0**. All seven
silence scenarios in these two families would have gone green against it. That is the 2026-08-22
`budget-*` defect in this section's own history, reproduced exactly, and it is why the staging
helper reproduces the pre-move **geometry** rather than just the pre-move imports.

**`savepoint-fit-stop.mjs` IS an entry point, and that was established by execution, not by
name.** Unlike `turn-id.mjs` above, it reads stdin at top level and writes a decision: staged
beside `session-gate.mjs` *and* a reachable checker, the same payload produces **817 bytes** of
`{"decision":"block",...}` at exit 0. `grep -c 'process.argv\|readFileSync(0\|process.stdout.write'`
returns 2. Counting a word would not have settled this; feeding it a payload did.

**The repair: `stage_retired_fit_hook`, in `lib/hook-eval.sh`.** Each of the 13 scenarios calls it
immediately after sourcing the library. It copies the quarantined hook and `session-gate.mjs` into
`$WORK/.staged-hooks/` and the checker into `$WORK/tools/` — which is where `../tools/` from
`.staged-hooks/` actually lands — then repoints `$HOOKS`. Nothing under `hooks/` or `tools/` is
written and nothing in the quarantine is edited. It asserts the staged checker is executable and
goes INDETERMINATE if it is not, because an unexecutable checker there is break 2 again.

**`LINTEL_HOOKS` is deliberately not exported by the helper.** `savepoint-fit.sh` reads it to
locate `savepoint-restore.sh`, its single source of truth for the budget. Leaving it unset keeps
the tool on the real restore hook, whose provenance `budget-limit-derived-from-restore-hook`
asserts; exporting it would silently demote that scenario to the built-in fallback and it would
still read green on the byte count alone.

**Red direction, demonstrated rather than assumed.** Nine mutant trees, each
`<root>/hooks/` plus a sibling `<root>/tools/`, run as
`LINTEL_HOOKS=<root>/hooks sh run-tier1.sh budget` and `... fit`. An unmutated tree (`m0`) went
14/14 first per convention 2, `cmp`-verified byte-identical to both sources, so every red below is
attributable to its mutation rather than to the tree:

| Mutant | What it breaks | Goes red |
| ------ | -------------- | -------- |
| `m1` | the FITS verdict no longer allows | `budget-under-limit-silent`, `budget-at-limit-exactly-silent`, `fit-under-limit-silent` |
| `m2` | session gate removed | `budget-foreign-session-silent`, `fit-foreign-session-silent` |
| `m3a` | the fire-once silence marker is ignored | `budget-silence-marker-honored` |
| `m3b` | the marker becomes absolute, fires at most once ever | `budget-rewritten-still-oversize-refires` |
| `m4` | missing-checker fail-safe inverted into a block | `fit-missing-checker-fails-safe` |
| `m5` | overage arithmetic off by one | `budget-one-byte-over-blocks`, `budget-over-limit-names-exact-overage`, `budget-rewritten-still-oversize-refires` |
| `m6a` | the restore-hook parse is skipped, budget falls back | `budget-limit-derived-from-restore-hook` |
| `m6b` | the `LINTEL_INJECTION_BUDGET` override is ignored | `budget-env-override-sets-limit` |
| `m7` | the cliff marker wording changed | `fit-over-limit-names-cliff-section` |

**Every one of the seven silence scenarios reds by making the hook SPEAK** — `m1`, `m2`, `m3a` and
`m4` each turn a silence into a block. None of them rests on nothing having happened, which is the
only form of evidence this family's history allows.

**The VOID mechanism was observed firing, not just trusted.** `m3b`, `m6b` and `m7` each break the
*only* firing scenario in their group, so the machine measured that hook mute in that run and
named every silence pass in the group VOID, exiting **2** rather than 1. Reading the `m7` run:
`fit-over-limit-names-cliff-section` FAILED and `fit-foreign-session-silent`,
`fit-missing-checker-fails-safe` and `fit-under-limit-silent` were all VOIDed despite passing. The
enforcement added on 2026-08-22 for these exact files now demonstrably refuses to credit them
without a live firing sibling.

# eval-pair: firing savepoint-restore.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf '%s' '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
case "$OUT" in *'LAB CANARY'*) exit 0 ;; *) echo "FAIL: the save point was not injected in its own session: ${OUT:-<silence>}" >&2; exit 1 ;; esac

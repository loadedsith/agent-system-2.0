FIRING sibling of gate-restore-foreign-session-silent. In the orchestrator's own session the
SessionStart hook must still inject the save point, canary and all.

THE HOLE THE AGE CHECK CANNOT CLOSE, made visible instead of silent.

zsh reads a script as it executes rather than slurping it, so a write landing DURING a run can
still be executed — part of the old file and part of the new one. No mtime check before the exec
can prevent that. What the wrapper can do is notice afterwards and say so.

Here the script is settled when the run starts, and is appended to while it is running. The run
exits 0. It must still be recorded as SUSPECT, because "exited 0" is exactly what a half-executed
publisher would report on its way to having pushed something nobody wrote.

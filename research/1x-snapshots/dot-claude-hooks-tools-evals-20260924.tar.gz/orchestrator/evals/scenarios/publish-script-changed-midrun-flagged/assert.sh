# eval-pair: firing publish-run.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
STUB="$WORK/pub.sh"
printf 'print -- "%s"\nsleep 4\nexit 0\n' "$PUB_SENTINEL" > "$STUB"
touch -t 202601010000 "$STUB"        # settled at the moment the run starts
( sleep 2; printf '# an edit landing mid-run\n' >> "$STUB" ) &
run_publisher "$STUB"
# The publisher DID run and DID exit 0. That is not enough to call the run clean.
_publisher_executed || _indeterminate "the stub never ran; this case cannot test what it is for"
[ "$PUB_RC" -eq 3 ] || { echo "FAIL: expected exit 3 (suspect), got $PUB_RC" >&2; exit 1; }
[ -f "$PUB_FAIL" ] || { echo "FAIL: mid-run edit passed silently — no marker for the hook to announce" >&2; exit 1; }
grep -q 'SUSPECT' "$PUB_FAIL" && exit 0
echo "FAIL: marker does not name the run as suspect: $(cat "$PUB_FAIL")" >&2; exit 1

# eval-pair: firing turn-id-mint.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
A=$(mint_id p-1 'first turn')
B=$(mint_id p-2 'second turn')
[ -n "$A" ] && [ -n "$B" ] || { echo "FAIL: a mint produced no id (A=$A B=$B)" >&2; exit 1; }
[ "$A" != "$B" ] || { echo "FAIL: two turns got the same id: $A" >&2; exit 1; }
exit 0

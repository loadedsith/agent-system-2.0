Two consecutive turns of the SAME session get different ids — including when they are minted
inside the same wall-clock second, which is what a scripted or fast-typed pair does. The seconds
field alone does not carry this; the 2-character prompt tag does, and the ledger collision check
closes the residual case where two prompt hashes agree.

. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence identifier-link-guard.mjs
expect_silence identifier-link-guard.mjs '{"session_id": "eval", "last_assistant_message": "REQ-479 assigns the identifier-link machinery to Tinker and remains open."}'

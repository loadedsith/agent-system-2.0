REQ-, DEC-, EXP-, ADR- and GAP- identifiers have NO URL and never will — they are rows in orchestrator/state ledgers. A guard demanding a URL for them would be unshippable.

Their requirement is their CONTENT in the same sentence, which is the failure Jo actually quoted: "I have no idea what you mean by Eng 1563's audit. I don't even know what Eng 1563 is about" (JUDGEMENT.md:49).

A ledger id whose sentence says what it is must pass.

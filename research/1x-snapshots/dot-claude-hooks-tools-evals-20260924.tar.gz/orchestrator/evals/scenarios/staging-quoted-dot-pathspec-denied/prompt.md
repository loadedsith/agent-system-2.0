REGRESSION for the requoting bypass, applied to the PATHSPEC. The unquoted spelling was denied
and the quoted one was allowed, which is the whole defect in one pair.

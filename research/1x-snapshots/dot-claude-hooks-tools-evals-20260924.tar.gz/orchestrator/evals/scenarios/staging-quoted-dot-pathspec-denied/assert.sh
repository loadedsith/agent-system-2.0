. "$(dirname "$0")/../../lib/hook-eval.sh"
# The command under test is:  git add '.'   — the pathspec in SINGLE quotes. Writing that inside
# this file's own single-quoted argument needs the '\'' dance; without it the quotes collapse and
# the scenario silently tests the UNQUOTED spelling, which the old hook already denied.
expect_deny staging-guard.mjs '{"session_id": "eval", "tool_name": "Bash", "cwd": "/Users/jowolff/.claude", "tool_input": {"command": "git add '\''.'\''"}}'

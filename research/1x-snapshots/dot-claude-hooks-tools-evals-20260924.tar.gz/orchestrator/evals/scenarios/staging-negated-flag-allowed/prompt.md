SILENCE sibling of staging-equivalent-flag-denied, differing only by the "no-" prefix. A guard
that keyed on the substring "ignore-removal" would deny this, and it is a narrow, explicit,
legitimate add. Proves the flag reading is semantic rather than textual.

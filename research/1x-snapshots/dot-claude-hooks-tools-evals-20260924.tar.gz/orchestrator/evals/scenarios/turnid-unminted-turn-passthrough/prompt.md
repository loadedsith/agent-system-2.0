THE failure mode this whole design is arranged around. A Stop that fires for a turn which never
had an id minted — a hook-driven continuation, a session resumed after the state dir was cleared,
a turn from before this hook existed — must NOT block. A verifier that fires on such a turn would
demand an id nobody can produce and would block that session on every stop, permanently.

The brake is that the marker is keyed by session_id + prompt_id: a stop whose prompt_id has no
marker is a stop with nothing to enforce. Here a turn IS minted (prompt_id p-1) and the stop
arrives for a different one (p-2), so this cannot pass merely because the state dir is empty.

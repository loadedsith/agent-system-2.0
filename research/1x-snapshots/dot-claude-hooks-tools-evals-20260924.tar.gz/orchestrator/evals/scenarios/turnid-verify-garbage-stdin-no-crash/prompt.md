Unparsable stdin on the Stop side: exit 0, allow. Failing open is mandatory here — this hook can
refuse to let a turn end.

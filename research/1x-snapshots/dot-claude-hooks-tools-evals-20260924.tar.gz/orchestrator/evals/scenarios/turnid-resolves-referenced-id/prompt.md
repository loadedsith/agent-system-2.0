The half that makes the whole mechanism pay off. When Jo writes "responding to turn
T-20260819-213045-K7Q2, do these commands", the mint hook resolves that id out of the daily
ledger and injects what was asked then, plus the path to the full exchange — rather than telling
the model to go and read a file, which is a step a model can skip.

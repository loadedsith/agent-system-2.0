. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
FIRST=$(mint_id p-1 'audit the deploy pipeline please')
[ -n "$FIRST" ] || { echo "FAIL: first mint produced no id" >&2; exit 1; }
expect_stdout_contains turn-id-mint.mjs \
  "{\"hook_event_name\":\"UserPromptSubmit\",\"session_id\":\"eval\",\"prompt_id\":\"p-2\",\"cwd\":\"/tmp/fixture\",\"prompt\":\"responding to turn $FIRST, do these commands\"}" \
  'audit the deploy pipeline please'

. "$(dirname "$0")/../../lib/hook-eval.sh"
node "${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}/intake-sweep.mjs" "$WORK/t.jsonl" "$WORK" >/dev/null || { echo INDETERMINATE >&2; exit 3; }
expect_file_lacks "$WORK/REQUESTS-INBOX.jsonl" 'task-notification'

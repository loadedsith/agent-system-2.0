SILENCE sibling, differing only in the queued content.

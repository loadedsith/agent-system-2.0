printf '%s\n' '{"type":"queue-operation","operation":"enqueue","content":"<task-notification> done","timestamp":"2026-01-01T00:00:00Z"}' > "$WORK/t.jsonl"

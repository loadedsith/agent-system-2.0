. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence identifier-link-guard.mjs
expect_silence identifier-link-guard.mjs '{"session_id": "eval", "last_assistant_message": "ALL-937 - https://linear.app/contextpress/issue/ALL-937"}'

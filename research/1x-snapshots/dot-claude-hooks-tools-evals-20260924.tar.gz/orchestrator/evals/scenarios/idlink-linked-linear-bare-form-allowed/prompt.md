The bare `/issue/<ID>` form, with no title slug, must also satisfy the guard.

Stated as a design requirement rather than a past defect, which is the honest label: a matcher that demanded the slug would reject a correct-looking link, and a matcher that rejected the slug would reject the canonical one. Accepting both is the only position that does not rest on the untested claim that the bare form redirects.

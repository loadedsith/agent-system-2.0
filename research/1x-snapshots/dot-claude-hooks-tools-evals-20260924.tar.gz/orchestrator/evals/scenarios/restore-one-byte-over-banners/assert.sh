# eval-pair: firing savepoint-restore.sh
[ "$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')" -eq 6001 ] || { echo "INDETERMINATE: fixture is not exactly 6001 bytes" >&2; exit 3; }
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf %s '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
case "$OUT" in *'STANDUP TRUNCATED. 1 of 6001 bytes were NOT shown'*) exit 0 ;; esac
echo "FAIL: expected a banner naming 1 of 6001 bytes; got: ${OUT:-<silence>}" >&2; exit 1

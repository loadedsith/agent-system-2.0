{ head -c 6000 /dev/zero | tr '\0' 'x'; printf 'Z'; } > "$WORK/STANDUP.md"

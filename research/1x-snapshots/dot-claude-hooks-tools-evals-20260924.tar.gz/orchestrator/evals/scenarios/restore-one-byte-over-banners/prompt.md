FIRING sibling of restore-at-limit-exactly-no-banner, one byte larger. 6001 bytes with no `## `
heading anywhere past the first, so the section-boundary cut has nothing to snap to and falls back
to the blind 6000-byte cut. Exactly 1 byte is dropped and the banner must say so.

This is the scenario that catches an off-by-one in either the comparison or the arithmetic.

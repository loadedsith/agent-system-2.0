SILENCE sibling of guard-untriaged-capture-blocks. Identical fixtures; ONLY stop_hook_active
differs. The loop guard must win over a finding that would otherwise block.

Re-sibled 2026-09-09. It used to name guard-state-moved-blocks, whose fixture stopped being able
to make this guard speak at all; see guard-state-moved-nudges/prompt.md.

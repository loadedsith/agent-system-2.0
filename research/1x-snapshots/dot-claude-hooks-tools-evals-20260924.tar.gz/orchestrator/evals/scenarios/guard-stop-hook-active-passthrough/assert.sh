. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_silence savepoint-guard.mjs '{"hook_event_name": "Stop", "stop_hook_active": true, "session_id": "eval"}'

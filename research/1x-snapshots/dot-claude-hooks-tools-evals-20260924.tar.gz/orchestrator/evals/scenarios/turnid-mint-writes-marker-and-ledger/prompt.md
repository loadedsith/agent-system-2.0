The id has to OUTLIVE the turn in two different places, for two different readers:

  .turn-state/<session>-<prompt>.json   the machine's copy, read by the Stop hook this turn
  turn-ids/<YYYY-MM-DD>.jsonl           the human's copy, read weeks later to answer
                                        "what was turn T-20260819-213045-K7Q2?"

Delete either and a different capability is lost, so both are asserted.

# eval-pair: firing turn-id-mint.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
ID=$(mint_id p-1 'audit the deploy pipeline')
[ -n "$ID" ] || { echo "FAIL: mint produced no id" >&2; exit 1; }
[ -f "$WORK/.turn-state/eval-p-1.json" ] || { echo "FAIL: no marker file for the turn" >&2; exit 1; }
grep -q "$ID" "$WORK/.turn-state/eval-p-1.json" || { echo "FAIL: marker does not hold the minted id" >&2; exit 1; }
LEDGER="$WORK/turn-ids/$(date +%Y-%m-%d).jsonl"
[ -f "$LEDGER" ] || { echo "FAIL: no ledger file at $LEDGER" >&2; exit 1; }
grep -q "$ID" "$LEDGER" || { echo "FAIL: ledger lacks the id" >&2; exit 1; }
grep -q 'audit the deploy pipeline' "$LEDGER" || { echo "FAIL: ledger lacks the prompt excerpt" >&2; exit 1; }
exit 0

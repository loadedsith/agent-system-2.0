FIRING. The failure this whole check exists for: a prompt carrying an actual instruction is marked
triaged:true, disposition:"conversation", and never becomes an obligation. Watermark is armed and
the row is newer than it.

SILENCE sibling of staging-tilde-path-denied, which walks IN by cd and must be denied. This one
walks OUT by cd and must pass. The old scope test read cwd only, so it denied this.

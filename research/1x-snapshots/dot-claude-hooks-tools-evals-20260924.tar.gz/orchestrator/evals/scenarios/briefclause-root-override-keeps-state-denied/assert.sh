. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: firing brief-clause-guard.mjs
H="$WORK/home"; R="$WORK/widened"
OUT=$(printf '{"session_id":"eval","tool_name":"Agent","cwd":"%s","tool_input":{"prompt":"Find it."}}' "$R/repo" \
  | env -u LINTEL_STATE -u BRIEF_CLAUSE_SOURCE -u BRIEF_CLAUSE_LOG BRIEF_CLAUSE_ROOT="$R" HOME="$H" node "$HOOKS/brief-clause-guard.mjs" 2>/dev/null) \
  || _indeterminate "hook exited non-zero"
case "$OUT" in *'"permissionDecision":"deny"'*) ;; *) echo "FAIL: expected deny (boilerplate read from the fixed state dir), got: ${OUT:-<silence>}" >&2; exit 1 ;; esac
n=$(find "$WORK" -name 'brief-clause-guard.jsonl' | wc -l | tr -d ' ')
[ "$n" = 1 ] || { echo "FAIL: expected exactly one log under $WORK, found $n: $(find "$WORK" -name 'brief-clause-guard.jsonl' | tr '\n' ' ')" >&2; exit 1; }
expect_file_contains "$H/.claude/orchestrator/state/brief-clause-guard.jsonl" '"decision":"deny"'

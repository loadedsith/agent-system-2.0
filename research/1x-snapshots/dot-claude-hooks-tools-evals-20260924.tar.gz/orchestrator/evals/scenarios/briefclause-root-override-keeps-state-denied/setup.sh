mkdir -p "$WORK/home/.claude/orchestrator/state" "$WORK/widened/repo"
printf '%s\n' '# Brief boilerplate' '' \
  '## A fact carries its origin and what that origin claimed for it' '' \
  '**When you record a fact, record who supplied it and the grade they gave it.**' '' \
  '## A receipt proves what it literally shows' '' \
  '**Record what the evidence covers separately from what you concluded, so a reader can see the gap.**' '' \
  '## A fact recorded without the means to check it' '' \
  '**Write the route as a command someone ran, never as a capability.**' > "$WORK/home/.claude/orchestrator/state/BRIEF-BOILERPLATE.md"

. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
expect_silence turn-id-mint.mjs 'not json at all {{{'

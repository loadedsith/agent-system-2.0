Unparsable stdin: exit 0, say nothing. Same contract as the other four hooks — a hook that throws
on a payload shape it did not expect is a hook that breaks Jo's turn.

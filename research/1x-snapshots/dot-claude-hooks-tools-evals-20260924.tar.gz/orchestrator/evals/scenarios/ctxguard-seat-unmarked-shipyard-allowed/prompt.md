Minimal pair with ctxguard-seat-marked-shipyard-denied, differing only in the marker: an unmarked session (Jo's own) in the same repo is not gated.

Lintel decided, from Jo's words "seats dispatching from their own repos" (attributed, relayed by Tinker), that outside ~/.claude only a session carrying the seat marker MARCHES_SEAT is gated, so Jo's own interactive sessions stay ungated; inside ~/.claude the gate stays unconditional so Lintel stays gated. No defect has happened here yet; this pins that decision.

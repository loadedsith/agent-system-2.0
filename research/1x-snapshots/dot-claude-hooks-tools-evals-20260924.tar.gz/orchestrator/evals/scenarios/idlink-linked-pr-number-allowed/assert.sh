. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence identifier-link-guard.mjs
expect_silence identifier-link-guard.mjs '{"session_id": "eval", "last_assistant_message": "I landed the fix in #1073 - https://github.com/ContextPress/newdle-web/pull/1073"}'

The firing sibling of idlink-bare-pr-number-blocked, differing in exactly one field: the same message plus the full GitHub URL.

Without this pair the block test is indistinguishable from a hook that blocks every message containing a number. This is also the case that must stay cheap — a false positive here taxes every message a seat sends.

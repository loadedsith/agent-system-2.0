SILENCE. Same dangling reference, but the payload session_id is not the orchestrator's. The new
check sits behind the same session gate as everything else in this hook: it must never instruct an
unrelated session in another repo to repair Lintel's inbox.

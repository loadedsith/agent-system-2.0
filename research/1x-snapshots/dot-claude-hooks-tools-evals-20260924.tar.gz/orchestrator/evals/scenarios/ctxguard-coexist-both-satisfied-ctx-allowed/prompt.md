Coexistence: a brief carrying the three brief clauses AND a ctx line passes this guard. Sibling: ctxguard-coexist-clauses-only-ctx-denied.

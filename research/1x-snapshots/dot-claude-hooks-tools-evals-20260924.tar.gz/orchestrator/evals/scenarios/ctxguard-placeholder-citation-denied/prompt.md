The refusal text prints a template; pasting the template unfilled must not pass. No defect has happened here yet; this pins a design requirement, stated so rather than invented.

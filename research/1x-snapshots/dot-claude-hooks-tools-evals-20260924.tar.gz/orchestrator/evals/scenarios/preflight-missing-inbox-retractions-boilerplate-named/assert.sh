# eval-pair: firing summon.sh
ORCH=$(CDPATH= cd -- "$(dirname -- "$0")/../../.." 2>/dev/null && pwd)
SUMMON="$ORCH/summon.sh"
[ -f "$SUMMON" ] || { echo "INDETERMINATE: no summon.sh at $SUMMON" >&2; exit 3; }
command -v zsh >/dev/null || { echo "INDETERMINATE: summon.sh is a zsh script and zsh is not on PATH" >&2; exit 3; }
command -v claude >/dev/null || { echo "INDETERMINATE: claude not on PATH; preflight [1/6] would fail for an unrelated reason" >&2; exit 3; }
grep -q 'LINTEL_STATE' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_STATE; this would test the live state dir" >&2; exit 3; }
grep -q 'LINTEL_SUMMON_LOG' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_SUMMON_LOG; this would clobber the real summon.log" >&2; exit 3; }
grep -q 'LINTEL_BOOTSTRAP_RUNBOOK' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_BOOTSTRAP_RUNBOOK; this would depend on the real runbook" >&2; exit 3; }

LOG="$WORK/summon-preflight.log"
BOOK="$WORK/fixture-bootstrap.md"
printf 'fixture bootstrap runbook\n' > "$BOOK"
run_preflight() {
  ORCH_PREFLIGHT_ONLY=1 LINTEL_STATE="$WORK/state" LINTEL_SUMMON_LOG="$LOG" \
    LINTEL_BOOTSTRAP_RUNBOOK="$1" zsh "$SUMMON" "$WORK" >/dev/null 2>&1
}

mkdir -p "$WORK/quarantine"
for f in REQUESTS-INBOX.jsonl RETRACTIONS.md BRIEF-BOILERPLATE.md; do
  mv "$WORK/state/$f" "$WORK/quarantine/$f"
done

run_preflight "$BOOK"
rc=0
grep -q 'BOOTSTRAP REQUIRED' "$LOG" || { echo "FAIL: three required files are gone and the log never says BOOTSTRAP REQUIRED" >&2; rc=1; }
# EVERY missing file, not just the first: a report that stops at the first gap sends the reader
# back for a second round after each repair.
for f in REQUESTS-INBOX.jsonl RETRACTIONS.md BRIEF-BOILERPLATE.md; do
  grep -q -- "$f" "$LOG" || { echo "FAIL: the log never names $f" >&2; rc=1; }
done
[ "$rc" -eq 0 ] || { sed 's/^/    /' "$LOG" >&2; exit 1; }

# The hard stop that survived the 2026-08-20 change: no readable recovery runbook, no handover.
if run_preflight "$WORK/no-such-runbook.md"; then
  echo "FAIL: preflight handed the session over with three required files gone AND no readable recovery runbook" >&2
  sed 's/^/    /' "$LOG" >&2; exit 1
fi
exit 0

The remaining three state files added to summon's [5/6] check on 2026-08-20, removed together so
the scenario also proves the report lists EVERY missing file rather than stopping at the first:

  REQUESTS-INBOX.jsonl   read by savepoint-guard.mjs (triage referential integrity) and
                         intake-sweep.mjs. Both swallow its absence, which is the problem: with
                         the inbox gone the invariant checks nothing and reports clean.
  RETRACTIONS.md         savepoint-guard.mjs's WATCH list; the charter's audit log.
  BRIEF-BOILERPLATE.md   the charter requires every dispatch to APPEND the labeling contract from
                         this file precisely so it is never retyped from memory. Absent, it gets
                         retyped and drifts, and the drift is invisible because the worker's
                         report still looks like a report.

REPAIRED 2026-08-22, same reason as preflight-missing-request-queue-fails: summon.sh's [5/6]
check now enters BOOTSTRAP REQUIRED mode and hands the session over instead of returning 1, so the
old "preflight exits non-zero" assertion was pinned to a design that had been replaced. The list
half -- every missing file named, not just the first -- is unchanged and is still the point. The
hard-stop half is preserved by a second run with no readable recovery runbook, which must still
refuse to hand over.

# eval-pair: firing savepoint-fit-stop.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_fit_hook
SZ=$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')
[ "$SZ" -eq 6487 ] || { echo "INDETERMINATE: fixture is $SZ bytes, expected 6487" >&2; exit 3; }
# TWO needles, so this is written out rather than using expect_block, which takes one. The number
# and its provenance are separate facts: 6000 from a hardcoded constant would satisfy the first
# needle alone and would be exactly the drift this scenario exists to catch. The path is NOT
# asserted -- LINTEL_HOOKS relocates it during mutation runs -- only the file name and match mode.
_run savepoint-fit-stop.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}'
_check_exit0
case "$OUT" in
  *'"decision":"block"'*) ;;
  *) echo "FAIL: expected block, got: ${OUT:-<silence>}" >&2; exit 1 ;;
esac
case "$OUT" in
  *'budget: 6000 bytes'*) ;;
  *) echo "FAIL: block reason does not report a 6000-byte budget" >&2; exit 1 ;;
esac
case "$OUT" in
  *'savepoint-restore.sh (LIMIT=)'*) exit 0 ;;
  *) echo "FAIL: block reason does not name savepoint-restore.sh as the source of the limit" >&2; exit 1 ;;
esac

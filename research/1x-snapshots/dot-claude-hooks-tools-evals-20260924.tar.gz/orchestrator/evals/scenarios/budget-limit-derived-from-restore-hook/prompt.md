FIRING, asserting on the SOURCE of the number rather than the number. The limit is not hardcoded in
the hook; it is parsed out of savepoint-restore.sh, the hook that performs the cut, so the two
cannot drift. The message names where it came from, which means a parse failure degrades to a
message that says "built-in fallback" instead of quietly reporting a stale limit as authoritative.

REPOINTED 2026-08-22 from savepoint-guard.mjs to savepoint-fit-stop.mjs, which is where the
injection-budget check moved on 2026-08-20. The parse itself now lives in tools/savepoint-fit.sh,
and the wording changed from "budget:  6000 bytes (from savepoint-restore.sh)" to
"budget: 6000 bytes  [source: <path>/savepoint-restore.sh (LIMIT=)]".

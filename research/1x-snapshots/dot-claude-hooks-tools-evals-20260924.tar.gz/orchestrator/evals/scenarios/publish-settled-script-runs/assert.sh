# eval-pair: silence publish-run.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
STUB="$WORK/pub.sh"
make_stub_publisher "$STUB"
touch -t 202601010000 "$STUB"        # the ONE field that differs from the sibling
run_publisher "$STUB"
expect_publisher_ran

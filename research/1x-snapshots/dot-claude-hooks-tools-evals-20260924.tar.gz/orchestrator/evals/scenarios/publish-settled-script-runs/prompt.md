FIRING SIBLING of publish-fresh-script-refused, differing in exactly ONE field: the script's mtime
is old instead of seconds ago.

Its job is the opposite defect. A mid-edit guard that has quietly become a blanket refusal passes
every refusal scenario in this suite while publishing nothing, forever — and publishing that has
silently stopped is the failure the whole publish mechanism exists to prevent. This is the case
that goes red when that happens.

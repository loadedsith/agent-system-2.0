Regression for the exact defect: stop_hook_active true, written with a space before the colon.
The shell version blocked here. Parsed JSON must not care about spacing.

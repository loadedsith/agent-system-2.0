# eval-pair: silence savepoint-guard.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf '%s' '{"stop_hook_active" : true,"session_id":"eval"}' | LINTEL_STATE="$WORK" node "${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}/savepoint-guard.mjs"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
[ -z "$OUT" ] && exit 0
echo "FAIL: loop guard missed odd spacing; got $OUT" >&2; exit 1

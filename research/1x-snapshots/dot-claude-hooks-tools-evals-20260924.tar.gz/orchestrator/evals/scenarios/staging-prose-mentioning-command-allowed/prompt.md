REGRESSION for defect #7. The guard shipped unanchored, matched its own name inside heredoc
prose, and blocked the commit writing its own uninstall documentation 90 seconds after install.
Writing ABOUT the command must not trip it.

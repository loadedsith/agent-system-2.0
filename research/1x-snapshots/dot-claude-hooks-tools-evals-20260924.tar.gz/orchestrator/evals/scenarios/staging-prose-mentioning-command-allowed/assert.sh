. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_allow_tool staging-guard.mjs '{"session_id": "eval", "tool_name": "Bash", "cwd": "/Users/jowolff/.claude", "tool_input": {"command": "echo \"the guard denies git add -A inside ~/.claude\""}}'

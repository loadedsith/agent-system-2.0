SILENCE. Same firing row as refint-conversation-instruction-blocks with the watermark file removed.
Absent watermark means the conversation-mislabel check is inert, so installing the hook without the
install script's watermark step cannot block on 78 historical rows.

. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
expect_stdout_contains turn-id-mint.mjs \
  '{"hook_event_name":"UserPromptSubmit","session_id":"eval","prompt_id":"p-1","cwd":"/tmp/fixture","prompt":"do the thing"}' \
  '"hookEventName":"UserPromptSubmit"'

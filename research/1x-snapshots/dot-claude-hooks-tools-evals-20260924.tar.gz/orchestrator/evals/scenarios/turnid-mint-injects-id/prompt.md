FIRING scenario for the mint half. A normal user turn must produce an injected TURN ID.

The injection FORM is load-bearing and was chosen by measurement, not by reading docs: plain text
on stdout from UserPromptSubmit did NOT reach the model on the first turn of a fresh session in
two trials (probe-1, probe-3 in this lab), while the JSON hookSpecificOutput.additionalContext
form reached it on both a first turn and a resumed turn. So this asserts the JSON envelope, not
just the presence of the string.

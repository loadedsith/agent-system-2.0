CODEX-FIXES item 6, Stop-hook half. savepoint-guard.mjs filtered obligations with
`.filter((r) => r && r.state !== 'delivered')` — byte-for-byte the same wrong predicate the
SessionStart hook used — so its "Open obligations that must appear in it" list named rows Jo had
already dropped or deferred.

Only six rows are shown by the guard, so the fixture holds exactly six: three terminal, three
non-terminal. The three terminal rows must not appear. The list is capped at 6, so a fixture
larger than that would let a terminal row hide behind the cap and pass by accident.

FIRING SIBLING: oblig-restore-hides-terminal-rows, the same predicate in the SessionStart hook.

FIXTURE REPAIRED 2026-09-09. The guard prints its obligation list only when it blocks, and commit
2939ca7 (2026-08-25) made moved state alone a non-blocking nudge. This scenario's fixture had
nothing but moved state, so from that day the guard never blocked here and the assert.sh reported
INDETERMINATE — correctly, and for two weeks nobody was told. One aged untriaged capture now
restores the block. The predicate being tested is untouched.

ASSERTION RE-AIMED 2026-09-09, same commit, third staleness. 2939ca7 also replaced the roll of six
row ids with a count and a path — deliberately, and the reasoning is in the guard at the
`THE ROLL, SHRUNK TO A COUNT AND A POINTER` comment: slice(0, 6) over an append-ordered file always
returned the six OLDEST open rows, so nothing in flight could ever appear in it and the heading
"obligations that must appear in it" was false. There are no row ids in the output any more, so
naming them cannot be the assertion.

The predicate under test is unchanged and so is the fixture: three terminal rows, three
non-terminal, and the count must read 3. That number is a strictly sharper instrument than the
id list was, because both historical wrong answers are distinguishable in it — 6 for no filtering,
5 for the `state !== 'delivered'` predicate this scenario was written to catch — and the assert
names which one it saw rather than just reporting a mismatch.

# STANDUP.md must be OLDER than a watched state file or the guard allows and never reaches the
# obligations block at all. Same construction as guard-state-moved-nudges.
printf 'fixture standup\n' > "$WORK/STANDUP.md"; sleep 1
cat > "$WORK/REQUESTS.jsonl" <<'ROWS'
{"id":"OBLIG-DELIVERED","state":"delivered","request":"terminal: asked and got it"}
{"id":"OBLIG-DEFERRED","state":"deferred","request":"terminal: deliberately not now"}
{"id":"OBLIG-DROPPED","state":"dropped","request":"terminal: Jo called it off"}
{"id":"OBLIG-OPEN","state":"open","request":"non-terminal: accepted as work, unfinished"}
{"id":"OBLIG-PARTIAL","state":"partial","request":"non-terminal: some landed, a remainder is owed"}
{"id":"OBLIG-BLOCKED","state":"blocked","request":"non-terminal: waiting on something outside the fleet"}
ROWS
# Added 2026-09-09. The obligation list is printed only on the BLOCK path, and since 2026-08-25
# moved state alone produces a nudge instead. One aged untriaged capture restores the block, which
# is the precondition this scenario needs rather than the thing it asserts.
printf '{"ts":"2026-01-01T00:00:00Z","triaged":false,"verbatim":"look at the deploy pipeline"}\n' > "$WORK/REQUESTS-INBOX.jsonl"
cp /Users/jowolff/.claude/orchestrator/CHARTER.md "$WORK/CHARTER.md"

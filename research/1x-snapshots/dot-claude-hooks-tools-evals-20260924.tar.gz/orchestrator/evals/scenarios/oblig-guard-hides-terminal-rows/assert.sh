# eval-pair: firing savepoint-guard.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"

# HOOK RESOLUTION — see the sibling scenario oblig-restore-hides-terminal-rows for why.
LAB=/Users/jowolff/.claude/orchestrator/state/hook-lab/terminal-states-2026-08-20/candidates
if grep -q 'request-states.sh' "$HOOKS/savepoint-guard.mjs" 2>/dev/null; then
  UNDER="$HOOKS/savepoint-guard.mjs"
elif grep -q 'request-states.sh' "$LAB/savepoint-guard.mjs" 2>/dev/null; then
  UNDER="$LAB/savepoint-guard.mjs"
else
  echo "INDETERMINATE: no savepoint-guard.mjs carrying the shared terminal-state predicate, in $HOOKS or $LAB" >&2
  exit 3
fi
echo "hook under test: $UNDER"

OUT=$(printf '%s' '{"hook_event_name":"Stop","stop_hook_active":false,"session_id":"eval"}' \
  | LINTEL_STATE="$WORK" LINTEL_CHARTER="$WORK/CHARTER.md" node "$UNDER" 2>/dev/null); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: guard exited $RC; its contract is to always exit 0" >&2; exit 3; }
case "$OUT" in
  *'"decision":"block"'*) ;;
  *) echo "INDETERMINATE: the guard did not block, so it never printed an obligation count: ${OUT:-<silence>}" >&2; exit 3 ;;
esac
case "$OUT" in *'open obligation(s) are on file'*) ;; *)
  echo "INDETERMINATE: blocked without an obligation count; the fixture ledger was not read" >&2
  echo "$OUT" >&2; exit 3 ;;
esac
case "$OUT" in *'UNFILTERED'*)
  echo "INDETERMINATE: the guard reported the terminal-state predicate unavailable, so this run tested the fallback, not the fix" >&2
  echo "$OUT" >&2; exit 3 ;;
esac

# THE ASSERTION. The fixture is three terminal rows and three non-terminal ones, so the only
# correct count is 3. The two ways this predicate has actually been wrong both land on a
# different number and are therefore both caught here:
#   6 — no filtering at all
#   5 — the old `state !== 'delivered'` predicate, which counts dropped and deferred as open
case "$OUT" in
  *'3 open obligation(s) are on file'*) exit 0 ;;
esac
case "$OUT" in
  *'5 open obligation(s) are on file'*)
    echo "FAIL: count is 5 — dropped and deferred are being counted as open, which is the exact" >&2
    echo "      'state !== delivered' predicate CODEX-FIXES item 6 removed" >&2 ;;
  *'6 open obligation(s) are on file'*)
    echo "FAIL: count is 6 — no terminal filtering is happening at all" >&2 ;;
  *)
    echo "FAIL: expected 3 open obligations (3 terminal rows filtered out); got neither 3, 5 nor 6" >&2 ;;
esac
echo "--- guard output ---" >&2; echo "$OUT" >&2; exit 1

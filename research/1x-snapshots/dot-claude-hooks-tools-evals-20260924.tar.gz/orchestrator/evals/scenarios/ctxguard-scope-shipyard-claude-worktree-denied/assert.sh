. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: firing ctx-search-guard.mjs
export MARCHES_SEAT='eval-seat'
expect_deny ctx-search-guard.mjs '{"session_id":"eval","tool_name":"Agent","cwd":"/Users/jowolff/code/shipyard/repos/kitchen/.claude/worktrees/feat-x","tool_input":{"subagent_type":"scout","description":"find login validation","prompt":"Find where the login form is validated and report the file and line."}}'

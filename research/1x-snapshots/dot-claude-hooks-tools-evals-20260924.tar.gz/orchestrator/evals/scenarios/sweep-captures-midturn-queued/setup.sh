printf '%s\n' \
  '{"type":"queue-operation","operation":"enqueue","content":"i still want the adversarial pass","timestamp":"2026-01-01T00:00:00Z"}' \
  '{"type":"queue-operation","operation":"remove","content":"i still want the adversarial pass","timestamp":"2026-01-01T00:00:05Z"}' \
  > "$WORK/t.jsonl"

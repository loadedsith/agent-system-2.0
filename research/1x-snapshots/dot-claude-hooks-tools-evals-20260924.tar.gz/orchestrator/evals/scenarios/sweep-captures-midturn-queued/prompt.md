FIRING sibling of sweep-ignores-machine-envelope. UserPromptSubmit is DOCUMENTED not to fire for
queued mid-turn messages, which is the half that actually failed. The sweep is the only thing that
sees them.

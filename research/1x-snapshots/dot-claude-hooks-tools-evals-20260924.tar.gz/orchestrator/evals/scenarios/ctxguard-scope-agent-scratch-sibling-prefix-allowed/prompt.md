Same segment-exact rule for the agent-scratch root. Minimal pair with ctxguard-scope-agent-scratch-worktree-denied. Round 3: runs as a marked seat (MARCHES_SEAT=eval-seat).

REGRESSION GUARD for the request queue. state/REQUESTS.jsonl is read at SessionStart by
savepoint-restore.sh (the "OPEN OBLIGATIONS" block) and on every Stop by savepoint-guard.mjs.
Until 2026-08-20 summon's [5/6] check listed five files and this was not one of them, so a
session could start cleanly with every open obligation gone and nothing said.

THE CONTRACT CHANGED UNDER THIS SCENARIO, uncommitted, and this scenario was red because of it.
summon.sh's [5/6] check used to print INCOMPLETE and `return 1`, stopping the summon. It now sets
bootstrap_required, prints BOOTSTRAP REQUIRED, names the missing files, names the recovery runbook,
and HANDS THE SESSION OVER in bootstrap mode. So "preflight exits non-zero" is no longer the
contract and asserting it is asserting against a design that was deliberately replaced.

WHAT IS ASSERTED INSTEAD, in two parts, because the naming half alone is weaker than what this
scenario was written to hold:
  1. incomplete state layer + readable runbook -> the log says BOOTSTRAP REQUIRED, names
     REQUESTS.jsonl, and says the session is starting in bootstrap mode. Naming matters as much as
     the verdict: summon.sh tells Jo to hand summon.log to a Claude session rather than diagnose
     it, so a log that reports a gap without saying which file is gone sends them back to the
     terminal to work it out.
  2. incomplete state layer + NO readable runbook -> preflight still exits non-zero. That is the
     hard stop that survived the change, and it is what keeps part 1 from passing against a
     preflight that had simply stopped checking.

OPEN FOR JO, not decidable here: bootstrap mode means a session can now START with the request
queue missing. The old behaviour refused. Whether that trade is right is a design call.

# eval-pair: firing summon.sh
ORCH=$(CDPATH= cd -- "$(dirname -- "$0")/../../.." 2>/dev/null && pwd)
SUMMON="$ORCH/summon.sh"
[ -f "$SUMMON" ] || { echo "INDETERMINATE: no summon.sh at $SUMMON" >&2; exit 3; }
command -v zsh >/dev/null || { echo "INDETERMINATE: summon.sh is a zsh script and zsh is not on PATH" >&2; exit 3; }
command -v claude >/dev/null || { echo "INDETERMINATE: claude not on PATH; preflight [1/6] would fail for an unrelated reason" >&2; exit 3; }
grep -q 'LINTEL_STATE' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_STATE; this would test the live state dir" >&2; exit 3; }
grep -q 'LINTEL_SUMMON_LOG' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_SUMMON_LOG; this would clobber the real summon.log" >&2; exit 3; }
grep -q 'LINTEL_BOOTSTRAP_RUNBOOK' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_BOOTSTRAP_RUNBOOK; this would depend on the real runbook" >&2; exit 3; }

LOG="$WORK/summon-preflight.log"
BOOK="$WORK/fixture-bootstrap.md"
printf 'fixture bootstrap runbook\n' > "$BOOK"
run_preflight() {
  ORCH_PREFLIGHT_ONLY=1 LINTEL_STATE="$WORK/state" LINTEL_SUMMON_LOG="$LOG" \
    LINTEL_BOOTSTRAP_RUNBOOK="$1" zsh "$SUMMON" "$WORK" >/dev/null 2>&1
}

mkdir -p "$WORK/quarantine"
mv "$WORK/state/REQUESTS.jsonl" "$WORK/quarantine/REQUESTS.jsonl"

# PART 1 — with a readable recovery runbook, preflight hands over in BOOTSTRAP MODE. It must
# still say, in the log, that the state layer is incomplete and which file is gone.
run_preflight "$BOOK"
grep -q 'BOOTSTRAP REQUIRED' "$LOG" || {
  echo "FAIL: the state layer is incomplete and the log never says BOOTSTRAP REQUIRED" >&2
  sed 's/^/    /' "$LOG" >&2; exit 1; }
grep -q 'REQUESTS.jsonl' "$LOG" || {
  echo "FAIL: preflight noticed the gap but the log never names REQUESTS.jsonl" >&2
  sed 's/^/    /' "$LOG" >&2; exit 1; }
grep -q 'bootstrap mode' "$LOG" || {
  echo "FAIL: the log never tells the session it is starting in bootstrap mode" >&2
  sed 's/^/    /' "$LOG" >&2; exit 1; }

# PART 2 — the hard stop that survived the 2026-08-20 change. Bootstrap mode is only a legitimate
# answer when the recovery path is actually readable. With no runbook there is nothing to hand the
# session, and preflight must refuse to start rather than hand over a session that cannot recover.
# Without this half, PART 1 alone would pass against a preflight that had stopped checking.
if run_preflight "$WORK/no-such-runbook.md"; then
  echo "FAIL: preflight handed the session over with the state layer incomplete AND no readable recovery runbook" >&2
  sed 's/^/    /' "$LOG" >&2; exit 1
fi
exit 0

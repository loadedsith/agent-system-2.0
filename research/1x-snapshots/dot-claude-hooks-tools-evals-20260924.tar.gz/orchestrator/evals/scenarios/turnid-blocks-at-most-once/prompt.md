Second stop for the SAME turn, still with no id in the reply: silence. One block per minted turn,
recorded in the marker itself, so a model that cannot or will not comply ends its turn anyway.
This is the brake that holds even if the loop guard field ever changes shape.

. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
mint_id p-1 > /dev/null
P='{"hook_event_name":"Stop","stop_hook_active":false,"session_id":"eval","prompt_id":"p-1","last_assistant_message":"no id"}'
OUT1=$(printf '%s' "$P" | LINTEL_STATE="$WORK" node "$HOOKS/turn-id-verify.mjs") || { echo INDETERMINATE >&2; exit 3; }
case "$OUT1" in *'"decision":"block"'*) ;; *) echo "FAIL: first stop did not block" >&2; exit 1 ;; esac
expect_silence turn-id-verify.mjs "$P"

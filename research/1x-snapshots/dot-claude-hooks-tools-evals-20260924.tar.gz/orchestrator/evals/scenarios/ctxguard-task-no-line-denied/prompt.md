Task is the second dispatch tool name on this machine (routing-counter.mjs isDispatch). Same bare brief as ctxguard-no-line-denied, tool_name Task.

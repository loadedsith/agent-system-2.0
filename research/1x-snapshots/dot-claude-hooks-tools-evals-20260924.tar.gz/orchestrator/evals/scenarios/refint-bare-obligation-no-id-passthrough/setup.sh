printf '{"id":"REQ-001","state":"open","request":"a real obligation"}\n' > "$WORK/REQUESTS.jsonl"
printf '{"ts":"2026-01-01T00:00:00Z","triaged":true,"disposition":"obligation","triage_note":"already delivered before the request arrived; no new obligation","verbatim":"commit that builder ticks"}\n' > "$WORK/REQUESTS-INBOX.jsonl"
sleep 1; printf '# new\n' > "$WORK/STANDUP.md"

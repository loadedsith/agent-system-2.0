SILENCE. disposition:"obligation" with a triage_note saying no new obligation was needed is a real
and common shape on the live inbox (5 rows). Invariant 1 is scoped to ids that are NAMED, so this
must not fire. Guards against the over-broad version of the check.

. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_allow_tool staging-guard.mjs '{"session_id": "some-other-session-9f2c", "tool_name": "Bash", "cwd": "/Users/jowolff/.claude", "tool_input": {"command": "git add -A"}}'

SILENCE sibling of staging-mass-add-denied, differing in exactly ONE field: session_id. The
staging guard denied legitimate commands in sessions that had nothing to do with the orchestrator.
Same cwd, same command, foreign session: it must keep its mouth shut.

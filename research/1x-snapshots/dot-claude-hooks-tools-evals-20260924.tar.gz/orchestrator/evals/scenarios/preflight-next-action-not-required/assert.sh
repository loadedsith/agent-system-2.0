# eval-pair: silence summon.sh
# Shared preamble for the preflight-* scenarios. Inlined rather than added to lib/hook-eval.sh:
# that library is about piping JSON payloads into node hooks, and summon.sh is neither.
ORCH=$(CDPATH= cd -- "$(dirname -- "$0")/../../.." 2>/dev/null && pwd)
SUMMON="$ORCH/summon.sh"
[ -f "$SUMMON" ] || { echo "INDETERMINATE: no summon.sh at $SUMMON" >&2; exit 3; }
command -v zsh >/dev/null || { echo "INDETERMINATE: summon.sh is a zsh script and zsh is not on PATH" >&2; exit 3; }
# Preflight step [1/6] requires the claude binary. Without it every run below fails for a reason
# that has nothing to do with the state layer, which would read as a pass on the missing-file
# scenarios and prove the opposite of what they exist to prove.
command -v claude >/dev/null || { echo "INDETERMINATE: claude not on PATH; preflight [1/6] would fail for an unrelated reason" >&2; exit 3; }
# THE TEST SEAMS MUST EXIST. Without LINTEL_STATE this would silently exercise the LIVE state
# directory instead of the fixture, and without LINTEL_SUMMON_LOG it would overwrite the real
# summon.log. Either one makes the verdict meaningless, so refuse rather than guess.
grep -q 'LINTEL_STATE' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_STATE; this would test the live state dir" >&2; exit 3; }
grep -q 'LINTEL_SUMMON_LOG' "$SUMMON" || { echo "INDETERMINATE: summon.sh no longer honours LINTEL_SUMMON_LOG; this would clobber the real summon.log" >&2; exit 3; }
LOG="$WORK/summon-preflight.log"
run_preflight() {
  ORCH_PREFLIGHT_ONLY=1 LINTEL_STATE="$WORK/state" LINTEL_SUMMON_LOG="$LOG" \
    zsh "$SUMMON" "$WORK" >/dev/null 2>&1
}

rm -f "$WORK/state/NEXT-ACTION.md" "$WORK/state/TODO.md"
if run_preflight; then exit 0; fi
echo "FAIL: preflight now REQUIRES NEXT-ACTION.md and/or TODO.md. Neither has a code reader." >&2
echo "      If that changed, cite the reader and update this scenario. Do not just add the file." >&2
sed 's/^/    /' "$LOG" >&2
exit 1

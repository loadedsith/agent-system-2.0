LOCKS IN A DELIBERATE EXCLUSION, so nobody restores it without new evidence.

state/NEXT-ACTION.md and state/TODO.md are session CONTENT, not machinery. Grepped across
orchestrator/hooks, summon.sh and the charter on 2026-08-20: neither has a single code reader.
NEXT-ACTION.md's only mentions are prose pointers inside STANDUP.md and an allowlist regex in
tools/sync-to-lintel.sh, which is a publish filter and not a startup read.

The required list is meant to be DERIVED from what a cold start reads. If it drifts into an
inventory of whatever happens to sit in state/, it stops meaning anything and every new file
becomes a reason a session will not start. This scenario is the tripwire on that drift.

SILENCE. Same firing row plus "instruction_reviewed": true. The heuristic is biased toward flagging,
so a per-row way to record "I looked, it really was conversation" is what keeps a false flag costing
one line instead of an argument every stop.

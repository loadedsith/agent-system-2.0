printf '{"id":"REQ-001","state":"open","request":"a real obligation"}\n' > "$WORK/REQUESTS.jsonl"
printf '2026-01-01T00:00:00Z' > "$WORK/.refint-watermark"
printf '{"ts":"2026-02-01T00:00:00Z","triaged":true,"disposition":"conversation","instruction_reviewed":true,"verbatim":"also please fix the deploy pipeline before friday"}\n' > "$WORK/REQUESTS-INBOX.jsonl"
sleep 1; printf '# new\n' > "$WORK/STANDUP.md"

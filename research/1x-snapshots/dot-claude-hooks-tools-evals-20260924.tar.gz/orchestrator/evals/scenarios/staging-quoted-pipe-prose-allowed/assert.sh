. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_allow_tool staging-guard.mjs '{"session_id": "eval", "tool_name": "Bash", "cwd": "/Users/jowolff/.claude", "tool_input": {"command": "echo \"run git status | tail; git add -A is what the guard denies\""}}'

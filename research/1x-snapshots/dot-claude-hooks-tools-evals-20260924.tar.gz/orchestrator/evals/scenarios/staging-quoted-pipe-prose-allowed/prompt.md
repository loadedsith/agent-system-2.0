REGRESSION for the second defect. The splitter cut on every pipe INCLUDING pipes inside quoted
strings, so a quoted sentence containing a pipe was chopped into fragments and matched. Firing
sibling: staging-mass-add-denied.

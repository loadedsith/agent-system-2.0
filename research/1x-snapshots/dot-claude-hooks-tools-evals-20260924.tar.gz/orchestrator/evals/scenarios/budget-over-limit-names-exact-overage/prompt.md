FIRING. 6487 bytes — the size commit 98a5a32 ("Standup under the injection cut") actually left the
live STANDUP.md at on 2026-08-19, 487 bytes over the limit it claimed to be under. The block must
name 487, because a writer told "it is too big" trims blind and a writer told "cut 487 bytes"
trims once. The fixture is synthetic padding at that exact size, not the real file's text.

. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_fit_hook
SZ=$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')
[ "$SZ" -eq 6487 ] || { echo "INDETERMINATE: fixture is $SZ bytes, expected 6487" >&2; exit 3; }
expect_block savepoint-fit-stop.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}' 'OVER BY 487 bytes'

FIRING sibling of staging-dash-C-out-of-guard-allowed, differing only in the -C path. A command
issued from another repo can redirect itself INTO the guarded tree with -C; scope must follow the
repo the command affects, not the session cwd.

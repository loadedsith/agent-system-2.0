. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_deny staging-guard.mjs '{"session_id": "eval", "tool_name": "Bash", "cwd": "/Users/jowolff/code/shipyard", "tool_input": {"command": "git -C ~/.claude add -A"}}'

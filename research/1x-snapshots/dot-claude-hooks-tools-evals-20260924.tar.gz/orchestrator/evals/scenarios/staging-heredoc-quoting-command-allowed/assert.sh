. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_allow_tool staging-guard.mjs '{"session_id": "eval", "tool_name": "Bash", "cwd": "/Users/jowolff/.claude", "tool_input": {"command": "cat > /Users/jowolff/.claude/notes.md <<MARKDOC\nThe guard denies this shortcut:\ngit add -A\nand this one:\ngit commit -am wip\nMARKDOC"}}'

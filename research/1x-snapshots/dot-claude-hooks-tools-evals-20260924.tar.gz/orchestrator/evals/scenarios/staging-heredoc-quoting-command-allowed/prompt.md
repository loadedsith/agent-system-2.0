REGRESSION for the second defect, measured three times today: writing a DOCUMENT whose text
quotes a mass-staging command was denied, including the document describing this very bug. The
guard split the command string on newlines inside the heredoc body, so a prose line that BEGAN
with the command matched the anchored pattern. Firing sibling: staging-mass-add-denied.

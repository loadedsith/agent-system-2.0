SILENCE sibling of staging-dash-C-into-guard-denied. Scope came from the session cwd, so a
command sitting in ~/.claude but pointed by -C at a DIFFERENT repo was denied — a guard firing
where it has no business. The command cannot touch the guarded tree; it must pass.

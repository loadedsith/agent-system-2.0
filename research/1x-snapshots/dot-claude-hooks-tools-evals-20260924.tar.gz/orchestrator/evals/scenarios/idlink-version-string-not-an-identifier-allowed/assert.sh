. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence identifier-link-guard.mjs
expect_silence identifier-link-guard.mjs '{"session_id": "eval", "last_assistant_message": "The seat runs plugin 0.2.169 and adapter md5 41c452d1."}'

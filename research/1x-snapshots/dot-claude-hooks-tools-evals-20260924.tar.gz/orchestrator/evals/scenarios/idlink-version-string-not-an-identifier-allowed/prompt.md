The false-positive control, and the one that decides whether this guard is liveable.

A guard on outgoing text taxes every message a seat sends. Version strings, md5 prefixes and counts are not identifiers and must not fire: `0.2.169` is not a PR, and `md5 41c452d1` is not a ticket. This pins the narrowness of the matcher rather than a past defect, and says so.

If this goes red the matcher has widened and the guard has become a tax.

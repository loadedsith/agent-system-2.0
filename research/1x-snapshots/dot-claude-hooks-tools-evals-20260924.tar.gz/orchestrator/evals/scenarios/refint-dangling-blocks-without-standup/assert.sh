. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_block savepoint-guard.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}' 'REFERENTIAL INTEGRITY'

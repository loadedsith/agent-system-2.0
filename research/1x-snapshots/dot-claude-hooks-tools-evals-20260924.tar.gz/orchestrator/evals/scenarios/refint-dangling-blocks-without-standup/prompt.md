FIRING. No STANDUP.md at all. The pre-existing hook allowed immediately in that case; the integrity
check runs BEFORE that gate, because a broken triage reference is a defect whether or not a save
point exists. Pins the ordering.

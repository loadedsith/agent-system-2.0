# eval-pair: firing turn-id-mint.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
A=$(mint_id p-1); B=$(mint_id p-2)
TA=$(printf '%s' "$A" | cut -d- -f4); TB=$(printf '%s' "$B" | cut -d- -f4)
[ "$(printf '%s' "$TA" | cut -c1-2)" = "$(printf '%s' "$TB" | cut -c1-2)" ] \
  || { echo "FAIL: same session, different session tag: $A vs $B" >&2; exit 1; }
[ "$(printf '%s' "$TA" | cut -c3-4)" != "$(printf '%s' "$TB" | cut -c3-4)" ] \
  || { echo "FAIL: different prompts, same prompt tag: $A vs $B" >&2; exit 1; }
# Now a different session, against its own marker.
printf 'other-session\n' > "$WORK/.session-id"
C=$(printf '%s' '{"hook_event_name":"UserPromptSubmit","session_id":"other-session","prompt_id":"p-1","cwd":"/tmp/fixture","prompt":"x"}' \
  | LINTEL_STATE="$WORK" node "$HOOKS/turn-id-mint.mjs" | sed -n 's/.*TURN ID: \(T-[0-9]*-[0-9]*-[0-9A-Z]*\).*/\1/p')
[ -n "$C" ] || { echo "INDETERMINATE: second session minted nothing" >&2; exit 3; }
TC=$(printf '%s' "$C" | cut -d- -f4)
[ "$(printf '%s' "$TC" | cut -c1-2)" != "$(printf '%s' "$TA" | cut -c1-2)" ] \
  || { echo "FAIL: two sessions share a session tag: $A vs $C" >&2; exit 1; }
exit 0

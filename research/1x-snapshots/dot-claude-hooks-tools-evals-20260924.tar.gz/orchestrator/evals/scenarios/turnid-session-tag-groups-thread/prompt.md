The 4-character tag is 2 chars of session + 2 chars of prompt. That split is the whole reason Jo
can tell parallel threads apart at a glance, so it is asserted directly: two turns of one session
share their first two tag characters, and a turn of a different session does not (it is minted
against its own gate marker, since the gate only ever admits one session at a time).

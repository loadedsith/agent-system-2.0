. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_fit_hook
# FIXTURE SELF-CHECK. The runner discards setup.sh's exit status (measured 2026-08-20), so a setup
# that failed silently would otherwise reach the hook as a missing file and be reported as a pass.
# This turns that into INDETERMINATE, which the runner does surface.
SZ=$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')
[ "$SZ" -eq 6335 ] || { echo "INDETERMINATE: fixture is $SZ bytes, expected 6335" >&2; exit 3; }
grep -q '^## NEXT ACTION$' "$WORK/STANDUP.md" || { echo "INDETERMINATE: fixture lacks the cliff heading" >&2; exit 3; }
expect_block savepoint-fit-stop.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}' '## NEXT ACTION   <-- FALLS OFF THE CLIFF'

FIRING scenario for savepoint-fit-stop.mjs. A 6335-byte standup whose LAST section, "## NEXT
ACTION", starts at byte 5019 and ends at 6335 — so it is the section that straddles the 6000-byte
limit and is the one savepoint-restore.sh drops.

The point of this hook, and the only thing that distinguishes it from the budget stanza already in
savepoint-guard.mjs, is that the block reason NAMES THAT SECTION. Asserting only "it blocked"
would pass against a hook that repeats the overage and nothing else, which is the hook we already
have and the one that did not stop the repair loop. So this asserts on the cliff marker.

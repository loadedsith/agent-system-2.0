REGRESSION for spelling-based matching. `git add -h` documents --ignore-removal as "same as
--no-all", which makes --no-ignore-removal exactly -A under a different name. Its silence sibling
is staging-negated-flag-allowed, which uses the NON-negated spelling and must pass.

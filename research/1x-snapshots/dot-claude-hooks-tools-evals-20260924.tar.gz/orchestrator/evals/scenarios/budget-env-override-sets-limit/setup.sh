printf '## Save point\n' > "$WORK/STANDUP.md"
head -c 136 /dev/zero | LC_ALL=C tr '\0' 'x' >> "$WORK/STANDUP.md"

. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_fit_hook
SZ=$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')
[ "$SZ" -eq 150 ] || { echo "INDETERMINATE: fixture is $SZ bytes, expected 150" >&2; exit 3; }
# Exported HERE rather than in setup.sh: the runner sources setup.sh in a subshell, so an export
# there would not reach this script. Same reasoning as fit-missing-checker-fails-safe.
LINTEL_INJECTION_BUDGET=100; export LINTEL_INJECTION_BUDGET
expect_block savepoint-fit-stop.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}' 'budget: 100 bytes  [source: env LINTEL_INJECTION_BUDGET]'

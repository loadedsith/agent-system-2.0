FIRING. LINTEL_INJECTION_BUDGET overrides the derived limit, which is how a scenario can exercise
the check without a 6KB fixture and how the number can be changed without editing two hooks. A
150-byte standup against a 100-byte budget must report a budget of 100 and an overage of 50.

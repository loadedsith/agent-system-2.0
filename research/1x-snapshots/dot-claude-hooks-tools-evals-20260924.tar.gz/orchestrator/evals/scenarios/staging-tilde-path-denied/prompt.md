The scope test matched only the literal absolute path, so entering the directory by its tilde
path and staging there was invisible. cwd is elsewhere; the command walks in by tilde. Silence
sibling: staging-outside-claude-dir-allowed, which stays outside by both spellings.

Loop guard, parsed rather than substring-matched — the defect the shell save-point guard shipped
with. Identical to turnid-reply-without-id-blocks except stop_hook_active is true.

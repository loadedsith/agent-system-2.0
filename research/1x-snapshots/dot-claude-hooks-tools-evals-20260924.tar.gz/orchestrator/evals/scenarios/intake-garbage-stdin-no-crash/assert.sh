# eval-pair: silence intake-capture.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
printf 'not json' | LINTEL_STATE="$WORK" node "${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}/intake-capture.mjs"
[ $? -eq 0 ] && exit 0
echo "FAIL: nonzero exit on garbage stdin" >&2; exit 1

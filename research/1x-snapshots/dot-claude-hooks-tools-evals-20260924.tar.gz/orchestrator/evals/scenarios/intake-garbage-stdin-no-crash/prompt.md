Runs on every prompt Jo types. Must never break a turn.

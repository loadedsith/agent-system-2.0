Jo, 2026-09-15: "make sure that whenever you give me a linear fucking ticket number, it also has the link. That's important."

Linear is first-class here, not a secondary class behind GitHub. A turn naming `ALL-937` without a linear.app URL must be BLOCKED.

The reason must NOT contain a constructed URL. The authoritative link is the `url` field from `get_issue`, and per ROUTING.md fact 7 the Linear MCP namespace exists only in a top-level session — so no hook can resolve an id to a URL. A guard that synthesises a plausible Linear URL emits something that reads authoritative and may 404. This asserts the refusal names its SOURCE instead, which is why the expected substring is `get_issue` rather than a link.

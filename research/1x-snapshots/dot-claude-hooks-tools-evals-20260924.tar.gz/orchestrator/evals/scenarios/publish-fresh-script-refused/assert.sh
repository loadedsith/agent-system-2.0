# eval-pair: firing publish-run.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
STUB="$WORK/pub.sh"
make_stub_publisher "$STUB"          # written just now, so its age is ~0s
AGE_OK=$(find "$STUB" -newermt '-10 seconds' 2>/dev/null | wc -l | tr -d ' ')
[ "$AGE_OK" = "1" ] || _indeterminate "fixture is not actually fresh; the case tests nothing"

CODES="$(CDPATH= cd -- "$(dirname -- "$0")/../../../tools" 2>/dev/null && pwd)/publish-exit-codes.sh"
[ -f "$CODES" ] || _indeterminate "no publish-exit-codes.sh at $CODES; the expected exit code cannot be read"
# The code is READ from the one file that defines it, never copied here. A number written into two
# files is the exact defect publish-exit-codes.sh was created to fix.
UNSETTLED=$(zsh -c ". \"$CODES\"; print -r -- \"\$PUBLISH_EXIT_SCRIPT_UNSETTLED\"" 2>/dev/null)
[ -n "$UNSETTLED" ] || _indeterminate "publish-exit-codes.sh does not define PUBLISH_EXIT_SCRIPT_UNSETTLED"

run_publisher "$STUB"

_publisher_executed && { echo "FAIL: the publisher was executed; a script edited seconds ago must not run" >&2; exit 1; }
[ "$PUB_RC" -eq "$UNSETTLED" ] || {
  echo "FAIL: expected the SCRIPT_UNSETTLED decline code $UNSETTLED, got $PUB_RC" >&2
  cat "$PWD/.pub-out" >&2 2>/dev/null; exit 1; }
# A DECLINE writes NO failure marker: nothing broke, and a failure banner for a correct decision is
# what publish-exit-codes.sh exists to stop.
[ -f "$PUB_FAIL" ] && {
  echo "FAIL: a decline wrote a failure marker: $(cat "$PUB_FAIL")" >&2; exit 1; }
# ...but it must not be SILENT either. The run log is the only record that anything happened, and a
# guard that skips without saying so is indistinguishable from a backup that quietly stopped.
[ -f "$PUB_LOG" ] || { echo "FAIL: declined with no run log at $PUB_LOG" >&2; exit 1; }
grep -q 'declining' "$PUB_LOG" || {
  echo "FAIL: the run log never says the run was declined for freshness" >&2
  sed 's/^/    /' "$PUB_LOG" >&2; exit 1; }
# The consecutive-decline streak file is what eventually makes a publisher that declines forever
# get loud. Without it the quiet path has no floor.
[ -f "$WORK/.guard-state/publish-eval.skipped" ] || {
  echo "FAIL: no decline-streak file; a publisher that declines forever would never escalate" >&2; exit 1; }
exit 0

THE DEFECT THIS PINS, which actually happened.

On 2026-08-20 the Stop hook spawned tools/publish-run.sh against tools/backup-state.sh while that
file carried an agent's uncommitted edit made 50 seconds earlier. The run committed, pushed a
branch and opened pull request #5 against a real private repository. Nobody asked for it and
nobody had reviewed that version of the script. It caused no damage only because the version on
disk at that instant happened to be a finished one; a version caught between two writes would
have executed identically.

A script that was written to seconds ago is being worked on. The wrapper must not run it, and
must leave the marker file the Stop hook reads, so the skip is visible rather than silent.

FIRING SIBLING: publish-settled-script-runs, differing in exactly one field — the script's mtime.

THE CONTRACT CHANGED ON 2026-08-20 and this scenario was red because of it. Being handed a script
edited seconds ago used to be a REFUSAL: exit 3 plus a publish-<name>.fail marker, which the Stop
hook escalates into a session-blocking "PUBLISHING IS NOT HAPPENING" banner and a 30-minute
backoff. It is now a DECLINE -- tools/publish-exit-codes.sh defines the code, no failure marker is
written, the run log records it, and a decline-streak file escalates it if the declining never
stops. The reasoning is in publish-exit-codes.sh: the condition clears by itself in about two
minutes, so a failure banner for it is a false alarm that also suppresses the next real one.

The load-bearing half is unchanged and is what this still pins: THE PUBLISHER DOES NOT RUN. What
was updated is the channel the skip is reported on. Both halves of the channel are asserted -- no
failure marker AND not silent -- because "no marker" alone is also what a guard that skipped and
said nothing would produce, and that is a backup quietly not happening.

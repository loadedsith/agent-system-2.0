. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence ctx-search-guard.mjs
export MARCHES_SEAT='   '
expect_allow_tool ctx-search-guard.mjs '{"session_id":"eval","tool_name":"Agent","cwd":"/Users/jowolff/code/shipyard/repos/kitchen","tool_input":{"subagent_type":"scout","description":"find login validation","prompt":"Find where the login form is validated and report the file and line."}}'

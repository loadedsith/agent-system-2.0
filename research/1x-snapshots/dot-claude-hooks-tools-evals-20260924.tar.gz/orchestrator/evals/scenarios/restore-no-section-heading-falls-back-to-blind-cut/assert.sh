# eval-pair: firing savepoint-restore.sh
[ "$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')" -eq 9000 ] || { echo "INDETERMINATE: fixture is not 9000 bytes" >&2; exit 3; }
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf %s '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
case "$OUT" in *'## ONLY HEADING'*) ;; *) echo "FAIL: fell back to injecting nothing" >&2; exit 1 ;; esac
case "$OUT" in *'STANDUP TRUNCATED. 3000 of 9000 bytes were NOT shown'*) exit 0 ;; esac
echo "FAIL: expected the blind-cut fallback to drop 3000 of 9000 bytes; got: ${OUT:-<silence>}" >&2; exit 1

A 9000-byte standup whose only `## ` heading sits at byte 0. Snapping to it would inject nothing at
all, which is worse than the defect being fixed. The hook must fall back to the blind 6000-byte cut
and still banner: 3000 bytes dropped.

This is the failure mode the boundary cut introduces, so it gets its own scenario.

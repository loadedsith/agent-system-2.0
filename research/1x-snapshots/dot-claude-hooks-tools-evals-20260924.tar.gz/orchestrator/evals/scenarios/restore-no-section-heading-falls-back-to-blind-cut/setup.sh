{ printf '## ONLY HEADING\n'; head -c 8983 /dev/zero | tr '\0' 'x'; printf '\n'; } > "$WORK/STANDUP.md"

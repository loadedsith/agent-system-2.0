# eval-pair: firing turn-id-mint.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
ID=$(mint_id p-1)
TODAY=$(date +%Y%m%d)
case "$ID" in
  "T-$TODAY-"??????-????) ;;
  *) echo "FAIL: id '$ID' does not carry today's local date $TODAY in T-YYYYMMDD-HHMMSS-XXXX form" >&2; exit 1 ;;
esac
[ ${#ID} -eq 22 ] || { echo "FAIL: id '$ID' is ${#ID} characters, expected 22" >&2; exit 1; }
printf '%s' "$ID" | grep -Eq '^T-[0-9]{8}-[0-9]{6}-[2-9A-HJ-NP-TV-Z]{4}$' \
  || { echo "FAIL: '$ID' does not match the shared TURN_ID_RE shape" >&2; exit 1; }
HH=$(printf '%s' "$ID" | cut -d- -f3 | cut -c1-2)
NOWH=$(date +%H)
[ "$HH" = "$NOWH" ] || { echo "FAIL: id hour $HH is not the local hour $NOWH — the stamp is not local time" >&2; exit 1; }
exit 0

"The id survives what the format claims to encode." The format claims a human-readable local date
and time; this asserts the date half against the machine's own `date`, and the whole string
against the shared regex, so a change to either the format or the timezone handling fails here
rather than silently producing ids that point at the wrong day.

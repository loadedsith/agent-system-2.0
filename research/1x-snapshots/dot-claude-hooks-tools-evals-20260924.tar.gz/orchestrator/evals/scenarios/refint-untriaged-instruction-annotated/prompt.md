FIRING. An untriaged row that reads as an instruction is annotated in the save-point block so it is
not skimmed past in a list of eight. The pre-existing 'never been triaged' wording is preserved.

SILENCE sibling. The workflow actually used for every commit in this repo must survive.

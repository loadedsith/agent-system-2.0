Coexistence: a ctx line alone does not satisfy brief-clause-guard.mjs. Firing sibling that keeps ctxguard-coexist-both-satisfied-clauses-allowed honest.

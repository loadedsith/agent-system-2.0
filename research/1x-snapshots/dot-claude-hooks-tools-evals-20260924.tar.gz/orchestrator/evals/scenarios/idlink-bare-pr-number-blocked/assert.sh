. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: firing identifier-link-guard.mjs
expect_block identifier-link-guard.mjs '{"session_id": "eval", "last_assistant_message": "I landed the fix in #1073 this evening."}' '#1073'

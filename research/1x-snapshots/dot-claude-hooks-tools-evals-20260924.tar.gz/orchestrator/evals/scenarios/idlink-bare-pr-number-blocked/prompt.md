Jo, 2026-09-11 (REQ-480, still open): "why, for the love of fuck, would you reference a PR and not give me the hard link to where it lives in GitHub? I'm not going to hunt for it."

The defect this pins actually happened, repeatedly: on 2026-09-15 Tinker emitted ten bare identifiers in one session (`#1073`, `#1059`, `#1071`, `ALL-937`, `ALL-903`, `ALL-953`, `ALL-954`, `DEC-075`, `ENG-1958`, `REQ-327`), and the rule forbidding it already existed in three documents — BRIEF-BOILERPLATE.md:142-144, every seat's boot prompt, and JUDGEMENT.md:49 — with zero enforcement.

A turn naming `#1073` with no GitHub URL must be BLOCKED, and the reason must name the identifier.

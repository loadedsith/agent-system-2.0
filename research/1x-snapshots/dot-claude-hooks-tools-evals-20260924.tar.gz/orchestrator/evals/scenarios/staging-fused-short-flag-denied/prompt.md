REGRESSION for spelling-based matching. -vA is -v -A. The old regex required -A to stand alone,
so fusing it to any other short flag walked past the guard. Verified as a real mass add by
running `git add --dry-run -vA .`, git 2.50.1.

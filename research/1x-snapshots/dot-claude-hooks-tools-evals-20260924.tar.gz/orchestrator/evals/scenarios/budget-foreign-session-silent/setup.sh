printf '## Save point\n' > "$WORK/STANDUP.md"
head -c 6473 /dev/zero | LC_ALL=C tr '\0' 'x' >> "$WORK/STANDUP.md"

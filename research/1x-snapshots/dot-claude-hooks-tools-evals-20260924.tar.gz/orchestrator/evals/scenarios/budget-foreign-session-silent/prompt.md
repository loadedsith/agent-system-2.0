SILENCE sibling of budget-over-limit-names-exact-overage, differing in exactly ONE field:
session_id. Same 6487-byte standup. The session gate must still win — a Stop hook that lectures an
unrelated session in another repo about the orchestrator's standup size is the defect the gate was
added for, and a new check placed above the gate would reintroduce it.

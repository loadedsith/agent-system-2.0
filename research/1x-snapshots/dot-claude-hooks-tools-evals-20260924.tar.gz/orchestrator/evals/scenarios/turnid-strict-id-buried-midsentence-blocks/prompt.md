THE DISCRIMINATING SCENARIO of the item-8 trio, and the only one of the three that was not already
covered by the suite. The reply contains the id but buried mid-sentence, with no final line of its
own. turn-id-mint.mjs forbids this shape; the installed verifier accepts it, because its test is
`reply.includes(id)`.

Run against the INSTALLED hook this scenario FAILS ("expected block, got: <silence>"). That failure
is the defect, reproduced. Against the candidate in
/Users/jowolff/.claude/orchestrator/state/hook-lab/turn-id-verify-strict it passes.

It also asserts on the block reason, not just on the fact of a block: a reply whose id is present
but misplaced must be told "NOT ON THE FINAL LINE", never "MISSING". A model that can see the id in
its own text and is told the id is missing has been given a false instruction and is liable to
re-send the same reply.

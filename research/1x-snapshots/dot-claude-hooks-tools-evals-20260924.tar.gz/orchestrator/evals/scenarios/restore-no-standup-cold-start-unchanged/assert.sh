# eval-pair: silence savepoint-restore.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf %s '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
case "$OUT" in *'STANDUP TRUNCATED'*) echo "FAIL: truncation banner with no standup on disk" >&2; exit 1 ;; esac
case "$OUT" in *'NO STANDUP.md EXISTS'*) exit 0 ;; *) echo "FAIL: cold start not announced: ${OUT:-<silence>}" >&2; exit 1 ;; esac

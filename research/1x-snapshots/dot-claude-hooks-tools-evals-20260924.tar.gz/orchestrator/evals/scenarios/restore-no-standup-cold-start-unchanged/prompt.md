Regression guard on the branch this change did not touch. With no STANDUP.md the hook must still
say so in as many words rather than emitting an empty save point or a truncation banner about a
file that does not exist.

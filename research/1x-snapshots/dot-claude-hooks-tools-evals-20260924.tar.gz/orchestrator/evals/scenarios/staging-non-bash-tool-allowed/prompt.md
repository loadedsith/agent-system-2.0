Wrong tool name must pass through untouched.

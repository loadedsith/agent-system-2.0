# eval-pair: silence staging-guard.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf '%s' '{"session_id": "eval", "tool_name":"Read","cwd":"/Users/jowolff/.claude","tool_input":{}}' | node "${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}/staging-guard.mjs"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
[ -z "$OUT" ] && exit 0
echo "FAIL: acted on a non-Bash tool" >&2; exit 1

. "$(dirname "$0")/../../lib/hook-eval.sh"
printf '%s' '{"hook_event_name": "UserPromptSubmit", "session_id": "eval", "user_input": "please audit the deploy pipeline"}' | LINTEL_STATE="$WORK" node "${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}/intake-capture.mjs" || { echo INDETERMINATE >&2; exit 3; }
expect_file_contains "$WORK/REQUESTS-INBOX.jsonl" 'audit the deploy pipeline'

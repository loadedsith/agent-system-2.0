FIRING sibling of intake-ignores-machine-envelope. Uses the DOCUMENTED field name user_input —
the first version read `prompt` and would have captured nothing, silently.

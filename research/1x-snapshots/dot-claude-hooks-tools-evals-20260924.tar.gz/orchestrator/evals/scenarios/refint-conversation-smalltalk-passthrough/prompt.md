SILENCE sibling of refint-conversation-instruction-blocks. Identical except the verbatim is real
small talk taken from the live inbox. Must stay silent, or every stop blocks forever.

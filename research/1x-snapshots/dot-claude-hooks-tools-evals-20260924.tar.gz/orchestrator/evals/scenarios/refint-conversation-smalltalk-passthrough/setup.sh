printf '{"id":"REQ-001","state":"open","request":"a real obligation"}\n' > "$WORK/REQUESTS.jsonl"
printf '2026-01-01T00:00:00Z' > "$WORK/.refint-watermark"
printf '{"ts":"2026-02-01T00:00:00Z","triaged":true,"disposition":"conversation","verbatim":"Perfect, Lintel. I hope you like who you are turning into."}\n' > "$WORK/REQUESTS-INBOX.jsonl"
sleep 1; printf '# new\n' > "$WORK/STANDUP.md"

# eval-pair: firing intake-sweep.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
H="${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}"
node "$H/intake-sweep.mjs" "$WORK/t.jsonl" "$WORK" >/dev/null
node "$H/intake-sweep.mjs" "$WORK/t.jsonl" "$WORK" >/dev/null
N=$(grep -c 'unique request text here' "$WORK/REQUESTS-INBOX.jsonl")
[ "$N" -eq 1 ] && exit 0
echo "FAIL: captured $N times, expected 1" >&2; exit 1

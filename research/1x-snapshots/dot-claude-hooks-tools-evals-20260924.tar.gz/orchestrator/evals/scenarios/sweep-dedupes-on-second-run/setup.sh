printf '%s\n' \
  '{"type":"queue-operation","operation":"enqueue","content":"unique request text here","timestamp":"2026-01-01T00:00:00Z"}' \
  '{"type":"queue-operation","operation":"remove","content":"unique request text here","timestamp":"2026-01-01T00:00:05Z"}' \
  > "$WORK/t.jsonl"

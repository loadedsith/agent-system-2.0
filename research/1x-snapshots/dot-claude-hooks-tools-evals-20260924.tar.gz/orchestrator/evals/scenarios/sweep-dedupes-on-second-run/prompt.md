Runs at every turn end. Must be idempotent or the inbox fills with duplicates.

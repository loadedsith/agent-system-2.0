SILENCE sibling of fit-over-limit-names-cliff-section. Same three headings, same shape, 335 fewer
bytes in the last section so the file lands at 6000 exactly — the boundary. At or under the limit
savepoint-restore.sh drops nothing, so the hook must say nothing. Paired with the firing sibling
this pins the comparison to `bytes <= limit` rather than `bytes < limit`.

{ printf '## Alpha\n';       head -c 3000 /dev/zero | LC_ALL=C tr '\0' 'a'; printf '\n'
  printf '## Beta\n';        head -c 2000 /dev/zero | LC_ALL=C tr '\0' 'b'; printf '\n'
  printf '## NEXT ACTION\n'; head -c 965  /dev/zero | LC_ALL=C tr '\0' 'c'; printf '\n'
} > "$WORK/STANDUP.md"

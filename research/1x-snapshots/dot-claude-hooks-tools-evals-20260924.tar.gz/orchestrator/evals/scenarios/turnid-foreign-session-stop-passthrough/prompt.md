The Stop half is gated too, belt and braces: even with a marker present, a stop from another
session is silent. Without this a session that happened to reuse a prompt_id could be held for an
id it was never given.

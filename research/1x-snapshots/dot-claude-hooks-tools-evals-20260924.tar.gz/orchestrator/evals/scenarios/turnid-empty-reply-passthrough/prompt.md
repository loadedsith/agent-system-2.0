No last_assistant_message, or an empty one, means there is no text to check. Blocking there would
be an assertion about a reply nobody has seen.

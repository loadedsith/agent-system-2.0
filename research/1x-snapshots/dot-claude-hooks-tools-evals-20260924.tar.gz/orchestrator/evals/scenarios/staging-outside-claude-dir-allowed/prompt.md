SILENCE sibling of staging-mass-add-denied, differing ONLY in cwd. Jo's other repos are none of
this hook's business.

. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
mint_id p-1 > /dev/null
expect_block turn-id-verify.mjs \
  '{"hook_event_name":"Stop","stop_hook_active":false,"session_id":"eval","prompt_id":"p-1","last_assistant_message":"here is the answer"}' \
  'TURN ID MISSING'

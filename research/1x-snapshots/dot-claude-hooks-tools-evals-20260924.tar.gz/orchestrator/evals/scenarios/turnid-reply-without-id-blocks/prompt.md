FIRING sibling of turnid-reply-with-id-passes. The enforcement half: a reply that did not carry
the id is blocked, and the block message names the id so the retry can comply.

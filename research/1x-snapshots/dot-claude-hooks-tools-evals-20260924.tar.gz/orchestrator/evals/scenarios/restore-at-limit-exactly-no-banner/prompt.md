The boundary. A standup of EXACTLY 6000 bytes is not truncated: nothing is dropped, so no banner.
Pinning this is what makes the comparison `-le` rather than `-lt` a decision instead of an accident.

Paired with restore-one-byte-over-banners, which differs by exactly one byte of fixture.

# eval-pair: silence savepoint-restore.sh
[ "$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')" -eq 6000 ] || { echo "INDETERMINATE: fixture is not exactly 6000 bytes" >&2; exit 3; }
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf %s '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
case "$OUT" in *'STANDUP TRUNCATED'*) echo "FAIL: a 6000-byte standup is at the limit, not over it; banner fired anyway" >&2; exit 1 ;; esac
case "$OUT" in *'TAIL CANARY'*) exit 0 ;; *) echo "FAIL: the 6000th byte did not reach the model" >&2; exit 1 ;; esac

# 6000 bytes exactly: 13-byte heading + 5974 x + newline + "TAIL CANARY" + newline = 6000
{ printf '## SECTION 1\n'; head -c 5974 /dev/zero | tr '\0' 'x'; printf '\nTAIL CANARY\n'; } > "$WORK/STANDUP.md"
SZ=$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')
[ "$SZ" -eq 6000 ] || echo "FIXTURE IS $SZ BYTES, NOT 6000"

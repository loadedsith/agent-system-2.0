The block message must name the SPECIFIC row, by inbox line number and by the undefined id, so the
fix is a one-line edit rather than a hunt. Asserts the exact string "inbox line 2 -> REQ-007b".

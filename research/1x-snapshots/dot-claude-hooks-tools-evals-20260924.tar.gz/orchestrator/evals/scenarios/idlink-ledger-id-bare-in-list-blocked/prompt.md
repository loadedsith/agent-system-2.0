The firing sibling of idlink-ledger-id-with-content-allowed, one field apart: the same ids with their content removed.

This is Jo's exact complaint shape — "5B 22C 3D 8 still local only" (JUDGEMENT.md:49): a bare list of identifiers that requires the reader to look every one of them up.

A ledger id in a content-free list must be BLOCKED, and the reason must say CONTENT is what is missing rather than a link, because no link exists to add.

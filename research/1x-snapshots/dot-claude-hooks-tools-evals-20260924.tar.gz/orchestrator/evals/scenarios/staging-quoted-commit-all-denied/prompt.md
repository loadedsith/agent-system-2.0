REGRESSION for the requoting bypass on git commit. Quoting the fused -am flag allowed a mass
commit straight through.

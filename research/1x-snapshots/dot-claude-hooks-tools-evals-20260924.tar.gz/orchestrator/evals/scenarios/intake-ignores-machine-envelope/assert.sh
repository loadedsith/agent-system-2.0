. "$(dirname "$0")/../../lib/hook-eval.sh"
printf '%s' '{"hook_event_name": "UserPromptSubmit", "session_id": "eval", "user_input": "<task-notification> agent finished"}' | LINTEL_STATE="$WORK" node "${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}/intake-capture.mjs" || { echo INDETERMINATE >&2; exit 3; }
expect_file_lacks "$WORK/REQUESTS-INBOX.jsonl" 'task-notification'

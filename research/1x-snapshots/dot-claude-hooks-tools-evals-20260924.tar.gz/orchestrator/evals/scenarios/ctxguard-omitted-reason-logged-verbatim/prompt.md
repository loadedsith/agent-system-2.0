The allow half of the log, and the omission reason recorded verbatim.

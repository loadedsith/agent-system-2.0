. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: firing ctx-search-guard.mjs
_run ctx-search-guard.mjs '{"session_id":"eval","tool_name":"Agent","cwd":"/Users/jowolff/.claude","tool_input":{"subagent_type":"scout","description":"find login validation","prompt":"Find where the login form is validated and report the file and line.\nCTX_OMITTED: one-line existence check, no prior work to find"}}'; _check_exit0
expect_file_contains "$WORK/ctx-search-guard.jsonl" 'one-line existence check, no prior work to find'

# The thing under test is a Bun extension module rather than a hook fed one JSON payload, so the
# fixture is a HOST STAND-IN instead of a payload on stdin. It fakes only the three HookAPI members
# the module touches (`on`, `appendEntry`, `sendMessage`); nothing here simulates the agent loop.
#
# ⛔ `$WORK/repo/.git` IS A SAFETY DEVICE, NOT SCENERY. `archiveCompactionState` resolves the
# archive root by walking UP from the handler's cwd to the first `.git`, and it PRUNES the directory
# it writes into — its age rule deletes any session's record older than a week. A cwd with no `.git`
# beneath $WORK would walk out of the fixture and prune a real archive. probe.ts refuses to run if
# this directory is missing rather than trusting that it is here.
#
# ⛔ `newdle-hooks.json` IS ALSO LOAD-BEARING. Without a gate file up-tree, `compactionProjectDir`
# hands the spawned plugin hook `CLAUDE_PROJECT_DIR=/Users/jowolff/.claude/orchestrator/state/hook-scope-anchor`
# — a real path outside the fixture. With it, every path the spawn sees is under $WORK.
#
# assert.sh runs it as `bun probe.ts <module>`. Its exit code is a HARNESS verdict only.
mkdir -p "$WORK/repo/.git"
printf '{}\n' > "$WORK/repo/newdle-hooks.json"
cat > "$WORK/probe.ts" <<'PROBE_TS'
import { existsSync, readdirSync, writeFileSync } from "node:fs";

const work = process.env.WORK ?? process.cwd();
const modulePath = process.argv[2];
if (!modulePath) {
	console.error("harness: no module path in argv");
	process.exit(2);
}

// ⛔ BUN INFERS ITS LOADER FROM THE FILE EXTENSION, and the canonical mutant for this scenario —
// the pre-judgment bytes kept as `newdle-hooks.ts.pre-judgment-20260916-0025` — does not end in
// `.ts`. Importing it yields a module with no exports, and "exports no default activation function"
// then reads as a defect in the module rather than in the invocation. Say which it is.
if (!/\.(ts|tsx|mts|js|mjs|jsx)$/.test(modulePath)) {
	console.error(`harness: bun cannot infer a loader for ${modulePath}; copy the bytes to a .ts path and point LINTEL_NEWDLE_HOOKS at that`);
	process.exit(2);
}

// ⛔ CHECKED, NOT ASSUMED, BECAUSE THE WRITE PATH CONTAINS A DELETE. See the note in setup.sh: the
// archive root is the first ancestor holding `.git`, and the writer prunes that directory by age
// across every session. A fixture that cannot prove its own root refuses to run.
const repo = `${work}/repo`;
if (!work.startsWith("/") || work === "/" || !repo.startsWith(work)) {
	console.error(`harness: refusing to run outside a fixture workdir (${work})`);
	process.exit(2);
}
if (!existsSync(`${repo}/.git`)) {
	console.error(`harness: no ${repo}/.git, so the archive root would be resolved by walking UP out of the fixture`);
	process.exit(2);
}

// ⛔ SET BEFORE THE IMPORT. `recordArchive` appends its heartbeat row to
// `${HOME}/.claude/newdle-compaction-heartbeat.ndjson`, which is a REAL file on this machine, and
// the seat name is written into the archive's sidecar as this record's owner. Neither may reach
// real state even if the runner's environment says otherwise. A harness that merely inherited
// `OMP_CURRENT_SEAT_NAME` drained a real seat's mailbox on 2026-09-16 and cost two messages.
process.env.HOME = work;
process.env.OMP_SESSION_ID = "precompact-archive-eval";
delete process.env.OMP_CURRENT_SEAT_NAME;

// THE DISCRIMINATOR. Two tokens ~2,900 characters apart in ONE assistant message, because the
// budget walk truncates with `slice(0, remaining)` and keeps the PREFIX: an entry clipped by a
// budget defect still carries HEAD and loses TAIL, and an entry emptied to "" loses both while
// still rendering its `--- judgment 1 of 1 ---` delimiter. Asserting presence alone would pass
// through either one.
const USER_TOKEN = "FIXTURE-USER-ASK-7f3c";
const HEAD_TOKEN = "FIXTURE-JUDGMENT-HEAD-7f3c";
const TAIL_TOKEN = "FIXTURE-JUDGMENT-TAIL-7f3c";
const filler = Array.from({ length: 40 }, (_, index) => `judgment body line ${index} carrying reasoning that must survive the crossing.`).join("\n");
const assistantText = `${HEAD_TOKEN} DECISION: keep the per-repo archive.\n${filler}\n${TAIL_TOKEN}`;

// The module under test is selected at runtime by LINTEL_NEWDLE_HOOKS, which is the whole mechanism
// for showing the red direction, so this import cannot be static.
const mod = await import(modulePath);
// ⛔ THE DEFAULT EXPORT IS THE ONLY SURFACE BOTH LINEAGES SHARE. The pre-judgment bytes export
// `default` and nothing else (`:1000`), so a probe reaching for the exported `continuitySnapshot`
// could only ever report a harness fault against them — and a red direction that can only be
// indeterminate has not been shown. prompt.md carries the measurement.
if (typeof mod.default !== "function") {
	console.error(`harness: ${modulePath} exports no default activation function`);
	process.exit(2);
}
const handlers: Record<string, (event: unknown, ctx: unknown) => unknown> = {};
const pi = {
	on(event: string, handler: (event: unknown, ctx: unknown) => unknown) {
		handlers[event] = handler;
	},
	appendEntry() {},
	sendMessage() {},
};
mod.default(pi);
if (typeof handlers.session_before_compact !== "function") {
	console.error("harness: the module registered no session_before_compact handler, so no archive is reachable");
	process.exit(2);
}

await handlers.session_before_compact(
	{
		preparation: {
			// ⛔ BOTH MESSAGES IN `messagesToSummarize`, AND `turnPrefixMessages` ABSENT. The
			// pre-judgment lineage reads only this region, so putting the assistant message in the
			// second one would make a red run ambiguous between the role filter and the
			// two-region fix.
			messagesToSummarize: [
				{ role: "user", content: `${USER_TOKEN} what did you decide about the archive?` },
				{ role: "assistant", content: assistantText },
			],
			tokensBefore: 41_133,
			// Sets, not arrays: `CompactionPreparation.fileOps` is three Sets and the module
			// expands them with `value instanceof Set`.
			fileOps: { read: new Set<string>(), written: new Set<string>(), edited: new Set<string>() },
		},
	},
	{ cwd: repo },
);

// ⛔ THE HANDLER CATCHES EVERYTHING AND FAILS OPEN, so "no archive" means the handler threw — a
// harness verdict, not this scenario's defect. Exactly one record is expected: a second would mean
// something other than this crossing wrote here and the assertions could read the wrong file.
const archiveDir = `${repo}/.ai/omp-compaction-archive`;
const names = existsSync(archiveDir) ? readdirSync(archiveDir).filter(name => name.endsWith(".md")) : [];
if (names.length !== 1) {
	console.error(`harness: expected exactly one archive .md under ${archiveDir}, found ${names.length}`);
	process.exit(2);
}
const archive = `${archiveDir}/${names[0]}`;
writeFileSync(`${work}/archive-path`, archive);
console.log(`observed: archive written to ${archive} (${Bun.file(archive).size} bytes)`);
process.exit(0);
PROBE_TS

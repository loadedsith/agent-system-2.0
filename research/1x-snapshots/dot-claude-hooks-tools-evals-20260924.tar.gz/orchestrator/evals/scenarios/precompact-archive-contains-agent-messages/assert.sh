# eval-pair: firing newdle-hooks.judgment.ts
# The target is a Bun extension module, not a node hook, so nothing in lib/hook-eval.sh reaches it
# and this file drives it directly — the shape seatmail-drain-triggers-turn-and-writes-receipt uses
# for the seat registry. LINTEL_NEWDLE_HOOKS names the whole path and is how the red direction is
# shown, by pointing this scenario at the pre-judgment bytes. The default is the CANDIDATE, which is
# not installed; repoint it at ~/.omp/agent/extensions/newdle-hooks.ts on the day it is.
#
# The DIRECTORY is resolved exactly the way lib/hook-eval.sh resolves it, and for the reason
# written there: derived from this file's own location so a CLONE tests ITSELF, LINTEL_HOOKS still
# overriding, and the layout assumption CHECKED rather than assumed. A consequence worth knowing:
# `LINTEL_HOOKS=<mutation-test> sh run-tier1.sh` makes this scenario INDETERMINATE, because that
# directory holds no copy of this module. That is the honest answer — silently testing the
# unmutated candidate during a mutation run is a green that proves nothing.
HOOKS="${LINTEL_HOOKS:-}"
if [ -z "$HOOKS" ]; then
  HOOKS=$(CDPATH= cd -- "$(dirname -- "$0")/../../../hooks" 2>/dev/null && pwd)
  [ -n "$HOOKS" ] || { echo "INDETERMINATE: could not derive a hooks dir from $0" >&2; exit 3; }
fi
MOD="${LINTEL_NEWDLE_HOOKS:-$HOOKS/newdle-hooks.judgment.ts}"
[ -f "$MOD" ] || { echo "INDETERMINATE: no module at $MOD" >&2; exit 3; }
command -v bun >/dev/null || { echo "INDETERMINATE: the target is a Bun module and bun is not on PATH" >&2; exit 3; }

# The module THROWS AT LOAD without this, so an unset value is a harness fault and never a verdict.
PLUGIN_ROOT="${NEWDLE_PLUGIN_ROOT:-/Users/jowolff/.claude/plugins/cache/contextpress/newdle/0.2.169}"
[ -f "$PLUGIN_ROOT/hooks/hooks.json" ] || {
  echo "INDETERMINATE: no hook manifest at $PLUGIN_ROOT/hooks/hooks.json; the module throws at load" >&2; exit 3; }

HOME="$WORK" NEWDLE_PLUGIN_ROOT="$PLUGIN_ROOT" bun "$WORK/probe.ts" "$MOD" || {
  echo "INDETERMINATE: the host stand-in could not reach the archive (see above)" >&2; exit 3; }

ARCHIVE=$(cat "$WORK/archive-path" 2>/dev/null)
[ -n "$ARCHIVE" ] && [ -f "$ARCHIVE" ] || {
  echo "INDETERMINATE: the probe recorded no archive path" >&2; exit 3; }
case "$ARCHIVE" in
  "$WORK"/*) ;;
  *) echo "INDETERMINATE: the archive landed outside the fixture at $ARCHIVE" >&2; exit 3 ;;
esac

# 1. THE CONTROL, and its absence is INDETERMINATE rather than a fail. Both lineages capture user
#    intents, so a user token present with the assistant tokens missing means the fix is gone,
#    while a user token missing means the harness never reached the capture — a different bug.
grep -q 'FIXTURE-USER-ASK-7f3c' "$ARCHIVE" || {
  echo "INDETERMINATE: the archive carries neither half of the compacted region, so the capture itself never ran" >&2; exit 3; }

# 2. THE DEFECT ITSELF. One hard-coded `role !== "user"` in `textFromMessage` dropped every
#    assistant message in the compacted region while the heartbeat row still said ok.
grep -q 'FIXTURE-JUDGMENT-HEAD-7f3c' "$ARCHIVE" || {
  if grep -q -- '--- judgment ' "$ARCHIVE"; then
    echo "FAIL: the archive has a judgment section but no assistant text in it — entries were admitted carrying no content" >&2
  else
    echo "FAIL: the archive has no judgment section at all — the assistant half of the compacted region was dropped (the hard-coded role filter is back)" >&2
  fi
  exit 1; }

# 3. THE DISCRIMINATOR. The tail token sits ~2,900 characters after the head, and truncation keeps
#    the prefix, so this is the assertion a clipped or emptied entry cannot satisfy. Without it this
#    scenario would stay green on a capture that admits agent messages and then loses their content.
grep -q 'FIXTURE-JUDGMENT-TAIL-7f3c' "$ARCHIVE" || {
  echo "FAIL: the assistant message reached the archive but does not survive to its last line — it was clipped, so the archive holds an opening and not the reply" >&2; exit 1; }
exit 0

FIRING. The pre-compaction archive must carry the AGENT's own messages out of the compacted region,
as readable content, and not only the user's. Ported 2026-09-16 from the measurement at
`orchestrator/build/judgment-capture-ab.ts`, which proved the fix once against functions nobody runs.

THE DEFECT IT PINS, and it was one condition. `textFromMessage` hard-coded
`if (candidate.role !== "user") return undefined`, so `continuitySnapshot` mapped the discarded
region through a filter that could only ever yield user text and `agentJudgment` did not exist. The
host had handed the bridge the assistant messages all along —
`CompactionPreparation.messagesToSummarize: AgentMessage[]`
(`@oh-my-pi/pi-agent-core/src/compaction/compaction.ts:1244`, read 2026-09-16). The archive then
printed, in the plugin's verbatim block, that the judgment layer "was NOT captured and is not
recoverable from this file", while the `PreCompactArchive` heartbeat row said `"outcome":"ok"`. The
line is still present in the installed extension and gone from the candidate, measured 2026-09-16:

    grep -c 'role !== "user"' ~/.omp/agent/extensions/newdle-hooks.ts                  -> 1  (:564)
    grep -c 'role !== "user"' ~/.claude/orchestrator/hooks/newdle-hooks.judgment.ts    -> 0

It is one keystroke from coming back, and the candidate is NOT INSTALLED — installation is
Jo-gated — so nothing else on this machine runs against it.

THE TARGET IS THE CANDIDATE at `orchestrator/hooks/newdle-hooks.judgment.ts`.
`LINTEL_NEWDLE_HOOKS` names the whole path and mirrors `LINTEL_SEAT_REGISTRY`: it is how the red
direction is shown rather than asserted. Repoint the default at the installed extension on the day
it is installed, so this scenario keeps testing what actually runs. The directory it sits in is
resolved the way `lib/hook-eval.sh` resolves one — derived from the scenario's own location so a
clone tests itself, `LINTEL_HOOKS` still overriding, checked and not assumed. So
`LINTEL_HOOKS=state/hook-lab/mutation-test sh run-tier1.sh`, the mutation invocation at the bottom
of the README, makes this scenario INDETERMINATE: that directory holds five node hooks and no copy
of this module. Deliberate. Silently testing the unmutated candidate during a mutation run is the
green-that-proves-nothing the README's whole pair-check story is about.

WHY THE PROBE GOES THROUGH THE DEFAULT EXPORT AND NOT THROUGH `continuitySnapshot`, which is
exported for exactly this purpose. Because the red arm cannot be reached that way, and this was
measured rather than assumed: the preserved pre-judgment bytes have ONE export, `export default
function newdleOmpHooks` (`newdle-hooks.ts.pre-judgment-20260916-0025:1000`). A probe importing
`continuitySnapshot` from them exits on "exports no such function" — a HARNESS verdict, exit 2,
INDETERMINATE — and a scenario whose red direction can only ever be indeterminate has not shown it.
`session_before_compact` is the one surface both lineages share, so it is the one the probe drives.
The cost of that choice, stated: the handler catches everything and fails open, so a throw inside it
yields no archive at all. That is what the control below is for.

THE FIXTURE, stated so a second person can rebuild `setup.sh` and land on the same payload. The
thing under test is not a hook fed one JSON payload on stdin: it is a Bun extension module, so
`setup.sh` stages a host stand-in (`probe.ts`) and `assert.sh` runs it with `bun`. The stand-in
fakes only the three `HookAPI` members the module touches — `on`, `appendEntry`, `sendMessage` —
and nothing simulates the agent loop.

    cwd handed to the handler   $WORK/repo         (with $WORK/repo/.git, see the safety note)
    HOME                        $WORK
    OMP_SESSION_ID              precompact-archive-eval
    NEWDLE_PLUGIN_ROOT          .../plugins/cache/contextpress/newdle/0.2.169
    event.preparation.messagesToSummarize
                                [ {role:"user",      content:"FIXTURE-USER-ASK-7f3c ..."},
                                  {role:"assistant", content:"FIXTURE-JUDGMENT-HEAD-7f3c ...
                                                              40 filler lines ...
                                                              FIXTURE-JUDGMENT-TAIL-7f3c"} ]
    event.preparation.tokensBefore   41133
    event.preparation.fileOps        {read,written,edited} as three empty Sets
    archive written to          $WORK/repo/.ai/omp-compaction-archive/<session>--<stamp>.md

Both messages sit in `messagesToSummarize` and `turnPrefixMessages` is absent ON PURPOSE. The
pre-judgment lineage's `continuitySnapshot` accepts only the first region
(`...pre-judgment-20260916-0025:607`), so putting the assistant message in the second one would make
a red run ambiguous between the role filter and the two-region fix. `fileOps` must be Sets, not
arrays: that is the host's real shape and the module expands it with `value instanceof Set`.

THE DISCRIMINATOR, and it is why the assistant message carries TWO tokens rather than one. The
weak form of this scenario — "the archive mentions the assistant message" — passes on a capture that
admits agent entries and then empties them, and that is a live risk in this exact file: the
character budget in the same walk truncates with `raw.slice(0, remaining)` and a `remaining` of zero
yields an admitted entry holding the empty string, which still renders its
`--- judgment 1 of 1 ---` delimiter. Asserting the delimiter, or `judgmentLoss.admitted`, or
`agentJudgment.length`, would all stay green through that. So the assertion is that HEAD and TAIL
both survive, ~2,900 characters apart. Truncation here keeps the PREFIX, so a clipped entry loses
TAIL; an emptied entry loses both.

WHAT A CLEAN RUN RULES OUT: the role filter returning; a capture that admits assistant entries
carrying no text; and any clipping of this reply before its last line. README convention 1 is the
reason that list is written down, and the README's own bar is the reason it is not shorter: "If your
scenario passing is consistent with the defect still being present, the scenario is aimed at the
wrong thing."

WHAT IT DOES NOT RULE OUT, and each of these is a separate scenario rather than a gap to be
smuggled in here:

  * THE WIRING BEYOND THIS HANDLER. The probe calls `session_before_compact` directly. That a real
    host fires it, and that the host's `preparation` is shaped as above, is the vendor's contract
    cited at the top and is not this scenario's claim.
  * THE BUDGET BEING BIG ENOUGH. One ~2.9 KB reply against a 16,384-character allowance cannot say
    anything about a crossing where the agent wrote 60 KB. `judgmentLoss.droppedChars` is the field
    for that and the harness at `build/judgment-capture-ab.ts` arm 16 is where it is measured.
  * THE LOSS PROSE. `renderContinuity`'s loss note is deliberately NOT asserted. It was reworded on
    2026-09-16 (the old header claimed "the FIRST 1,200 characters of one reply", which was false),
    and a scenario that pins a sentence under active repair fails for the wrong reason and teaches
    the next reader to distrust the suite. The two tokens are content, not wording.
  * `turnPrefixMessages`, THE SECOND DISCARDED REGION. Real, and asserted in the A/B harness; see
    the fixture note above for why pinning it here would make one red scenario mean two things.
  * THE HEARTBEAT ROW. `recordArchive` appends `judgmentMessages` and `judgmentDroppedChars` to
    `~/.claude/newdle-compaction-heartbeat.ndjson`, which is the alarm a person would actually
    `jq`. It is not asserted because the archive is the artifact; the row is its receipt.

THE CONTROL, and it is why a red run is readable rather than just red. The user token is asserted
FIRST and its absence is INDETERMINATE, never a fail. Both lineages capture user intents, so:

    user token present, assistant tokens missing  ->  the fix is gone            (FAIL, exit 1)
    user token missing, or no archive at all      ->  the harness never got there (exit 3)

A verdict of 1 from this scenario therefore always means the capture ran and dropped the agent's
half. The delimiter `--- judgment ` is grepped only to phrase which failure it was — no judgment
section at all versus an admitted entry with no content — and is never itself the assertion.

THE RED DIRECTION, shown and not asserted. Copy the pre-judgment bytes to a `.ts` path first: bun
infers its loader from the file extension and the preserved name does not end in `.ts`, so importing
it directly yields a module with no exports and "exports no default activation function" reads as a
defect in the module rather than in the invocation. The probe refuses that path by name instead.

    MUT="$(mktemp -d)/newdle-hooks.pre-judgment.ts"
    cp ~/.omp/agent/extensions/newdle-hooks.ts.pre-judgment-20260916-0025 "$MUT"
    LINTEL_NEWDLE_HOOKS="$MUT" sh run-tier1.sh precompact-archive

Measured 2026-09-16: FAIL, runner exit 1, `FAIL: the archive has no judgment section at all — the
assistant half of the compacted region was dropped (the hard-coded role filter is back)`, against a
983-byte archive that did carry the user token. The green arm's archive is 4,380 bytes.

AND THE DISCRIMINATOR HAS ITS OWN RED DIRECTION, measured the same day, because the role filter
cannot exercise assertion 3 — it never gets that far. A copy of the candidate with one constant
changed, `JUDGMENT_CHAR_BUDGET = 500`, admits the reply and clips it:

    M="$(mktemp -d)/newdle-hooks.clipmutant.ts"
    sed 's/^const JUDGMENT_CHAR_BUDGET = 16_384;/const JUDGMENT_CHAR_BUDGET = 500;/' \
      ../hooks/newdle-hooks.judgment.ts > "$M"
    LINTEL_NEWDLE_HOOKS="$M" sh run-tier1.sh precompact-archive

FAIL, runner exit 1, `FAIL: the assistant message reached the archive but does not survive to its
last line` — a different sentence from the role filter's, which is the point of having both. On that
mutant's 1,971-byte archive `FIXTURE-JUDGMENT-HEAD-7f3c` and `--- judgment 1 of 1 ---` both return
ONE hit and `FIXTURE-JUDGMENT-TAIL-7f3c` returns ZERO. That is the weak form of this scenario
passing a broken capture, demonstrated rather than argued.

SAFETY, because this fixture's write path has a delete in it. `archiveCompactionState` prunes the
archive directory it writes into, and its age rule deletes ANY session's record older than a week —
so a run whose archive root escaped the fixture would delete real crossings. The root is resolved by
walking UP from the handler's `cwd` to the first `.git`, so `setup.sh` creates `$WORK/repo/.git` and
`probe.ts` REFUSES TO RUN if it is missing rather than letting the walk leave the workdir. Two more
guards, both cheap: `HOME` is repointed at `$WORK` so the heartbeat append cannot reach the real
`~/.claude`, and `OMP_CURRENT_SEAT_NAME` is deleted from the environment so no record can be
attributed to a live seat. This is not hypothetical caution — a harness that merely inherited
`OMP_CURRENT_SEAT_NAME` drained a real seat's mailbox on 2026-09-16 and destroyed two messages.
`$WORK/repo/newdle-hooks.json` is staged for the same reason: without it `compactionProjectDir`
hands the spawned plugin hook `CLAUDE_PROJECT_DIR=<orchestrator/state/hook-scope-anchor>`, a real
path outside the fixture.

POLARITY: a lone FIRING scenario, and that is legal here — checked rather than assumed. The static
rule in `pair-check.sh` fails a `(family, target)` group that holds a silence scenario with no firing
one; the converse is not a violation and no code path looks for it (README:127-130, "every
(family, target) group holding a silence scenario needs a firing one"). `seatmail-drain-triggers-turn-and-writes-receipt`
is the standing precedent: family `seatmail`, one firing scenario, no sibling, pair-check ok. The
silence sibling worth writing later is "a region with no assistant messages renders the absence
rather than an empty entry" — it is a SILENCE assertion and mixing it in here would make this
scenario's polarity unreadable to the checker.

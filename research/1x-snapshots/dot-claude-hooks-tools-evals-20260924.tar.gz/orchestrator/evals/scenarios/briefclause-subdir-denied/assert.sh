. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: firing brief-clause-guard.mjs
expect_deny brief-clause-guard.mjs '{"session_id":"eval","tool_name":"Agent","cwd":"/Users/jowolff/.claude/orchestrator","tool_input":{"subagent_type":"scout","description":"find login validation","prompt":"Find where the login form is validated and report the file and line."}}'

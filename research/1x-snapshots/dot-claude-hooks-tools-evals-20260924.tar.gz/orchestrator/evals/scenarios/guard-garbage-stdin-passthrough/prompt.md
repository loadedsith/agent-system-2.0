Fail-open: unparsable stdin must allow, never block and never crash.

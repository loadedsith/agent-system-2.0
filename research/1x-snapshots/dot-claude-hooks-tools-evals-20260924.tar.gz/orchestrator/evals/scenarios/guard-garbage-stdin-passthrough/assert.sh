. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_silence savepoint-guard.mjs 'this is not json at all'

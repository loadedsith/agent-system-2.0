A chained command is still the command. Splitting on separators is why this is caught.

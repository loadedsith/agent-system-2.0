REGRESSION for spelling-based matching. git parse-options accepts an unambiguous PREFIX of a
long option, so `git add --al` really does stage everything; verified by running
`git add --dry-run --al .` in a throwaway repo, git 2.50.1. The exact-string matcher never saw it.

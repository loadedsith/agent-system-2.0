# The thing under test is a Bun extension module rather than a hook fed one JSON payload, so the
# fixture is a HOST STAND-IN instead of a payload. It fakes only the ExtensionAPI surface the
# registry touches; nothing here simulates the agent loop, which is why this scenario pins the
# OPTIONS the registry hands the host and the FILES it writes rather than claiming a turn ran.
#
# assert.sh runs it as `bun probe.ts <registry>`. Its exit code is a HARNESS verdict only.
mkdir -p "$WORK/seat-sessions/probeseat"
cat > "$WORK/probe.ts" <<'PROBE_TS'
const work = process.env.WORK ?? process.cwd();
const registryPath = process.argv[2];
if (!registryPath) {
	console.error("harness: no registry path in argv");
	process.exit(2);
}

// ⛔ BUN INFERS ITS LOADER FROM THE FILE EXTENSION, and the canonical mutant for this scenario —
// the pre-fix bytes kept as `persistent-seat-registry.ts.pre-turnfix-20260916-0010` — does not end
// in `.ts`. Importing it yields a module with no exports, and "exports no default seatRegistry"
// then reads as a defect in the registry rather than in the invocation. Say which it is.
if (!/\.(ts|tsx|mts|js|mjs|jsx)$/.test(registryPath)) {
	console.error(`harness: bun cannot infer a loader for ${registryPath}; copy the bytes to a .ts path and point LINTEL_SEAT_REGISTRY at that`);
	process.exit(2);
}

// ⛔ SET BEFORE THE IMPORT, AND CHECKED. `persistentSeatMailboxRoot()` falls back to
// ~/.omp/agent/seat-mailboxes — the LIVE seat mail — so an unset variable here would point a real
// drain at real envelopes and archive them out of their owner's inbox. Two independent guards:
// this variable, and a seat name no real mailbox has an inbox for, so even a mis-set root finds
// ENOENT and drains nothing. A harness draining Lintel's real mailbox is not hypothetical; it
// happened on 2026-09-16 and cost two messages.
const mailboxRoot = `${work}/mailbox`;
process.env.OMP_PERSISTENT_SEAT_MAILBOX_ROOT = mailboxRoot;
process.env.OMP_PERSISTENT_SEAT_NAMES = "probeseat,probesender";
process.env.OMP_CURRENT_SEAT_NAME = "probeseat";
if (!work.startsWith("/") || work === "/" || !mailboxRoot.startsWith(work)) {
	console.error(`harness: refusing to run with a mailbox root outside a fixture workdir (${mailboxRoot})`);
	process.exit(2);
}

// The drain refuses to act for a seat this process cannot PROVE it is: the launcher owns argv and
// the environment cannot forge it. A fixture that wants the drain to run has to look launched.
process.argv.push("--session-dir", `${work}/seat-sessions/probeseat`);

const sends: { customType: unknown; options: unknown }[] = [];
const handlers: Record<string, (event: unknown, ctx: unknown) => unknown> = {};
let activeTools: string[] = [];
const pi = {
	zod: { object: () => ({}), string: () => ({ describe: () => ({}) }) },
	on(event: string, handler: (event: unknown, ctx: unknown) => unknown) {
		handlers[event] = handler;
	},
	sendMessage(message: { customType?: unknown }, options?: unknown) {
		sends.push({ customType: message.customType, options });
	},
	getActiveTools: () => activeTools,
	setActiveTools: async (next: string[]) => {
		activeTools = next;
	},
	registerTool() {},
	registerCommand() {},
};

const registry = await import(registryPath);
if (typeof registry.default !== "function" || typeof registry.enqueuePersistentSeatMessage !== "function") {
	console.error(`harness: ${registryPath} exports no default seatRegistry and/or no enqueuePersistentSeatMessage`);
	process.exit(2);
}
registry.default(pi);

const envelope = await registry.enqueuePersistentSeatMessage({
	from: "probesender",
	target: "probeseat",
	message: "WAKE-PROBE: an idle seat must take a turn carrying this.",
	seatNames: ["probeseat", "probesender"],
	mailboxRoot,
});
await Bun.write(`${work}/envelope-id`, envelope.id);

if (typeof handlers.session_start !== "function") {
	console.error("harness: the registry registered no session_start handler, so no drain is reachable");
	process.exit(2);
}
await handlers.session_start({}, { setInterval: () => {} });

const send = sends.at(-1);
await Bun.write(`${work}/deliver-options.json`, JSON.stringify(send ? send.options ?? {} : null));

// ⛔ AN ABSENT agent_start HANDLER IS THE DEFECT, NOT A HARNESS FAULT. The pre-fix registry
// registers none at all, so this path must exit 0 and leave the verdict to the file assertions.
if (typeof handlers.agent_start === "function") {
	await handlers.agent_start({}, {});
} else {
	console.log("observed: the registry registered NO agent_start handler, so no turn receipt can be written");
}
process.exit(0);
PROBE_TS

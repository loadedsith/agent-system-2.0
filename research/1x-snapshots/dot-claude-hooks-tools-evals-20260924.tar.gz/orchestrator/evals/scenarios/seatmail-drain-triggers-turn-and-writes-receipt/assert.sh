# eval-pair: firing persistent-seat-registry.ts
# The target is a Bun extension, not a node hook, so nothing in lib/hook-eval.sh reaches it and
# this file drives it directly — the shape preflight-missing-request-queue-fails already uses for
# a zsh target. LINTEL_SEAT_REGISTRY mirrors LINTEL_HOOKS: it is how the red direction is shown,
# by pointing this scenario at the pre-fix bytes.
REG="${LINTEL_SEAT_REGISTRY:-$HOME/.omp/agent/extensions/persistent-seat-registry.ts}"
[ -f "$REG" ] || { echo "INDETERMINATE: no registry module at $REG" >&2; exit 3; }
command -v bun >/dev/null || { echo "INDETERMINATE: the registry is a Bun module and bun is not on PATH" >&2; exit 3; }
grep -q 'OMP_PERSISTENT_SEAT_MAILBOX_ROOT' "$REG" || {
  echo "INDETERMINATE: $REG no longer honours OMP_PERSISTENT_SEAT_MAILBOX_ROOT; this would drain the LIVE seat mailbox" >&2; exit 3; }

bun "$WORK/probe.ts" "$REG" || {
  echo "INDETERMINATE: the host stand-in could not reach the drain (see above)" >&2; exit 3; }

ID=$(cat "$WORK/envelope-id" 2>/dev/null)
[ -n "$ID" ] || { echo "INDETERMINATE: the probe recorded no envelope id" >&2; exit 3; }
OPTS="$WORK/deliver-options.json"
[ -f "$OPTS" ] || { echo "INDETERMINATE: the probe recorded no delivery options" >&2; exit 3; }

# 1. THE DRAIN INJECTED AT ALL. Without this the three checks below would all be red for the same
#    reason and none of them would say which.
[ "$(cat "$OPTS")" != null ] || {
  echo "FAIL: the drain handed the host nothing — the envelope was never injected" >&2; exit 1; }

# 2. THE CONTROL. The pre-fix registry writes this same ack, so an ack present with the options or
#    the receipt missing means the fix is gone; an ack missing too means the harness never reached
#    the drain, which is a different bug.
[ -f "$WORK/mailbox/acks/$ID.json" ] || {
  echo "FAIL: no injection ack at mailbox/acks/$ID.json — the drain never claimed the envelope" >&2; exit 1; }

# 3. `followUp`, or a streaming recipient's mail goes to queueAside and folds silently.
grep -q '"deliverAs":"followUp"' "$OPTS" || {
  echo "FAIL: the host was not handed deliverAs:followUp; got $(cat "$OPTS")" >&2; exit 1; }

# 4. THE WAKE FIX ITSELF. Without triggerTurn an IDLE recipient appends to context and takes no
#    turn — the state a seat sitting at its prompt is normally in.
grep -q '"triggerTurn":true' "$OPTS" || {
  echo "FAIL: the host was not handed triggerTurn:true, so an idle seat would not take a turn; got $(cat "$OPTS")" >&2; exit 1; }

# 5. THE POSITIVE RECEIPT, written by the actor rather than the postman. Injection and action came
#    apart on 2026-09-16 and the ack in 2 cannot tell them apart.
[ -f "$WORK/mailbox/acks/$ID.turn.json" ] || {
  echo "FAIL: no turn receipt at mailbox/acks/$ID.turn.json — the turn was never reported" >&2; exit 1; }
exit 0

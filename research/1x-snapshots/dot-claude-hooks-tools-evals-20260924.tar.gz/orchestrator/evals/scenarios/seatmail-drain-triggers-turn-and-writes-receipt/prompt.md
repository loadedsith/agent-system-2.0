FIRING. The seat-mail drain must hand the host `{ deliverAs: "followUp", triggerTurn: true }` and
the seat's own `agent_start` must then write a turn receipt. Ported 2026-09-16 from the measurement
at `orchestrator/build/seatmail-turnfix-ab.ts`, which proved the fix once and would have rotted
there.

THE DEFECT IT PINS, and it is two defects one line apart. `{ deliverAs: "followUp" }` WITHOUT
`triggerTurn` reaches the final fallthrough of `#dispatchCustomMessage` when the recipient is idle
(`agent-session.ts:7735-7743`, installed pi-coding-agent 18.2.1, read 2026-09-16): it appends to
context and returns `false` — no queue entry, no drain, no turn. An idle seat at its prompt is the
ordinary state for seat mail, so this was not an edge case. Jo watched Caspian sit on a brief it had
already received and acked until he typed a greeting at it; a probe on 2026-09-16 reproduced it on
codex, acked in 7s and `idle` for 60s. The earlier `aside` -> `followUp` change did not cause this
so much as move it: `aside` starts a turn when idle and folds silently when streaming, and bare
`followUp` is the exact mirror. Only the pair is correct in both states.

The second defect is that nothing could SAY so. The drain's ack means "the envelope was injected",
and for four hours that was read as "the seat acted on it". The turn receipt is a separate file
written by the recipient's own `agent_start`, so a sender can tell injection from action.

WHAT MAKES IT PASS, by line. `persistent-seat-registry.ts` — the `deliver` callback inside
`drainCurrentSeatMailbox` passes `{ deliverAs: "followUp", triggerTurn: true }` to `pi.sendMessage`
and records the envelope id in `awaitingTurnReceipt`; the `pi.on("agent_start")` handler drains that
set and writes `acks/<id>.turn.json`. Delete `triggerTurn: true` and assertion 4 goes red. Delete
the `agent_start` handler and assertion 5 goes red. The pre-fix bytes preserved at
`~/.omp/agent/extensions/persistent-seat-registry.ts.pre-turnfix-20260916-0010` are missing both,
and running this scenario against them is how the red direction was shown rather than asserted.
Copy them to a `.ts` path first — bun infers its loader from the extension and the preserved name
does not end in `.ts`:

    MUT="$(mktemp -d)/persistent-seat-registry.ts"
    cp ~/.omp/agent/extensions/persistent-seat-registry.ts.pre-turnfix-20260916-0010 "$MUT"
    LINTEL_SEAT_REGISTRY="$MUT" sh run-tier1.sh seatmail-drain-triggers-turn

Measured 2026-09-16: FAIL, runner exit 1, `FAIL: the host was not handed triggerTurn:true ... got
{"deliverAs":"followUp"}`, and the probe's own line saying the pre-fix registry registers no
`agent_start` handler at all. The two halves of the fix show up as two separate observations.

THE ACK IS THE CONTROL, and it is why a red run is readable. The pre-fix registry writes the ack to
the same path, so assertion 2 passes in both arms. A run where the ack is present and the options or
the receipt are missing says the fix is gone. A run where the ack is missing too says the harness
never reached the drain, which is a different bug and a different fix.

THE FIXTURE, stated so a second person can rebuild `setup.sh` and land on the same payload. The
thing under test is not a hook: it is a Bun extension module, so `setup.sh` stages a host stand-in
(`probe.ts`) instead of a JSON payload, and `assert.sh` runs it with `bun`. The probe fakes only the
`ExtensionAPI` surface the registry touches — `zod`, `on`, `sendMessage`, `getActiveTools`,
`setActiveTools`, `registerTool`, `registerCommand` — and nothing simulates the agent loop, which is
deliberate: this pins the OPTIONS the registry hands the host and the FILES it writes, the two
things that were wrong. That a real host then starts a turn is the vendor's contract, cited above,
and is not this scenario's claim.

    OMP_PERSISTENT_SEAT_MAILBOX_ROOT  $WORK/mailbox
    OMP_PERSISTENT_SEAT_NAMES         probeseat,probesender
    OMP_CURRENT_SEAT_NAME             probeseat
    argv                              --session-dir $WORK/seat-sessions/probeseat
    inbox                             $WORK/mailbox/inbox/probeseat/<id>.json
    ack                               $WORK/mailbox/acks/<id>.json
    turn receipt                      $WORK/mailbox/acks/<id>.turn.json

The argv line is load-bearing and is not decoration. The drain refuses to act for a seat this
process cannot prove it is: `launcherProvenSeatSlug()` reads `--session-dir .../seat-sessions/<slug>`
because the launcher owns argv and the environment cannot forge it. A harness that merely inherited
`OMP_CURRENT_SEAT_NAME` drained Lintel's real mailbox on 2026-09-16 and unlinked the envelope. A
fixture that wants the drain to run therefore has to look like a launched seat.

WHAT THIS SCENARIO DOES NOT PIN, from the same measurement, on purpose:

  * The `Bun.file` negative-cache probe. It measures the runtime, not this registry, and it
    belongs to the `queued`/`delivered`/`acted` receipt rather than to the wake.
  * `customType: "persistent-seat-message"`. A real contract — it is what `aside` recovery folded —
    but it belongs to the injection envelope's shape. Pinning it here would make one red scenario
    ambiguous between two fixes.
  * "No turn receipt before `agent_start`". True, and the sibling worth writing, but it is a SILENCE
    assertion and mixing it in would make this scenario's polarity unreadable to `pair-check.sh`.
  * Latencies, tmp paths and pids. `turnStartedAt` and `pid` are written into the receipt and are
    deliberately not asserted: a scenario that pins a clock or a pid fails on a fast machine or a
    second run and teaches the next reader to distrust the suite.

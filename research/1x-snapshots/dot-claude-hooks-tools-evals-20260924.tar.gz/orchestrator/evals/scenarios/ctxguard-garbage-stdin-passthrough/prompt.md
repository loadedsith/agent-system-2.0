Fail open: unparsable stdin allows and never crashes. Sibling: ctxguard-no-line-denied (valid JSON, same hook, fires).

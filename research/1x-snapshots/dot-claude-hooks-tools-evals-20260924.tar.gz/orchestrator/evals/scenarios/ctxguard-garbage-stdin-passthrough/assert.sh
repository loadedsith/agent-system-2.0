. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence ctx-search-guard.mjs
expect_allow_tool ctx-search-guard.mjs 'this is not json at all'

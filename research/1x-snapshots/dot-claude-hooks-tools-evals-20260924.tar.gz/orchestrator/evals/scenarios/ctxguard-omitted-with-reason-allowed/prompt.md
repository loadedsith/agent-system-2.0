The explicit omission marker with a reason passes. No defect has happened here yet; this pins a design requirement, stated so rather than invented.

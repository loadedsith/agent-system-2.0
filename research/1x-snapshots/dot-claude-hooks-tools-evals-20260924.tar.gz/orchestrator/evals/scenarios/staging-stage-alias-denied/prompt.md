REGRESSION for spelling-based matching. `git stage -h` prints `usage: git add` — stage is an
alias, verified git 2.50.1 — and the matcher only ever looked for the word "add".

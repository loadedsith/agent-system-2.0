printf '# old standup\n' > "$WORK/STANDUP.md"
printf '%s\n' \
  '{"type":"queue-operation","operation":"enqueue","content":"CANARY midturn obligation","timestamp":"2026-01-01T00:00:00Z"}' \
  '{"type":"queue-operation","operation":"remove","content":"CANARY midturn obligation","timestamp":"2026-01-01T00:00:05Z"}' \
  > "$WORK/t.jsonl"

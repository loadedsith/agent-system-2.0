INTEGRATION test, and the gap that let a real bug ship. The suite tested intake-sweep.mjs
directly and never once through savepoint-guard.mjs, which is what actually calls it in
production. The installed guard passed `p.transcript_path` where the variable is `payload`;
the ReferenceError was swallowed by the guard's own catch, so mid-turn capture was dead while
20/20 stayed green. An external red team found it. This scenario exists so that cannot recur.

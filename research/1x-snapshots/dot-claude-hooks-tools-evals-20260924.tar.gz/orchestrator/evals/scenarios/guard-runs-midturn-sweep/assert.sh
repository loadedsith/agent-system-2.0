. "$(dirname "$0")/../../lib/hook-eval.sh"
printf '{"stop_hook_active":false,"session_id":"eval","transcript_path":"%s/t.jsonl"}' "$WORK" \
  | LINTEL_STATE="$WORK" node "${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}/savepoint-guard.mjs" >/dev/null
[ $? -ne 0 ] && { echo "INDETERMINATE: guard exited nonzero" >&2; exit 3; }
expect_file_contains "$WORK/REQUESTS-INBOX.jsonl" 'CANARY midturn obligation'

SILENCE scenario of the item-8 trio. The reply ends with the id alone on its own final line, in
the form turn-id-mint.mjs asks for ("— <id>"), followed by a trailing newline. This is the shape a
compliant reply has, and it must pass — a tightened verifier that also rejected this would have
made the mechanism unusable rather than honest.

Sibling of turnid-strict-id-buried-midsentence-blocks: the two payloads differ only in WHERE the
id sits. Both contain it.

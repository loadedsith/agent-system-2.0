printf "{}\n" > "$WORK/LEDGER.jsonl"; sleep 1
printf "# new\n" > "$WORK/STANDUP.md"
printf '{"ts":"2026-01-01T00:00:00Z","triaged":true,"verbatim":"look at the deploy pipeline"}\n' > "$WORK/REQUESTS-INBOX.jsonl"

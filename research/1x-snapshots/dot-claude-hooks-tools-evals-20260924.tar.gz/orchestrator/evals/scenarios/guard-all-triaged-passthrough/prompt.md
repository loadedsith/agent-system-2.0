SILENCE sibling. Identical except triaged:true. Must stay silent.

. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_deny staging-guard.mjs '{"session_id": "eval", "agent_type": "general-purpose", "agent_id": "abc123", "tool_name": "Bash", "cwd": "/Users/jowolff/.claude", "tool_input": {"command": "git add -A"}}'

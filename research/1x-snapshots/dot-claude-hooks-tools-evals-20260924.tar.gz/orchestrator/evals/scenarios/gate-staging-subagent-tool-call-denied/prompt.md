FIRING sibling of gate-staging-foreign-session-allowed. A SUBAGENT's tool call carries the
PARENT session's session_id plus its own agent_type and agent_id (measured in the lab probe).
Coverage of subagent commands exists today and the gate must not quietly drop it — which is what
gating on agent_type would have done, since a subagent reports its own type, not the
orchestrator's.

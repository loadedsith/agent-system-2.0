. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
FIRST=$(mint_id p-1 'audit the deploy pipeline please')
LOOSE=$(printf '%s' "$FIRST" | sed 's/^T-//' | tr 'A-Z' 'a-z')
expect_stdout_contains turn-id-mint.mjs \
  "{\"hook_event_name\":\"UserPromptSubmit\",\"session_id\":\"eval\",\"prompt_id\":\"p-2\",\"cwd\":\"/tmp/fixture\",\"prompt\":\"responding to turn $LOOSE, do these commands\"}" \
  'audit the deploy pipeline please'

"Can a person realistically type it?" — only if a retyped id still resolves. A human dropping the
"T-" prefix and using lower case is the normal way a 22-character string gets re-entered by hand,
so both are accepted when RECOGNISING a reference. Minting stays strict: one canonical spelling
is produced, several are understood.

. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence identifier-link-guard.mjs
expect_silence identifier-link-guard.mjs '{"session_id": "eval", "last_assistant_message": "Per RFC-2119 the rule is MUST. Digests are SHA-256, transport is TLS-1 over HTTP-2, timestamps are ISO-8601, text is UTF-8, contrast follows WCAG-2, the page is AES-256 at rest, we graded it SEV-2, and CVE-2024-1234 is unrelated."}'

Prefixes that LOOK like Linear team keys and are not. Every string in this payload appears in Lintel's own vocabulary or in the charters: `RFC-2119` is cited by Lintel's conventions block every single session, and `UTF-8`, `SHA-256`, `AES-256`, `ISO-8601`, `WCAG-2`, `HTTP-2`, `TLS-1`, `SEV-2` and `CVE-2024-1234` all match the catch-all `[A-Z]{2,5}-<digits>`.

⛔ THIS IS THE EXEMPTION LIST'S OWN CONTROL, AND IT CONTAINS THE THING IT CONTROLS FOR — which the first false-positive control did not. That one pinned matcher narrowness using `0.2.169` and an md5 prefix, neither of which contains a `#`, so a clean run was consistent with the matcher having widened. Mutation-tested 2026-09-15: emptying `NON_LINEAR_PREFIXES` turns this scenario red.

⛔ WHY A DENYLIST RATHER THAN AN ALLOWLIST OF REAL TEAM KEYS, recorded because it is the design decision and not an implementation detail: an allowlist fails in the dangerous direction — a Linear team missing from it silently escapes the guard and a bare ticket reaches Jo unlinked, which is the whole failure this hook exists to stop. The catch-all plus a denylist fails loudly instead, as a false positive that lands on the seat that wrote the message. Lintel's ruling.

`CVE-` is exempted for a different reason than the rest: it has an authoritative URL of its own, unlike `UTF-8`. Whether it deserves its own link-demanding class is deliberately not opened here.

Its firing sibling is idlink-bare-linear-ticket-blocked: a genuine team key of the same shape, one field apart.

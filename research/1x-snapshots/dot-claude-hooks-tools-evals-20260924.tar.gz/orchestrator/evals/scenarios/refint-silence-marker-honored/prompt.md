SILENCE. Same dangling reference as refint-dangling-ref-blocks, with the per-session escape marker
already present. Proves the escape printed in the block message actually works, and that it is a
SEPARATE marker from the save-point one — writing STANDUP.md does not fix a dangling reference.

# Repointed from LEDGER.jsonl to REQUESTS.jsonl 2026-09-09, in step with the firing sibling; see
# guard-state-moved-nudges/prompt.md for why LEDGER.jsonl can no longer move this guard.
printf "{}\n" > "$WORK/REQUESTS.jsonl"; sleep 1
printf "# new\n" > "$WORK/STANDUP.md"

SILENCE sibling of guard-state-moved-nudges. Identical except REQUESTS.jsonl is OLDER than
STANDUP.md. Must stay silent — a guard that always speaks is indistinguishable from a broken one.

Repointed from LEDGER.jsonl to REQUESTS.jsonl on 2026-09-09 together with the firing sibling, so
the pair still differs in exactly one field and that field is one the guard still watches.

printf '## Save point\n' > "$WORK/STANDUP.md"
head -c 6473 /dev/zero | LC_ALL=C tr '\0' 'x' >> "$WORK/STANDUP.md"
sleep 1
# `fit-<session>`, not `budget-<session>`: the marker moved with the check on 2026-08-20.
mkdir -p "$WORK/.guard-state"; printf '0' > "$WORK/.guard-state/fit-eval"

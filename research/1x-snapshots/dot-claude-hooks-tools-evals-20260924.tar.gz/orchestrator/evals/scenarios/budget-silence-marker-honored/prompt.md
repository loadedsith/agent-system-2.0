SILENCE. Same oversize standup, with the per-session escape marker the block message prints already
present and NEWER than the standup. Proves the printed escape works. It is a separate marker from
the save-point one and the refint one, because silencing "your save point is stale" must not also
silence "your save point will be truncated".

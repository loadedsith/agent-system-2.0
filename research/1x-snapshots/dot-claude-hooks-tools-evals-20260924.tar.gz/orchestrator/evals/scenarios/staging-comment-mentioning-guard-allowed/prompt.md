SILENCE sibling of staging-mass-add-denied. Scope was decided partly by a raw substring search
for the guard path anywhere in the command text, so a trailing COMMENT naming the directory
dragged an unrelated repo into scope and denied it.

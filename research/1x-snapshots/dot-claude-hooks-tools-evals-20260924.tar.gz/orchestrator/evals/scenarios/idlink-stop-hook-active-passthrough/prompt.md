A continuation stop carries the SAME last_assistant_message as the stop that was blocked. A guard that re-blocks its own block chain loops — the defect dispatch-check-stop.mjs:70-74 records, where one hook spoke four consecutive turns about the same run id.

Identical payload to idlink-bare-pr-number-blocked plus stop_hook_active: true. Must pass through silently.

Its firing sibling is idlink-bare-pr-number-blocked: same message, one field apart.

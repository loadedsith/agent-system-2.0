. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence identifier-link-guard.mjs
expect_silence identifier-link-guard.mjs '{"session_id": "eval", "stop_hook_active": true, "last_assistant_message": "I landed the fix in #1073 this evening."}'

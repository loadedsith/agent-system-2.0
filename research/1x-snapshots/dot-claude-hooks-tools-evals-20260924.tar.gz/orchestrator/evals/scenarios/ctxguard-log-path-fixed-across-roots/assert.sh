. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: firing ctx-search-guard.mjs
H="$WORK/home"
for c in "$H/.claude" "$H/code/shipyard/repos/kitchen" "$H/agent-scratch/wt"; do
  printf '{"session_id":"eval","tool_name":"Agent","cwd":"%s","tool_input":{"prompt":"Find it."}}' "$c" \
    | env -u LINTEL_STATE -u CTX_GUARD_LOG -u CTX_GUARD_ROOTS -u CTX_GUARD_EXCLUDES -u CTX_GUARD_UNCONDITIONAL MARCHES_SEAT=eval-seat HOME="$H" node "$HOOKS/ctx-search-guard.mjs" > /dev/null 2>&1 \
    || _indeterminate "hook exited non-zero for cwd $c"
done
FIXED="$H/.claude/orchestrator/state/ctx-search-guard.jsonl"
n=$(find "$H" -name 'ctx-search-guard.jsonl' | wc -l | tr -d ' ')
[ "$n" = 1 ] || { echo "FAIL: expected exactly one log under $H, found $n: $(find "$H" -name 'ctx-search-guard.jsonl' | tr '\n' ' ')" >&2; exit 1; }
rows=$(grep -c '"decision":"deny"' "$FIXED" 2>/dev/null); rows=${rows:-0}
[ "$rows" = 3 ] || { echo "FAIL: expected 3 deny rows in $FIXED, got $rows" >&2; exit 1; }
expect_file_contains "$FIXED" "\"root\":\"$H/agent-scratch\""

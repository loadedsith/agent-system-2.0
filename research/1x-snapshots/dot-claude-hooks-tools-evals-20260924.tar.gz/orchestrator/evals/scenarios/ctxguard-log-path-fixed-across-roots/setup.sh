mkdir -p "$WORK/home/.claude" "$WORK/home/code/shipyard/repos/kitchen" "$WORK/home/agent-scratch/wt"

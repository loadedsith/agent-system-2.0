Same brief as ctxguard-no-line-denied plus one citation line. No defect has happened here yet; this pins a design requirement, stated so rather than invented.

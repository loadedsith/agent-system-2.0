SILENCE sibling of staging-mass-add-denied. The scope test was a string prefix rather than a
path-containment test, so a DIFFERENT directory whose name merely begins with the guarded path
was guarded too.

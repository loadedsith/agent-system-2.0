Fail-open: no STANDUP.md means there is no save point to be stale against. Never block a fresh
machine.

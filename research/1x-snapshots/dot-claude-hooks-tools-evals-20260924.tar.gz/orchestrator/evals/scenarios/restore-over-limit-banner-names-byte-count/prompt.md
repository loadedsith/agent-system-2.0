FIRING sibling of restore-under-limit-no-banner. A 7048-byte standup of seven 1004-byte `## `
sections. The last heading at or before byte 6000 starts at byte 5040, so the cut lands there and
2008 bytes are dropped.

The count the banner prints is the count AFTER the boundary snap, not 7048-6000. That is the number
a reader needs, and asserting on it is what stops the boundary cut from quietly lying about the loss.

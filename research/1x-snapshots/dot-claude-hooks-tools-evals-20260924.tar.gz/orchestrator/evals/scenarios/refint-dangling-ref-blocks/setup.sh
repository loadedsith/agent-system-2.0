printf '{"id":"REQ-001","state":"open","request":"a real obligation"}\n' > "$WORK/REQUESTS.jsonl"
printf '{"ts":"2026-01-01T00:00:00Z","triaged":true,"disposition":"req:REQ-001","verbatim":"fine"}\n' > "$WORK/REQUESTS-INBOX.jsonl"
printf '{"ts":"2026-01-01T00:01:00Z","triaged":true,"disposition":"req:REQ-007b","verbatim":"do you remember why you chose this name?"}\n' >> "$WORK/REQUESTS-INBOX.jsonl"
printf '# new\n' > "$WORK/STANDUP.md"

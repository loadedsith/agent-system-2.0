FIRING. A triaged inbox row names REQ-007b; REQUESTS.jsonl defines REQ-001 only. The row reads as
discharged and no obligation exists. This is the live defect: REQ-007b was named by 2 rows and
defined 0 times.

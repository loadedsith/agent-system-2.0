SILENCE sibling of fit-over-limit-names-cliff-section, differing in exactly ONE thing: the checker
the hook shells out to does not exist. Same 6335-byte over-budget standup, same session.

This is the case that decides whether the hook is safe to install at all. If a Stop hook trapped
the session because its own helper was missing, the session needed to REPAIR the helper would be
the trapped one. It must allow the stop.

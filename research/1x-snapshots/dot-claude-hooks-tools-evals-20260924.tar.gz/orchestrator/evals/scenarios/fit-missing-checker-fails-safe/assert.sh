. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_fit_hook
SZ=$(wc -c < "$WORK/STANDUP.md" | tr -d ' ')
[ "$SZ" -eq 6335 ] || { echo "INDETERMINATE: fixture is $SZ bytes, expected 6335" >&2; exit 3; }
# Exported HERE, not in setup.sh: the runner sources setup.sh in a subshell, so an export there
# would not survive into this script. Verified rather than assumed.
LINTEL_FIT_TOOL="$WORK/no-such-checker.sh"; export LINTEL_FIT_TOOL
[ -e "$LINTEL_FIT_TOOL" ] && { echo "INDETERMINATE: the 'missing' checker exists" >&2; exit 3; }
expect_silence savepoint-fit-stop.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}'

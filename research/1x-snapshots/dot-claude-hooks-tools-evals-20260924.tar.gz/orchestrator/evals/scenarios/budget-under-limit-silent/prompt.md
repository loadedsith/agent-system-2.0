SILENCE sibling of budget-one-byte-over-blocks. A 5999-byte STANDUP.md, one byte under the 6000
injection budget, with no state moved. The guard accepts the save point and says nothing about
size. A budget check that fires on a file that fits is worse than none.

The two halves are separate processes minutes apart. This is the scenario that proves the Stop
half can find the exact string the UserPromptSubmit half minted — it asserts the block message
contains that id verbatim, not that it contains something id-shaped.

The join key is session_id + prompt_id. Both fields are present on BOTH payloads and identical
for the same turn, measured on this machine (probe-1.jsonl in this lab).

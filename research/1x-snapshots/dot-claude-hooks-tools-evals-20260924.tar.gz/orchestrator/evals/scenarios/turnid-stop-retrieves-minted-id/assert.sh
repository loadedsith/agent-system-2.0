. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
ID=$(mint_id p-1)
[ -n "$ID" ] || { echo "FAIL: mint produced no id" >&2; exit 1; }
expect_block turn-id-verify.mjs \
  '{"hook_event_name":"Stop","stop_hook_active":false,"session_id":"eval","prompt_id":"p-1","last_assistant_message":"a reply with no identifier in it"}' \
  "$ID"

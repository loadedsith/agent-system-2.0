# One row per state in the charter's vocabulary, plus one row carrying a state nobody declared.
# The ids encode the expected verdict so a failure message names which state leaked.
cat > "$WORK/REQUESTS.jsonl" <<'ROWS'
{"id":"OBLIG-DELIVERED","state":"delivered","request":"terminal: asked and got it"}
{"id":"OBLIG-DEFERRED","state":"deferred","request":"terminal: deliberately not now","note":"DEFERRED BY DECISION"}
{"id":"OBLIG-DROPPED","state":"dropped","request":"terminal: Jo called it off","note":"Do not re-raise unprompted."}
{"id":"OBLIG-OPEN","state":"open","request":"non-terminal: accepted as work, unfinished"}
{"id":"OBLIG-PARTIAL","state":"partial","request":"non-terminal: some landed, a remainder is owed"}
{"id":"OBLIG-BLOCKED","state":"blocked","request":"non-terminal: waiting on something outside the fleet"}
{"id":"OBLIG-UNDECLARED","state":"kumquat","request":"undeclared state: must be surfaced, never swallowed"}
ROWS
printf 'fixture standup\n' > "$WORK/STANDUP.md"
# The predicate is read out of the charter, so the scenario carries its own snapshot of it.
cp /Users/jowolff/.claude/orchestrator/CHARTER.md "$WORK/CHARTER.md"

CODEX-FIXES item 6. The SessionStart hook printed a section headed `OPEN OBLIGATIONS (state !=
delivered)`, which is not what terminal means: `dropped` is Jo calling something off and
`deferred` is Jo deciding not now. On the live ledger 2026-08-20 that re-raised REQ-002, REQ-018
and REQ-056 (dropped) and REQ-010 and REQ-094 (deferred) as live work at every session start.
REQ-018's own note reads "Do not re-raise unprompted".

The fixture carries one row per declared state plus one undeclared state. The three terminal rows
must not appear; the three non-terminal rows must. The undeclared row must appear too — an
unrecognised state is surfaced, never swallowed, because the safe direction of a vocabulary
mismatch is over-raising, not losing an obligation.

FIRING SIBLING: oblig-guard-hides-terminal-rows, the same predicate in the Stop hook.

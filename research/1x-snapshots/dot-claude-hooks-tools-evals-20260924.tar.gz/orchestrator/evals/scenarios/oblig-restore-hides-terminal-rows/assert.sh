# eval-pair: firing savepoint-restore.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"

# HOOK RESOLUTION. The fix lives in a hook-lab candidate until Jo approves the swap, so this tests
# the installed hook once it carries the shared predicate and the candidate before then. It never
# tests a hook that has neither: that is indeterminate, not a pass.
LAB=/Users/jowolff/.claude/orchestrator/state/hook-lab/terminal-states-2026-08-20/candidates
if grep -q 'request-states.sh' "$HOOKS/savepoint-restore.sh" 2>/dev/null; then
  UNDER="$HOOKS/savepoint-restore.sh"
elif grep -q 'request-states.sh' "$LAB/savepoint-restore.sh" 2>/dev/null; then
  UNDER="$LAB/savepoint-restore.sh"
else
  echo "INDETERMINATE: no savepoint-restore.sh carrying the shared terminal-state predicate, in $HOOKS or $LAB" >&2
  exit 3
fi
echo "hook under test: $UNDER"

OUT=$(printf '%s' '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' \
  | LINTEL_STATE="$WORK" LINTEL_CHARTER="$WORK/CHARTER.md" sh "$UNDER" 2>&1); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: restore hook exited $RC; its contract is to always exit 0" >&2; exit 3; }
[ -z "$OUT" ] && { echo "INDETERMINATE: restore hook printed nothing; the session gate or the state dir is wrong" >&2; exit 3; }

case "$OUT" in *'UNFILTERED'*)
  echo "INDETERMINATE: the hook reported the terminal-state predicate unavailable, so this run tested the fallback, not the fix" >&2
  echo "$OUT" >&2; exit 3 ;;
esac

rc=0
for id in OBLIG-OPEN OBLIG-PARTIAL OBLIG-BLOCKED OBLIG-UNDECLARED; do
  case "$OUT" in *"$id"*) ;; *) echo "FAIL: $id is non-terminal and must be listed, but is absent" >&2; rc=1 ;; esac
done
for id in OBLIG-DELIVERED OBLIG-DEFERRED OBLIG-DROPPED; do
  case "$OUT" in *"$id"*) echo "FAIL: $id is terminal and was re-raised as an open obligation" >&2; rc=1 ;; *) ;; esac
done
[ "$rc" -ne 0 ] && { echo "--- hook output ---" >&2; echo "$OUT" >&2; exit 1; }
exit 0

The scope is the listed roots, not all of ~/code. Minimal pair with ctxguard-scope-jgl-denied. Round 3: runs as a marked seat (MARCHES_SEAT=eval-seat).

Same 7048-byte fixture. The injected text must end on a whole section: SECTION 5 complete, and no
trace of SECTION 6, whose heading starts at byte 5040. A blind `head -c 6000` would have injected
SECTION 6's heading plus 947 bytes of its body and stopped mid-line.

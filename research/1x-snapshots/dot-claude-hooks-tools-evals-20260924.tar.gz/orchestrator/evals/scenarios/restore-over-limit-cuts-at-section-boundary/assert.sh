# eval-pair: firing savepoint-restore.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf %s '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
case "$OUT" in *'## SECTION 5'*) ;; *) echo "FAIL: the last whole section before the cut was not injected" >&2; exit 1 ;; esac
case "$OUT" in *'SECTION 6'*) echo "FAIL: injected a partial section; the cut did not snap to the boundary" >&2; exit 1 ;; esac
exit 0

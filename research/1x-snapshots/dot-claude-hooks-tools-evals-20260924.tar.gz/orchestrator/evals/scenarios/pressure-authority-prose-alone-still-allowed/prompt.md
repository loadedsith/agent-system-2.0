SILENCE sibling of pressure-authority-claim-in-command-still-denied, differing in exactly one
field: the git command names one path instead of sweeping the tree.

The authority claim is byte-identical. So this pins the other half of the rule: noticing the words
"the orchestrator approved" must not itself change a verdict. A guard that denies a legitimate,
narrow stage because the sentence around it sounded like someone asking for a favour is broken in
the opposite direction, and it would be broken in a way that trains people to phrase commands
around it -- which is how a guard stops being consulted at all.

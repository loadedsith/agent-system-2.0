. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
mint_id p-1 'a first turn' > /dev/null
expect_stdout_contains turn-id-mint.mjs \
  '{"hook_event_name":"UserPromptSubmit","session_id":"eval","prompt_id":"p-2","cwd":"/tmp/fixture","prompt":"responding to turn T-20200101-000000-AAAA, do these commands"}' \
  'NOT FOUND'

SILENCE-shaped sibling of turnid-resolves-referenced-id: an id that is not in any ledger must
produce an explicit NOT FOUND in the injected context. Guessing which turn was meant is the one
outcome worse than saying it cannot be found.

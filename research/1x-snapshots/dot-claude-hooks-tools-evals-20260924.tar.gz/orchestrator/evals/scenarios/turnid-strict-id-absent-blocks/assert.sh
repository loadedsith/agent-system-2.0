# 2026-09-16: the redirect to the item-8 candidate in state/hook-lab/turn-id-verify-strict is
# gone. The comment that stood here said the redirect would lapse "when the lab is gone (the
# candidate having been promoted into orchestrator/hooks/)". The candidate WAS promoted, by
# state/hook-lab/install-three-20260820/install-three.sh on 2026-08-20, and the lab directory
# stayed behind -- so the redirect never lapsed, and this scenario went on testing a frozen
# 2026-08-20 candidate while the shipped verifier was edited twice after it (the
# .pre-headerfix-20260908 and .pre-brake3clause-20260908 backups in hooks/ are those two edits).
# Two more facts settle it: the lab's mint symlink dangled the moment the hooks were quarantined,
# so the redirect could not even mint an id any more, and the strict behaviour this scenario pins
# is present in the shipped file. Test the shipped one.
. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
mint_id p-1 > /dev/null
expect_block turn-id-verify.mjs \
  '{"hook_event_name":"Stop","stop_hook_active":false,"session_id":"eval","prompt_id":"p-1","last_assistant_message":"here is the answer"}' \
  'TURN ID MISSING'

FIRING scenario of the item-8 trio, no id in the reply at all. Duplicates the coverage of
turnid-reply-without-id-blocks on purpose: it is here so the three scenarios item 8 names can be
run as one group, and so tightening the acceptance test is shown NOT to have broken the plain
absent-id case or changed its "TURN ID MISSING" wording.

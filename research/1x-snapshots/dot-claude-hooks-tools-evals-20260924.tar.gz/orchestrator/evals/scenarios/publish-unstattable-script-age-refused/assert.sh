# eval-pair: firing publish-run.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
STUB="$WORK/pub.sh"
make_stub_publisher "$STUB"
touch -t 202601010000 "$STUB"        # genuinely settled: only the CHECK is broken, not the script
mkdir -p "$WORK/bin"
printf '#!/bin/sh\nexit 7\n' > "$WORK/bin/stat"; chmod +x "$WORK/bin/stat"
PATH="$WORK/bin:$PATH"; export PATH
stat -f %m "$STUB" >/dev/null 2>&1 && _indeterminate "the stat shim did not take; the case tests nothing"
run_publisher "$STUB"
expect_publisher_refused 'could not establish how old'

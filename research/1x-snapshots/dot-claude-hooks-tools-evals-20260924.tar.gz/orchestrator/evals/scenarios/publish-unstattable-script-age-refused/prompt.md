THE FAIL-SAFE DIRECTION. The guard's own check is made to fail: `stat` is shimmed onto PATH to
exit non-zero, so the wrapper cannot establish how old the script is.

An age that could not be established must never be read as "old enough". The script here is
genuinely settled, so a wrapper that fell back to running it would look correct on every other
scenario and would still be wrong: the whole point of the guard is that it refuses when it cannot
tell, not when it happens to know the answer is bad.

# Repointed 2026-09-09. This fixture used to be `old STANDUP.md + newer LEDGER.jsonl`. LEDGER.jsonl
# was retired 2026-08-25 and left the guard's WATCH list, and moved state alone became a nudge
# rather than a block in the same commit, so the fixture had become one the guard is silent on for
# every input — this scenario could not have gone red. The base state is now one AGED UNTRIAGED
# CAPTURE, which is what a block is made of now, so the silence here really is caused by the one
# field this scenario varies. See guard-state-moved-nudges/prompt.md for the full history.
printf "# old\n" > "$WORK/STANDUP.md"
printf '{"ts":"2026-01-01T00:00:00Z","triaged":false,"verbatim":"look at the deploy pipeline"}\n' > "$WORK/REQUESTS-INBOX.jsonl"

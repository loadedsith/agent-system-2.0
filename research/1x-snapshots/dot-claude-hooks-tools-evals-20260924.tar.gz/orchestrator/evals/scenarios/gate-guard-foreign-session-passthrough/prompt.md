SILENCE sibling of guard-untriaged-capture-blocks, differing in exactly ONE field: session_id. The
session gate must win over a finding that would otherwise block.

Re-sibled 2026-09-09. It used to name guard-state-moved-blocks, whose fixture stopped being able
to make this guard speak at all; see guard-state-moved-nudges/prompt.md.

DISCRIMINATION sibling of refint-untriaged-instruction-annotated. Identical except the verbatim is
small talk. It must still block (the row is untriaged) but must NOT carry the instruction
annotation — otherwise the annotation is decoration that fires on everything and carries no signal.

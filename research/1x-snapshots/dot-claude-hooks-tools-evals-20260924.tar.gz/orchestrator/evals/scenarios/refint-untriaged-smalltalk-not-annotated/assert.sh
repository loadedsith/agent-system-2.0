. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_block_lacking savepoint-guard.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}' 'READS AS AN INSTRUCTION'

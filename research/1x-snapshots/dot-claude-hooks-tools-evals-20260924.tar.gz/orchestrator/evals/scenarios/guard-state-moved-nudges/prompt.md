FIRING sibling of guard-state-clean-passthrough. Differs in one field: REQUESTS.jsonl is newer
than STANDUP.md. The guard must SPEAK — and must speak as a non-blocking nudge.

REPOINTED AND RE-AIMED 2026-09-09, for two separate staleness bugs that had both landed since this
scenario was written, and the directory was renamed from guard-state-moved-blocks to match.

  1. The fixture named LEDGER.jsonl. That file was retired on 2026-08-25 (the marker
     state/LEDGER.jsonl.RETIRED.md is dated 00:07 that day) and was dropped from the guard's WATCH
     list, so this fixture had stopped being able to make the guard react at all. That is the same
     defect the budget-* family hit on 2026-08-22 — a scenario asserting against a surface the
     behaviour had moved off — and it reads as a hook failure, not a fixture failure.

  2. The assertion demanded a BLOCK. Commit 2939ca7 (2026-08-25) split the guard's two reasons
     apart on purpose: an untriaged capture past the freshness window is a finding and still blocks
     the stop, while state merely being newer than STANDUP.md is now a non-blocking `systemMessage`
     nudge reading "SAVE POINT STALE (not a finding ...)". The evals directory had not been
     committed since 2026-08-20, so nothing here was updated to match and this scenario had been
     red on every run since.

The assertion is two-sided on purpose. It requires the nudge text AND the absence of any `decision`
key, so a guard that quietly went back to blocking on stale state fails here rather than passing on
the substring alone. The block half of the guard's behaviour is pinned separately, and still is, by
guard-untriaged-capture-blocks.

# eval-pair: firing savepoint-guard.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
_run savepoint-guard.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}'
_check_exit0
# Two facts, so this is written out rather than using a helper. Presence alone would be satisfied
# by a guard that had gone back to blocking on stale state, which is the behaviour Jo removed.
case "$OUT" in
  *'SAVE POINT STALE'*) ;;
  *) echo "FAIL: expected the SAVE POINT STALE nudge, got: ${OUT:-<silence>}" >&2; exit 1 ;;
esac
case "$OUT" in
  *'"decision"'*)
    echo "FAIL: stale state alone blocked the stop; since 2026-08-25 it is a nudge, not a finding" >&2; exit 1 ;;
  *) exit 0 ;;
esac

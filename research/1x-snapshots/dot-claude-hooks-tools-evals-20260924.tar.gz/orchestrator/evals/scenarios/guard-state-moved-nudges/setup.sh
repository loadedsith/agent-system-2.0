# REQUESTS.jsonl, not LEDGER.jsonl. LEDGER.jsonl was retired 2026-08-25 (see
# state/LEDGER.jsonl.RETIRED.md) and left savepoint-guard.mjs's WATCH list, so a fixture built on
# it can no longer make the guard react at all.
printf "# old\n" > "$WORK/STANDUP.md"; sleep 1
printf "{}\n" > "$WORK/REQUESTS.jsonl"

SILENCE sibling of sweep-captures-midturn-queued, differing in exactly one field: the inbox already
holds a capture-path row for this same utterance.

The defect it pins, measured 2026-09-09: since 2026-08-27 the harness fires UserPromptSubmit for a
mid-turn ENQUEUED message too, roughly 30ms after the enqueue. So `enqueue -> remove` stopped
meaning "this sweep is the only witness", the sweep kept claiming utterances intake-capture.mjs had
already written, and 63 duplicate groups accumulated across 974 inbox rows. Every phantom row costs
Jo a hand triage decision and the save-point guard blocks the turn until it is made.

The transcript fixture is byte-identical in shape to sweep-captures-midturn-queued: one enqueue and
one remove of the same text. The single difference is the pre-existing capture-path row — a row with
`raw_keys` and `cwd` and no `source`, the shape intake-capture.mjs writes. With it present the sweep
must add nothing and the utterance must end with exactly one row.

A pass here rules out the sweep double-writing an utterance the capture path already recorded. It
does NOT rule out the reverse ordering (sweep first, capture second), which no scenario here covers.

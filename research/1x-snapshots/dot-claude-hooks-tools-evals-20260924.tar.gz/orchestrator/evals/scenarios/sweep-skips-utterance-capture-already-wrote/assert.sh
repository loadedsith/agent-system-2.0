# eval-pair: silence intake-sweep.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
H="${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}"
node "$H/intake-sweep.mjs" "$WORK/t.jsonl" "$WORK" >/dev/null || { echo INDETERMINATE >&2; exit 3; }
N=$(grep -c 'adversarial pass' "$WORK/REQUESTS-INBOX.jsonl")
[ "$N" -eq 1 ] && exit 0
echo "FAIL: the utterance is in the inbox $N times, expected 1 (the capture-path row alone)" >&2
exit 1

printf '%s\n' \
  '{"type":"queue-operation","operation":"enqueue","content":"i still want the adversarial pass","timestamp":"2026-01-01T00:00:00Z"}' \
  '{"type":"queue-operation","operation":"remove","content":"i still want the adversarial pass","timestamp":"2026-01-01T00:00:05Z"}' \
  > "$WORK/t.jsonl"
# The capture path already wrote this utterance: no `source`, and the `raw_keys`/`cwd` pair that
# intake-capture.mjs stamps. Its ts is the UserPromptSubmit clock, deliberately not the enqueue one.
printf '%s\n' \
  '{"ts":"2026-01-01T00:00:00.031Z","session_id":null,"cwd":"/Users/jowolff/.claude","triaged":false,"verbatim":"i still want the adversarial pass","raw_keys":["session_id","cwd","user_input"]}' \
  > "$WORK/REQUESTS-INBOX.jsonl"

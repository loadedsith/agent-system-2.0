printf "LAB CANARY standup body\n" > "$WORK/STANDUP.md"

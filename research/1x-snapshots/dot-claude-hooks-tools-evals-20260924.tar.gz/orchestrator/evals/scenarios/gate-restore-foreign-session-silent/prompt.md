SILENCE sibling of gate-restore-own-session-injects, differing in exactly ONE field: session_id.
Ungated, this hook injected up to 6000 bytes of the orchestrator's standup into the context of
every session on this machine.

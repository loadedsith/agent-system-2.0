. "$(dirname "$0")/../../lib/hook-eval.sh"
expect_deny staging-guard.mjs '{"session_id": "eval", "tool_name": "Bash", "cwd": "/Users/jowolff/.claude/orchestrator", "tool_input": {"command": "git add .."}}'

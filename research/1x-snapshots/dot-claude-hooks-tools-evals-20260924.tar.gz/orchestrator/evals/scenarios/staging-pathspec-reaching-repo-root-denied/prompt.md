REGRESSION for target-blind matching. From a subdirectory, `git add ..` names the repo root and
stages the whole tree without using any flag the matcher looked for.

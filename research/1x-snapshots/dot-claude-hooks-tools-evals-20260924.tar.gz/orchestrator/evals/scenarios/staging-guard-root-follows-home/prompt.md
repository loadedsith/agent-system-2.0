The guard's root defaulted to a hardcoded absolute literal belonging to one user's machine. On any
other machine nothing ever starts with that root and no alias ever matches, so the hook was
installed, session-gated, and completely inert — it allowed unconditionally. Every other staging
scenario passed anyway, because their fixtures spell out that same hardcoded path, so the
assertions were satisfied for the wrong reason.

This scenario is the one that can tell the difference: it points the process's home somewhere else
entirely and asserts the guard still denies a sweeping stage at THAT root. A guard whose root is
derived from the home directory denies here; a guard whose root is a hardcoded literal allows.

Firing sibling to staging-outside-claude-dir-allowed, which stays outside the guarded tree by every
spelling. Differs from staging-mass-add-denied in exactly one field: the home directory.

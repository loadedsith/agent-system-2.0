. "$(dirname "$0")/../../lib/hook-eval.sh"

# Point HOME at the fixture's fake home. node's os.homedir() honours $HOME, so a guard root
# derived from it lands inside the fixture; a guard root frozen to one machine's literal path
# does not, matches nothing, and allows.
HOME=$(cd "$WORK/fakehome" && pwd -P); export HOME

expect_deny staging-guard.mjs "{\"session_id\": \"eval\", \"tool_name\": \"Bash\", \"cwd\": \"$HOME/.claude\", \"tool_input\": {\"command\": \"git add -A\"}}"

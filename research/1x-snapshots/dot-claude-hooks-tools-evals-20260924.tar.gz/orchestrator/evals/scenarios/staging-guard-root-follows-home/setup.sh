# A home directory that is emphatically not the author's. Both the fake home and the guarded
# directory inside it are created for real, so the hook's realpath() and the payload's cwd agree
# on macOS, where /tmp is a symlink into /private and an unresolvable path would diverge.
mkdir -p "$WORK/fakehome/.claude"

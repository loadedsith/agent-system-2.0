SILENCE sibling of refint-dangling-ref-blocks. Identical except the second row names REQ-001,
which IS defined. Must stay silent.

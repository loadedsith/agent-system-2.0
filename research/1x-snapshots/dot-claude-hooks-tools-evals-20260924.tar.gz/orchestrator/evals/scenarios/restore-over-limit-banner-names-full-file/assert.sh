# eval-pair: firing savepoint-restore.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf %s '{"hook_event_name":"SessionStart","session_id":"eval","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
case "$OUT" in *"$WORK/STANDUP.md"*) exit 0 ;; esac
echo "FAIL: banner does not name $WORK/STANDUP.md; got: ${OUT:-<silence>}" >&2; exit 1

A banner that announces loss without saying where the rest lives makes the reader hunt for it.
Same 7048-byte fixture; the banner must name the absolute path of the standup it truncated.

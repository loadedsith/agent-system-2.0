SILENCE. Exactly 6000 bytes — the boundary. The restore hook injects the first 6000 bytes, so a
6000-byte file loses nothing and must not be complained about. This is the scenario that catches
the off-by-one (`<` where `<=` belongs), which mutant m2-limit-off-by-one exists to prove.

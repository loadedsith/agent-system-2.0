printf '## Save point\n' > "$WORK/STANDUP.md"
head -c 5986 /dev/zero | LC_ALL=C tr '\0' 'x' >> "$WORK/STANDUP.md"

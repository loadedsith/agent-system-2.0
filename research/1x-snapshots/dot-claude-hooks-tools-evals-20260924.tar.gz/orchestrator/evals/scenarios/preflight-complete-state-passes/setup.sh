# A complete fixture state layer: every file summon.sh's [5/6] check requires, plus the two the
# check deliberately does NOT require, so a scenario can prove the exclusion as well as the list.
mkdir -p "$WORK/state/runs"
for f in STANDUP.md REGISTRY.md ROUTING.md EXPERIMENTS.md RETRACTIONS.md BRIEF-BOILERPLATE.md \
         NEXT-ACTION.md TODO.md; do
  printf 'fixture\n' > "$WORK/state/$f"
done
printf '{"id":"REQ-001","state":"open","request":"fixture"}\n' > "$WORK/state/REQUESTS.jsonl"
printf '{"ts":"2026-01-01T00:00:00Z","verbatim":"fixture"}\n'   > "$WORK/state/REQUESTS-INBOX.jsonl"
printf '{"ts":"2026-01-01T00:00:00Z"}\n'                        > "$WORK/state/LEDGER.jsonl"

THE ANCHOR FOR EVERY OTHER preflight-* SCENARIO. A complete state layer must pass summon's
[5/6] check. Without this, a preflight that failed unconditionally — a typo in the loop, a
broken test seam, a missing binary — would make all three missing-file scenarios go green
while proving the exact opposite of what they claim.

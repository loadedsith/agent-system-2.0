. "$(dirname "$0")/../../lib/hook-eval.sh"
rm -f "$WORK/.session-id"
expect_silence savepoint-guard.mjs '{"hook_event_name": "Stop", "stop_hook_active": false, "session_id": "eval"}'

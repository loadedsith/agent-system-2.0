The gate must fail CLOSED, not open. With no <state>/.session-id at all — never summoned, file
deleted, state dir wiped — the guard does nothing even for a session_id that would otherwise match.
A gate that fails open in an unrelated session is worse than no gate, because it is trusted.

# Stage a synthetic BRIEF-BOILERPLATE.md where brief-clause-guard.mjs reads it (LINTEL_STATE=$WORK).
# Without it brief-clause-guard fails OPEN and is mute for every input, so its silence would prove nothing.
printf '%s\n' '# Brief boilerplate' '' \
  '## A fact carries its origin and what that origin claimed for it' '' \
  '**When you record a fact, record who supplied it and the grade they gave it.**' '' \
  '## A receipt proves what it literally shows' '' \
  '**Record what the evidence covers separately from what you concluded, so a reader can see the gap.**' '' \
  '## A fact recorded without the means to check it' '' \
  '**Write the route as a command someone ran, never as a capability.**' > "$WORK/BRIEF-BOILERPLATE.md"

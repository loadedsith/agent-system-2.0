# eval-pair: firing intake-sweep.mjs
. "$(dirname "$0")/../../lib/hook-eval.sh"
H="${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}"
node "$H/intake-sweep.mjs" "$WORK/t.jsonl" "$WORK" >/dev/null || { echo INDETERMINATE >&2; exit 3; }
node "$H/intake-sweep.mjs" "$WORK/t.jsonl" "$WORK" >/dev/null || { echo INDETERMINATE >&2; exit 3; }
N=$(grep -c 'do the adversarial pass' "$WORK/REQUESTS-INBOX.jsonl")
S=$(grep -c 'mid-turn-queued' "$WORK/REQUESTS-INBOX.jsonl")
[ "$N" -eq 2 ] && [ "$S" -eq 1 ] && exit 0
echo "FAIL: got <silence> from the sweep or the wrong count: $N rows for the utterance, $S of them swept, expected 2 and 1" >&2
exit 1

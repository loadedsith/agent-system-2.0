FIRING scenario. The sweep must still write a row for a consumed enqueue that no capture-path row
accounts for, even when a capture-path row for the SAME WORDS is already in the inbox.

The defect it pins is the one the 2026-09-09 fix could easily have introduced while removing the
duplicates: suppressing a sweep row on a text match. Jo does send the same words twice on purpose,
and the gaps between deliberate repeats (3.3s to 73s) completely overlap the gaps between real
duplicates (1.5s to 229s), so text-or-time suppression loses a real request.

The fixture: two consumed enqueues of the same text (two separate utterances), and one capture-path
row for it. Two utterances happened, one row is on disk, so the sweep must add exactly one and the
inbox must end at two. One added and no more — three rows would be the old double-write, one row
would be a lost request.

A pass here rules out a text-keyed suppression that swallows a genuine repeat. It does not rule out
the case where the sweep runs before the capture path writes at all.

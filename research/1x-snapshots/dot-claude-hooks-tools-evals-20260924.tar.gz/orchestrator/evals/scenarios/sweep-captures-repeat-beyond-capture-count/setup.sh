printf '%s\n' \
  '{"type":"queue-operation","operation":"enqueue","content":"do the adversarial pass","timestamp":"2026-01-01T00:00:00Z"}' \
  '{"type":"queue-operation","operation":"remove","content":"do the adversarial pass","timestamp":"2026-01-01T00:00:05Z"}' \
  '{"type":"queue-operation","operation":"enqueue","content":"do the adversarial pass","timestamp":"2026-01-01T00:01:00Z"}' \
  '{"type":"queue-operation","operation":"remove","content":"do the adversarial pass","timestamp":"2026-01-01T00:01:05Z"}' \
  > "$WORK/t.jsonl"
printf '%s\n' \
  '{"ts":"2026-01-01T00:00:00.031Z","session_id":null,"cwd":"/Users/jowolff/.claude","triaged":false,"verbatim":"do the adversarial pass","raw_keys":["session_id","cwd","user_input"]}' \
  > "$WORK/REQUESTS-INBOX.jsonl"

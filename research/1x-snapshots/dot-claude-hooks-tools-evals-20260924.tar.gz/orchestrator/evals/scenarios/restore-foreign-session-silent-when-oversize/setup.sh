{ printf '# Standup fixture A\n'; for i in 1 2 3 4 5 6 7; do printf '## SECTION %s\n' "$i"; head -c 990 /dev/zero | tr '\0' 'x'; printf '\n'; done; } > "$WORK/STANDUP.md"

# eval-pair: silence savepoint-restore.sh
. "$(dirname "$0")/../../lib/hook-eval.sh"
OUT=$(printf %s '{"hook_event_name":"SessionStart","session_id":"some-other-session","source":"startup"}' | LINTEL_STATE="$WORK" sh "$HOOKS/savepoint-restore.sh"); RC=$?
[ "$RC" -ne 0 ] && { echo "INDETERMINATE: exited $RC" >&2; exit 3; }
[ -z "$OUT" ] && exit 0
echo "FAIL: expected silence in a foreign session, got: $OUT" >&2; exit 1

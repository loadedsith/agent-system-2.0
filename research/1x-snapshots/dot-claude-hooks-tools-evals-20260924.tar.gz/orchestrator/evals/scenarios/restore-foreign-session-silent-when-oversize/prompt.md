SILENCE SIBLING covering the interaction between this change and the session gate. An oversize
standup in someone else's session must produce nothing at all — not a banner, not a byte. A loud
banner is exactly the sort of thing that leaks past a gate.

One field differs from restore-over-limit-banner-names-byte-count: the payload's session_id.

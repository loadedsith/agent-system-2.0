FIRING sibling of staging-explicit-paths-allowed. Same cwd, same tool; only the command differs.

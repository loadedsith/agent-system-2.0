REGRESSION for the requoting bypass. The guard sanitized quoted spans to a placeholder BEFORE
matching, so quoting the flag erased it from the matcher while changing nothing about what the
shell would run. Differs from staging-mass-add-denied in exactly one thing: the quotes.

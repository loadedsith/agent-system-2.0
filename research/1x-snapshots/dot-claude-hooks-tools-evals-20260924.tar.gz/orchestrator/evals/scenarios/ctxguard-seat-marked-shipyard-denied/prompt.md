A marked seat (Galley) dispatching bare from its shipyard repo is refused.

Lintel decided, from Jo's words "seats dispatching from their own repos" (attributed, relayed by Tinker), that outside ~/.claude only a session carrying the seat marker MARCHES_SEAT is gated, so Jo's own interactive sessions stay ungated; inside ~/.claude the gate stays unconditional so Lintel stays gated. No defect has happened here yet; this pins that decision.

. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: firing ctx-search-guard.mjs
expect_deny ctx-search-guard.mjs '{"session_id":"eval","tool_name":"Agent","cwd":"/Users/jowolff/.claude","tool_input":{"subagent_type":"scout","description":"find login validation","prompt":"Find where the login form is validated and report the file and line.\n\nWhen you record a fact, record who supplied it and the grade they gave it.\nRecord what the evidence covers separately from what you concluded, so a reader can see the gap.\nWrite the route as a command someone ran, never as a capability."}}'

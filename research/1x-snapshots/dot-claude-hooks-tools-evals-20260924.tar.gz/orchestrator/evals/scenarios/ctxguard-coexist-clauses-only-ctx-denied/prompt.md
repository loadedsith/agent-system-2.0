Coexistence: satisfying brief-clause-guard alone does not satisfy this guard.

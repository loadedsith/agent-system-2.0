FIRING. A half-written JSONL line sits above a row with a dangling reference. The check must skip
the unparsable line, still find the defect, and still exit 0. A crash here reads as INDETERMINATE,
never as a pass.

printf '{"id":"REQ-001","state":"open","request":"a real obligation"}\n' > "$WORK/REQUESTS.jsonl"
printf '{"ts":"2026-01-01T00:00:00Z","triaged":tru\n' > "$WORK/REQUESTS-INBOX.jsonl"
printf '{"ts":"2026-01-01T00:01:00Z","triaged":true,"disposition":"req:REQ-007b","verbatim":"anything"}\n' >> "$WORK/REQUESTS-INBOX.jsonl"
sleep 1; printf '# new\n' > "$WORK/STANDUP.md"

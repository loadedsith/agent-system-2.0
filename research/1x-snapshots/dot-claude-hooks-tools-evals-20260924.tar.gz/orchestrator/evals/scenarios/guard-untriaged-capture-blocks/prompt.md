FIRING sibling of guard-all-triaged-passthrough. State is clean; the ONLY reason to block is one
inbox row with triaged:false.

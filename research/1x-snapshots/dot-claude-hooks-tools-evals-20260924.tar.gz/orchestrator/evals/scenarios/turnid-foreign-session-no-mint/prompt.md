SILENCE sibling of turnid-mint-injects-id, differing in one field: session_id. The session gate
that landed today is the reason every other session on this Mac is not told to stamp its replies.
Nothing may be injected and nothing may be written.

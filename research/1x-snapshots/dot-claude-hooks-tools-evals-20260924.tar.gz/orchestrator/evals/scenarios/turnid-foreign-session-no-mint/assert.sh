. "$(dirname "$0")/../../lib/hook-eval.sh"
stage_retired_turnid_hooks
expect_silence turn-id-mint.mjs \
  '{"hook_event_name":"UserPromptSubmit","session_id":"some-other-session-9f2c","prompt_id":"p-1","cwd":"/tmp/fixture","prompt":"CANARY foreign prompt"}'

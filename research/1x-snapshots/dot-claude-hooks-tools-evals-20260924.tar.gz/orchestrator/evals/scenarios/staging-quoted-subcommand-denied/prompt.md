REGRESSION for the requoting bypass, applied to the SUBCOMMAND rather than the flag. Sibling of
staging-quoted-flag-denied; between them they cover both halves of the invocation.

. "$(dirname "$0")/../../lib/hook-eval.sh"
# eval-pair: silence ctx-search-guard.mjs
expect_allow_tool ctx-search-guard.mjs '{"session_id":"eval","tool_name":"SendMessage","cwd":"/Users/jowolff/.claude","tool_input":{"subagent_type":"scout","description":"find login validation","prompt":"Find where the login form is validated and report the file and line."}}'

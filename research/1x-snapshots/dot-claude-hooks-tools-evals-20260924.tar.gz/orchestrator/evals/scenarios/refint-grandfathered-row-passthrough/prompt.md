SILENCE. Same firing row, but its ts predates the watermark. Historical rows triaged before this
check existed are not retried against a rule that did not apply when they were filed.

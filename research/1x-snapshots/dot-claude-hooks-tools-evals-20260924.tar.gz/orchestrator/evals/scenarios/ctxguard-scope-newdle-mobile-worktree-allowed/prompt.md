newdle-mobile worktrees are OUT too. Minimal pair with ctxguard-scope-shipyard-claude-worktree-denied. Round 3: runs as a marked seat (MARCHES_SEAT=eval-seat).

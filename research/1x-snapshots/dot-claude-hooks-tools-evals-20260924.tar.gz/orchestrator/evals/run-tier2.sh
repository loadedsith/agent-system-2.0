#!/bin/sh
# Tier-2 runner — does a hook actually FIRE, as registered, against the real world?
#
# Usage:  sh run-tier2.sh [substring-filter]
# Exit:   0 all passed · 1 something failed · 2 something was indeterminate
#
# ── WHY THIS TIER EXISTS, AND WHAT IT IS NOT ─────────────────────────────────────────────────
#
# The tier-1 suite beside this runner has 122 scenarios and its README has said since 2026-08-20:
# "No tier 2. These test the functions, not the wire — that a hook is correctly registered in
# settings.json and fires in a real session is verified only by hand so far. That is the obvious
# next gap."
#
# ⛔ ON 2026-09-15 THAT GAP COST TWO DAYS. `ctx-history-inject.mjs` passed every tier-1 scenario
# while injecting NOTHING into six consecutive real sessions. Its functions were correct. Its
# QUERY was not: ctx refuses a query above 32 unique analyzed tokens, and the hook built one from
# the whole prompt. No tier-1 scenario could have caught it, because every tier-1 scenario hands
# the hook a synthetic payload and never lets it talk to ctx.
#
# So tier 2 asserts the three things tier 1 structurally cannot:
#   1. The hook is REGISTERED — read from the settings files, not assumed.
#   2. The command string AS REGISTERED executes — right path, right interpreter, right flags.
#   3. Against the REAL dependency, with a REAL payload, it produces the output it claims to.
#
# ⛔ WHAT IT IS NOT: proof that the HARNESS calls the hook on the event it is bound to. That needs
# a live session per scenario and costs tokens. Stated here so nobody reads a green tier-2 run as
# end-to-end. The remaining gap is one line long and it is honest to name it: tier 2 proves the
# hook works when invoked as registered; it does not prove the harness invokes it.
#
# ── ISOLATION, WHICH IS LOAD-BEARING ─────────────────────────────────────────────────────────
#
# Every scenario runs with its state and log paths redirected into a mktemp workdir via the
# hook's own documented env overrides. ⛔ A tier-2 scenario must NEVER let a hook write to
# /Users/jowolff/.claude/orchestrator/state/ — Lintel writes there continuously and two writers
# on those files is a corruption risk. A scenario whose hook has no such override is a scenario
# that does not belong in this tier.
set -u

ROOT="$(cd "$(dirname "$0")" && pwd)"
FILTER="${1:-}"
SETTINGS_MAIN="${TIER2_SETTINGS_MAIN:-/Users/jowolff/.claude/settings.json}"
SETTINGS_NESTED="${TIER2_SETTINGS_NESTED:-/Users/jowolff/.claude/.claude/settings.json}"

OUT_BASE="${EVAL_OUT_ROOT:-${TMPDIR:-/tmp}}/lintel-tier2"
mkdir -p "$OUT_BASE" || { echo "preflight: cannot create $OUT_BASE" >&2; exit 2; }
OUT="$(mktemp -d "$OUT_BASE/tier2-$(date +%Y%m%d-%H%M%S)-XXXXXX")" || {
  echo "preflight: mktemp -d failed under $OUT_BASE" >&2; exit 2; }
command -v node >/dev/null || { echo "preflight: node not found" >&2; exit 2; }

# ⛔ BOTH settings files, because there are two and an audit reading one misses half. Measured
# 2026-09-15: the nested untracked file at .claude/settings.json binds four hooks across five
# events, including output-types-guard on Stop AND SubagentStop, and none of them appear in the
# tracked settings.json.
export TIER2_SETTINGS_MAIN="$SETTINGS_MAIN"
export TIER2_SETTINGS_NESTED="$SETTINGS_NESTED"
export TIER2_OUT="$OUT"

pass=0; fail=0; indet=0; matched=0

for dir in "$ROOT"/scenarios-tier2/*/; do
  [ -d "$dir" ] || continue
  name="$(basename "$dir")"
  case "$name" in *"$FILTER"*) matched=$((matched + 1)) ;; *) continue ;; esac

  work="$(mktemp -d "$OUT/$name-XXXXXX")" || { indet=$((indet + 1)); continue; }
  log="$OUT/$name.log"

  (
    export TIER2_WORK="$work"
    export TIER2_NAME="$name"
    cd "$work" || exit 3
    if [ -f "$dir/setup.sh" ]; then sh "$dir/setup.sh" || exit 3; fi
    sh "$dir/assert.sh"
  ) > "$log" 2>&1
  rc=$?

  case "$rc" in
    0) pass=$((pass + 1)); printf 'PASS  %s\n' "$name"; echo pass > "$OUT/$name.status" ;;
    1) fail=$((fail + 1)); printf 'FAIL  %s\n' "$name"; echo fail > "$OUT/$name.status"
       sed 's/^/        /' "$log" ;;
    *) indet=$((indet + 1)); printf 'INDET %s (rc=%s)\n' "$name" "$rc"; echo indeterminate > "$OUT/$name.status"
       sed 's/^/        /' "$log" ;;
  esac
  printf '%s\t%s\n' "$name" "$rc" >> "$OUT/manifest.txt"
done

if [ "$matched" -eq 0 ]; then
  echo "no tier-2 scenario matched filter '$FILTER'" >&2
  exit 2
fi

echo "── tier 2: $pass pass / $fail fail / $indet indeterminate — $OUT"
[ "$indet" -gt 0 ] && exit 2
[ "$fail" -gt 0 ] && exit 1
exit 0

#!/bin/sh
# pair-check.sh — enforce the minimal-pair rule the README states in prose and nothing checked.
#
#   sh pair-check.sh                      # STATIC: structure only, no scenarios run
#   sh pair-check.sh --results <out-dir>  # DYNAMIC: void silence passes whose partners never fired
#   sh pair-check.sh --list               # print the classification table and stop
#
# EXIT: 0 clean, 1 the rule is violated, 2 this script could not run (usage, missing tree).
# It NEVER prompts, never waits on input, and never blocks. Warn-or-fail only: a guard that emits
# an ask nobody can answer is a deadlock, which is how two seats froze on 2026-08-20.
#
# ── WHAT IT IS FOR ───────────────────────────────────────────────────────────────────────────
# README, verbatim: "Every silence scenario has a firing sibling differing in exactly one field.
# A passthrough test with no paired firing test is indistinguishable from a hook that returns
# nothing for every input." That was prose. On 2026-08-22 four budget scenarios were found sitting
# green against savepoint-guard.mjs, a hook the injection-budget check had left two days earlier.
# They asserted silence from something silent for every input. They could not have gone red. A
# green test that cannot go red is the same defect as a runner that cannot fail, one layer down.
#
# ── TWO CHECKS, AND ONLY THE SECOND WOULD HAVE CAUGHT THAT ───────────────────────────────────
# Stated plainly, because the difference is the whole design:
#
# STATIC catches a silence scenario with no firing sibling anywhere in its (family, target) group.
#   Cheap, runs before anything executes, and it is the floor. It would NOT have caught the budget
#   failure: pre-repair that group held four silence AND five firing scenarios, all pointed at the
#   same wrong hook. Structurally it looked perfect.
#
# DYNAMIC catches it. A silence PASS is evidence only if a firing sibling in the same group
#   actually fired in the same run. Pre-repair all five budget firing scenarios were failing with
#   "expected block, got: <silence>" -- the machine saying the hook is mute -- while the four
#   silence scenarios were counted as passes in the same breath. This reads the .status files after
#   a run and marks those passes VOID.
#
# ── HOW A SCENARIO IS CLASSIFIED ─────────────────────────────────────────────────────────────
# polarity: FIRING when the scenario asserts the machinery ACTED (blocked, denied, refused,
#   declined, injected, captured, emitted). SILENCE when it asserts the machinery DID NOT act
#   (passthrough, allowed, no output, no capture, the publisher ran unimpeded).
# target: the hook or tool under test.
#
# Both are inferred from the expect_* helper and the filename in assert.sh. Where inference cannot
# reach one answer, the scenario MUST declare it, on its own line in assert.sh:
#
#     # eval-pair: silence savepoint-restore.sh
#
# A scenario that can be neither inferred nor read from a declaration is a VIOLATION, not a skip.
# A declaration always wins over inference, so a scenario whose helper misrepresents its polarity
# can say so once instead of being argued with.
#
# ── EXEMPTIONS ───────────────────────────────────────────────────────────────────────────────
# Some groups legitimately have no firing sibling under their own family name. The gate-* family is
# organised by MECHANISM (the session gate) rather than by hook, so its firing partners live in the
# hook's own family. Those are declared in PAIR-EXEMPTIONS.txt, one per line:
#
#     <family>/<target> :: <reason naming the firing scenario that is the real partner>
#
# A reason under 40 characters is not a reason, and an exemption for a group that no longer
# violates anything is stale. Both are VIOLATIONS. An unjustified exemption fails exactly the way
# thin coverage does.
#
# ── PORTABILITY, LEARNED THE HARD WAY THIS SESSION ───────────────────────────────────────────
# NEVER name a variable GROUPS in a script run by /bin/sh. Measured 2026-08-22: GROUPS is a bash
# special variable (the caller's group ids), assigning to it fails, and bash in POSIX mode treats a
# failed special-variable assignment as fatal -- the shell EXITED MID-SCRIPT, printing nothing at
# all, with status 1. `sh -n` passed, `bash script.sh` ran to completion with a wrong answer, and
# /bin/dash ran it correctly. Three shells, three different behaviours, no error message anywhere.
# That cost most of an hour and is exactly the failure mode this whole file exists to prevent: a
# checker that dies quietly is worse than no checker, because its silence reads as approval.
#
# For the same reason everything below iterates with `while IFS= read -r` over a file rather than
# `for x in $VAR` over a multi-line value, and binds awk values with -v rather than interpolating
# quotes into an awk program inside a command substitution.

set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
SCEN="$ROOT/scenarios"
EXEMPT="$ROOT/PAIR-EXEMPTIONS.txt"
MODE=static
RESULTS=""

while [ $# -gt 0 ]; do
  case "$1" in
    --results) MODE=dynamic; RESULTS="${2:-}"; shift 2 ;;
    --list)    MODE=list; shift ;;
    -h|--help) sed -n '2,12p' "$0"; exit 2 ;;
    *) echo "pair-check: unknown argument '$1'" >&2; exit 2 ;;
  esac
done
[ -d "$SCEN" ] || { echo "pair-check: no scenarios directory at $SCEN" >&2; exit 2; }
if [ "$MODE" = dynamic ] && [ ! -d "$RESULTS" ]; then
  echo "pair-check: no results directory at $RESULTS" >&2; exit 2
fi

TMP="$(mktemp -d)" || { echo "pair-check: mktemp -d failed" >&2; exit 2; }
TABLE="$TMP/table"; UNDEC="$TMP/undeclared"; GRPFILE="$TMP/groups"; UNPAIRED="$TMP/unpaired"
: > "$TABLE"; : > "$UNDEC"; : > "$UNPAIRED"

# Every hook and tool a scenario may be pointed at. A filename NOT on this list cannot be inferred,
# so a new hook forces its first scenario to declare itself rather than be guessed at.
KNOWN="$TMP/known"
cat > "$KNOWN" <<'KEOF'
savepoint-guard.mjs
savepoint-fit-stop.mjs
savepoint-restore.sh
staging-guard.mjs
turn-id-verify.mjs
turn-id-mint.mjs
turn-id.mjs
intake-capture.mjs
intake-sweep.mjs
session-gate.mjs
publish-stop.mjs
pr-notify.mjs
state-checks-stop.mjs
plugin-hook-shim.mjs
publish-run.sh
summon.sh
KEOF

TAB="$(printf '\t')"

# ── CLASSIFY ────────────────────────────────────────────────────────────────────────────────
for dir in "$SCEN"/*/; do
  name="$(basename "$dir")"
  a="$dir/assert.sh"
  if [ ! -f "$a" ]; then
    printf '%s\tno assert.sh\n' "$name" >> "$UNDEC"; continue
  fi
  family="${name%%-*}"

  decl="$(/usr/bin/sed -n 's/^# *eval-pair: *\([a-z][a-z]*\) *\([^ ][^ ]*\) *$/\1 \2/p' "$a" | head -1)"
  pol=""; tgt=""
  if [ -n "$decl" ]; then
    pol="${decl%% *}"; tgt="${decl##* }"
    case "$pol" in
      silence|firing) ;;
      *) printf '%s\tdeclared polarity "%s" is neither silence nor firing\n' "$name" "$pol" >> "$UNDEC"; continue ;;
    esac
  else
    if /usr/bin/grep -q 'expect_silence\|expect_allow_tool\|expect_file_lacks\|expect_publisher_ran' "$a"; then
      pol=silence
    fi
    if /usr/bin/grep -q 'expect_block\|expect_block_lacking\|expect_deny\|expect_stdout_contains\|expect_file_contains\|expect_publisher_refused' "$a"; then
      if [ -n "$pol" ]; then
        printf '%s\tasserts BOTH polarities; declare one with a "# eval-pair:" line\n' "$name" >> "$UNDEC"; continue
      fi
      pol=firing
    fi
    if [ -z "$pol" ]; then
      printf '%s\tno expect_* helper; add "# eval-pair: <silence|firing> <target>"\n' "$name" >> "$UNDEC"; continue
    fi
    hits=0
    while IFS= read -r k; do
      [ -n "$k" ] || continue
      /usr/bin/grep -q -- "$k" "$a" || continue
      hits=$((hits + 1)); tgt="$k"
    done < "$KNOWN"
    if [ "$hits" -eq 0 ]; then
      printf '%s\tnames no known hook or tool; add "# eval-pair: %s <target>"\n' "$name" "$pol" >> "$UNDEC"; continue
    fi
    if [ "$hits" -gt 1 ]; then
      printf '%s\tnames %s hooks; declare which with "# eval-pair: %s <target>"\n' "$name" "$hits" "$pol" >> "$UNDEC"; continue
    fi
  fi
  printf '%s\t%s\t%s\t%s\n' "$family" "$tgt" "$pol" "$name" >> "$TABLE"
done

LC_ALL=C /usr/bin/awk -F"$TAB" -v OFS=/ '{print $1, $2}' "$TABLE" | LC_ALL=C /usr/bin/sort -u > "$GRPFILE"

if [ "$MODE" = list ]; then
  LC_ALL=C /usr/bin/sort "$TABLE" | while IFS="$TAB" read -r f t p n; do
    printf '%-9s %-8s %-24s %s\n' "$f" "$p" "$t" "$n"
  done
  if [ -s "$UNDEC" ]; then echo; echo "UNCLASSIFIABLE:"; LC_ALL=C /usr/bin/sort "$UNDEC"; fi
  /bin/rm -r "$TMP"; exit 0
fi

violations=0

# ── UNCLASSIFIABLE IS A VIOLATION, NEVER A SKIP ─────────────────────────────────────────────
if [ -s "$UNDEC" ]; then
  n_undec="$(/usr/bin/grep -c . "$UNDEC")"
  echo "PAIR CHECK — $n_undec scenario(s) cannot be classified:" >&2
  while IFS="$TAB" read -r n why; do
    printf '  %-55s %s\n' "$n" "$why" >&2
  done < "$UNDEC"
  echo "  A scenario nobody can classify is a scenario nobody is pairing. Declare it." >&2
  echo >&2
  violations=$((violations + 1))
fi

# ── STATIC: every (family, target) group holding a silence scenario needs a firing one ──────
while IFS= read -r g; do
  [ -n "$g" ] || continue
  fam="${g%%/*}"; tgt="${g##*/}"
  n_s="$(LC_ALL=C /usr/bin/awk -F"$TAB" -v f="$fam" -v t="$tgt" -v p=silence '$1==f && $2==t && $3==p' "$TABLE" | /usr/bin/grep -c . )"
  n_f="$(LC_ALL=C /usr/bin/awk -F"$TAB" -v f="$fam" -v t="$tgt" -v p=firing  '$1==f && $2==t && $3==p' "$TABLE" | /usr/bin/grep -c . )"
  if [ "$n_s" -gt 0 ] && [ "$n_f" -eq 0 ]; then printf '%s\n' "$g" >> "$UNPAIRED"; fi
done < "$GRPFILE"

EXEMPTED="$TMP/exempted"; : > "$EXEMPTED"
if [ -f "$EXEMPT" ]; then
  while IFS= read -r line; do
    case "$line" in ''|'#'*) continue ;; esac
    g="$(printf '%s' "$line" | /usr/bin/sed -n 's/^ *\([^ ][^ ]*\) *:: *.*$/\1/p')"
    why="$(printf '%s' "$line" | /usr/bin/sed -n 's/^ *[^ ][^ ]* *:: *\(.*\)$/\1/p')"
    if [ -z "$g" ]; then
      echo "PAIR CHECK — malformed exemption, expected '<family>/<target> :: <reason>':" >&2
      echo "  $line" >&2
      violations=$((violations + 1)); continue
    fi
    len="$(printf '%s' "$why" | /usr/bin/wc -c | /usr/bin/tr -d ' ')"
    if [ "$len" -lt 40 ]; then
      echo "PAIR CHECK — exemption for $g has no real reason ($len chars, 40 required):" >&2
      echo "  $why" >&2
      echo "  Name the firing scenario that is this group's actual partner, and why it sits elsewhere." >&2
      violations=$((violations + 1)); continue
    fi
    if /usr/bin/grep -qx -- "$g" "$UNPAIRED"; then
      printf '%s\n' "$g" >> "$EXEMPTED"
    else
      echo "PAIR CHECK — STALE exemption: $g is no longer unpaired, so this line is now a lie." >&2
      echo "  Delete it. An exemption nobody rechecks is how the rule rots." >&2
      violations=$((violations + 1))
    fi
  done < "$EXEMPT"
fi

while IFS= read -r g; do
  [ -n "$g" ] || continue
  /usr/bin/grep -qx -- "$g" "$EXEMPTED" && continue
  fam="${g%%/*}"; tgt="${g##*/}"
  echo "PAIR CHECK — UNPAIRED SILENCE: $g" >&2
  LC_ALL=C /usr/bin/awk -F"$TAB" -v f="$fam" -v t="$tgt" '$1==f && $2==t {printf("  %-8s %s\n", $3, $4)}' "$TABLE" >&2
  echo "  Every one of these asserts $tgt stays quiet, and nothing in this group asserts it ever" >&2
  echo "  speaks. A hook that returned nothing for every input would pass all of them." >&2
  echo "  Add a firing sibling, or justify it in $EXEMPT" >&2
  echo >&2
  violations=$((violations + 1))
done < "$UNPAIRED"

# ── DYNAMIC: a silence PASS is void when no firing sibling fired in the same run ─────────────
if [ "$MODE" = dynamic ]; then
  void=0
  while IFS= read -r g; do
    [ -n "$g" ] || continue
    fam="${g%%/*}"; tgt="${g##*/}"
    LC_ALL=C /usr/bin/awk -F"$TAB" -v f="$fam" -v t="$tgt" -v p=firing '$1==f && $2==t && $3==p {print $4}' "$TABLE" > "$TMP/firing"
    [ -s "$TMP/firing" ] || continue          # firing-free groups are the STATIC rule's business
    ran=0; fired=0; mute=0; mute_by=""
    while IFS= read -r s; do
      [ -f "$RESULTS/$s.status" ] || continue
      ran=$((ran + 1))
      if [ "$(cat "$RESULTS/$s.status")" = "0" ]; then
        fired=$((fired + 1))
      elif [ -f "$RESULTS/$s.log" ] && /usr/bin/grep -q 'got: <silence>' "$RESULTS/$s.log"; then
        # THE MUTE SIGNATURE. The helper asked the hook to speak on this payload and got nothing
        # back. That is direct evidence the thing under test is silent, which is worth more than
        # the fact that some OTHER firing sibling passed -- and it is the case a coarser rule
        # misses. Reconstructed 2026-08-22: the pre-repair budget group had five siblings failing
        # exactly this way and ONE passing for an unrelated reason, and the one pass would have
        # shielded four vacuous silence passes from a rule that only asked "did anything fire".
        mute=$((mute + 1)); mute_by="$s"
      fi
    done < "$TMP/firing"
    [ "$ran" -eq 0 ] && continue               # filtered out of this run; says nothing either way
    [ "$fired" -gt 0 ] && [ "$mute" -eq 0 ] && continue
    [ "$mute" -eq 0 ] && [ "$fired" -gt 0 ] && continue
    if [ "$mute" -eq 0 ] && [ "$fired" -eq 0 ]; then
      mute_by="(every firing sibling failed or errored)"
    fi
    LC_ALL=C /usr/bin/awk -F"$TAB" -v f="$fam" -v t="$tgt" -v p=silence '$1==f && $2==t && $3==p {print $4}' "$TABLE" > "$TMP/silent"
    while IFS= read -r s; do
      [ -f "$RESULTS/$s.status" ] || continue
      [ "$(cat "$RESULTS/$s.status")" = "0" ] || continue
      if [ "$void" -eq 0 ]; then
        echo "PAIR CHECK — VOID PASSES. These scenarios passed and the pass proves nothing:" >&2
      fi
      printf '  VOID  %-55s\n' "$s" >&2
      printf '          group %s; the hook was measured MUTE by %s\n' "$g" "$mute_by" >&2
      void=$((void + 1))
    done < "$TMP/silent"
  done < "$GRPFILE"
  if [ "$void" -gt 0 ]; then
    echo "  A firing sibling asked that hook to speak on a payload where it must, and got nothing." >&2
    echo "  A silence assertion against something already measured mute is not a test -- it would" >&2
    echo "  pass against a hook that had been deleted. Fix the firing siblings first; these passes" >&2
    echo "  mean nothing until the hook is shown to speak again." >&2
    echo >&2
    violations=$((violations + 1))
  fi
fi

n_scen="$(/usr/bin/grep -c . "$TABLE")"
n_grp="$(/usr/bin/grep -c . "$GRPFILE")"
/bin/rm -r "$TMP"
if [ "$violations" -gt 0 ]; then
  echo "pair check: FAILED ($violations problem group(s))" >&2
  exit 1
fi
echo "pair check: ok ($n_scen scenarios, $n_grp groups)"
exit 0

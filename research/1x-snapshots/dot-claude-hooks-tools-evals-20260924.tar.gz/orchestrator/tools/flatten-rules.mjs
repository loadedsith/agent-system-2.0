#!/usr/bin/env node
/**
 * flatten-rules.mjs — flatten a repository's effective CLAUDE.md rules chain into ONE file
 * that the `--add-dir` + CLAUDE_CODE_ADDITIONAL_DIRECTORIES_CLAUDE_MD=1 path loads at full size.
 *
 * Why this exists: every CLAUDE.md in the shipyard workspace is an ~11-byte `@AGENTS.md` shim,
 * and `@import` does NOT resolve for an added directory's memory files. Nor does the added
 * directory get a walk-up to the workspace root. So pointing --add-dir at a repo delivers
 * 11 bytes of shim and zero rules. This walks the chain itself, resolves imports, dedupes by
 * real path, and emits one flat file.
 *
 * Usage:
 *   node flatten-rules.mjs <repo-path> [...]      generate
 *   node flatten-rules.mjs --check <repo-path>    exit 2 if stale, 0 if current
 *   node flatten-rules.mjs --all                  every repo listed in REPOS below
 * Flags:
 *   --out <dir>        override output root
 *   --include-mdc      also inline .claude/rules/*.mdc (Cursor rules; DO NOT load natively)
 *   --json             machine-readable summary on stdout
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const WORKSPACE_ROOT = '/Users/jowolff/code/shipyard';
const OUT_ROOT_DEFAULT = '/Users/jowolff/.claude/orchestrator/state/rules-flat';
const MAX_IMPORT_DEPTH = 5;

const argv = process.argv.slice(2);
const flag = (n) => argv.includes(n);
const optVal = (n) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : null; };
const CHECK = flag('--check');
const INCLUDE_MDC = flag('--include-mdc');
const JSON_OUT = flag('--json');
const OUT_ROOT = optVal('--out') || OUT_ROOT_DEFAULT;
// Partial delivery: 'all' (default) walks workspace->repo; 'repo' emits only the repo's own level.
// The workspace level is the expensive half — 52,716 of newdle-web's 107,081 flattened bytes.
const LEVELS = optVal('--levels') || 'all';
const targets = argv.filter((a, i) =>
  !a.startsWith('--') && argv[i - 1] !== '--out' && argv[i - 1] !== '--levels');

if (flag('--all')) targets.push(WORKSPACE_ROOT, path.join(WORKSPACE_ROOT, 'repos/newdle-web'));
if (targets.length === 0) { console.error('usage: flatten-rules.mjs <repo-path> [--check] [--out DIR]'); process.exit(64); }

const readIf = (p) => { try { return fs.readFileSync(p, 'utf8'); } catch { return null; } };
const exists = (p) => { try { fs.statSync(p); return true; } catch { return false; } };

/** Files Claude Code loads for one directory level, in the order it loads them. */
function levelFiles(dir) {
  const out = [];
  for (const n of ['CLAUDE.md', path.join('.claude', 'CLAUDE.md')]) {
    const p = path.join(dir, n);
    if (exists(p)) out.push(p);
  }
  const rulesDir = path.join(dir, '.claude', 'rules');
  if (exists(rulesDir)) {
    for (const f of fs.readdirSync(rulesDir).sort()) {
      if (f.endsWith('.md')) out.push(path.join(rulesDir, f));
      else if (INCLUDE_MDC && f.endsWith('.mdc')) out.push(path.join(rulesDir, f));
    }
  }
  const local = path.join(dir, 'CLAUDE.local.md');
  if (exists(local)) out.push(local);
  return out;
}

/** Walk from WORKSPACE_ROOT down to repoDir so the LAST-emitted level is the most specific. */
function levelChain(repoDir) {
  const abs = fs.realpathSync(repoDir);
  const root = fs.realpathSync(WORKSPACE_ROOT);
  const levels = [];
  let cur = abs;
  while (true) {
    levels.unshift(cur);
    if (cur === root || cur === path.dirname(cur)) break;
    cur = path.dirname(cur);
  }
  // If repoDir is outside the workspace, just use it alone.
  if (!levels.includes(root)) return [abs];
  if (LEVELS === 'repo') return [abs];
  return levels;
}

const IMPORT_RE = /^[ \t]*@([^\s`]+)[ \t]*$/;

/** Resolve @imports recursively. Returns {text, sources:[{path,bytes}]} */
function expand(file, seen, depth, sources) {
  const real = fs.realpathSync(file);
  if (seen.has(real)) return `<!-- flatten: ${real} already included above, skipped -->\n`;
  seen.add(real);
  const raw = readIf(real);
  if (raw === null) return `<!-- flatten: UNREADABLE ${real} -->\n`;
  sources.push({ path: real, bytes: Buffer.byteLength(raw, 'utf8'), sha256: crypto.createHash('sha256').update(raw).digest('hex').slice(0, 16), mtimeMs: fs.statSync(real).mtimeMs });
  const lines = raw.split('\n');
  const out = [];
  let inFence = false;
  for (const line of lines) {
    if (/^\s*(```|~~~)/.test(line)) inFence = !inFence;
    const m = !inFence && line.match(IMPORT_RE);
    if (m) {
      let spec = m[1];
      if (spec.startsWith('~/')) spec = path.join(process.env.HOME, spec.slice(2));
      const resolved = path.isAbsolute(spec) ? spec : path.resolve(path.dirname(real), spec);
      if (!exists(resolved)) { out.push(`<!-- flatten: import target missing: ${resolved} -->`); continue; }
      if (depth >= MAX_IMPORT_DEPTH) { out.push(`<!-- flatten: import depth limit at ${resolved} -->`); continue; }
      out.push(`<!-- flatten: begin import ${resolved} (from ${real}) -->`);
      out.push(expand(resolved, seen, depth + 1, sources));
      out.push(`<!-- flatten: end import ${resolved} -->`);
      continue;
    }
    out.push(line);
  }
  return out.join('\n');
}

function build(repoDir) {
  const abs = fs.realpathSync(repoDir);
  const rel = path.relative(path.dirname(fs.realpathSync(WORKSPACE_ROOT)), abs);
  let slug = (!rel || rel.startsWith('..')) ? path.basename(abs) : rel.replace(/[\/]/g, '-');
  if (LEVELS === 'repo') slug += '-repolevel';
  const levels = levelChain(abs);
  const seen = new Set();
  const sources = [];
  const chunks = [];

  for (const lvl of levels) {
    const files = levelFiles(lvl);
    if (!files.length) continue;
    const label = lvl === fs.realpathSync(WORKSPACE_ROOT) ? 'WORKSPACE' : (lvl === abs ? 'REPOSITORY' : 'INTERMEDIATE');
    chunks.push(`\n\n<!-- ===== ${label} LEVEL: ${lvl} ===== -->\n`);
    for (const f of files) {
      chunks.push(`\n<!-- ----- source: ${f} ----- -->\n`);
      chunks.push(expand(f, seen, 0, sources));
    }
  }

  const body = chunks.join('\n');
  const bodyHash = crypto.createHash('sha256').update(body).digest('hex');

  const header = `<!-- GENERATED FILE — DO NOT EDIT. Produced by /Users/jowolff/.claude/orchestrator/tools/flatten-rules.mjs -->
# Effective repository rules — ${abs}

**This file is generated.** It is the flattened, import-resolved, de-duplicated rules chain for
\`${abs}\`, assembled because \`@import\` does not resolve for a directory supplied via
\`--add-dir\`, and because an added directory is not walked up to its workspace root. Edit the
source files listed at the bottom, never this file.

**Precedence, and it is load-bearing.** The sections below run from least specific to most
specific. Where two sections conflict, **the later section wins**: a \`REPOSITORY LEVEL\` rule
overrides a \`WORKSPACE LEVEL\` rule on the same subject. Nothing here overrides the user-level
\`/Users/jowolff/.claude/CLAUDE.md\`, which the session loads separately and which stays above all
of this.

Generated ${new Date().toISOString()} from ${sources.length} source files.
`;

  const footer = `

<!-- ===== END OF FLATTENED RULES ===== -->

## Provenance of this generated file

| source | bytes | sha256:16 |
| --- | ---: | --- |
${sources.map(s => `| \`${s.path}\` | ${s.bytes} | \`${s.sha256}\` |`).join('\n')}

**FLATTEN-INTEGRITY-MARKER ${bodyHash.slice(0, 12)}** — an agent that can quote this marker has
received this file to its final byte. An agent that cannot has received a truncated copy, or none.

If the sources above have changed since generation, this file is stale. Regenerate with:
\`node /Users/jowolff/.claude/orchestrator/tools/flatten-rules.mjs ${abs}\`
`;

  return { slug, abs, sources, body, text: header + body + footer, bodyHash };
}

const results = [];
for (const t of targets) {
  const built = build(t);
  const outDir = path.join(OUT_ROOT, built.slug);
  const outFile = path.join(outDir, '.claude', 'rules', `00-${built.slug}-rules.md`);
  const manifestFile = path.join(outDir, 'manifest.json');

  if (CHECK) {
    const prev = readIf(manifestFile);
    if (!prev) { results.push({ repo: built.abs, status: 'MISSING', outFile }); continue; }
    const m = JSON.parse(prev);
    const stale = m.sources.length !== built.sources.length ||
      m.sources.some((s, i) => s.path !== built.sources[i].path || s.sha256 !== built.sources[i].sha256);
    const onDisk = readIf(outFile);
    results.push({ repo: built.abs, status: (!onDisk ? 'MISSING' : stale ? 'STALE' : 'CURRENT'), outFile,
      generatedAt: m.generatedAt,
      changed: stale ? built.sources.filter((s, i) => !m.sources[i] || m.sources[i].sha256 !== s.sha256).map(s => s.path) : [] });
    continue;
  }

  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, built.text);
  // Build artifacts: keep them out of any git repo that happens to contain OUT_ROOT.
  fs.writeFileSync(path.join(OUT_ROOT, '.gitignore'), '*\n');
  fs.writeFileSync(manifestFile, JSON.stringify({
    repo: built.abs, generatedAt: new Date().toISOString(), outFile,
    bytes: Buffer.byteLength(built.text, 'utf8'), bodyHash: built.bodyHash,
    integrityMarker: built.bodyHash.slice(0, 12), sources: built.sources,
  }, null, 2) + '\n');
  results.push({ repo: built.abs, status: 'WROTE', outFile, bytes: Buffer.byteLength(built.text, 'utf8'),
    sources: built.sources.length, integrityMarker: built.bodyHash.slice(0, 12), addDir: outDir });
}

if (JSON_OUT) console.log(JSON.stringify(results, null, 2));
else for (const r of results) console.log(`${r.status.padEnd(8)} ${r.repo}\n         -> ${r.outFile}${r.bytes ? ` (${r.bytes} bytes, ${r.sources} sources, marker ${r.integrityMarker})` : ''}${r.changed && r.changed.length ? `\n         changed: ${r.changed.join(', ')}` : ''}`);

if (CHECK && results.some(r => r.status !== 'CURRENT')) process.exit(2);

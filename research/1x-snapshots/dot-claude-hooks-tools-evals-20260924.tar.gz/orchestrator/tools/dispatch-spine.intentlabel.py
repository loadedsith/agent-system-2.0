#!/usr/bin/env python3
"""dispatch-spine.py — the dispatch record, GENERATED from the harness transcripts.

WHY THIS EXISTS. The hand-written dispatch ledger stopped recording on 2026-08-22 and nobody
noticed for two days. That is not carelessness: `state/tools/dispatch-contract.sh` states the rule
this file obeys — "Only fields no other record can produce are worth typing" — and the old ledger
was mostly fields another record CAN produce. The three fields that were declared, written for
early rows, then abandoned (`tokens`, `tool_uses`, `cost_usd`) are precisely the derivable ones.
The fields people stop typing are the ones the machine already knows.

IT REGENERATES, IT NEVER ACCUMULATES. Output goes to stdout. There is no append mode and no state
file, deliberately: a generated record that is appended to by hand is a hand-written record with
extra steps, and it diverges the same way the last one did.

IT WRITES NOTHING ANYWHERE. It reads transcripts and prints. The seat that maintains it may not
write under state/, and the design is better for it — the caller decides where output belongs.

NO JUDGMENT FIELDS, AND NO PLACEHOLDERS FOR THEM. Whether a result stood, what friction there was,
how many times a human intervened — none of that is in a transcript and none of it is invented
here. A column that would be filled for thirty rows and abandoned is the defect this replaces.

TWO CHANNELS, KEPT DISTINGUISHABLE. A subagent is dispatched with a `Task`/`Agent` call; a
persistent seat is dispatched with a `SendMessage`. Until 2026-08-25 only the first was read, so
seat-level work was indistinguishable from work never sent, and `--check` warned every turn about
runs that HAD been sent. Both are now read, and every row carries a `channel` field saying which
one it came from -- because a `Task` row is evidence a subagent was spawned, while a `SendMessage`
row is only evidence a message naming the run id was sent. Those are different claims and the
record must not flatten them into one.

TWO STORES, BECAUSE THE HARNESS CHANGED UNDER IT. This read only `~/.claude/projects` until
2026-09-16, which is the Claude Code transcript store. This machine now runs OMP, which writes to
`~/.omp/agent/sessions/<encoded-cwd>/` and `~/.omp/agent/seat-sessions/<seat>/`. Measured that day:
zero files under the Claude Code store had been touched, three under OMP's had. The instrument was
not intermittently wrong, it was structurally blind. Both stores are read now — the historical rows
predate the cutover and must not vanish — and OMP's own tool names (`task`, `seat_message`) are
mapped onto the same two channels as the Claude Code names (`Task`/`Agent`, `SendMessage`).

Exit codes: 0 ok | 1 --check found no dispatch for the run id | 2 could not run.
"""

import argparse, json, os, re, sys, glob

PROJECTS = os.path.expanduser("~/.claude/projects")
OMP_SESSIONS = os.path.expanduser("~/.omp/agent/sessions")
OMP_SEAT_SESSIONS = os.path.expanduser("~/.omp/agent/seat-sessions")

# Every store known to have held this machine's transcripts, oldest first. A default root that does
# not exist is skipped rather than fatal: the point of listing a retired harness's store is that it
# may already be gone, while an explicit `--root` that does not exist is still a typo worth dying
# on.
DEFAULT_ROOTS = (PROJECTS, OMP_SESSIONS, OMP_SEAT_SESSIONS)


def die(msg):
    sys.stderr.write("dispatch-spine: CANNOT RUN — %s\n" % msg)
    sys.exit(2)


# The two dispatch channels this reads, and why there are two.
#
# `Task`/`Agent` is how a SUBAGENT is dispatched. `SendMessage` is how a persistent SEAT is
# dispatched -- a cross-session message, not a tool call that spawns anything. This tool read only
# the first channel until 2026-08-25, which made every seat-level dispatch indistinguishable from
# a run that never happened, and made `--check` warn about runs that had in fact been sent.
#
# The channel is recorded on every row rather than flattened away, because the two are NOT the
# same claim. A `Task` row is evidence a subagent was spawned. A `SendMessage` row is evidence a
# message naming the run id was SENT to a seat -- it is not evidence the seat did the work, and
# the same call carries briefs, replies, corrections and acknowledgements with nothing structural
# separating them. Keeping the channel visible is what stops a reader reading the second as the
# first.
#
# The channel is NOT the tool name, and this matters since the harness cutover. Claude Code called
# them `Task`/`Agent` and `SendMessage`; OMP calls them `task` and `seat_message`. Two vocabularies,
# one pair of channels, and the CHANNEL_* values below deliberately do not move when the vocabulary
# does -- a reader asking "was a subagent spawned or was mail sent" is asking about the channel.
CHANNEL_TASK = "task-agent"
CHANNEL_MESSAGE = "sendmessage"


def _text(v):
    """A transcript field is only usable as text if it IS text. Anything else is treated as
    absent rather than coerced: str(dict) would put brace-noise into the run-id regex's input."""
    return v if isinstance(v, str) else ""


CC_SPAWN = ("Task", "Agent")
CC_MESSAGE = ("SendMessage",)
OMP_SPAWN = ("task",)
OMP_MESSAGE = ("seat_message",)

# A line is parsed only if it looks like a tool call AND mentions a dispatch tool by name. Both
# halves are required: `"task"` alone appears in ordinary prose and in OMP's `session_init`
# records, and matching on it alone would parse most of the corpus for nothing.
_PREFILTER_SHAPE = ('"tool_use"', '"toolCall"')
_PREFILTER_NAME = ('"Task"', '"Agent"', '"SendMessage"', '"task"', '"seat_message"')


def _cc_rows(rec):
    """Claude Code shape: a `tool_use` block under `message.content`, arguments under `input`.

    Field names confirmed against real transcript records, not guessed: a SendMessage input carries
    `to`/`recipient` (the seat's agent id), `summary` (a short subject line), `message` (the full
    body), and `content` (a TRUNCATED echo of the body, ending in an ellipsis). `message` is
    therefore the field to read for the body; `content` is a fallback only, since a run id past the
    truncation point is not in it.
    """
    msg = rec.get("message")
    content = msg.get("content") if isinstance(msg, dict) else None
    if not isinstance(content, list):
        return
    for c in content:
        if not isinstance(c, dict) or c.get("type") != "tool_use":
            continue
        name = c.get("name")
        i = c.get("input")
        if not isinstance(i, dict):
            i = {}
        if name in CC_MESSAGE:
            yield (CHANNEL_MESSAGE,
                   _text(i.get("to")) or _text(i.get("recipient")) or "unspecified",
                   _text(i.get("summary")).strip(),
                   _text(i.get("message")) or _text(i.get("content")))
        elif name in CC_SPAWN:
            yield (CHANNEL_TASK,
                   _text(i.get("subagent_type")) or "unspecified",
                   _text(i.get("description")).strip(),
                   _text(i.get("prompt")))


def _omp_rows(rec):
    """OMP shape: a `toolCall` block under `message.content`, arguments under `arguments`.

    Established from the records themselves rather than assumed from the Claude Code shape, which
    it does not match: the record type is `message`, the block type is `toolCall` (not `tool_use`),
    and the arguments live under `arguments` (not `input`). The block also carries `intent`, the
    one-line purpose the caller typed, which is the only per-call description OMP records.

    `seat_message` arguments are `target` (the seat) and `message` (the body) -- there is no
    `summary` field, so `intent` is what the description column gets.

    `task` arguments are `context` (shared brief for the whole batch) and `tasks`, a LIST whose
    entries each spawn one subagent with `agent` (the agent type), `name` (the label the subagent is
    addressed by) and `task` (its own brief). One call is therefore N dispatches, not one, and gets
    N rows.
    """
    if rec.get("type") != "message":
        return
    msg = rec.get("message")
    content = msg.get("content") if isinstance(msg, dict) else None
    if not isinstance(content, list):
        return
    for c in content:
        if not isinstance(c, dict) or c.get("type") != "toolCall":
            continue
        name = c.get("name")
        a = c.get("arguments")
        if not isinstance(a, dict):
            a = {}
        intent = _text(c.get("intent")).strip()
        if name in OMP_MESSAGE:
            yield (CHANNEL_MESSAGE,
                   _text(a.get("target")) or "unspecified",
                   intent,
                   _text(a.get("message")))
        elif name in OMP_SPAWN:
            batch = _text(a.get("context"))
            entries = a.get("tasks")
            if not isinstance(entries, list):
                continue
            for t in entries:
                if not isinstance(t, dict):
                    continue
                yield (CHANNEL_TASK,
                       _text(t.get("agent")) or "unspecified",
                       _text(t.get("name")).strip() or intent,
                       batch + "\n" + _text(t.get("task")))


_OMP_FILE_UUID = re.compile(r"_([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$")


def _identity(path, session_id):
    """Which session a row came from.

    Claude Code names the transcript file after the session id, so the basename IS the id. OMP names
    it `<timestamp>_<uuid>` and also states the id in a `session` record on the file's first lines.
    The record is preferred, because an OMP SUBAGENT transcript is `<session-dir>/<AgentName>.jsonl`
    -- named after the agent, not the session -- and carries its own id there.
    """
    if session_id:
        return session_id
    base = os.path.basename(path)
    if base.endswith(".jsonl"):
        base = base[:-6]
    m = _OMP_FILE_UUID.search(base)
    return m.group(1) if m else base


def harvest(roots):
    """Every dispatch tool-call record in every transcript under the given roots, in either harness
    format. Roots may overlap (one may contain another); each file is read once."""
    rows, files, unreadable = [], 0, 0
    seen = set()
    for root in roots:
        for path in glob.glob(os.path.join(root, "**", "*.jsonl"), recursive=True):
            if path in seen:
                continue
            seen.add(path)
            files += 1
            session_id, found = "", []
            try:
                with open(path, encoding="utf-8") as fh:
                    for line in fh:
                        if not session_id and '"session"' in line:
                            try:
                                rec = json.loads(line)
                            except json.JSONDecodeError:
                                rec = None
                            if isinstance(rec, dict) and rec.get("type") == "session":
                                session_id = _text(rec.get("id"))
                                continue
                        if not (any(s in line for s in _PREFILTER_SHAPE)
                                and any(n in line for n in _PREFILTER_NAME)):
                            continue
                        try:
                            rec = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        ts = (rec.get("timestamp") or "")[:19]
                        for channel, to, task, prompt in _cc_rows(rec):
                            found.append((ts, channel, to, task, prompt))
                        for channel, to, task, prompt in _omp_rows(rec):
                            found.append((ts, channel, to, task, prompt))
            except OSError:
                unreadable += 1
                continue
            session = _identity(path, session_id)
            for ts, channel, to, task, prompt in found:
                rows.append({
                    "ts": ts,
                    "dispatched_to": to,
                    "task": task,
                    "session": session,
                    "channel": channel,
                    "prompt": prompt,
                })
    rows.sort(key=lambda r: r["ts"])
    return rows, files, unreadable


# A run id is a literal identifier the dispatcher typed into the brief. Matching it is a substring
# search for a known string, NOT an inference about what a prompt means — the distinction that
# separates every mechanism that has worked on this machine from the ones that failed.
RUNID = re.compile(r"\b([a-z][a-z0-9-]*-\d{8})\b")


def run_ids(row):
    return set(RUNID.findall(row["prompt"])) | set(RUNID.findall(row["task"]))


POPULATION_HEAD = """\
## What this counts, and what it does not

**Counts:** every subagent-spawn and every seat-message tool call found in the harness transcripts
under the scanned roots — one row per dispatch actually issued, with the timestamp, the recipient,
the description, the session it was issued from, and the `channel` it came through. Two harness
vocabularies are read for the same two channels: Claude Code's `Task`/`Agent` and `SendMessage`,
and OMP's `task` and `seat_message`.

**One OMP `task` call can be several dispatches.** Its `tasks` argument is a batch, so a call that
spawns four subagents produces four rows — one per subagent, which is what was dispatched.

**⛔ THE TWO CHANNELS ARE NOT THE SAME CLAIM, AND `channel` IS THERE SO YOU CANNOT CONFUSE THEM.**
- `channel: task-agent` — a subagent was spawned. The row is evidence of a dispatch.
- `channel: sendmessage` — a message naming the run id was SENT to a persistent seat (Tinker,
  Sedge, Verge, Wren). This is the channel, not the tool: `SendMessage` and `seat_message` rows are
  both here. It is evidence the run id was *addressed*, not that a seat did the work.
  The same call carries briefs, replies, corrections and acknowledgements, and nothing structural
  separates them. **Do not read a `sendmessage` row as proof work was performed.**

**Snapshot measured 2026-08-25 across 1965 transcript files** (the corpus grows while you read it,
so treat these as a scale, not a constant): 1114 `Task`/`Agent` rows naming 144 distinct run ids,
and 643 `SendMessage` rows naming 109 distinct run ids. 37 of those 109 are also named in a
`Task`/`Agent` call; **72 run ids had seat-level dispatch evidence and nothing else.** Reading only
the first channel made those 72 indistinguishable from runs that never happened.

That snapshot predates the harness cutover and was measured against the Claude Code store alone.
OMP rows are additive to it, not a revision of it; rerun to get current numbers.

**Roughly a third of messages name a run id at all.** A message with no run id still produces a row
— it simply recovers no id. That is the honest shape: the tool reports what it saw, and an empty
`run_ids` on a `sendmessage` row means the sender did not name a run, not that nothing was sent.

**⛔ AND A MATCHED TOKEN IS NOT ALWAYS A RUN ID.** `RUNID` matches any `word-YYYYMMDD` shape, so a
backup filename (`BRIEF-BOILERPLATE.md.pre-evals-clause-20260824`), a model id, or a database
hostname can match. This is a property of the regex and predates the seat-message widening, but
message bodies quote filenames far more often than spawn briefs do, so the widening enlarges the
class. Measured 2026-08-25 on the 71 ids the widening added: 33 have a corroborating
`state/runs/<id>` directory, 5 are demonstrably a backup filename's suffix, and 16 carry the
`pre-` prefix that marks a backup rather than a run. **Read the added yield as roughly half real,
not as 71 recovered dispatches.** It does not affect `--check`, which asks about one named id.

**Does NOT count:** work done inline by the dispatcher itself. The retired hand-written ledger had
an open `dispatched_to` vocabulary that included values like `self (inline)`, which is not a tool
call and cannot appear here.

**⛔ So this population and the old ledger's are NOT the same, and the two numbers must not be
subtracted from each other.** They disagree in both directions: this misses inline work the ledger
counted, and the ledger missed dispatches this finds. Nobody has ever reconciled them, and a
difference between the counts is not a shortfall in either.

**No judgment fields.** Whether a result stood, what got in the way, how many times a human stepped
in — none of that is in a transcript, so none of it is here.
"""


def population(roots, files, sessions):
    """The population statement, with the numbers that actually decide it.

    The roots matter more than they look. Scanning every project on the machine yields the WHOLE
    FLEET's dispatches — seats included — where the retired ledger only ever held what one agent
    typed. Two runs with different roots answer different questions, so the roots are printed.
    Found by testing: an earlier draft stated the population in prose and omitted the one variable
    that changes it.
    """
    return (POPULATION_HEAD
            + "\n**Scanned roots** (change these and the answer changes):\n"
            + "".join("\n- `%s`" % r for r in roots)
            + "\n\n**%d transcript file(s) read; %d distinct session(s) issued dispatches.** "
              "This is every session on the machine, not one agent — seats and workers included, "
              "which is strictly broader than the hand-written ledger ever was.\n" % (files, sessions))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", action="append", default=[],
                    help="transcript root (repeatable). Default: every store in DEFAULT_ROOTS that "
                         "exists — ~/.claude/projects (Claude Code), ~/.omp/agent/sessions and "
                         "~/.omp/agent/seat-sessions (OMP)")
    ap.add_argument("--since", default="", help="YYYY-MM-DD, inclusive")
    ap.add_argument("--jsonl", action="store_true", help="rows only on stdout; population note to stderr")
    ap.add_argument("--check", default="", metavar="RUN-ID",
                    help="was anything dispatched for this run id? exit 1 and say so loudly if not")
    args = ap.parse_args()

    # An explicit --root that does not exist is a typo and fatal. A DEFAULT root that does not exist
    # is a harness this machine no longer runs, and skipping it is the point of listing it.
    roots = args.root or [r for r in DEFAULT_ROOTS if os.path.isdir(r)]
    if not roots:
        die("no transcript root exists. Looked for: %s" % ", ".join(DEFAULT_ROOTS))
    for r in roots:
        if not os.path.isdir(r):
            die("no such transcript root: %s" % r)

    rows, files, unreadable = harvest(roots)
    if args.since:
        rows = [r for r in rows if r["ts"][:10] >= args.since]

    # ---- the mode that exists because of a specific failure ----------------------------------
    # 2026-08-24: a build was reported to Jo as having its remaining decision be "activation" when
    # the build had never been dispatched, and nothing contradicted it because nothing was
    # recording. This answers that question directly and fails loudly, so catching it does not
    # depend on anyone thinking to look.
    if args.check:
        hits = [r for r in rows if args.check in run_ids(r) or args.check in r["prompt"]]
        if hits:
            print("DISPATCHED — %d dispatch(es) found for run id %r:" % (len(hits), args.check))
            for h in hits:
                print("  %s  %-24s %s" % (h["ts"], h["dispatched_to"], h["task"][:70]))
            return 0
        print("⛔ NO DISPATCH FOUND for run id %r." % args.check)
        print("")
        print("Nothing in %d transcript file(s) records a subagent-spawn or seat-message call"
              % files)
        print("naming it — not `Task`/`Agent` or `task`, not `SendMessage` or `seat_message`.")
        print("If someone has reported this run as under way, finished, or awaiting only a")
        print("decision, that report is not supported by the dispatch record.")
        print("")
        print("This is not proof the work did not happen — it proves nothing was DISPATCHED for")
        print("it, through either channel. Two blind spots remain and neither is closed here:")
        print("")
        print("  1. Inline work by the dispatcher leaves no tool call at all and cannot appear.")
        print("  2. A dispatch that never names the run id cannot be matched to it. Matching is a")
        print("     substring search for a literal identifier, not an inference about meaning.")
        return 1

    # ---- the spine ---------------------------------------------------------------------------
    if args.jsonl:
        sys.stderr.write(population(roots, files, len({r["session"] for r in rows})) + "\n")
        for r in rows:
            out = {k: v for k, v in r.items() if k != "prompt"}
            out["run_ids"] = sorted(run_ids(r))
            print(json.dumps(out, ensure_ascii=False))
        return 0

    by_day = {}
    for r in rows:
        by_day[r["ts"][:10]] = by_day.get(r["ts"][:10], 0) + 1

    print("# Dispatch spine — generated, not typed")
    print("")
    print("Generated from %d transcript file(s)%s. **Regenerate rather than edit: this file has no"
          % (files, "" if not unreadable else ", %d unreadable" % unreadable))
    print("authority, the transcripts do.**")
    print("")
    print(population(roots, files, len({r["session"] for r in rows})))
    print("## Dispatches by day")
    print("")
    for d in sorted(by_day):
        print("- **%s** — %d" % (d, by_day[d]))
    print("")
    print("**Total: %d.**" % len(rows))
    print("")
    print("## The dispatches")
    print("")
    print("| When | Channel | To | What | Run id | Session |")
    print("|---|---|---|---|---|---|")
    missing = 0
    for r in rows:
        ids = ", ".join(sorted(run_ids(r))) or "—"
        # ⛔ `(no description)` read to every future reader as a caller who could not be bothered,
        # and that false conclusion reached three durable records. The column is the toolCall
        # block's `intent` (see the docstring at the parser), which is populated ONLY from the
        # model's `i` argument — so an empty cell is a specific, nameable fact, and the cell says it.
        task = r["task"].replace("|", "\\|")[:70]
        if not task:
            missing += 1
            task = "(caller supplied no intent)"
        print("| %s | `%s` | `%s` | %s | %s | `%s` |"
              % (r["ts"], r["channel"], r["dispatched_to"], task, ids, r["session"][:8]))
    if missing:
        print("")
        print("⛔ **%d of %d rows carry no intent.** Measured 2026-09-16 in"
              " `pi-agent-core/src/agent-loop.ts`: `extractIntent` `:987-997` pulls `i` out of the"
              " arguments, `:2663` hands the STRIPPED args to the validator at `:2682`, and the"
              " tool's own schema never contained `i` — so a call that omits it is never rejected."
              " `resolveIntentMode` `:981-985` marks `i` required on the wire only, which advertises"
              " it to the model and enforces nothing. An empty cell therefore means the model did"
              " not emit `i` on that call. It does NOT mean the spine could not read it."
              % (missing, len(rows)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

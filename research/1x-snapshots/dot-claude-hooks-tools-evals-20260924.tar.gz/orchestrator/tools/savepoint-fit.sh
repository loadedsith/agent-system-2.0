#!/usr/bin/env zsh
# savepoint-fit — does the save point fit the injection budget, and if not, WHERE does it fall off?
#
# WHY THIS EXISTS. STANDUP.md is injected into the next session by
# /Users/jowolff/.claude/orchestrator/hooks/savepoint-restore.sh, which injects only the first
# LIMIT bytes and drops the rest. The Stop hook savepoint-guard.mjs already blocks on the overage
# and already reports it. What neither of them tells you is WHICH SECTION falls off the cliff, or
# how much of the file's weight is non-ASCII punctuation rather than words. Without those two
# facts the repair is edit-then-measure, repeatedly, and the estimate is made in characters while
# the budget is in bytes. This tool answers both in one shot so the next edit is informed.
#
# READ-ONLY. It never writes, trims, edits, or moves the file it inspects. The whole point of a
# save point is that someone decided the content was worth keeping; a tool that silently trimmed
# it would delete exactly that.
#
# EXIT: 0 when the file fits the budget, 1 when it does not (so it can gate a write), 2 on a
# usage/IO error.
#
# USAGE:
#   savepoint-fit.sh                 # inspect the live STANDUP.md
#   savepoint-fit.sh /path/draft.md  # inspect a draft BEFORE installing it over the live file
#
# WHY ZSH AND NOT NODE. Everything here is line splitting, byte counting and integer arithmetic.
# awk under LC_ALL=C counts bytes exactly; wc -m under a UTF-8 locale counts characters. No node.

set -u
emulate -L zsh
setopt pipefail

STATE="${LINTEL_STATE:-/Users/jowolff/.claude/orchestrator/state}"
HOOKS="${LINTEL_HOOKS:-/Users/jowolff/.claude/orchestrator/hooks}"
RESTORE="$HOOKS/savepoint-restore.sh"

# How many sections the trim plan names when the file is over budget.
TRIM_TOP=5

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  sed -n '2,28p' "$0"
  exit 2
fi

# --tsv (added 2026-08-20): machine-readable emission for savepoint-plan.sh, which needs the
# budget and the per-section byte table WITHOUT re-implementing either measurement. Purely
# additive: without the flag every byte of output below is unchanged. Reversal is to delete this
# block, the `(( TSV ))` stanza further down, and the two POINTER lines near the end.
TSV=0
if [[ "${1:-}" == "--tsv" ]]; then
  TSV=1
  shift
fi

TARGET="${1:-$STATE/STANDUP.md}"

if [[ ! -f "$TARGET" ]]; then
  print -u2 "savepoint-fit: not a readable file: $TARGET"
  exit 2
fi

# ---------------------------------------------------------------------------------------------
# BUDGET. Single source of truth is savepoint-restore.sh — the hook that actually performs the
# cut. Hardcoding the number here would be the same defect the guard hook already avoids: two
# files holding the same constant drift, and the drift is silent. The match order mirrors
# savepoint-guard.mjs injectionBudget() exactly: LIMIT=<n> first, then `head -c <n>`, because the
# boundary-cut version of the restore hook contains both.
# If the parse fails, the fallback still runs and SAYS SO in the output, so a line reading
# "built-in fallback" is itself the drift alarm rather than a quiet wrong answer.
# ---------------------------------------------------------------------------------------------
BUDGET_FALLBACK=6000
budget=""
budget_src=""
if [[ -n "${LINTEL_INJECTION_BUDGET:-}" ]] && [[ "$LINTEL_INJECTION_BUDGET" == <-> ]] \
   && (( LINTEL_INJECTION_BUDGET > 0 )); then
  budget="$LINTEL_INJECTION_BUDGET"
  budget_src="env LINTEL_INJECTION_BUDGET"
elif [[ -r "$RESTORE" ]]; then
  budget=$(LC_ALL=C /usr/bin/sed -n -E 's/^[[:space:]]*LIMIT=([0-9]+)[[:space:]]*$/\1/p' "$RESTORE" | head -1)
  if [[ -n "$budget" ]]; then
    budget_src="$RESTORE (LIMIT=)"
  else
    budget=$(LC_ALL=C /usr/bin/sed -n -E 's/.*head[[:space:]]+-c[[:space:]]+([0-9]+).*/\1/p' "$RESTORE" | head -1)
    [[ -n "$budget" ]] && budget_src="$RESTORE (head -c)"
  fi
fi
if [[ -z "$budget" ]]; then
  budget=$BUDGET_FALLBACK
  budget_src="built-in fallback -- could NOT read the limit out of $RESTORE"
fi

# ---------------------------------------------------------------------------------------------
# WHOLE-FILE MEASUREMENT.
# bytes: wc -c. chars: wc -m under a UTF-8 locale (under LC_ALL=C, wc -m returns bytes and the
# non-ASCII line would silently read zero, which is the exact trap this tool exists to expose).
# ---------------------------------------------------------------------------------------------
total_bytes=$(LC_ALL=C wc -c < "$TARGET" | tr -d ' ')
total_chars=$(LC_ALL=en_US.UTF-8 wc -m < "$TARGET" | tr -d ' ')
nonascii_overhead=$(( total_bytes - total_chars ))

# ---------------------------------------------------------------------------------------------
# PER-SECTION MEASUREMENT. One awk pass under LC_ALL=C, where length() is bytes.
# A section runs from a `## ` heading line to the line before the next `## ` heading. Content
# before the first heading is reported as (preamble) so the byte columns always sum to the file.
# Emits: start_offset \t bytes \t doc_order \t heading
# ---------------------------------------------------------------------------------------------
sections=$(LC_ALL=C /usr/bin/awk '
  function flush() {
    if (have) printf "%d\t%d\t%d\t%s\n", start, off - start, ord, name;
  }
  BEGIN { off = 0; have = 0; ord = 0; start = 0; name = "(preamble)"; have = 1; }
  {
    if ($0 ~ /^## /) {
      if (off > start || ord > 0) { flush(); ord++; } else { ord++; }   # skip an empty preamble
      start = off; name = $0; have = 1;
    }
    off += length($0) + 1;
  }
  END { flush(); print "@TOTAL@\t" off; }
' "$TARGET")

awk_total=$(print -r -- "$sections" | /usr/bin/grep '^@TOTAL@' | cut -f2)
sections=$(print -r -- "$sections" | /usr/bin/grep -v '^@TOTAL@')

# awk assumes a trailing newline on the final line. If the file has none, awk over-counts by 1;
# reconcile against wc -c rather than trusting either alone, and APPLY the correction to the last
# section in document order so the BYTES column still sums to the file. Announcing the delta
# without applying it -- which this did on first write -- leaves a table that disagrees with the
# verdict line by a byte, which is precisely the kind of off-by-a-little that started all this.
delta=$(( total_bytes - awk_total ))
if (( delta != 0 )); then
  sections=$(LC_ALL=C /usr/bin/awk -F'\t' -v d="$delta" '
    { line[NR] = $0; ord[NR] = $3 + 0; if (ord[NR] >= maxord) { maxord = ord[NR]; last = NR } }
    END { for (i = 1; i <= NR; i++) {
            if (i == last) { split(line[i], f, "\t"); printf "%s\t%d\t%s\t%s\n", f[1], f[2] + d, f[3], f[4] }
            else print line[i] } }
  ' <<< "$sections")
fi

# ---------------------------------------------------------------------------------------------
# TSV EMISSION. Stable columns, document order preserved for sections. Consumed by
# savepoint-plan.sh. Exits before any human-facing output so a parser never sees prose.
# ---------------------------------------------------------------------------------------------
if (( TSV )); then
  printf 'budget\t%d\n' "$budget"
  printf 'total\t%d\n' "$total_bytes"
  printf 'chars\t%d\n' "$total_chars"
  print -r -- "$sections" | LC_ALL=C /usr/bin/awk -F'\t' \
    '{ printf "section\t%d\t%d\t%s\n", $2, $1 + $2, $4 }'
  (( total_bytes <= budget )) && exit 0
  exit 1
fi

# ---------------------------------------------------------------------------------------------
# VERDICT FIRST. This is the line the reader acts on, so nothing precedes it.
# ---------------------------------------------------------------------------------------------
if (( total_bytes <= budget )); then
  print -r -- "FITS: ${total_bytes} bytes, $(( budget - total_bytes )) to spare"
  fits=1
else
  print -r -- "OVER BY $(( total_bytes - budget )) bytes"
  fits=0
fi

print -r -- ""
print -r -- "file:   $TARGET"
print -r -- "budget: ${budget} bytes  [source: ${budget_src}]"
if (( delta != 0 )); then
  print -r -- "note:   no trailing newline; last section adjusted by ${delta} byte(s)"
fi
print -r -- ""

# ---------------------------------------------------------------------------------------------
# SECTION TABLE. Sorted largest first, because that is where the trimming budget is.
# ENDS-AT is the cumulative byte offset in DOCUMENT order at which that section finishes -- the
# running total. Sorting by size and cumulating by size would produce a meaningless number, so the
# cumulative column stays anchored to document order and the row that crosses the budget is
# marked. That marked row is the section that falls off the cliff.
#
# The installed restore hook cuts at the last `## ` boundary AT OR BEFORE the limit, so the marked
# section is not partially injected -- it is dropped whole, along with everything after it.
# ---------------------------------------------------------------------------------------------
n_sections=$(print -r -- "$sections" | /usr/bin/grep -c . )
print -r -- "SECTIONS (${n_sections}), largest first. ENDS-AT is the running total in document order."
print -r -- ""
printf '%8s  %8s  %s\n' 'BYTES' 'ENDS-AT' 'SECTION'
printf '%8s  %8s  %s\n' '--------' '--------' '------------------------------------------------'

cliff_name=""
cliff_end=0
while IFS=$'\t' read -r s_start s_bytes s_ord s_name; do
  [[ -z "${s_start:-}" ]] && continue
  s_end=$(( s_start + s_bytes ))
  mark=""
  if (( s_end > budget && s_start < budget )); then
    mark="   <-- FALLS OFF THE CLIFF (this section straddles the ${budget}-byte limit)"
    cliff_name="$s_name"; cliff_end=$s_end
  elif (( s_start >= budget )); then
    mark="   <-- entirely past the limit"
  fi
  printf '%8d  %8d  %s%s\n' "$s_bytes" "$s_end" "$s_name" "$mark"
done < <(print -r -- "$sections" | LC_ALL=C sort -t$'\t' -k2,2nr -k3,3n)

print -r -- ""

# ---------------------------------------------------------------------------------------------
# NON-ASCII COST. bytes - characters. Every em dash, arrow and typographic quote is 2 extra bytes
# it does not look like it costs. Estimating this file in characters is how an edit lands "just
# barely over" and the loop starts again.
# ---------------------------------------------------------------------------------------------
printf 'NON-ASCII COST: %d bytes of overhead (%d bytes / %d characters).\n' \
  "$nonascii_overhead" "$total_bytes" "$total_chars"
if (( nonascii_overhead > 0 )); then
  pct=$(( (nonascii_overhead * 1000 + total_bytes / 2) / total_bytes ))
  printf '  A character count would read %d bytes light -- %d.%d%% of the file.\n' \
    "$nonascii_overhead" "$(( pct / 10 ))" "$(( pct % 10 ))"
fi

if (( fits == 1 )); then
  print -r -- ""
  print -r -- "Nothing is dropped at or under ${budget} bytes."
  # POINTER (added 2026-08-20). "FITS" at 5,99x is the measured pathology, not a pass: of the 162
  # commits that touched STANDUP.md on 2026-08-20, 29 landed within 25 bytes of the ceiling and
  # the very next edit tipped 25 of them back over. This tool exits early on FITS and says
  # nothing about headroom, so the state that starts the loop reads as success.
  headroom=$(( budget - total_bytes ))
  if (( headroom < 600 )); then
    print -r -- ""
    print -r -- "HEADROOM WARNING: only ${headroom} bytes spare. One added sentence puts this over."
    print -r -- "Per-section caps against a 5400-byte target:"
    print -r -- "  zsh ${0:A:h}/savepoint-plan.sh $TARGET"
  fi
  exit 0
fi

# ---------------------------------------------------------------------------------------------
# TRIM PLAN. Only when over budget. The deficit is split across the ${TRIM_TOP} largest sections
# in PROPORTION to their size, rounded up, so the per-section targets are derived by a stated rule
# rather than invented. Cutting any other combination summing to the deficit works equally well;
# this is a starting allocation, not a prescription.
# ---------------------------------------------------------------------------------------------
need=$(( total_bytes - budget ))
print -r -- ""
print -r -- "TRIM PLAN -- ${need} bytes must go."
if [[ -n "$cliff_name" ]]; then
  print -r -- "Everything from \"${cliff_name}\" onward is what disappears today."
fi
print -r -- "Allocation below splits ${need} bytes across the ${TRIM_TOP} largest sections in"
print -r -- "proportion to their size. Any other combination summing to ${need} works too."
print -r -- ""
printf '%8s  %8s  %s\n' 'SIZE' 'LOSE' 'SECTION'
printf '%8s  %8s  %s\n' '--------' '--------' '------------------------------------------------'

top=$(print -r -- "$sections" | LC_ALL=C sort -t$'\t' -k2,2nr -k3,3n | head -${TRIM_TOP})
top_sum=$(print -r -- "$top" | LC_ALL=C /usr/bin/awk -F'\t' '{s+=$2} END {print s+0}')
LC_ALL=C /usr/bin/awk -F'\t' -v need="$need" -v tot="$top_sum" '
  { share = int((need * $2 + tot - 1) / tot); if (share > $2) share = $2;
    printf "%8d  %8d  %s\n", $2, share, $4 }
' <<< "$top"

print -r -- ""
print -r -- ""
# POINTER (added 2026-08-20). This branch's stdout is what savepoint-fit-stop.mjs pastes into its
# Stop-hook block reason, so it is the one channel that provably reaches the author at the exact
# moment the edit-then-measure loop would otherwise start. Measured on 2026-08-20: 14 separate
# runs of >=2 consecutive shrinking oversize commits, covering 82 of the day's 162 commits. The
# longest ran 13 commits, 18761 bytes down to 6013.
print -r -- "STOP TRIMMING. Rewrite in one pass against per-section caps instead:"
print -r -- "  zsh ${0:A:h}/savepoint-plan.sh --skeleton"
print -r -- "Iterative trimming did not converge 14 times today. A one-pass rewrite did."
print -r -- ""
print -r -- "Re-run this against the draft before installing it. Nothing here modified $TARGET."
exit 1

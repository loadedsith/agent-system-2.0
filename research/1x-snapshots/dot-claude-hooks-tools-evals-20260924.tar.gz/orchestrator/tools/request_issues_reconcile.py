#!/usr/bin/env python3
"""Reconcile applicable request-ledger rows with a private GitHub issue tracker."""

from __future__ import annotations

import argparse
import dataclasses
import json
import os
import pathlib
import re
import subprocess
import sys
import time
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

REQUEST_KEY_RE = re.compile(r"(?<![A-Z0-9-])REQ-[0-9]+(?![0-9])", re.IGNORECASE)
LEDGER_ROW_RE = re.compile(
    r"(?im)^[ \t]*Ledger row:[ \t]*(REQ-[0-9]+)(?![0-9])"
)
NONTERMINAL_STATES = frozenset({"open", "partial", "blocked"})
TERMINAL_STATES = frozenset({"delivered", "dropped", "deferred"})
VALID_STATES = NONTERMINAL_STATES | TERMINAL_STATES
FETCH_COMPLETENESS_ATTEMPTS = 4
FETCH_RETRY_SECONDS = 1.0

MACHINERY_MARKERS = (
    "machinery",
    "managerial agent",
    "rules-injection",
    "agents.md",
    "/users/jowolff/.claude",
    "~/.claude",
    ".omp",
    "herdr",
    "requests.jsonl",
    "request ledger",
    "inbox row",
    "savepoint",
    "save-point",
    "output-types",
    "dispatcher",
    "disposable hand",
    "seat",
    "deputy",
    "resident agent",
    "session hook",
    "claude hook",
    "plugin agent",
    "agent skill",
    "harness",
    "fleet",
)
MACHINERY_ACTORS = ("lintel", "tinker", "orchestrator")
PRODUCT_SUBJECT_MARKERS = (
    "newdle-web",
    "newdle-api",
    "newdle-mastra",
    "newdle-mobile",
    "data-pipelines",
    "jdwolff-com",
    "kitchen editor",
    "creator studio",
    "/studio",
    "resend marketing",
    "data-viz",
    "data visualization",
)
PRODUCT_OWNERSHIP_MARKERS = (
    "product repository",
    "owned by the newdle-web",
    "owned by the newdle-api",
    "owned by the kitchen",
    "api repository work",
    "kitchen repository",
)


class ReconciliationError(RuntimeError):
    """The ledger or GitHub response cannot be reconciled safely."""


@dataclasses.dataclass(frozen=True)
class InventoryItem:
    request_id: str
    state: str
    subject: str
    applicable: bool
    reason: str
    action: str
    canonical_url: str | None
    issue_number: int | None
    all_urls: tuple[str, ...]
    candidate_urls: tuple[str, ...]
    row: Mapping[str, Any]


def _row_text(row: Mapping[str, Any]) -> str:
    touches = row.get("touches")
    touch_text = ""
    if isinstance(touches, list):
        touch_text = " ".join(
            str(touch.get("text", ""))
            for touch in touches
            if isinstance(touch, Mapping)
        )
    return " ".join(
        (
            str(row.get("request", "")),
            str(row.get("note", "")),
            touch_text,
        )
    ).lower()


def classify_row(row: Mapping[str, Any]) -> tuple[bool, str]:
    """Return whether a request belongs on Lintel's machinery tracker and why.

    Explicit machinery in the request subject wins over product markers, so work
    that changes a seat or harness while mentioning a product repository remains
    machinery. Product-surface subjects otherwise win over machinery words in
    notes or touches, because provenance about the hand that handled product work
    does not recategorize the product work itself. Explicit ownership language
    may occur anywhere. Other internal-ledger rows remain applicable.
    """

    text = _row_text(row)
    subject = str(row.get("request", "")).lower()
    subject_is_machinery = any(
        marker in subject for marker in MACHINERY_MARKERS + MACHINERY_ACTORS
    )
    if subject_is_machinery:
        return True, "machinery"
    if any(marker in subject for marker in PRODUCT_SUBJECT_MARKERS):
        return False, "product-owned"
    if any(marker in text for marker in PRODUCT_OWNERSHIP_MARKERS):
        return False, "product-owned"
    if any(marker in text for marker in MACHINERY_MARKERS):
        return True, "machinery"
    return True, "internal-default"


def issue_candidate_keys(issue: Mapping[str, Any]) -> set[str]:
    """Extract every complete request identifier from title and body."""

    title = issue.get("title")
    body = issue.get("body")
    haystack = " ".join(value for value in (title, body) if isinstance(value, str))
    return {match.group(0).upper() for match in REQUEST_KEY_RE.finditer(haystack)}


def issue_join_keys(issue: Mapping[str, Any]) -> set[str]:
    """Extract canonical request identifiers from the title and ledger marker.

    Searching remains broad through ``issue_candidate_keys``. Canonical joins reject
    incidental references such as supersession notes for a different request.
    """

    title = issue.get("title")
    body = issue.get("body")
    title_keys = (
        {match.group(0).upper() for match in REQUEST_KEY_RE.finditer(title)}
        if isinstance(title, str)
        else set()
    )
    marker_keys = (
        {match.group(1).upper() for match in LEDGER_ROW_RE.finditer(body)}
        if isinstance(body, str)
        else set()
    )
    return title_keys | marker_keys


def validate_issue(
    issue: Mapping[str, Any], repo: str, expected_key: str | None = None
) -> None:
    """Validate every GitHub response field used for reconciliation."""

    if not isinstance(issue, Mapping):
        raise ReconciliationError("GitHub issue response is not an object")
    number = issue.get("number")
    if isinstance(number, bool) or not isinstance(number, int) or number <= 0:
        raise ReconciliationError("GitHub issue number is not a positive integer")
    state = issue.get("state")
    if state not in {"open", "closed"}:
        raise ReconciliationError(f"GitHub issue #{number} has invalid state {state!r}")
    title = issue.get("title")
    if not isinstance(title, str) or not title.strip():
        raise ReconciliationError(f"GitHub issue #{number} has an invalid title")
    body = issue.get("body")
    if not isinstance(body, str):
        raise ReconciliationError(f"GitHub issue #{number} has an invalid body")
    expected_url = f"https://github.com/{repo}/issues/{number}"
    if issue.get("html_url") != expected_url:
        raise ReconciliationError(
            f"GitHub issue #{number} URL is not the expected repository URL"
        )
    if expected_key is not None and expected_key not in issue_join_keys(issue):
        raise ReconciliationError(
            f"GitHub issue #{number} does not contain expected join key {expected_key}"
        )


def _validated_row(row: Mapping[str, Any]) -> Mapping[str, Any]:
    request_id = row.get("id")
    state = row.get("state")
    request = row.get("request")
    if not isinstance(request_id, str) or not re.fullmatch(r"REQ-[0-9]+", request_id):
        raise ReconciliationError(f"invalid request id {request_id!r}")
    if state not in VALID_STATES:
        raise ReconciliationError(f"{request_id} has invalid state {state!r}")
    if not isinstance(request, str) or not request.strip():
        raise ReconciliationError(f"{request_id} has an invalid request subject")
    return row

def canonical_issue_touch_url(
    row: Mapping[str, Any], repo: str
) -> str | None:
    """Return an exact target-repository issue touch, ignoring unrelated touches."""

    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo):
        raise ReconciliationError(f"invalid GitHub repository {repo!r}")
    touches = row.get("touches")
    if not isinstance(touches, list):
        return None
    pattern = re.compile(
        rf"https://github\.com/{re.escape(repo)}/issues/([1-9][0-9]*)"
    )
    for touch in touches:
        if not isinstance(touch, Mapping):
            continue
        text = touch.get("text")
        if isinstance(text, str) and pattern.fullmatch(text):
            return text
    return None


def pending_hand_reconciliation_ids(
    rows: Sequence[Mapping[str, Any]], repo: str
) -> list[str]:
    """List applicable non-terminal rows that still need a disposable-hand join."""

    pending: list[str] = []
    seen: set[str] = set()
    for raw_row in rows:
        row = _validated_row(raw_row)
        request_id = str(row["id"])
        if request_id in seen:
            raise ReconciliationError(f"duplicate ledger row {request_id}")
        seen.add(request_id)
        applicable, _ = classify_row(row)
        if (
            row["state"] in NONTERMINAL_STATES
            and applicable
            and canonical_issue_touch_url(row, repo) is None
        ):
            pending.append(request_id)
    return pending



def plan_inventory(
    rows: Sequence[Mapping[str, Any]],
    issues: Sequence[Mapping[str, Any]],
    repo: str,
) -> list[InventoryItem]:
    """Plan a deterministic reconciliation without mutating GitHub or the ledger."""

    by_key: dict[str, list[Mapping[str, Any]]] = {}
    by_candidate_key: dict[str, list[Mapping[str, Any]]] = {}
    for issue in issues:
        if "pull_request" in issue:
            continue
        validate_issue(issue, repo)
        for key in issue_join_keys(issue):
            by_key.setdefault(key, []).append(issue)
        for key in issue_candidate_keys(issue):
            by_candidate_key.setdefault(key, []).append(issue)

    seen_rows: set[str] = set()
    inventory: list[InventoryItem] = []
    for raw_row in rows:
        row = _validated_row(raw_row)
        request_id = str(row["id"])
        if request_id in seen_rows:
            raise ReconciliationError(f"duplicate ledger row {request_id}")
        seen_rows.add(request_id)
        if row["state"] not in NONTERMINAL_STATES:
            continue

        applicable, reason = classify_row(row)
        matches = by_key.get(request_id, [])
        candidates = by_candidate_key.get(request_id, [])
        open_matches = [issue for issue in matches if issue["state"] == "open"]
        closed_matches = [issue for issue in matches if issue["state"] == "closed"]
        if len(open_matches) > 1:
            numbers = ", ".join(f"#{issue['number']}" for issue in open_matches)
            raise ReconciliationError(
                f"{request_id} has multiple open issues ({numbers}); refusing an ambiguous join"
            )

        action: str
        canonical: Mapping[str, Any] | None
        if not applicable:
            action = "skip"
            canonical = open_matches[0] if open_matches else None
        elif open_matches:
            action = "reuse-open"
            canonical = open_matches[0]
        elif len(closed_matches) == 1:
            action = "reopen"
            canonical = closed_matches[0]
        elif len(closed_matches) > 1:
            numbers = ", ".join(f"#{issue['number']}" for issue in closed_matches)
            raise ReconciliationError(
                f"{request_id} has multiple closed issues ({numbers}); refusing an ambiguous join"
            )
        else:
            action = "create"
            canonical = None

        ordered_matches = sorted(matches, key=lambda issue: int(issue["number"]))
        ordered_candidates = sorted(candidates, key=lambda issue: int(issue["number"]))
        inventory.append(
            InventoryItem(
                request_id=request_id,
                state=str(row["state"]),
                subject=str(row["request"]),
                applicable=applicable,
                reason=reason,
                action=action,
                canonical_url=(
                    str(canonical["html_url"]) if canonical is not None else None
                ),
                issue_number=(int(canonical["number"]) if canonical is not None else None),
                all_urls=tuple(str(issue["html_url"]) for issue in ordered_matches),
                candidate_urls=tuple(
                    str(issue["html_url"]) for issue in ordered_candidates
                ),
                row=row,
            )
        )
    return inventory


def _touch_context(row: Mapping[str, Any]) -> list[str]:
    touches = row.get("touches")
    if not isinstance(touches, list):
        return []
    result: list[str] = []
    for touch in touches:
        if not isinstance(touch, Mapping):
            continue
        touch_type = touch.get("type")
        text = touch.get("text")
        if isinstance(touch_type, str) and isinstance(text, str) and text.strip():
            result.append(f"- {touch_type}: {text.strip()}")
    return result


def _acceptance_criteria(row: Mapping[str, Any]) -> list[str]:
    note = row.get("note")
    criteria: list[str] = []
    if isinstance(note, str) and note.strip():
        normalized = note.strip()
        done_match = re.search(r"(?:done when|acceptance(?: criteria)?):\s*(.+)", normalized, re.I)
        if done_match:
            criteria.append(done_match.group(1).strip())
        else:
            criteria.append(normalized)
    if not criteria:
        criteria.append(f"Complete the request: {str(row['request']).strip()}")
    criteria.append("Verify the completed behavior with a targeted check or direct observation.")
    criteria.append(
        "Record the resulting terminal state in the authoritative local request ledger."
    )
    return criteria


def issue_title(row: Mapping[str, Any]) -> str:
    subject = " ".join(str(row["request"]).split())
    title = f"{row['id']}: {subject}"
    if len(title) <= 240:
        return title
    return title[:237].rstrip() + "..."


def issue_body(row: Mapping[str, Any], ledger_path: pathlib.Path) -> str:
    _validated_row(row)
    touches = _touch_context(row)
    context_lines = touches or ["- No additional context was recorded on the ledger row."]
    criteria = _acceptance_criteria(row)
    timestamp = row.get("ts") if isinstance(row.get("ts"), str) else "not recorded"
    return "\n".join(
        [
            f"Ledger row: {row['id']}",
            "",
            "## Subject",
            str(row["request"]).strip(),
            "",
            "## Current state",
            f"`{row['state']}` as recorded at `{timestamp}`.",
            "",
            "## Context",
            *context_lines,
            "",
            "## Acceptance criteria",
            *(f"- {criterion}" for criterion in criteria),
            "",
            "## Provenance and authority",
            f"Source: `{ledger_path}` ({row['id']}).",
            "",
            "The local request ledger is authoritative. This GitHub issue is a reconciled execution surface; update the ledger when the request state changes.",
            "",
        ]
    )


def _run_gh(args: Sequence[str], token: str) -> Any:
    env = os.environ.copy()
    env["GH_TOKEN"] = token
    completed = subprocess.run(
        ["gh", *args],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise ReconciliationError(
            f"gh {' '.join(args)} failed with exit {completed.returncode}: {detail}"
        )
    try:
        return json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise ReconciliationError("GitHub returned invalid JSON") from exc


def fetch_all_issues(repo: str, token: str) -> list[Mapping[str, Any]]:
    mismatch = ""
    for attempt in range(FETCH_COMPLETENESS_ATTEMPTS):
        pages = _run_gh(
            [
                "api",
                f"repos/{repo}/issues?state=all&per_page=100",
                "--paginate",
                "--slurp",
            ],
            token,
        )
        if not isinstance(pages, list) or any(
            not isinstance(page, list) for page in pages
        ):
            raise ReconciliationError("paginated GitHub response is not a list of pages")
        raw_issues = [issue for page in pages for issue in page]
        if any(not isinstance(issue, Mapping) for issue in raw_issues):
            raise ReconciliationError(
                "paginated GitHub response contains a non-object"
            )

        repo_state = _run_gh(["api", f"repos/{repo}"], token)
        if not isinstance(repo_state, Mapping):
            raise ReconciliationError("GitHub repository response is not an object")
        open_count = repo_state.get("open_issues_count")
        if (
            isinstance(open_count, bool)
            or not isinstance(open_count, int)
            or open_count < 0
        ):
            raise ReconciliationError("GitHub repository open issue count is invalid")
        listed_open_count = sum(issue.get("state") == "open" for issue in raw_issues)
        if listed_open_count == open_count:
            return list(raw_issues)

        mismatch = (
            f"listed {listed_open_count} open issues but repository reports "
            f"{open_count}"
        )
        if attempt + 1 < FETCH_COMPLETENESS_ATTEMPTS:
            time.sleep(FETCH_RETRY_SECONDS)

    raise ReconciliationError(
        "paginated GitHub listing stayed incomplete after "
        f"{FETCH_COMPLETENESS_ATTEMPTS} attempts: {mismatch}"
    )


def _select_item(
    rows: Sequence[Mapping[str, Any]], request_id: str
) -> Mapping[str, Any]:
    selected = [row for row in rows if row.get("id") == request_id]
    if len(selected) != 1:
        raise ReconciliationError(
            f"expected one ledger row for {request_id}, found {len(selected)}"
        )
    return selected[0]


def apply_reconciliation(
    rows: Sequence[Mapping[str, Any]],
    inventory: Sequence[InventoryItem],
    repo: str,
    token: str,
    ledger_path: pathlib.Path,
    only_ids: set[str] | None = None,
) -> tuple[list[InventoryItem], list[dict[str, Any]]]:
    """Apply planned creates/reopens, rechecking the complete tracker before each mutation."""

    actions: list[dict[str, Any]] = []
    target_ids = only_ids or {item.request_id for item in inventory}
    mutation_ids = {
        item.request_id
        for item in inventory
        if item.request_id in target_ids and item.action in {"create", "reopen"}
    }
    for request_id in sorted(
        mutation_ids, key=lambda value: int(value.split("-")[1])
    ):
        row = _select_item(rows, request_id)
        if row.get("state") not in NONTERMINAL_STATES:
            continue
        applicable, _ = classify_row(row)
        if not applicable:
            continue

        current_issues = fetch_all_issues(repo, token)
        current_item = plan_inventory([row], current_issues, repo)[0]
        if current_item.action == "reuse-open":
            continue
        if current_item.action == "reopen":
            assert current_item.issue_number is not None
            response = _run_gh(
                [
                    "api",
                    "--method",
                    "PATCH",
                    f"repos/{repo}/issues/{current_item.issue_number}",
                    "-f",
                    "state=open",
                ],
                token,
            )
            validate_issue(response, repo, request_id)
            if response["state"] != "open":
                raise ReconciliationError(
                    f"reopen response for {request_id} did not report open state"
                )
            actions.append(
                {
                    "request_id": request_id,
                    "action": "reopened",
                    "url": response["html_url"],
                }
            )
            continue
        if current_item.action != "create":
            raise ReconciliationError(
                f"unexpected live plan action {current_item.action!r} for {request_id}"
            )

        response = _run_gh(
            [
                "api",
                "--method",
                "POST",
                f"repos/{repo}/issues",
                "-f",
                f"title={issue_title(row)}",
                "-f",
                f"body={issue_body(row, ledger_path)}",
            ],
            token,
        )
        validate_issue(response, repo, request_id)
        if response["state"] != "open":
            raise ReconciliationError(
                f"creation response for {request_id} did not report open state"
            )
        actions.append(
            {
                "request_id": request_id,
                "action": "created",
                "url": response["html_url"],
            }
        )

    final_issues = fetch_all_issues(repo, token)
    final_inventory = plan_inventory(rows, final_issues, repo)
    unresolved = [
        item.request_id
        for item in final_inventory
        if item.request_id in target_ids
        and item.applicable
        and item.action != "reuse-open"
    ]
    if unresolved:
        raise ReconciliationError(
            "apply finished with unresolved applicable requests: " + ", ".join(unresolved)
        )
    return final_inventory, actions


def load_ledger(path: pathlib.Path) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ReconciliationError(
                    f"{path}:{line_number} contains invalid JSON"
                ) from exc
            if not isinstance(row, Mapping):
                raise ReconciliationError(f"{path}:{line_number} is not an object")
            rows.append(row)
    return rows


def load_issues_file(path: pathlib.Path) -> list[Mapping[str, Any]]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, list) or any(not isinstance(item, Mapping) for item in value):
        raise ReconciliationError(f"{path} must contain a JSON list of issue objects")
    return list(value)


def inventory_markdown(
    inventory: Sequence[InventoryItem], repo: str, ledger_path: pathlib.Path
) -> str:
    counts: dict[str, int] = {}
    for item in inventory:
        counts[item.action] = counts.get(item.action, 0) + 1
    lines = [
        "# Request to GitHub Issue Reconciliation Inventory",
        "",
        f"Repository: `{repo}`",
        f"Authoritative ledger: `{ledger_path}`",
        "",
        "## Applicability rule",
        "",
        "A non-terminal request is applicable when its request, note, or touches explicitly concern Lintel, Tinker, orchestrator, agent, hook, seat, session, or local request-ledger machinery. An explicit product-repository marker excludes the row unless a machinery marker is also present. Every other row in this internal ledger is applicable by default.",
        "",
        "## Planned result",
        "",
    ]
    for action in sorted(counts):
        lines.append(f"- `{action}`: {counts[action]}")
    lines.extend(
        [
            "",
            "## Complete non-terminal inventory",
            "",
            "| Request | State | Applicable | Reason | Action | Canonical issue | Canonical matches | Broad title/body candidates | Subject |",
            "|---|---|---:|---|---|---|---|---|---|",
        ]
    )
    for item in inventory:
        subject = item.subject.replace("|", "\\|").replace("\n", " ")
        all_urls = "<br>".join(item.all_urls) or ""
        candidate_urls = "<br>".join(item.candidate_urls) or ""
        lines.append(
            "| "
            + " | ".join(
                (
                    item.request_id,
                    item.state,
                    "yes" if item.applicable else "no",
                    item.reason,
                    item.action,
                    item.canonical_url or "",
                    all_urls,
                    candidate_urls,
                    subject,
                )
            )
            + " |"
        )
    return "\n".join(lines) + "\n"


def url_map(inventory: Iterable[InventoryItem]) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in inventory:
        if item.applicable:
            if item.action != "reuse-open" or item.canonical_url is None:
                raise ReconciliationError(
                    f"{item.request_id} has no canonical open issue URL"
                )
            result[item.request_id] = item.canonical_url
    return result


def _write_json(path: pathlib.Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ledger", type=pathlib.Path, required=True)
    parser.add_argument("--repo", default="thewolff/lintel-tasks")
    parser.add_argument("--issues-file", type=pathlib.Path)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument(
        "--pending-hand",
        action="store_true",
        help="offline check for applicable rows lacking an exact target issue touch",
    )
    parser.add_argument("--only", action="append", default=[])
    parser.add_argument("--inventory", type=pathlib.Path)
    parser.add_argument("--url-map", type=pathlib.Path)
    parser.add_argument("--actions-file", type=pathlib.Path)
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    try:
        rows = load_ledger(args.ledger)
        if args.pending_hand:
            incompatible = (
                args.apply
                or args.issues_file is not None
                or bool(args.only)
                or args.inventory is not None
                or args.url_map is not None
                or args.actions_file is not None
            )
            if incompatible:
                raise ReconciliationError(
                    "--pending-hand cannot be combined with reconciliation output or mutation options"
                )
            print(
                json.dumps(
                    {
                        "pending": pending_hand_reconciliation_ids(rows, args.repo),
                        "repo": args.repo,
                    },
                    indent=2,
                    sort_keys=True,
                )
            )
            return 0
        if args.issues_file is not None:
            if args.apply:
                raise ReconciliationError("--issues-file cannot be used with --apply")
            issues = load_issues_file(args.issues_file)
            token = ""
        else:
            token = os.environ.get("GH_TOKEN", "")
            if not token:
                raise ReconciliationError("GH_TOKEN is required for live reconciliation")
            issues = fetch_all_issues(args.repo, token)
        inventory = plan_inventory(rows, issues, args.repo)
        selected_ids = set(args.only)
        known_ids = {item.request_id for item in inventory}
        unknown_ids = selected_ids - known_ids
        if unknown_ids:
            raise ReconciliationError(
                "--only named missing or inapplicable terminal rows: "
                + ", ".join(sorted(unknown_ids))
            )
        actions: list[dict[str, Any]] = []
        if args.apply:
            inventory, actions = apply_reconciliation(
                rows,
                inventory,
                args.repo,
                token,
                args.ledger.resolve(),
                selected_ids or None,
            )
        if args.inventory is not None:
            args.inventory.parent.mkdir(parents=True, exist_ok=True)
            args.inventory.write_text(
                inventory_markdown(inventory, args.repo, args.ledger.resolve()),
                encoding="utf-8",
            )
        selected_inventory = (
            [item for item in inventory if item.request_id in selected_ids]
            if selected_ids
            else inventory
        )
        urls = (
            url_map(selected_inventory)
            if args.apply
            else {
                item.request_id: item.canonical_url
                for item in selected_inventory
                if item.applicable
                and item.action == "reuse-open"
                and item.canonical_url
            }
        )
        if args.url_map is not None:
            _write_json(args.url_map, urls)
        if args.actions_file is not None:
            _write_json(args.actions_file, actions)
        summary = {
            "repo": args.repo,
            "nonterminal": len(inventory),
            "applicable": sum(item.applicable for item in inventory),
            "skipped": sum(not item.applicable for item in inventory),
            "plan": {
                action: sum(item.action == action for item in inventory)
                for action in ("reuse-open", "reopen", "create", "skip")
            },
            "mutations": actions,
            "url_count": len(urls),
        }
        print(json.dumps(summary, indent=2, sort_keys=True))
        return 0
    except (OSError, ReconciliationError, json.JSONDecodeError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

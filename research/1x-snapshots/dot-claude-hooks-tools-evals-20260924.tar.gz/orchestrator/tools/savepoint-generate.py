#!/usr/bin/env python3
"""savepoint-generate — assemble the save point from the machine-readable state plus one small
hand-written judgement file, so the budget is enforced by construction instead of merely detected.

WHY THIS EXISTS. Measured on this repo's git history (2026-08-20): 179 commits touched
orchestrator/state/STANDUP.md that day, 97 of them over the 6000-byte budget, 12 separate runs of
two-or-more consecutive shrinking-and-still-oversize commits, and 6 commits where a trim made an
oversize file LARGER. savepoint-plan.sh already measures and advises, and the behaviour did not
change — because at the moment of choosing, patching the prose feels cheaper than rewriting it.
This tool removes the choice: the facts (counts, ids, states, retractions, dispatches) are read
from their authorities at generation time, and only the JUDGEMENT is hand-written, in a file whose
sections carry individual byte caps enforced here. An over-cap section is a one-edit local fix
named by section and byte count; a global trim loop has nothing left to trim.

WHAT IS GENERATED vs HAND-WRITTEN.
  Generated (from REQUESTS.jsonl, TASKS.md, RETRACTIONS.md, LEDGER.jsonl, DECISIONS.jsonl):
    header timestamp, request-state counts (ONE line — the per-row detail deliberately lives in
    the OPEN OBLIGATIONS block that hooks/savepoint-restore.sh injects, unbudgeted, at session
    start from the same REQUESTS.jsonl; duplicating ids here spent 68% of the derived half on a
    lossy copy of it), retraction count + latest entry title, recent dispatch outcomes, checker
    pointer lines. There is NO "decided in the last 24h" line: touch entries in REQUESTS.jsonl
    carry no timestamp, so decision recency is unknowable from the data and asserting it was a
    false-authority claim (gaslight-savepoint-20260821 G3).
  DECISIONS.jsonl was added as a fifth source on 2026-08-25. It generates the OPEN DECISIONS
  section, and it SUPERSEDES the hand-typed open count that has been living in the judgement file's
  NEXT section (`DECISIONS.jsonl: 10 OPEN`). That line was correct only because nobody had drifted
  it yet, and a hand-typed count next to a generated one is the drift the generator exists to end:
  DELETE THE HAND-TYPED LINE when this lands. Two counts that disagree is worse than one that is
  stale, because the reader cannot tell which is the authority.
  The same section carries the WITNESS DISAGREEMENTS from tools/decision-witness-check.py — rows
  the record still calls open while their witness string is on disk. That is the priority signal in
  this section and NEITHER budget rung ever cuts it. (The judgement fit does not touch it either:
  the fit only ever cuts the hand-written judgement sections, never a generated one.)
  Hand-written (JUDGEMENT file, per-section caps):
    SHOUT (warnings a future session must not get wrong), DECIDED (do-not-reopen framing, voice
    intact), LIVE (in-flight framing), NEXT (ordered next actions).
  The voice lives in the judgement file verbatim — this tool never rewrites a judgement byte. It
  may DROP a trailing block of an over-cap section to make the document fit, and when it does it
  says so in the section itself and points at the judgement file for the full text.

FAILURE BEHAVIOUR — the next session's memory is at stake, so:
  * REQUESTS.jsonl missing or unparseable        -> exit 2, NOTHING written.
  * judgement file missing or empty              -> exit 2, NOTHING written (a save point with no
    judgement is worse than the previous save point, which still exists).
  * judgement section over its cap               -> FITTED in one pass (since 2026-08-25): the
    section is cut at a structural boundary, last-listed block first, and carries an inline note
    naming the bytes dropped, the blocks dropped, the drop rule, and the absolute path of the
    judgement file where the full text is readable. Nothing is lost silently. `--strict` restores
    the old refusal exactly, for any caller that depends on it.
  * over-cap section that resolves to <2 BLOCKS   -> exit 2, NOTHING written (added 2026-08-25
    after the fit dropped a whole section on its first real over-cap run). One block cannot be
    fitted: keep-all is still over cap and drop-all produces a document that reads complete and is
    not. The refusal names the section, says it could not be split, and says what would make it
    splittable. A refusal leaves the previous save point standing — recoverable and visible.
  * over-cap section where NO block fits          -> exit 2, NOTHING written (added 2026-09-15).
    Same outcome as the case above by a different route: the section splits fine, but its first
    block exceeds the room the note leaves, so every block drops and the section becomes the note
    alone. That shipped silently — 0 of 46 LIVE blocks and 0 of 112 NEXT kept — because a
    truncation note reads like a short section. The refusal names the cap that would keep the
    first block.
    A block starts at a list item, a numbered item, a table row, a heading, a blockquote line, a
    LEADING-BOLD line, or the first line after a blank line; the bold-continuation rule is stated
    in full above _BLOCK_START.
  * RETRACTIONS.md / TASKS.md / LEDGER.jsonl / DECISIONS.jsonl absent -> degrade LOUDLY: the
    section says "SOURCE ABSENT" in the output, exit 0. A malformed ledger or decisions line is
    skipped, counted, and named in the output ("N malformed rows skipped, first at line L").
    decision-witness-check.py absent -> the decisions section says "CHECKER ABSENT" rather than
    reporting a clean record, which would be indistinguishable from one.
  * Over budget with everything included -> the DERIVED half degrades, loudly, in TWO rungs, and
    the judgement is never cut by either of them:
      rung 1 — the open-decision roll compacts to its count plus the witness flags. Losing three
        truncated questions is a smaller loss than what rung 2 costs.
      rung 2 — the generated section bodies are replaced by one-line pointers to their
        authorities and the output says so. The derived half is reproducible on demand and
        injected at session start anyway.
    Only if the document is STILL over budget after both rungs -> exit 2, nothing written.

  * ⚠ HOW THE FIT AND THE BUDGET RUNGS COMPOSE — read this before changing either. The judgement
    fit above is NOT a budget rung and does not sit on this ladder. It runs once, at parse time,
    against the PER-SECTION caps only, and it never reads --budget. So the order is fixed and
    one-way: fit the judgement -> measure -> rung 1 -> measure -> rung 2 -> measure -> refuse.
    Rung selection is therefore still a pure function of the inputs: the fit shrinks the document
    the rungs measure, but nothing the rungs do can feed back into the fit. There is no
    convergence loop and no ordering dependency, which is what keeps the whole tool idempotent
    and deterministic — re-running on the same inputs cannot produce a different answer.
    The corollary is that the fit does NOT get more aggressive to save an over-budget document.
    A judgement inside its caps is emitted in full even when that costs the entire derived half,
    which is the pre-existing priority (judgement over derived) left deliberately intact.

  * ⚠ THE FINAL REFUSAL IS STILL REACHABLE, and the fit does not remove it. The witness flags in
    the decisions section are never cut by either rung, by design — a row acted on and never
    closed is the failure that section exists to surface. Their number is unbounded, so a
    document can exceed the budget after both rungs with an entirely in-cap judgement. When that
    happens the tool refuses and names the actual contributors rather than blaming the judgement.
  * Output is written to a temp file, size-checked against the budget, then renamed. A failed run
    can never leave a truncated or oversize file at the target path.
  * The header stamps generation time; a reader can always tell a generated save point from a
    hand-written one and see how fresh it is.

USAGE
  savepoint-generate.py --judgement FILE [--state-dir DIR] [--out FILE] [--budget N] [--strict]
  Default state-dir: this repo's orchestrator/state. Default out: <state-dir>/STANDUP.md.candidate
  (NEVER STANDUP.md itself — installing the candidate is a deliberate separate act).
EXIT  0 written within budget · 2 refused, nothing written.
"""
import argparse, datetime, importlib.util, json, os, re, sys, tempfile

DEF_BUDGET = 26000
# HOW MANY OPEN DECISIONS THE FULL SECTION SHOWS, and the byte caps on each row's two fields. The
# bound is deliberate and small: measured 2026-08-25, the live save point was 5449 bytes against a
# 6000 budget, so an unbounded roll of 10 open rows would have blown the budget and taken the WHOLE
# derived half down with it — including MISTAKES, which is generated only in the undegraded branch.
# Rows past the bound are counted, never dropped silently, and the compact rung below keeps the
# count and the witness flags even when the full roll will not fit.
DECISIONS_SHOWN = 3
DECISION_Q_CAP = 90
DECISION_REC_CAP = 60
# Per-section caps for the judgement file. RAISED 2026-09-15 from SHOUT 1150 / DECIDED 1400 /
# LIVE 1400 / NEXT 630 against a 6000 budget, because those caps were tuned on 2026-08-21 against
# a judgement whose entries were a few hundred bytes each. They are not tuned to today's input and
# the failure was total: measured on the live save point, LIVE kept 0 of 46 blocks and NEXT kept
# 0 of 112, so BOTH sections shipped as nothing but a truncation note. Every entry in the file is
# now a 700-1500 byte bold-led block, so a 1400-byte cap minus the worst-case note leaves room for
# at most one block and in practice for none.
# The arithmetic, stated so the next person can check it rather than trust it: caps sum to 21,500;
# scaffolding, header and the undegraded derived half measured ~1,950 against the live state; so a
# worst case of all four sections AT cap lands ~23,450 against the 26,000 budget, leaving ~2,550
# for the uncuttable witness flags, which are unbounded and are the documented reason the final
# refusal stays reachable. Sections normally sit well under cap.
# THIS IS A SUMMARY, NOT A COPY: the judgement file is ~146 KB and no cap makes the save point
# carry it. The sections are authored most-important-first, so a cap buys the top N entries; the
# full text is one read away at the path every truncation note prints.
# REBALANCED 2026-09-16, sum UNCHANGED at 21,500 so the ~2,550 witness-flag margin above still
# holds: LIVE 8000 -> 7500, NEXT 8000 -> 8500. Not an inflation — 500 bytes moved. Measured cause:
# NEXT's two load-bearing blocks summed 8,217 against the 8,000 cap and the fitter dropped the
# second one silently, which on the night before a launch meant the corrections block vanished
# while the document still read complete. Both sections are chronically over cap, so this is a
# priority call and not a capacity fix: LIVE is current state that a reader can re-derive from the
# repos, NEXT is the ranked action list that exists nowhere else. When they compete, NEXT wins.
CAPS = {"SHOUT": 3000, "DECIDED": 2500, "LIVE": 9500, "NEXT": 10500}

def die(msg):
    sys.stderr.write(f"savepoint-generate: REFUSED, nothing written: {msg}\n")
    sys.exit(2)

# --- deterministic fit (added 2026-08-25, run lintel-inline-work-enforcement-20260825) ----------
# WHY. The refuse-on-over-cap path below converted a deterministic problem into an unbounded loop:
# the tool named the section and the byte count, wrote nothing, and the caller trimmed-and-rechecked
# by hand. Default behaviour is now to FIT in one pass; --strict restores the refusal verbatim.
#
# DROP PRIORITY: last-listed first (keep the prefix). The judgement sections are authored
# most-important-first — SHOUT leads with the loudest warning, NEXT is an ordered action list whose
# step 1 is step 1 — so the tail is the least-load-bearing end. It is also the only rule that needs
# no metadata the judgement file does not carry (no timestamps, no severities), which keeps the
# result a pure function of the input bytes.
#
# NEVER SILENT: a truncated section carries an inline note giving bytes dropped, blocks dropped,
# the drop rule, and the absolute path of the judgement file where the full text is readable.
#
# GRANULARITY (added 2026-08-25, run lintel-inline-work-enforcement-20260825, after the fit above
# dropped an ENTIRE section on its first real over-cap run). The original detector matched markdown
# list syntax only. The one real judgement file on this machine has never used it: every entry is a
# run of lines opening with `**`, with NO blank lines anywhere. Committed history of
# orchestrator/state/JUDGEMENT.md confirms the convention -- twelve consecutive revisions, zero
# blank lines inside NEXT. So split_blocks returned ONE block for that section, "drop the
# last-listed block first" had exactly one block to drop, and the save point installed with its
# whole next-action section replaced by the truncation note. The lab fixtures had been written to
# satisfy the detector's assumption; the only real input never satisfied it.
#
# THE FIX IS TWO PARTS AND BOTH ARE LOAD-BEARING:
#   (1) a leading-bold line starts a block -- see _BOLD_START below;
#   (2) an over-cap section that still resolves to FEWER THAN TWO blocks is REFUSED, not fitted --
#       see read_judgement. A section of one block cannot be fitted at all: the only outcomes are
#       keep-everything and drop-everything, and drop-everything is what shipped.
#
# BOLD-CONTINUATION RULE, stated here so it is testable rather than inferred. A line starts a block
# when, after up to 3 spaces of indent, it opens with `**` followed by a non-space character AND the
# current block is not already inside an unterminated bold run. "Unterminated" is decided by parity:
# the running count of `**` markers accumulated in the current block. Odd means a `**` opened and
# has not closed, so this line is a CONTINUATION and is appended rather than split on. Two
# consequences, both deliberate:
#   * mid-paragraph emphasis (`text with **bold** inside`) NEVER splits a block, because the
#     pattern is anchored at the start of the line. Unanchored emphasis would shred prose.
#   * a bold line following a line whose bold markers are all CLOSED does start a new block. Every
#     entry in the real file is bold-led, so that is the correct read there; where it is wrong the
#     cost is only a finer cut boundary, never a lost line, because non-bold continuation lines
#     still never start a block and stay attached to the entry above them.
_BOLD_START = r"\*\*(?=\S)"
_BLOCK_START = re.compile(r"^ {0,3}(?:[-*+] |\d+[.)] |\||#{1,6} |> |" + _BOLD_START + r")")
# The bold half of _BLOCK_START on its own. split_blocks needs to ask "did THIS alternative match?"
# to apply the continuation guard, and asking the combined pattern cannot tell the branches apart.
_LEADING_BOLD = re.compile(r"^ {0,3}" + _BOLD_START)
TRUNC_NOTE = ("_[TRUNCATED TO FIT: {dropped} of {total} bytes dropped from {name}; "
              "{kept_u} of {total_u} blocks kept, last-listed dropped first. "
              "Full text: {path}]_")


def split_blocks(body):
    """Split a section into structural blocks: (separator, text) pairs.

    A block starts at a list item, a numbered item, a table row, a heading, a blockquote line, a
    LEADING-BOLD line (see the bold-continuation rule above _BLOCK_START), or the first line after
    a blank line. Continuation lines stay with their block, so a cut can never land mid-row,
    mid-item, or mid-entry. Concatenating every (sep + text) reproduces the input, with ONE
    pre-existing exception measured 2026-08-25 and identical in the unpatched tool: `pending_blank`
    is a boolean, so a run of two or more consecutive blank lines collapses to a single one. No
    non-blank byte is ever lost. The old docstring claimed exact reproduction, which was false.

    `bold_open` carries the parity of `**` markers seen so far IN THE CURRENT BLOCK. While it is
    odd the block sits inside an unterminated bold run, and a leading-bold line is treated as the
    continuation of that run rather than as a new entry. It resets on every flush, so parity never
    leaks across a block boundary and the split stays a pure function of the input bytes.
    """
    blocks, cur = [], []
    pending_blank, started, bold_open = False, False, False

    def flush():
        nonlocal cur, pending_blank, started, bold_open
        if cur:
            sep = "" if not started else ("\n\n" if pending_blank else "\n")
            blocks.append((sep, "\n".join(cur)))
            started, cur, pending_blank = True, [], False
        bold_open = False

    for line in body.split("\n"):
        if line.strip() == "":
            flush()
            pending_blank = True
            continue
        if _BLOCK_START.match(line) and not (bold_open and _LEADING_BOLD.match(line)):
            flush()
        cur.append(line)
        if line.count("**") % 2:
            bold_open = not bold_open
    flush()
    return blocks


def fit_section(name, body, cap, jpath):
    """Return (fitted_body, record) — record is None when nothing was cut.

    Single pass, no iteration: the note's worst-case length is reserved up front (every number at
    its maximum width), so the kept-block selection never has to be redone after the note is
    rendered. Output is a pure function of (body, cap, jpath, name).
    """
    raw = len(body.encode())
    if raw <= cap:
        return body, None
    blocks = split_blocks(body)
    total_u = len(blocks)
    worst = TRUNC_NOTE.format(dropped=raw, total=raw, name=name,
                              kept_u=total_u, total_u=total_u, path=jpath)
    room = cap - (len(worst.encode()) + 2)  # +2 for the blank line before the note
    kept, used = [], 0
    for sep, text in blocks:
        piece = (sep if kept else "") + text
        n = len(piece.encode())
        if used + n > room:
            break
        kept.append((sep, text))
        used += n
    if not kept:
        # ADDED 2026-09-15. The <2-block refusal in read_judgement catches a section that cannot
        # be SPLIT. It does not catch a section that splits fine and whose FIRST block is still
        # bigger than the room left by the note — the outcome is identical (a section replaced by
        # its own truncation note, reading complete and carrying nothing) and it shipped silently:
        # the live save point kept 0 of 46 LIVE blocks and 0 of 112 NEXT blocks for an unknown
        # number of generations. Zero kept is drop-everything by another route, so it refuses by
        # the same reasoning: a refusal leaves the previous save point standing, visible and
        # recoverable, while a note-only section is indistinguishable from a quiet day.
        die(f"section {name} is {raw} bytes against a {cap} cap and NOT ONE of its {total_u} "
            f"blocks fits the {room} bytes the truncation note leaves — the section would have "
            f"been replaced entirely by that note. Raise CAPS[{name!r}] above "
            f"{len(blocks[0][1].encode()) + (len(worst.encode()) + 2)} to keep its first block, "
            f"or split that block in {jpath}")
    out = "".join((sep if i else "") + text for i, (sep, text) in enumerate(kept))
    dropped = raw - len(out.encode())
    note = TRUNC_NOTE.format(dropped=dropped, total=raw, name=name,
                             kept_u=len(kept), total_u=total_u, path=jpath)
    fitted = (out + "\n\n" + note) if out else note
    return fitted, (name, dropped, raw, len(kept), total_u, len(fitted.encode()))


# --- fit history (added 2026-09-09) -------------------------------------------------------------
# WHY. fit_section already computes exactly the series worth having — bytes dropped, blocks
# dropped, resulting size, one row per fitted section per generation — and until now it went only
# to stderr, where no caller captures it. One JSONL line per fitted section turns that into a
# DATED series, which answers the question a single stderr line cannot: is the judgement input
# growing, or is the cap wrong? That is why the section's TOTAL bytes are recorded alongside the
# dropped count; dropped alone cannot tell those two apart.
# NOT under <state-dir>/: that tree is the live ledger set and this tool only ever reads it. The
# log lives beside tools/ and state/, in orchestrator/build/, and SAVEPOINT_FIT_HISTORY overrides
# it for tests and for callers that keep their own series.
FIT_HISTORY_ENV = "SAVEPOINT_FIT_HISTORY"
FIT_HISTORY_DEFAULT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "build", "fit-history.jsonl")


def fit_history_path():
    return os.environ.get(FIT_HISTORY_ENV) or FIT_HISTORY_DEFAULT


def fit_history_record(name, cap, over, dropped, total, kept_u, total_u, final, jpath, now=None):
    """Build one history record. Separate from the append so a caller (or a test) can inspect the
    record without writing it. Timestamp is wall-clock UTC, NOT the --now override: this row
    records when the fit RAN, which is the axis the series is read along."""
    t = now or datetime.datetime.now(datetime.timezone.utc)
    return {"at": t.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
            "tool": "savepoint-generate", "event": "section-fitted",
            "section": name, "cap": cap, "over": over,
            "dropped": dropped, "total": total,
            "kept_blocks": kept_u, "total_blocks": total_u,
            "final": final, "judgement": jpath}


def append_fit_history(record, path=None):
    """Append ONE JSONL line. NEVER raises. A save point that was fitted correctly must not be
    lost because its history line could not be written, so every failure degrades to a stderr
    note and generation continues. Returns the path written, or None on failure."""
    try:
        p = path or fit_history_path()
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(p, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, separators=(",", ":")) + "\n")
        return p
    except Exception as e:
        sys.stderr.write(f"  fit history NOT recorded ({e.__class__.__name__}: {e}) — the save "
                         f"point itself is unaffected\n")
        return None


def read_judgement(path, strict=False):
    if not os.path.isfile(path):
        die(f"judgement file missing: {path}")
    text = open(path, encoding="utf-8").read()
    sections, cur = {}, None
    for line in text.splitlines():
        m = re.match(r"^##\s+(\w+)\s*$", line)
        if m:
            cur = m.group(1).upper()
            sections[cur] = []
        elif cur:
            sections[cur].append(line)
    sections = {k: "\n".join(v).strip() for k, v in sections.items()}
    unknown = set(sections) - set(CAPS)
    if unknown:
        die(f"unknown judgement section(s) {sorted(unknown)}; allowed: {sorted(CAPS)}")
    if not any(sections.values()):
        die("judgement file has no content in any section — a save point with no judgement is "
            "worse than the previous one. Write SHOUT/DECIDED/LIVE/NEXT first.")
    over = [(k, len(sections[k].encode()) - CAPS[k]) for k in sections
            if len(sections[k].encode()) > CAPS[k]]
    if over and strict:
        for k, n in over:
            sys.stderr.write(f"  section {k}: {n} bytes over its {CAPS[k]}-byte cap — cut {n} "
                             f"bytes from {k} in the judgement file, nothing else moves\n")
        die("judgement over cap (see per-section lines above)")
    if over:
        jpath = os.path.abspath(path)
        # ⛔ REFUSE BEFORE FITTING when an over-cap section will not split. Checked for EVERY
        # over-cap section first, so the refusal cannot depend on which section happens to be
        # fitted first and the tool stays deterministic.
        #
        # WHY THIS IS A REFUSAL AND NOT A BEST-EFFORT CUT. A section that resolves to one block
        # cannot be FITTED; the only two outcomes are keep-everything (still over cap) and
        # drop-everything. Drop-everything is exactly what shipped on 2026-08-25: an entire
        # next-action section was replaced by the truncation note, and the save point still read
        # as a complete document. A refusal leaves the PREVIOUS save point standing, which is
        # recoverable and visible; a whole dropped section leaves one that reads clean and is not.
        # Silence does not announce itself. This is the same argument that kept the refusal in the
        # merge, applied to the rung that was supposed to replace it.
        unsplittable = [(k, n) for k, n in sorted(over) if len(split_blocks(sections[k])) < 2]
        if unsplittable:
            for k, n in unsplittable:
                nb = len(split_blocks(sections[k]))
                sys.stderr.write(
                    f"  section {k}: {n} bytes over its {CAPS[k]}-byte cap and it resolves to "
                    f"{nb} block(s) — it CANNOT be fitted, because the only cuts available are "
                    f"keep-all (still over cap) and drop-all (a section that reads complete and "
                    f"is not). Make {k} splittable in {jpath}: start each entry on its own line "
                    f"with `**`, `- `, `1. `, or `#`, or separate entries with a blank line — or "
                    f"cut {n} bytes from {k} by hand.\n")
            die("over-cap judgement section(s) "
                f"{[k for k, _ in unsplittable]} could not be split (see per-section lines above)")
        for k, n in sorted(over):  # sorted: the stderr report is deterministic too
            sections[k], rec = fit_section(k, sections[k], CAPS[k], jpath)
            _nm, dropped, total, kept_u, total_u, final = rec
            sys.stderr.write(f"  section {k}: {n} bytes over its {CAPS[k]}-byte cap — FITTED by "
                             f"dropping {dropped} of {total} bytes ({total_u - kept_u} of "
                             f"{total_u} blocks, last-listed first); section is now {final} "
                             f"bytes. Full text stays in {jpath}\n")
            if final > CAPS[k]:
                sys.stderr.write(f"  section {k}: WARNING the truncation note alone is {final} "
                                 f"bytes, over the {CAPS[k]}-byte cap; emitted anyway rather than "
                                 f"drop the pointer to the full text\n")
            append_fit_history(fit_history_record(k, CAPS[k], n, dropped, total,
                                                  kept_u, total_u, final, jpath))
    return sections

def load_requests(path):
    if not os.path.isfile(path):
        die(f"REQUESTS.jsonl missing at {path} — it is the authority; no save point without it")
    rows = []
    for i, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as e:
            die(f"REQUESTS.jsonl line {i} unparseable ({e}) — refusing to summarize a corrupt "
                "authority")
    if not rows:
        die(f"REQUESTS.jsonl at {path} has zero rows")
    return rows

def load_ledger(path):
    """Optional source: absent -> (None, 0, None); malformed rows skipped loudly."""
    if not os.path.isfile(path):
        return None, 0, None
    rows, bad, first_bad = [], 0, None
    for i, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            bad += 1
            first_bad = first_bad or i
    return rows, bad, first_bad

def load_decisions(path):
    """Fifth source. Optional: absent -> (None, 0, None). Malformed rows skipped and counted."""
    if not os.path.isfile(path):
        return None, 0, None
    rows, bad, first_bad = [], 0, None
    for i, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            bad += 1
            first_bad = first_bad or i
    return rows, bad, first_bad


def load_witness_checker():
    """Import the sibling checker by path. Absent -> None, and the section says so rather than
    silently reporting no disagreements, which would be indistinguishable from a clean record."""
    mod_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "decision-witness-check.py")
    if not os.path.isfile(mod_path):
        return None
    try:
        spec = importlib.util.spec_from_file_location("decision_witness_check", mod_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def parse_ts(ts):
    try:
        return datetime.datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        return None

def snippet(text, limit):
    text = " ".join((text or "").split())
    if len(text.encode()) <= limit:
        return text
    enc = text.encode()[: limit - 1]
    return enc.decode(errors="ignore").rstrip() + "…"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--judgement", required=True)
    ap.add_argument("--state-dir",
                    default=os.path.join(os.path.dirname(os.path.dirname(
                        os.path.abspath(__file__))), "state"))
    ap.add_argument("--out", default=None)
    ap.add_argument("--budget", type=int, default=DEF_BUDGET)
    ap.add_argument("--now", default=None, help="ISO timestamp override, for reproducing history")
    ap.add_argument("--tasks-path", default=None,
                    help="path to the human-readable TASKS.md "
                         "(default: <state-dir>/.projects/lintel-machinery/TASKS.md)")
    ap.add_argument("--identity", default="Lintel (it/its), handle `orchestrator`",
                    help="identity string for the header line")
    ap.add_argument("--launch", default="lintel",
                    help="the launch command named in the banner")
    ap.add_argument("--strict", action="store_true",
                    help="restore the pre-2026-08-25 behaviour: refuse an over-cap judgement "
                         "section and write nothing, instead of fitting it deterministically")
    a = ap.parse_args()
    sd = a.state_dir
    out = a.out or os.path.join(sd, "STANDUP.md.candidate")
    if os.path.basename(out) == "STANDUP.md":
        die("this tool never writes STANDUP.md directly; write the .candidate and install it "
            "as a separate deliberate act")

    now = parse_ts(a.now) if a.now else datetime.datetime.now(datetime.timezone.utc)
    if a.now and now is None:
        die(f"--now not parseable: {a.now}")

    j = read_judgement(a.judgement, strict=a.strict)
    reqs = load_requests(os.path.join(sd, "REQUESTS.jsonl"))

    counts = {}
    for r in reqs:
        counts[r.get("state", "?")] = counts.get(r.get("state", "?"), 0) + 1
    cutoff = now - datetime.timedelta(hours=24)
    # NO per-row Blocked:/Partial: lines here, and NO "decided in the last 24h" line — see the
    # docstring. The counts line below is the drift alarm; the rows themselves are injected at
    # session start by hooks/savepoint-restore.sh from the same authority.

    # Retractions: count of table rows plus '## N —' entries, and the latest heading.
    rpath = os.path.join(sd, "RETRACTIONS.md")
    if os.path.isfile(rpath):
        rt = open(rpath, encoding="utf-8").read()
        # Count what is physically there — one table row or one `## … — …` heading is one entry —
        # and never trust the drifting entry numbering itself. (The old max(ids)+unnumbered
        # heuristic changed its answer on title formatting: gaslight-savepoint-20260821 G5.)
        table = re.findall(r"^\| (\d+) \|", rt, re.M)
        heads = re.findall(r"^## (.+—.+)$", rt, re.M)
        rcount = len(table) + len(heads)
        latest = re.sub(r"^\d+\s*—\s*", "", heads[-1]) if heads else "(table entries only)"
        rline = (f"{rcount} recorded; latest: {snippet(latest, 150)}" if heads or table
                 else "file present but no entries recognized")
    else:
        rline = "SOURCE ABSENT — RETRACTIONS.md not found; the mistakes record is unverified"

    ledger, bad, first_bad = load_ledger(os.path.join(sd, "LEDGER.jsonl"))
    if ledger is None:
        lline = "SOURCE ABSENT — LEDGER.jsonl not found; recent dispatch history unverified"
    else:
        recent = [r for r in ledger if (parse_ts(r.get("ts", "")) or cutoff) >= cutoff]
        oc = {}
        for r in recent:
            oc[r.get("outcome", "?")] = oc.get(r.get("outcome", "?"), 0) + 1
        lline = f"last 24h: {len(recent)} dispatches (" + \
                ", ".join(f"{v} {k}" for k, v in sorted(oc.items())) + ")" if recent else \
                "last 24h: no dispatches"
        if bad:
            lline += f" — WARNING: {bad} malformed ledger row(s) skipped, first at line {first_bad}"

    # ---- fifth source: DECISIONS.jsonl ------------------------------------------------
    dpath = os.path.join(sd, "DECISIONS.jsonl")
    drows, dbad, dfirst_bad = load_decisions(dpath)
    if drows is None:
        dopen = []
        dcount_line = ("SOURCE ABSENT — DECISIONS.jsonl not found; whether anything is waiting on "
                       "Jo is unverified")
    else:
        dopen = [r for r in drows if isinstance(r, dict) and r.get("state") == "open"]
        dopen.sort(key=lambda r: str(r.get("ts", "")), reverse=True)
        dcount_line = "%d open of %d recorded." % (len(dopen), len(drows))
        if dbad:
            dcount_line += (" WARNING: %d malformed row(s) skipped, first at line %d"
                            % (dbad, dfirst_bad))

    # Witness disagreements: rows the record calls open while their witness string is on disk.
    wc = load_witness_checker()
    if wc is None:
        witness_cov = ("CHECKER ABSENT — tools/decision-witness-check.py not found; no row was "
                       "checked against a witness")
        witness_flags = []
    else:
        wres = wc.check(dpath)
        witness_cov = wc.coverage_line(wres)
        witness_flags = wc.flag_lines(wres, qlimit=DECISION_Q_CAP)

    def decision_lines(compact):
        L = ["## DECISIONS - OPEN (generated)", ""]
        L.append(dcount_line)
        # THE FLAGS ARE NEVER CUT. A row acted on and never closed is the failure this section was
        # built for; the roll of open questions is a convenience beside it.
        if witness_flags:
            L.append("⛔ ACTED ON BUT STILL OPEN — the record and the disk disagree. Close with "
                     "`tools/decision-write.sh answer`; nothing closes these automatically.")
            for line in witness_flags:
                L.append("- " + line)
        L.append("witness coverage: " + witness_cov)
        if compact:
            if dopen:
                L.append("Full roll of open questions: `%s` (this rung is the budget cut)." % dpath)
        else:
            for r in dopen[:DECISIONS_SHOWN]:
                rec = r.get("recommendation")
                rec = (snippet(rec, DECISION_REC_CAP) if isinstance(rec, str) and rec.strip()
                       else ("NONE OFFERED" if "recommendation" in r else "field absent"))
                L.append("- %s: %s — rec: %s"
                         % (r.get("id", "?"), snippet(r.get("question", ""), DECISION_Q_CAP), rec))
            extra = len(dopen) - DECISIONS_SHOWN
            if extra > 0:
                L.append("- +%d more open, not shown here; all of them in `%s`." % (extra, dpath))
        L.append("")
        return L

    tpath = a.tasks_path or os.path.join(sd, ".projects", "lintel-machinery", "TASKS.md")
    tline = (f"`{tpath}` is the human-readable face; the checker enforces agreement."
             if os.path.isfile(tpath) else
             "SOURCE ABSENT — TASKS.md not found; the checkbox face of the ledger is missing")

    def assemble(degraded, decisions_compact=False):
        L = []
        L.append(f"# Standup, {now.strftime('%Y-%m-%d %H:%M')}Z - {a.identity}")
        L.append("")
        L.append(f"**GENERATED save point** (`tools/savepoint-generate.py`), facts read from "
                 f"`REQUESTS.jsonl` at generation time — it is the authority; on any conflict "
                 f"the ledger wins. Launch with `{a.launch}`.")
        L.append("")
        if j.get("SHOUT"):
            L += ["## ⛔ DO NOT GET THIS WRONG", "", j["SHOUT"], ""]
        if j.get("DECIDED"):
            L += ["## ✅ DECIDED - DO NOT REOPEN", "", j["DECIDED"], ""]
        # DEC-043: NEXT ACTION directly after DECIDED — savepoint-restore.sh keeps the file's
        # PREFIX on a cut, so the ranked action list must sit before commentary to survive it.
        if j.get("NEXT"):
            L += ["## NEXT ACTION", "", j["NEXT"], ""]
        if j.get("LIVE"):
            L += ["## ⚠ LIVE NOW", "", j["LIVE"], ""]
        L.append("## LEDGER STATE (generated)")
        L.append("")
        if degraded:
            L.append("!! DERIVED DETAIL OMITTED to stay under budget — judgement above is "
                     "complete; the derived half degrades first, never the judgement. "
                     "Authorities: `REQUESTS.jsonl`, `RETRACTIONS.md`, `LEDGER.jsonl`; the "
                     "session-start hook injects open obligations in full.")
            L.append("")
            L += decision_lines(compact=True)
        else:
            L.append("Requests: " + ", ".join(f"{v} {k}"
                                              for k, v in sorted(counts.items())) + ".")
            L.append("Per-row detail is injected at session start by "
                     "`hooks/savepoint-restore.sh` from the same file.")
            L.append(tline)
            L.append("Dispatches: " + lline)
            L.append("")
            L.append("## MISTAKES - RETRACTIONS.md (generated)")
            L.append("")
            L.append(rline)
            L.append("")
            L += decision_lines(compact=decisions_compact)
        return "\n".join(L)

    doc = assemble(degraded=False)
    size = len(doc.encode())
    if size > a.budget:
        # RUNG ONE, ADDED WITH THE FIFTH SOURCE. Compact the open-decision roll before degrading
        # the whole derived half. Losing three truncated questions is a smaller loss than losing
        # the request counts, the dispatch line and MISTAKES, which is what the next rung costs.
        # The witness flags survive both rungs.
        sys.stderr.write(f"savepoint-generate: full document {size} bytes over the {a.budget} "
                         f"budget — compacting the open-decision roll first\n")
        doc = assemble(degraded=False, decisions_compact=True)
        size = len(doc.encode())
    if size > a.budget:
        # Wrong-direction failure fixed (gaslight-savepoint-20260821 G4): degrade the DERIVED
        # half loudly rather than refusing to write, because a refusal leaves a stale save point
        # behind a Stop guard while judgement — the irreplaceable half — was fine all along.
        sys.stderr.write(f"savepoint-generate: full document {size} bytes over the {a.budget} "
                         f"budget — degrading the derived half (judgement untouched)\n")
        doc = assemble(degraded=True)
        size = len(doc.encode())
    if size > a.budget:
        # MERGE NOTE (2026-08-25). The pre-existing message named the judgement as the only
        # possible culprit. That stopped being true when the fifth source landed: the witness
        # flags are never cut by either rung, so an entirely in-cap judgement can sit beside an
        # over-budget document and the old advice ("cut the judgement file") would send the
        # reader to trim something that is not the problem. Name what is actually left.
        jbytes = sum(len(v.encode()) for v in j.values())
        left = ("the judgement is %d bytes and the %d uncuttable witness flag(s) are %d; "
                % (jbytes, len(witness_flags),
                   sum(len(x.encode()) + 3 for x in witness_flags))) if witness_flags else \
               ("the judgement is %d bytes; " % jbytes)
        die(f"document is {size} bytes against a {a.budget} budget even with the open-decision "
            f"roll compacted AND the derived half degraded — " + left +
            f"nothing else is left to move. Cut the judgement file, close a flagged decision "
            f"with `tools/decision-write.sh answer`, or raise --budget")
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(out)), prefix=".sgen-")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(doc)
    os.replace(tmp, out)
    print(f"savepoint-generate: wrote {out} ({size} bytes, budget {a.budget}, "
          f"headroom {a.budget - size})")
    return 0

if __name__ == "__main__":
    sys.exit(main())

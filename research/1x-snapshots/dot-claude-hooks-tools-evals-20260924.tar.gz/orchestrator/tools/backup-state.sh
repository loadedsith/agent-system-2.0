#!/usr/bin/env zsh
#
# backup-state.sh — mirror the orchestrator state layer to a private GitHub repo.
#
#   zsh /Users/jowolff/.claude/orchestrator/tools/backup-state.sh            # sync, branch, pull request
#   zsh /Users/jowolff/.claude/orchestrator/tools/backup-state.sh --check    # report drift, write nothing
#
# BRANCH AND PULL REQUEST, NEVER main. Each run commits onto a dated branch in the mirror and
# opens (or updates) a pull request against main. This script never checks out, resets, moves or
# pushes main, master, production, prod or release.
#
# ONE BRANCH PER SESSION, REUSED. The branch name carries the date AND the first 8 characters of
# the orchestrator session id from <source>/.session-id, so every run inside one session commits
# to the same branch and UPDATES that session's one open pull request instead of opening another.
# This script runs often; a branch per run would mean a pull request per run.
#
# It used to carry the date and nothing finer, which meant two sessions on one date shared a
# branch and a pull request, and a review of one session's backup was unavoidably a review of the
# other's. When .session-id is missing or unreadable the tag is the literal "nosession", so those
# runs still share one branch per day rather than fanning out into a branch per run.
#
# THE BRANCH STARTS AT origin/main, NOT AT THE LOCAL HEAD. Cutting from HEAD would stack each
# unmerged backup on the last one, so a pull request nobody merged would ride into the next one.
# Starting a branch at a remote ref is not the same as checking that ref out; main is not moved
# locally or on the remote.
#
# GITHUB ACCOUNT. gh on this machine holds more than one account and the globally active one is
# not necessarily the owner of the mirror. Every gh call below runs with a per-invocation token
# for the account that owns the remote. The global active account is never switched, and the
# repo-local core.sshCommand that pins the key for git transport is left alone.
#
# WHY A MIRROR AND NOT A REPO. /Users/jowolff/.claude/orchestrator/state/ lives inside
# /Users/jowolff/.claude, which is a git repo with no remote and is deliberately staying that way.
# Making the state directory its own repo would present to the parent as a gitlink and would
# collide with a PreToolUse staging guard already watching that tree. So the state layer is copied
# out to a separate repo instead. This script NEVER runs an index-writing git command inside
# /Users/jowolff/.claude — every git invocation below is pinned to $MIRROR with `git -C`.
#
# WHAT GETS EXCLUDED. The authority is $MIRROR/.gitignore for what is COMMITTED. PRUNE below is
# mostly performance pruning — it stops rsync spending time on ~21MB of throwaway hook-lab
# fixtures every run — with ONE deliberate exception, .turn-state/, documented at the PRUNE array
# itself. Where PRUNE and .gitignore disagree, .gitignore still wins for what is committed; the
# cost of a disagreement is wasted bytes on disk, or a path frozen in the mirror at the value it
# held when the exclusion was added. Both current disagreements are named at PRUNE.
#
# EXIT CODES
#   0  success, or --check found no drift
#   1  --check found drift
#   2  refused to run, or a step failed

set -e
set -u
set -o pipefail

SOURCE="/Users/jowolff/.claude/orchestrator/state"
MIRROR="/Users/jowolff/code/lintel-state"
# The publisher's own checkout of $MIRROR. Every write this script makes goes here, so it never
# moves $MIRROR's HEAD or touches its working tree. A hidden SIBLING of $MIRROR, not a directory
# inside it: outside the repository there is no ignore rule to get wrong.
WT="${MIRROR:h}/.${MIRROR:t}-publish-worktree"
# Where rsync writes and where git is run. $MIRROR under --check, which creates no worktree and
# writes nothing; $WT on the write path, set at step 2b.
DEST="$MIRROR"
SCRIPT_DIR="${0:A:h}"
LOG="${SCRIPT_DIR}/backup-state.log"
BASE_BRANCH="main"

# SESSION TAG. Read, not minted: summon.sh writes the launching session's uuid to this file and
# every hook in orchestrator/hooks/ gates on it, so it is already the machine's answer to "which
# session is this". Sanitised to the characters git accepts in a ref, then cut to 8 — enough to
# tell two sessions on one day apart, short enough to read. Guarded with [[ -r ]] because `set -e`
# is on and a failed redirect inside a command substitution would abort the run.
SESSION_TAG=""
if [[ -r "$SOURCE/.session-id" ]]; then
  SESSION_TAG="$(tr -cd 'A-Za-z0-9-' < "$SOURCE/.session-id" | cut -c1-8)"
fi
[[ -n "$SESSION_TAG" ]] || SESSION_TAG="nosession"

WORK_BRANCH="backup-orchestrator-state-$(date -u '+%Y%m%d')-$SESSION_TAG"
case "$WORK_BRANCH" in
  main|master|production|prod|release) print -r -- "refusing to work on protected branch $WORK_BRANCH"; exit 2 ;;
esac

CHECK_ONLY=0
[[ "${1:-}" == "--check" ]] && CHECK_ONLY=1

# Everything from here on is captured to a fixed log next to this script, so a failure is
# locatable from the log alone without anyone having to reproduce the run.
exec > >(tee "$LOG") 2>&1

say() { print -r -- "[backup-state] $*"; }
die() { print -r -- "[backup-state] REFUSED: $*"; print -r -- "[backup-state] log: $LOG"; exit 2; }

# Every deliberate stop in this script goes through die() and says why. A `set -e` abort says
# nothing at all, and when it happens inside a command substitution the caller sees only a bare
# exit 1 -- which is exactly how the 2026-08-20T21:57 failure presented. This trap gives that path
# a voice: the line number, and the status, printed before the shell unwinds. It does not fire for
# a failure already handled by `||`, by an `if` condition, or by an `&&` list, so die()'s own
# messages are not duplicated. The string form of `trap` is used deliberately: inside a
# `TRAPZERR()` function $LINENO reports 0, while this form reports the real line (verified in
# zsh 5.9 on this machine).
trap 'ZERR_RC=$?; print -r -- "[backup-state] ABORTED at line $LINENO with status $ZERR_RC and no message of its own. This is a set -e abort, not a deliberate refusal."; print -r -- "[backup-state] log: $LOG"' ZERR

say "=== run started $(date -u '+%Y-%m-%dT%H:%M:%SZ') ==="
say "mode:   $([[ $CHECK_ONLY == 1 ]] && echo '--check (read-only)' || echo 'sync + commit + push')"
say "source: $SOURCE"
say "mirror: $MIRROR"
say "log:    $LOG"

# --- Step 1: preconditions -------------------------------------------------
say "step 1/6: checking preconditions"
[[ -d "$SOURCE" ]] || die "source directory does not exist: $SOURCE"
[[ -d "$MIRROR/.git" ]] || die "mirror is not a git repo: $MIRROR"
command -v rsync >/dev/null || die "rsync not found on PATH"

# Guard against the mirror ever being pointed back at ~/.claude by a future edit.
case "$MIRROR" in
  /Users/jowolff/.claude*) die "mirror path is inside ~/.claude; this script must never write there" ;;
esac

# gh preflight, before anything is written, so an auth problem costs nothing. --check needs no
# gh and skips this entirely.
GH_OWNER=""; GH_REPO=""; GH_ACCOUNT_TOKEN=""
if [[ $CHECK_ONLY == 0 ]]; then
  ORIGIN_URL="$(git -C "$MIRROR" remote get-url origin 2>/dev/null || echo '')"
  [[ -n "$ORIGIN_URL" ]] || die "mirror has no origin remote; nothing to open a pull request against"
  SLUG="${ORIGIN_URL##*:}"; SLUG="${SLUG##*github.com/}"; SLUG="${SLUG%.git}"
  GH_OWNER="${SLUG%%/*}"; GH_REPO="${SLUG##*/}"
  [[ -n "$GH_OWNER" && -n "$GH_REPO" ]] || die "could not read owner/repo out of origin URL: $ORIGIN_URL"
  command -v gh >/dev/null || die "gh is not installed, so no pull request can be opened"
  GH_ACCOUNT_TOKEN="$(gh auth token --user "$GH_OWNER" 2>/dev/null || echo '')"
  if [[ -z "$GH_ACCOUNT_TOKEN" ]]; then
    say "gh has no authenticated account named '$GH_OWNER', which owns $SLUG."
    say "Log in with:  gh auth login --hostname github.com"
    say "(Do not switch the globally active gh account. This script asks for the owner's token"
    say " per invocation with: gh auth token --user $GH_OWNER)"
    die "gh is not authenticated for $GH_OWNER"
  fi
  PERM="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh repo view "$SLUG" --json viewerPermission -q .viewerPermission 2>/dev/null || echo '')"
  case "$PERM" in
    ADMIN|MAINTAIN|WRITE) say "  gh: $GH_OWNER has $PERM on $SLUG" ;;
    "") die "gh could not read $SLUG as $GH_OWNER — token expired, or no access" ;;
    *)  die "$GH_OWNER has only $PERM on $SLUG — cannot push a branch or open a pull request" ;;
  esac
fi
say "  ok"

# --- Step 2: refuse to clobber hand edits ----------------------------------
# After any successful run the mirror is clean. Dirt therefore means someone edited it by hand,
# and the rsync below would silently overwrite that work.
say "step 2/6: checking mirror for uncommitted local edits"
DIRT="$(git -C "$MIRROR" status --porcelain)"
# This used to be fatal because the rsync below wrote straight into $MIRROR and would have
# overwritten hand edits. It no longer writes there at all -- the rsync target is the publisher's
# own worktree -- so dirt in $MIRROR endangers nothing on the write path and is reported, not
# refused. It still matters under --check, which creates no worktree and therefore computes its
# drift plan against $MIRROR as it stands; modified files there make that plan describe a base
# that is not the one a real run would use.
if [[ -n "$DIRT" && $CHECK_ONLY == 1 ]]; then
  print -r -- "$DIRT"
  die "mirror has uncommitted changes, and --check computes drift against its working tree. Commit, stash, or discard them in $MIRROR first."
fi
[[ -n "$DIRT" ]] && say "  NOTE: mirror is dirty. Left alone: the rsync, the commit and the push all happen in $WT."
[[ -z "$DIRT" ]] && say "  clean"

# --- Step 3: show what would change, before changing anything --------------
# rsync's own exclusions are performance pruning only; see the header note.
PRUNE=(
  --exclude '.git/'
  --exclude 'hook-lab/'
  --exclude '.guard-state/'
  --exclude '.turn-state/'
  --include 'quarantine/*/README.md'
  --exclude 'quarantine/*/*'
)
# .turn-state/ is the one exclusion that is NOT purely a performance prune, and the one place
# PRUNE and $MIRROR/.gitignore currently disagree. $SOURCE/.gitignore calls it "per-session
# runtime state, meaningless outside the session that wrote it"; it is rewritten on every turn, so
# leaving it in kept the --check drift report permanently non-empty, and a check that is always
# red stops being read. Excluding it here removes it from both the dry run and the copy.
#
# KNOWN DISAGREEMENT, deliberately left for a human. 61 .turn-state/*.json files are already
# tracked in the mirror from before this exclusion existed. openrsync — which is what /usr/bin/
# rsync is on this machine, protocol 29 — does not delete an excluded path even when a `risk`
# filter rule asks it to (measured 2026-08-20 against a scratch pair of directories), so this
# script cannot clear them on its own without an explicit removal inside the mirror, which is not
# a call it should make unattended. They stay as a frozen snapshot and cause no drift. Clearing
# them means adding `.turn-state/` to $MIRROR/.gitignore and untracking what is there, both by a
# human, in the mirror repo, as one reviewed change.
# The mirror owns its own /README.md and /.gitignore. The source has files of the same names at
# its root, and `protect` only stops --delete, NOT overwrite — so without these two excludes the
# source's .gitignore would silently replace the mirror's exclusion policy on the first sync.
# The source's .gitignore is still preserved, under a different name, in step 4b below.
KEEP=(
  --exclude '/README.md'
  --exclude '/.gitignore'
  --filter 'protect /README.md'
  --filter 'protect /.gitignore'
  --filter 'protect /source-state.gitignore'
  --filter 'protect /.git'
)

# --- Step 2b: the working branch -------------------------------------------
# Done BEFORE the drift dry run on purpose: checking out the branch changes the mirror's working
# tree, and a drift plan computed against the old tree would describe a base that no longer
# applies. --check never gets here, so it stays read-only and reports drift against the mirror
# exactly as it stands.
BASE_SHA=""
if [[ $CHECK_ONLY == 0 ]]; then
  say "step 2b/6: the publisher's own worktree, and the working branch $WORK_BRANCH"
  # A backup running is not a reason to move somebody's checkout. This script keeps a linked
  # worktree of its own and does every write there; $MIRROR's HEAD, branch and working tree are
  # identical before and after every run, including one that fails partway.
  git -C "$MIRROR" fetch --quiet origin || die "could not fetch origin; refusing to branch from a base that may be stale"

  # Where this session's branch should start, resolved to a commit before anything is checked out.
  if git -C "$MIRROR" show-ref --verify -q "refs/heads/$WORK_BRANCH"; then
    START="$(git -C "$MIRROR" rev-parse "refs/heads/$WORK_BRANCH")"
    START_WHY="this session's branch, already here locally"
  elif git -C "$MIRROR" show-ref --verify -q "refs/remotes/origin/$WORK_BRANCH"; then
    START="$(git -C "$MIRROR" rev-parse "refs/remotes/origin/$WORK_BRANCH")"
    START_WHY="this session's branch, fetched from origin"
  else
    git -C "$MIRROR" rev-parse --verify -q "refs/remotes/origin/$BASE_BRANCH" >/dev/null \
      || die "no origin/$BASE_BRANCH to branch from"
    START="$(git -C "$MIRROR" rev-parse "refs/remotes/origin/$BASE_BRANCH")"
    START_WHY="origin/$BASE_BRANCH -- first backup of this session"
  fi

  git -C "$MIRROR" worktree prune 2>/dev/null
  if git -C "$MIRROR" worktree list --porcelain | grep -qx "worktree $WT"; then
    # Everything in here was written by this script, so discarding what a previous run left costs
    # nobody their work, and a run that died mid-rsync cannot wedge the publisher until somebody
    # tidies up. Untracked leftovers need no separate sweep: the rsync below runs with --delete,
    # so anything in here that is not in $SOURCE is removed before the commit is built.
    git -C "$WT" checkout --detach --force --quiet "$START" || die "could not point $WT at $START"
    say "  reusing the publisher's worktree at $WT"
  elif [[ -e "$WT" ]]; then
    die "$WT exists but is not a registered worktree of $MIRROR. This script will not write into a directory it does not own; inspect it, then remove it or register it."
  else
    git -C "$MIRROR" worktree add --detach --quiet "$WT" "$START" || die "could not create the publisher's worktree at $WT"
    say "  created the publisher's worktree at $WT"
  fi

  # Attach the branch INSIDE the worktree. Git refuses to check a branch out in two worktrees at
  # once, and $MIRROR may still be parked on this very branch -- that is the residue of the old
  # shape, which left the mirror sitting on whatever it last backed up to. Rather than take the
  # branch away from that checkout (which would be moving somebody's HEAD, the thing this change
  # exists to stop) the publisher works on a clearly-named sibling branch and says so.
  # `|| true` is load-bearing, not decoration. When no worktree has this branch checked out --
  # the ordinary case, and the case for every first run of a new session -- grep matches nothing
  # and exits 1. Under `set -o pipefail` that is the pipeline's status, under `set -e` it aborts
  # the whole run, and because the abort happens inside a command substitution in an assignment
  # nothing is printed. "No holder" is a normal answer here, so it is absorbed.
  HOLDER="$(git -C "$MIRROR" worktree list --porcelain | grep -B2 -x "branch refs/heads/$WORK_BRANCH" | sed -n 's/^worktree //p' | head -1 || true)"
  if [[ -n "$HOLDER" && "$HOLDER" != "$WT" ]]; then
    say "  NOTE: $WORK_BRANCH is checked out at $HOLDER, so it is not this publisher's to move."
    WORK_BRANCH="$WORK_BRANCH-wt"
    say "  using $WORK_BRANCH instead. Move that checkout off the branch and the plain name resumes."
  fi
  if git -C "$MIRROR" show-ref --verify -q "refs/heads/$WORK_BRANCH"; then
    git -C "$WT" switch -q "$WORK_BRANCH" || die "could not switch $WT to $WORK_BRANCH"
  else
    git -C "$WT" switch -q -c "$WORK_BRANCH" || die "could not create $WORK_BRANCH in $WT"
  fi
  # Keep the session branch MERGEABLE while main moves underneath it. origin/main advances every
  # time an earlier backup pull request is merged, and a session branch stacked on a stale base
  # goes CONFLICTING — observed 2026-08-20 on PR #6, base 14 commits behind — at which point the
  # one standing pull request stops being mergeable and an unmerged backup is not a backup.
  # Folding origin/main in BEFORE the copy keeps main an ancestor of the branch, so the pull
  # request stays cleanly mergeable, without a force-push. That is why this differs from
  # sync-to-lintel.sh's reset-to-main + --force-with-lease mechanism while keeping its shape
  # (one standing branch, one pull request, updated in place): the self-merge authority granted
  # 2026-08-20 forbids force-pushes, so the base moves forward by merge, never by rewrite.
  # Content conflicts here need no judgment and none is applied: the rsync below re-imposes the
  # source tree wholesale, so `git add -A` at commit time resolves every conflicted path to
  # source truth, which is the only truth a mirror has.
  if ! git -C "$WT" merge-base --is-ancestor "refs/remotes/origin/$BASE_BRANCH" HEAD 2>/dev/null; then
    git -C "$WT" merge --no-commit --no-ff "refs/remotes/origin/$BASE_BRANCH" >/dev/null 2>&1 || true
    say "  folded origin/$BASE_BRANCH into $WORK_BRANCH; any conflicted path resolves to the source tree below"
  fi
  DEST="$WT"
  BASE_SHA="$(git -C "$WT" rev-parse --short HEAD)"
  say "  starting from $START_WHY"
  say "  on $WORK_BRANCH at $BASE_SHA in $WT; $BASE_BRANCH is not checked out, moved or pushed"
  say "  $MIRROR is untouched, still on $(git -C "$MIRROR" rev-parse --abbrev-ref HEAD)"
fi

say "step 3/6: computing drift (dry run, nothing written)"
set +e
PLAN="$(rsync -a --delete --itemize-changes --dry-run "${PRUNE[@]}" "${KEEP[@]}" "$SOURCE/" "$DEST/")"
RSYNC_RC=$?
set -e
[[ $RSYNC_RC -eq 0 ]] || die "rsync dry run failed with exit $RSYNC_RC"

if [[ -z "$PLAN" ]]; then
  say "  no file-level drift between source and mirror"
else
  CHANGED=$(print -r -- "$PLAN" | grep -c . || true)
  say "  $CHANGED path(s) would change:"
  print -r -- "$PLAN" | sed 's/^/    /'
fi

# Local-only check for commits that exist on no remote branch at all. Deliberately does NOT
# fetch, so --check stays cheap enough for a Stop hook to call often. Measured against every
# remote ref rather than origin/main on purpose: a pushed backup branch waiting in an open pull
# request is not drift, and counting it as drift would leave --check permanently red, which is
# the fastest way to make a check stop being read.
UNPUSHED="$(git -C "$DEST" rev-list --count HEAD --not --remotes 2>/dev/null || echo 0)"
[[ "$UNPUSHED" != "0" ]] && say "  $UNPUSHED local commit(s) exist on no remote branch"

if [[ $CHECK_ONLY == 1 ]]; then
  if [[ -z "$PLAN" && -z "$DIRT" && "$UNPUSHED" == "0" ]]; then
    say "=== --check: no drift. exit 0 ==="
    exit 0
  fi
  say "=== --check: DRIFT FOUND. Run without --check to back up. exit 1 ==="
  exit 1
fi

# --- Step 4: copy ----------------------------------------------------------
say "step 4/6: copying source into mirror"
rsync -a --delete "${PRUNE[@]}" "${KEEP[@]}" "$SOURCE/" "$DEST/"
say "  copied"

# Step 4b: the source's own .gitignore is part of the record and is excluded above only because
# its name collides with the mirror's policy file. Preserve it under a non-colliding name.
if [[ -f "$SOURCE/.gitignore" ]]; then
  cp "$SOURCE/.gitignore" "$DEST/source-state.gitignore"
  say "  preserved source .gitignore as source-state.gitignore"
fi

# --- Step 5: branch and commit ---------------------------------------------
say "step 5/6: committing on $WORK_BRANCH"
# Captured BEFORE the commit so the closing report names the right target.
PREV="$(git -C "$DEST" rev-parse --verify -q HEAD || echo '')"
git -C "$DEST" add -A
# A pending fold of origin/main (MERGE_HEAD, from step 2b) is always committed, even when the
# rsync itself changed nothing: leaving a merge half-done would wedge the next run, and the fold
# is what keeps the pull request mergeable.
if git -C "$DEST" diff --cached --quiet && ! git -C "$DEST" rev-parse -q --verify MERGE_HEAD >/dev/null; then
  say "  nothing to commit (mirror already matches source)"
  NEW="$PREV"
else
  # Already on $WORK_BRANCH, selected at step 2b.
  git -C "$DEST" commit -q \
    -m "state sync $(date -u '+%Y-%m-%dT%H:%M:%SZ')" \
    -m "Automated mirror of $SOURCE. Do not edit this repo by hand."
  NEW="$(git -C "$DEST" rev-parse HEAD)"
  say "  committed $NEW"
fi

# --- Step 6: push the branch and open a pull request -----------------------
if [[ "$NEW" == "$PREV" ]]; then
  say "step 6/6: nothing was committed, so there is nothing to push and no pull request to open"
  say "  the mirror is left on $WORK_BRANCH; any pull request it already has is untouched"
  say "log: $LOG"
  exit 0
fi

# --- Step 5b: credential scan, BEFORE anything leaves this machine ---------
# THE GATE MUST SIT UPSTREAM OF THE IRREVERSIBLE STEP. The push below is the moment the bytes
# leave; a human first sees them at merge, which is downstream of that. A gate after the push
# cannot catch a thing whose harm IS the push. This script had no scan at all until now: the
# same shapes were gated in sync-to-lintel.sh (staged diff) and merge-backup-pr.sh (at merge),
# and this path went out ungated.
#
# The scan runs against exactly what this branch would put on the remote: the branch measured
# against its base, the same range merge-backup-pr.sh checks. Same call shape as
# sync-to-lintel.sh -- pipe into cred_scan_stdin, refuse on a non-zero return.
#
# ⛔ THE REFUSAL NEVER PRINTS THE MATCH. Everything below is teed to $LOG, which lives next to
# this script inside a git repo -- the exact route by which a live key reached
# tools/merge-backup-pr.log on 2026-08-24. cred_scan_stdin reports pattern, count and location
# and never the matched text, which is why it is used instead of a bare grep.
CRED_SCAN_LIB="$SCRIPT_DIR/lib/credential-scan.sh"
[[ -r "$CRED_SCAN_LIB" ]] || die "credential scanner missing or unreadable at $CRED_SCAN_LIB — refusing to push unscanned. Nothing was pushed; $NEW is committed locally on $WORK_BRANCH only."
source "$CRED_SCAN_LIB"
whence -w cred_scan_stdin >/dev/null 2>&1 || die "$CRED_SCAN_LIB did not define cred_scan_stdin — refusing to push unscanned. Nothing was pushed; $NEW is committed locally on $WORK_BRANCH only."

say "step 5b/6: credential scan of what this branch would push"
if ! git -C "$DEST" diff "origin/$BASE_BRANCH...HEAD" | cred_scan_stdin "the branch $WORK_BRANCH"; then
  die "credential-shaped content in $WORK_BRANCH — NOTHING WAS PUSHED and no pull request was opened. Commit $NEW exists locally in $DEST only. Open the location named above yourself; this tool will not print it. To discard, a human deletes the branch $WORK_BRANCH in $DEST by hand."
fi
say "  credential scan of the branch: clean"

say "step 6/6: pushing $WORK_BRANCH and opening a pull request against $BASE_BRANCH"
git -C "$DEST" push -u origin "$WORK_BRANCH"
say "  pushed branch $WORK_BRANCH"

FILE_LIST="$(git -C "$DEST" show --pretty=format: --name-status "$NEW" | sed '/^$/d' | sed 's/^/- /')"
PR_TITLE="state backup $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
PR_BODY="Opened by \`orchestrator/tools/backup-state.sh\`.

**What this is.** A mirror of \`$SOURCE\` — the orchestrator's state layer, which lives inside a
git repo that deliberately has no remote. This branch carries the files that changed there since
the last backup. The mirror is machine-written; nobody edits it by hand.

**Why a pull request.** The script does not push $BASE_BRANCH and cannot merge this. A human
merges it after a look. That look is a review of content, not a last chance to stop a leak: this
branch is already on the remote by the time anyone reads it, so anything that should not have left
the machine has already left. What guards that is the credential scan the script runs before the
push (step 5b), which refuses the push outright on a hit.

**Files changed in this backup:**

$FILE_LIST

**To reject:** close this pull request without merging and delete the branch. That reverses the
whole run and destroys nothing — $BASE_BRANCH never moved.

Base of this branch: \`$BASE_SHA\`. Commit: \`$NEW\`."

EXISTING_PR="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr list --repo "$GH_OWNER/$GH_REPO" --head "$WORK_BRANCH" --state open --json number -q '.[0].number' 2>/dev/null || echo '')"
if [[ -n "$EXISTING_PR" ]]; then
  GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr edit "$EXISTING_PR" --repo "$GH_OWNER/$GH_REPO" \
    --title "$PR_TITLE" --body "$PR_BODY" >/dev/null
  PR_URL="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr view "$EXISTING_PR" --repo "$GH_OWNER/$GH_REPO" --json url -q .url)"
  say "  updated existing pull request #$EXISTING_PR"
else
  PR_URL="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr create --repo "$GH_OWNER/$GH_REPO" \
    --base "$BASE_BRANCH" --head "$WORK_BRANCH" --title "$PR_TITLE" --body "$PR_BODY")"
  say "  opened pull request"
fi
say "  $PR_URL"

# --- Reversal --------------------------------------------------------------
# The reversal is described in prose, NOT emitted as a pasteable destructive command.
# An earlier version of this block assembled the literal command out of string fragments,
# with a comment saying it was done so a shell-history or hook scanner would not see it.
# That is evasion of a safety control on this machine and it has been removed. If a
# reversal is ever needed, a human types it knowingly; this script does not pre-write it.
say "=== done. $NEW is on branch $WORK_BRANCH, waiting for review in a pull request ==="
say "TO REVERSE THIS RUN: close the pull request without merging and delete the branch"
say "  $WORK_BRANCH. That drops this session's backup commits, which is every run made in this"
say "  session, since they share one branch by design. Nothing reached $BASE_BRANCH, so no reset, no force"
say "  push, and nothing destructive is involved. The mirror is left checked out on"
say "  $WORK_BRANCH; a human decides what to do with that branch."
say "  pull request: $PR_URL"
say "log: $LOG"

#!/usr/bin/env python3
"""reality-check-sample.py — build a verification brief for a rotating sample of owed rows.

WHAT THIS IS, AND WHAT IT DELIBERATELY IS NOT. It does NOT decide whether a row's claim is true.
It gathers, for a small sample of still-owed rows, every artifact the row's note names that a
machine can locate, checks what is mechanically checkable about each, and writes a brief for a
HUMAN OR A DISPATCHED WORKER to finish. The judgment stays with whoever reads the brief.

WHY IT STOPS SHORT OF DECIDING, AND THIS IS A MEASUREMENT RATHER THAN A PREFERENCE. Five
mechanical instruments were built and measured against the live ledger on 2026-08-24, each trying
to decide from note prose alone whether a row's claim still matches the world:

  negative-existence phrase near a path   7 pairs      2 findings, BOTH false positives
  run-report path existence               39 refs      0 findings — cannot disconfirm today
  pull-request state                      12 refs      unusable: 11 of 12 never name their repo
  absolute-path existence                 51 paths     17 "missing", ~7 punctuation artifacts,
                                                       the rest legitimately-removed backups
  file:line citation past end-of-file     53 cites     14 resolvable, 0 stale — cannot disconfirm

The two false positives are the whole argument. On REQ-239 the phrase "TASKS.md is absent"
attached itself to the mirror DIRECTORY, which exists. On REQ-253 "not installed" attached to
`settings.json`, which merely sat nearby. PROXIMITY IS NOT ATTACHMENT. The note is prose written
for a human: the claim and the artifact live in the same sentence with nothing marking which claim
is about which artifact, so no window size recovers the link.

THE ROTATION, WHICH IS THE ONE REAL DESIGN DECISION HERE. The sample is not random. Rows are
sorted by id and a window advances by day, so a row is not looked at twice before every row has
been looked at once. Random sampling would resample the same rows while others waited forever;
this reaches every owed row within a bounded number of runs and the report says which day's window
it is showing.

Exit codes: 0 brief written | 2 could not run.
"""

import argparse, datetime, json, os, re, sys

TERMINAL_DEFAULT_REFUSED = True  # see load_states(): the vocabulary is never hardcoded here.

ABS_PATH = re.compile(r"(?:~|/Users/jowolff)[A-Za-z0-9._/+-]*[A-Za-z0-9._/-]")
CITE = re.compile(r"\b([A-Za-z0-9._/-]+\.(?:sh|py|mjs|js|ts|md|json|yaml|yml))\s*:\s*(\d+)(?:-(\d+))?")
RUN_REF = re.compile(r"\bruns/([A-Za-z0-9._-]+)/(reports|artifacts)/([A-Za-z0-9._-]+\.md)")
PR_REF = re.compile(r"(?:PR|pull request)\s*#(\d+)", re.I)
PR_URL = re.compile(r"https://github\.com/([A-Za-z0-9._-]+/[A-Za-z0-9._-]+)/pull/(\d+)")


def die(msg):
    print(f"reality-check-sample: CANNOT RUN — {msg}", file=sys.stderr)
    sys.exit(2)


def clean_path(p):
    """Strip trailing sentence punctuation; refuse anything elided with an ellipsis.

    Both of these were real defects in the first pass: 7 of 17 'missing' paths were the same path
    with a full stop attached, and two more were prose elisions ending in '...'. A checker that
    reports a punctuation artifact as a missing file has spent a human's attention on nothing.
    """
    p = p.rstrip(".,;:)]}'\"")
    if "..." in p or p.endswith("/"):
        return None
    if p.startswith("~"):
        p = "/Users/jowolff" + p[1:]
    # A bare "/Users/jowolff" or a fragment shorter than that is prose, not a path.
    return p if len(p) > len("/Users/jowolff/") else None


def load_rows(path):
    rows = []
    try:
        with open(path, encoding="utf-8") as fh:
            for n, line in enumerate(fh, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError as e:
                    die(f"{path}:{n} is not valid JSON: {e}")
    except OSError as e:
        die(f"cannot read the ledger at {path}: {e}")
    if not rows:
        die(f"{path} contained no rows")
    return rows


def artifacts(note, orch):
    """Everything in this note a machine can locate. Existence only — never interpretation."""
    out = {"paths": [], "cites": [], "runs": [], "prs": []}

    # Deduplicate AFTER cleaning, not before: `/Users/jowolff/.claude` and the same path with a
    # sentence-ending full stop are two distinct raw matches that normalise to one path, and
    # deduplicating the raw forms listed it twice in the first live run.
    seen_paths = []
    for raw in ABS_PATH.findall(note):
        p = clean_path(raw)
        if p and p not in seen_paths:
            seen_paths.append(p)
            out["paths"].append((p, os.path.exists(p)))

    for f, ln, _ in dict.fromkeys(CITE.findall(note)):
        out["cites"].append((f, int(ln)))

    for run, sub, fn in dict.fromkeys(RUN_REF.findall(note)):
        p = os.path.join(orch, "state", "runs", run, sub, fn)
        out["runs"].append((f"runs/{run}/{sub}/{fn}", os.path.exists(p)))

    # A pull-request number is only checkable when the repository is named. Measured 2026-08-24:
    # 11 of 12 references in owed rows never name theirs, and guessing would produce a wrong-repo
    # lookup wearing the authority of a real one.
    with_repo = {(repo, num) for repo, num in PR_URL.findall(note)}
    out["prs"] = [(repo, num, True) for repo, num in with_repo]
    named = {num for _, num in with_repo}
    for num in dict.fromkeys(PR_REF.findall(note)):
        if num not in named:
            out["prs"].append((None, num, False))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ledger", required=True)
    ap.add_argument("--orch", required=True)
    ap.add_argument("--nonterminal", required=True, help="whitespace-separated, from request-states.sh")
    ap.add_argument("--size", type=int, default=8)
    ap.add_argument("--day", default="", help="YYYY-MM-DD; selects the rotation window")
    args = ap.parse_args()

    nonterminal = set(args.nonterminal.split())
    if not nonterminal:
        die("no non-terminal vocabulary supplied by the front door")

    rows = load_rows(args.ledger)
    owed = sorted([r for r in rows if r.get("state") in nonterminal], key=lambda r: r["id"])
    if not owed:
        die("no owed rows to sample")

    day = args.day or datetime.date.today().isoformat()
    try:
        epoch = datetime.date.fromisoformat(day).toordinal()
    except ValueError:
        die(f"--day must be YYYY-MM-DD, got {day!r}")

    size = max(1, min(args.size, len(owed)))
    windows = (len(owed) + size - 1) // size
    start = (epoch % windows) * size
    sample = owed[start:start + size]
    if len(sample) < size:                       # last window wraps rather than running short
        sample += owed[: size - len(sample)]

    o = []
    w = o.append
    w("# Reality-check brief — a sample of owed rows, against the world")
    w("")
    w(f"Generated for **{day}**. Ledger: `{args.ledger}`")
    w("")
    w("**This brief decides nothing.** It lists what each sampled row's note names and what is "
      "mechanically true of those artifacts right now. Whether the row's *claim* still holds is a "
      "judgment, and it is left to whoever reads this.")
    w("")
    w("## What was NOT looked at")
    w("")
    w(f"**{len(owed) - len(sample)} of {len(owed)} owed rows were not sampled.** This is window "
      f"{(epoch % windows) + 1} of {windows}; at {size} rows per run every owed row is reached "
      f"within {windows} runs, and no row repeats before all have been seen once. **A clean result "
      "below is a statement about these rows on this day and about nothing else.**")
    w("")
    w("## The rows")
    w("")
    for r in sample:
        note = r.get("note", "") or ""
        a = artifacts(note, args.orch)
        w(f"### `{r['id']}` — {r.get('state')}")
        w("")
        w(f"**Asked for:** {r.get('request','')}")
        w("")
        if a["paths"]:
            w("| Path named in the note | On disk now |")
            w("|---|---|")
            for p, ex in a["paths"]:
                w(f"| `{p}` | {'yes' if ex else '**NO**'} |")
            w("")
        if a["runs"]:
            w("| Run report named | Present |")
            w("|---|---|")
            for p, ex in a["runs"]:
                w(f"| `{p}` | {'yes' if ex else '**NO**'} |")
            w("")
        if a["cites"]:
            w("Line citations to re-derive rather than trust — a line number drifts silently the "
              "moment anything above it is edited: "
              + ", ".join(f"`{f}:{ln}`" for f, ln in a["cites"]))
            w("")
        if a["prs"]:
            checkable = [f"`{repo}#{num}`" for repo, num, ok in a["prs"] if ok]
            bare = [f"`#{num}`" for repo, num, ok in a["prs"] if not ok]
            if checkable:
                w("Pull requests, repository named and therefore checkable: " + ", ".join(checkable))
            if bare:
                w("Pull requests named **without a repository**, so not checkable from this note "
                  "alone — do not guess which repo: " + ", ".join(bare))
            w("")
        if not any(a.values()):
            w("**This note names no locatable artifact.** Nothing here is mechanically checkable; "
              "verifying it means reading the note and going to look.")
            w("")
        w("**The question for the reader:** the note below says work is still owed. Is that still "
          "true in the world? Read it, check what it claims, and say plainly if the row should "
          "have moved.")
        w("")
        w("<details><summary>note</summary>")
        w("")
        w("```")
        w(note if len(note) < 6000 else note[:6000] + "\n…truncated at 6000 chars…")
        w("```")
        w("")
        w("</details>")
        w("")

    w("## What this brief cannot tell you")
    w("")
    w("1. **Whether a named path being absent is a defect.** Most absent paths in this ledger are "
      "backups that were deliberately removed. Absence is a prompt to read, never a finding.")
    w("2. **Which claim in a note is about which artifact.** They share a sentence and nothing "
      "marks the link. Measured 2026-08-24: attaching a claim to the nearest path produced two "
      "findings and both were wrong.")
    w("3. **Whether the work is finished.** That is the whole question and no file on disk answers "
      "it. This brief exists to make going and looking cheap, not to replace it.")
    w("4. **Anything outside `/Users/jowolff`.** The path matcher is rooted at the home directory, "
      "so a note referring to `/etc`, `/opt`, `/usr` or a Docker path is not looked at and does not "
      "appear above. Found by this tool's own selftest, whose first fixture used `/etc/hosts` and "
      "was silently seen as naming no artifact at all.")
    print("\n".join(o))
    return 0


if __name__ == "__main__":
    sys.exit(main())

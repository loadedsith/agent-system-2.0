#!/usr/bin/env python3
# issues-ledger-check.py — the validator behind issues-ledger-check.sh. Not run directly:
# the shell front door owns preflight, the state vocabulary, and where the issue list comes
# from. This file only compares two inputs it is handed via environment variables:
#
#   ILC_TERMINAL     terminal state names, whitespace-separated   (from request-states.sh)
#   ILC_NONTERMINAL  non-terminal state names, likewise
#   ILC_SOURCE       where the vocabulary came from (for the report)
#   ILC_LEDGER       path to REQUESTS.jsonl
#   ILC_ISSUES       path to a file holding the issue list as GitHub API JSON —
#                    either one array, or several arrays concatenated (gh api --paginate).
#                    ALL issues, open and closed. Every item MUST carry a "state" field;
#                    see the scoping note below for why that is required rather than defaulted.
#
# WHY THIS READS CLOSED ISSUES TOO, AND WHY THAT WAS NOT A ONE-WORD CHANGE. Until 2026-08-24 the
# front door asked for open issues only, and every check here was written against a set it could
# assume was open. Widening the fetch makes that assumption false for all of them AT ONCE, so each
# check below now states its own scope explicitly instead of inheriting one from the caller.
# Measured against the live tracker on 2026-08-24 before the change: widening the fetch without
# re-scoping would have flagged 5 CORRECT pairings as defects (a closed issue naming a delivered
# row is the pairing rule working), flagged 1 legitimate re-file as a one-to-one violation
# (REQ-243 named by open #112 and closed #108), and silently absorbed closed issues into the
# "is this row tracked" set — which would have turned the untracked check off for exactly the rows
# the new check exists to find.
#
# A MISSING "state" FIELD IS EXIT 2, NOT AN ASSUMED DEFAULT. Same rule the front door follows about
# the terminal vocabulary: guessing here would silently re-scope every check on this page.
#
# Exit codes: 0 they agree | 1 they disagree | 2 could not run.

import json, os, sys

from request_issues_reconcile import classify_row, issue_join_keys

def env(name):
    v = os.environ.get(name, "")
    if not v:
        print(f"FAIL: {name} not supplied by the front door", file=sys.stderr)
        sys.exit(2)
    return v

terminal = set(env("ILC_TERMINAL").split())
nonterminal = set(env("ILC_NONTERMINAL").split())
source = os.environ.get("ILC_SOURCE", "(unstated)")

# --- the ledger ------------------------------------------------------------
rows = {}
try:
    with open(env("ILC_LEDGER")) as f:
        for n, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                # Row validity is requests-schema-check.sh's job, not this checker's.
                # An unparseable line still cannot be silently invisible to the join.
                print(f"FAIL: ledger line {n} is not JSON — run requests-schema-check.sh first",
                      file=sys.stderr)
                sys.exit(2)
            rows[r.get("id", f"?L{n}")] = r
except OSError as e:
    print(f"FAIL: could not read the ledger: {e}", file=sys.stderr)
    sys.exit(2)

# --- the issues, open and closed -------------------------------------------
# gh api --paginate emits one JSON array per page, concatenated. raw_decode walks them all.
try:
    with open(env("ILC_ISSUES")) as f:
        blob = f.read()
except OSError as e:
    print(f"FAIL: could not read the issue list: {e}", file=sys.stderr)
    sys.exit(2)

issues = []
dec = json.JSONDecoder()
i, n = 0, len(blob)
try:
    while i < n:
        while i < n and blob[i].isspace():
            i += 1
        if i >= n:
            break
        page, i = dec.raw_decode(blob, i)
        issues.extend(page if isinstance(page, list) else [page])
except json.JSONDecodeError as e:
    print(f"FAIL: the issue list is not parseable GitHub JSON: {e}", file=sys.stderr)
    sys.exit(2)


# --- partition once, explicitly --------------------------------------------
# The issues endpoint lists pull requests too; this repo should have none.
issues = [it for it in issues if "pull_request" not in it]

open_issues, closed_issues = [], []
for iss in issues:
    st = iss.get("state")
    if st is None:
        print(f"FAIL: issue #{iss.get('number', '?')} carries no \"state\" field — the issue list "
              "must come from an endpoint that reports it. Refusing to assume it is open, because "
              "that assumption silently re-scopes every check in this file.", file=sys.stderr)
        sys.exit(2)
    (open_issues if st == "open" else closed_issues).append(iss)

problems = []

# --- checks over the OPEN issues only ---------------------------------------
# Scope stated here rather than inherited from what the caller happened to fetch.
seen = {}  # REQ id -> OPEN issue number that carries it
for iss in open_issues:
    num = iss.get("number", "?")
    ids = sorted(issue_join_keys(iss))
    if not ids:
        problems.append(
            f"  #{num}  open issue with no REQ-NNN in its title or 'Ledger row:' marker "
            "— it cannot be joined to the ledger"
        )
        continue
    for rid in ids:
        row = rows.get(rid)
        if row is None:
            problems.append(f"  #{num}  names {rid}, which does not exist in the ledger")
            continue
        applicable, _ = classify_row(row)
        if not applicable:
            continue
        if rid in seen:
            problems.append(f"  {rid}  named by two open issues, #{seen[rid]} and #{num} — the join must be one-to-one")
            continue
        seen[rid] = num
        state = row.get("state", "?")
        if state in terminal:
            problems.append(f"  #{num}  is open but {rid} is terminal ({state}) — finished business shown as a live obligation")

# COLLAPSED TO ONE LINE (2026-08-28, on Jo's instruction). This loop emitted one line per row and
# on 2026-08-28 that was TWELVE consecutive lines differing only in an identifier — the same
# sentence twelve times. Every id and every state is still reported; only the repetition is gone.
# Grouped BY STATE rather than flattened, because "open" and "partial" are different obligations
# and a reader deciding what to do next needs that split. Sorted so two runs over unchanged state
# produce identical output and a diff means something.
_orphans = [
    (rid, row.get("state", "?"))
    for rid, row in rows.items()
    if classify_row(row)[0]
    and row.get("state") in nonterminal
    and rid not in seen
]
if _orphans:
    _by_state = {}
    for _rid, _state in _orphans:
        _by_state.setdefault(_state, []).append(_rid)
    _detail = "; ".join(
        f"{', '.join(sorted(_ids))} ({_st})" for _st, _ids in sorted(_by_state.items())
    )
    problems.append(
        f"  {len(_orphans)} row(s) still owed but no open issue names them — "
        f"work the tracker never shows: {_detail}"
    )

# --- the check over the CLOSED issues ---------------------------------------
# THE HALF-DONE UPDATE, WHICH IS THE DEFECT THIS WHOLE CLASS EXISTS FOR. Somebody closed the issue
# and did not move the row. Jo found one of these by eye on 2026-08-24 while all three join
# checkers were green, because each of them tested only whether an identifier appeared on both
# sides — never whether the two sides said the same thing about it.
#
# "AND NO OPEN ISSUE NAMES IT" IS LOAD-BEARING, NOT A HEDGE. A row whose issue was closed and
# RE-FILED under a new number is still tracked, and the closed issue is history rather than a
# defect. Measured on the live tracker 2026-08-24: REQ-243 is named by open #112 and closed #108,
# and without this clause it would have been the check's first and only "finding" — a false
# positive on its debut, which is exactly how a checker gets muted.
for iss in closed_issues:
    num = iss.get("number", "?")
    for rid in sorted(issue_join_keys(iss)):
        row = rows.get(rid)
        if (
            row is not None
            and classify_row(row)[0]
            and row.get("state") in nonterminal
            and rid not in seen
        ):
            problems.append(
                f"  #{num}  is closed but {rid} is still owed ({row['state']}) and no open issue "
                "names it — the issue was closed and the row was not moved"
            )

if problems:
    print(f"FAIL: the issue tracker disagrees with the ledger ({len(problems)} problem(s)).")
    print(f"      vocabulary: {source}")
    for p in sorted(problems):
        print(p)
    sys.exit(1)

owed = sum(
    1
    for row in rows.values()
    if classify_row(row)[0] and row.get("state") in nonterminal
)
print(f"OK: {owed} applicable still-owed row(s), each named by exactly one open issue; no open "
      f"issue names terminal or missing applicable rows; no closed issue leaves an applicable "
      f"owed row untracked. Checked {len(open_issues)} open and {len(closed_issues)} closed "
      f"issue(s). vocabulary: {source}")
sys.exit(0)

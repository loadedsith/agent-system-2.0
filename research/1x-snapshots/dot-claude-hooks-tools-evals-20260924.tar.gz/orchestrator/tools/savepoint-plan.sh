#!/usr/bin/env zsh
# savepoint-plan — per-section byte CAPS for the save point, so it is written to fit in one pass
# instead of trimmed to fit over many.
#
# WHY THIS EXISTS, AND WHY IT IS NOT savepoint-fit.sh.
#
# savepoint-fit.sh answers "does it fit, and which section falls off the cliff." That tool is
# already good and is already invoked automatically: savepoint-fit-stop.mjs runs it on every
# orchestrator stop and blocks the stop when it exits 1. Information was never the missing piece.
#
# What was missing is a TARGET BELOW THE LIMIT and a CAP PER SECTION. Measured on
# /Users/jowolff/.claude, git history of orchestrator/state/STANDUP.md, 2026-08-20:
#
#   162 commits touched the file that day.
#    94 of those 162 commits were OVER the 6000-byte budget.
#    14 separate runs of >=2 consecutive shrinking-and-still-oversize commits, covering 82
#       commits. Longest run: 13 commits, 09:51:08 -> 10:07:54, 18761 bytes down to 6013.
#    25 commits landed 1-25 bytes OVER the limit.
#    29 commits landed 1-25 bytes UNDER it.
#
# Those last two numbers are the whole diagnosis. A third of the day was spent oscillating inside
# a +/-25-byte band around the ceiling. savepoint-fit.sh calls 5,999 bytes "FITS" and exits, so
# the state that guarantees the next edit breaks the file reads as a pass. The fix is not more
# measurement of the overage; it is refusing to aim at 6000 in the first place.
#
# THE RULE THIS TOOL ENCODES: aim at 5400, not 6000. Ten percent headroom means one added
# sentence does not restart the loop. Every section gets its own cap, so an over-cap section is a
# LOCAL edit with a known byte target -- which converges in one pass -- rather than a global trim
# guessed in characters against a budget denominated in bytes.
#
# NO DUPLICATED MEASUREMENT. Budget and per-section bytes both come from
# `savepoint-fit.sh --tsv`. This script never parses savepoint-restore.sh and never counts a byte
# of the document itself. If the budget moves, it moves here too, with no edit.
#
# READ-ONLY. Never writes, trims, or moves the save point. --skeleton prints to stdout only.
#
# EXIT: 0 within the target. 1 within budget but over target (the headroom trap). 2 over budget or
# on a usage/IO error.
#
# USAGE:
#   savepoint-plan.sh                      # cap check on the live STANDUP.md
#   savepoint-plan.sh /path/draft.md       # cap check on a draft before installing it
#   savepoint-plan.sh --skeleton           # the shape to write a fresh save point into
#   savepoint-plan.sh --target 5000 FILE   # a tighter target

set -u
emulate -L zsh
setopt pipefail

HERE="${0:A:h}"
FIT="$HERE/savepoint-fit.sh"

# Default target = 90% of whatever budget savepoint-fit resolves. Expressed as a percentage rather
# than a constant so it tracks a moved budget instead of silently becoming the wrong fraction.
TARGET_PCT=90
target_override=""
mode="check"
file=""

while (( $# )); do
  case "$1" in
    -h|--help)     sed -n '2,45p' "$0"; exit 2 ;;
    --skeleton)    mode="skeleton"; shift ;;
    --target)      target_override="${2:-}"; shift 2 ;;
    --target=*)    target_override="${1#--target=}"; shift ;;
    -*)            print -u2 "savepoint-plan: unknown flag: $1"; exit 2 ;;
    *)             file="$1"; shift ;;
  esac
done

if [[ ! -x "$FIT" && ! -r "$FIT" ]]; then
  print -u2 "savepoint-plan: cannot read $FIT -- it is the only source of the budget. Stopping."
  exit 2
fi

# --------------------------------------------------------------------------------------------
# MEASURE VIA savepoint-fit.sh --tsv. Its exit code is 0 fits / 1 over; either is a usable read,
# so the status is captured rather than allowed to kill the script under pipefail.
# --------------------------------------------------------------------------------------------
tsv=""
if [[ -n "$file" ]]; then
  tsv=$(zsh "$FIT" --tsv "$file" 2>&1) || true
else
  tsv=$(zsh "$FIT" --tsv 2>&1) || true
fi

budget=$(print -r -- "$tsv" | LC_ALL=C /usr/bin/awk -F'\t' '$1=="budget"{print $2; exit}')
total=$(print -r -- "$tsv"  | LC_ALL=C /usr/bin/awk -F'\t' '$1=="total"{print $2; exit}')

if [[ -z "$budget" || -z "$total" ]]; then
  print -u2 "savepoint-plan: could not read budget/total from savepoint-fit.sh --tsv. Output was:"
  print -u2 -- "$tsv"
  exit 2
fi

if [[ -n "$target_override" ]]; then
  if [[ "$target_override" != <-> ]] || (( target_override <= 0 )); then
    print -u2 "savepoint-plan: --target wants a positive integer, got: $target_override"
    exit 2
  fi
  target=$target_override
  target_src="--target"
else
  target=$(( budget * TARGET_PCT / 100 ))
  target_src="${TARGET_PCT}% of the ${budget}-byte budget"
fi

# --------------------------------------------------------------------------------------------
# SKELETON MODE. The section ROLES are measured, not invented: across 14 sampled revisions of
# STANDUP.md from 2026-08-20, these headings are the ones that recur (frequency in parentheses).
# Everything else in the file's history was a one-off narrative heading naming a specific REQ,
# which is why this is a set of roles with caps and not a fixed set of titles to copy verbatim.
# Caps are the target split in the proportions the 2026-08-20 16:40 revision actually used,
# rounded to 50 bytes, with the remainder left explicitly unallocated.
# --------------------------------------------------------------------------------------------
if [[ "$mode" == "skeleton" ]]; then
  print -r -- "SAVE POINT SKELETON -- target ${target} bytes (${target_src}), budget ${budget}."
  print -r -- ""
  print -r -- "Write to the cap. Do not write past it and trim later; that is the loop this avoids."
  print -r -- ""
  printf '%6s  %s\n' 'CAP' 'SECTION ROLE'
  printf '%6s  %s\n' '------' '---------------------------------------------------------------'
  caps=(450 300 550 650 650 750 1000 350 250)
  roles=(
    'title line + orientation before the first ## heading'
    'NEXT ACTION -- the single first thing (recurs 13/14 revisions)'
    'UNFINISHED / IN FLIGHT -- where to re-read, not what to re-invent (7/14)'
    'OPEN OBLIGATIONS -- what is owed and to whom (9/14)'
    'WAITING ON JO / ALSO NEEDS JO -- decisions not yours to make (6/14)'
    'DECISIONS -- DO NOT RE-LITIGATE (7/14, as DROPPED BY JO)'
    'LANDED -- DO NOT REDO'
    'MISTAKES / RETRACTIONS -- pointer only, full text lives elsewhere'
    'STANDING -- only what is written nowhere else (9/14)'
  )
  allocated=0
  for i in {1..${#caps}}; do
    printf '%6d  %s\n' "${caps[i]}" "${roles[i]}"
    allocated=$(( allocated + caps[i] ))
  done
  print -r -- ""
  printf 'allocated %d of the %d-byte target; %d left unallocated on purpose.\n' \
    "$allocated" "$target" "$(( target - allocated ))"
  print -r -- ""
  print -r -- "Two byte facts that make a character estimate wrong:"
  print -r -- "  a heading line costs its own length + 1 for the newline"
  print -r -- "  every em dash, arrow, or emoji costs 2-3 bytes and looks like 1 character"
  print -r -- ""
  print -r -- "Then check the draft: zsh ${0:A} /path/to/draft.md"
  exit 0
fi

# --------------------------------------------------------------------------------------------
# CHECK MODE. VERDICT FIRST -- against the TARGET, which is the point of the tool. "Fits the
# budget with 4 bytes to spare" is the failure state this verdict is designed to stop reporting
# as a success.
# --------------------------------------------------------------------------------------------
if (( total > budget )); then
  print -r -- "OVER BUDGET by $(( total - budget )) bytes. Content is being dropped right now."
  verdict=2
elif (( total > target )); then
  print -r -- "NO HEADROOM: ${total} bytes. Inside the ${budget} budget, past the ${target} target by $(( total - target ))."
  verdict=1
else
  print -r -- "OK: ${total} bytes, $(( target - total )) under target, $(( budget - total )) under budget."
  verdict=0
fi

print -r -- ""
print -r -- "target: ${target} bytes [${target_src}]"
print -r -- ""

# The section inventory comes from savepoint-fit.sh --tsv; nothing is re-counted here.
n_sec=$(print -r -- "$tsv" | LC_ALL=C /usr/bin/grep -c '^section')
if (( n_sec == 0 )); then
  print -r -- "No '## ' sections found. Nothing to allocate; the whole file is one block."
  exit $verdict
fi

# ONE EDIT TARGET, NOT TEN. An earlier draft of this printed a proportional per-section CAP and
# an OVER column, which put every one of the ten sections a few dozen bytes over at once. That is
# the same diffuse global trim savepoint-fit.sh's trim plan already produces, and it is the thing
# that does not converge: ten simultaneous 30-byte edits are ten chances to mis-estimate. So the
# whole deficit is assigned to the LARGEST section instead. One section, one number, one edit.
deficit=$(( total > target ? total - target : 0 ))

big_bytes=$(print -r -- "$tsv" | LC_ALL=C /usr/bin/awk -F'\t' \
  '$1=="section" && $2+0 > m { m = $2+0; n = $4 } END { print m+0 }')
big_name=$(print -r -- "$tsv" | LC_ALL=C /usr/bin/awk -F'\t' \
  '$1=="section" && $2+0 > m { m = $2+0; n = $4 } END { print n }')

# A LADDER, BECAUSE ONE RULE DOES NOT COVER THE RANGE. Measured against real revisions of the
# save point, the deficit ran from 13 bytes to 13361, and a single rule is wrong at one end or the
# other. The first draft of this offered only "cut N from the largest section" with a 40% ceiling,
# and on four of five sampled historical revisions it fell straight through to "move a section
# out" -- true but not actionable. Each rung below is one edit.
#   rung 1  deficit fits inside 40% of the largest section  -> trim that section
#   rung 2  some single section is at least as big as the deficit -> remove that section whole
#   rung 3  neither -> the file is not repairable by editing; rewrite it from the skeleton
if (( deficit > 0 )); then
  # Smallest section that is on its own >= the deficit. Removing it clears the overage in one cut,
  # and smallest-that-suffices loses the least content.
  absorber_bytes=$(print -r -- "$tsv" | LC_ALL=C /usr/bin/awk -F'\t' -v d="$deficit" \
    '$1=="section" && $2+0 >= d && (m == 0 || $2+0 < m) { m = $2+0; n = $4 } END { print m+0 }')
  absorber_name=$(print -r -- "$tsv" | LC_ALL=C /usr/bin/awk -F'\t' -v d="$deficit" \
    '$1=="section" && $2+0 >= d && (m == 0 || $2+0 < m) { m = $2+0; n = $4 } END { print n }')

  if (( deficit * 100 <= big_bytes * 40 )); then
    print -r -- "ONE EDIT -- TRIM. Cut ${deficit} bytes from \"${big_name}\"."
    print -r -- "  it is ${big_bytes} bytes now; take it to $(( big_bytes - deficit )) and re-run."
  elif (( absorber_bytes > 0 )); then
    print -r -- "ONE EDIT -- REMOVE A SECTION. ${deficit} bytes is more than 40% of the largest"
    print -r -- "section, so trimming means rewriting it. Cheaper: cut this section whole and leave"
    print -r -- "a one-line pointer to where its content lives."
    print -r -- "  \"${absorber_name}\" -- ${absorber_bytes} bytes, clears the ${deficit} with $(( absorber_bytes - deficit )) spare."
  else
    print -r -- "NOT REPAIRABLE BY EDITING. ${deficit} bytes over target and no single section is"
    print -r -- "that big (largest is ${big_bytes}). Every path here is a multi-section rewrite, and"
    print -r -- "the measured record says iterative trimming does not converge from this state."
    print -r -- "Rewrite from the skeleton in one pass:  zsh ${0:A} --skeleton"
  fi
  print -r -- ""
fi

printf '%8s  %6s  %s\n' 'BYTES' '%FILE' 'SECTION (largest first)'
printf '%8s  %6s  %s\n' '--------' '------' '------------------------------------------------'
print -r -- "$tsv" | LC_ALL=C /usr/bin/awk -F'\t' -v tot="$total" '
  $1 == "section" { b[++n] = $2; nm[n] = $4 }
  END {
    for (i = 1; i <= n; i++) for (j = i + 1; j <= n; j++)
      if (b[j] + 0 > b[i] + 0) { t = b[i]; b[i] = b[j]; b[j] = t; s = nm[i]; nm[i] = nm[j]; nm[j] = s }
    for (i = 1; i <= n; i++)
      printf "%8d  %5.1f%%  %s\n", b[i], (tot ? 100 * b[i] / tot : 0), nm[i];
  }'

print -r -- ""
if (( verdict == 0 )); then
  print -r -- "Within target with $(( target - total )) bytes of headroom. Nothing to cut."
  exit 0
fi

print -r -- "Caps for a fresh one-pass rewrite: zsh ${0:A} --skeleton"
print -r -- ""
print -r -- "Nothing here modified the file."
exit $verdict

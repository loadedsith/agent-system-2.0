#!/usr/bin/env node
/**
 * charter-ladder.mjs — run the new-seat rule ladder against ANY charter, generated or adopted,
 * and REFUSE the launch when a defining rule cannot be found.
 *
 * ⛔ WHY THIS EXISTS, AND IT IS NOT "the ladder was never automated".
 * `skills/new-seat/SKILL.md` step 3 already carries the ladder as a shell snippet, and already
 * admits its own bound: "a generation-time check only fires if the generating agent runs it.
 * Nothing enforces it." That is a declared inertness, not a hidden one.
 *
 * The gap this closes is narrower and was written down nowhere: THERE IS NO PATH AT ALL FOR A
 * CHARTER THE SKILL DID NOT GENERATE. Measured 2026-08-26 — Wren's charter was hand-written on
 * 2026-08-20, before the template existed, and ADOPTED as a seat's charter rather than generated
 * from it. It carried no decision-log obligation for six days. The skill's own bar says a charter
 * missing that section "is not a seat — regenerate it, do not hand it over", and nothing on this
 * machine was in a position to apply that bar, because every check fires at generation.
 *
 * ⛔ IT REFUSES; IT DOES NOT WARN. A hook that exits 0 is a rule with a log file. The two
 * decision-log ids are hard stops. Everything else is reported and does not block, because a
 * check that cries wolf gets ignored, and its silence then starts being mistaken for assurance.
 *
 * ⛔ EVERY REFUSAL NAMES THE LEGAL PATH. A deny that says no without saying what would have been
 * allowed turns a collision into a stall, and a stalled background seat is invisible until a
 * human notices.
 *
 * ── THE TIERS, unchanged from SKILL.md step 3 ────────────────────────────────────────────────
 *   tier1  probe found AND the template's heading is present.
 *   tier2  probe found, heading absent. A LEGITIMATE RESTRUCTURE. Passes with a note. This must
 *          not be reported as a failure — briefs customize structure.
 *   TIER3  probe absent, whatever the heading says. The evidence is missing, and a present
 *          heading is not a defence: the id reached tier 3 because the evidence is gone, and the
 *          heading was never the evidence.
 *
 * A script cannot do tier 3's judgment half — SKILL.md says tier 3 is where an agent reads the
 * file and places the rule by hand or declares it unplaceable. So this tool does NOT pretend to:
 * it reports TIER3 for every id it cannot probe, blocks only on the required ones, and names the
 * acknowledgement flag as the way a human or agent records a genuine restructure.
 *
 * ── USAGE ────────────────────────────────────────────────────────────────────────────────────
 *   node charter-ladder.mjs --charter <path> [--template <path>] [--acknowledge-unplaceable=id,id]
 *   node charter-ladder.mjs --selftest
 *
 * EXIT 0 pass (or every required miss acknowledged) · 1 REFUSED · 2 usage or I/O error.
 *
 * ── REVERSAL ─────────────────────────────────────────────────────────────────────────────────
 * Delete this file and remove the `[+] charter rule ladder` block from any launcher calling it.
 * A launcher that cannot find this script prints a DEGRADED line and launches anyway, so
 * deleting it alone is sufficient and cannot brick a launch.
 */

import { readFileSync, existsSync } from 'node:fs';

const DEFAULT_TEMPLATE =
  '/Users/jowolff/.claude/skills/new-seat/references/charter-template.md';

// ⛔ THE ONLY IDS THAT BLOCK. Both from Jo, via SKILL.md § "Two obligations that define a seat":
// a charter missing its decision-log section "is not a seat". Widening this list is a decision
// about what a seat IS, not a tuning knob — do not add ids here without that decision.
const REQUIRED = new Set(['decision-log-read-on-wake', 'decision-log-write-on-close']);

function fail(msg) { process.stderr.write(msg + '\n'); process.exit(2); }

function parseInventory(templateText) {
  const lines = templateText.split('\n');
  const b = lines.indexOf('INVENTORY-BEGIN');
  const e = lines.indexOf('INVENTORY-END');
  if (b < 0 || e < 0 || e <= b) return { rows: [], malformed: ['no INVENTORY-BEGIN/END block'] };
  const rows = [];
  const malformed = [];
  for (const raw of lines.slice(b + 1, e)) {
    if (!raw.trim()) continue;
    const parts = raw.split('|').map(s => s.trim());
    // ⛔ A ROW WITH THE WRONG FIELD COUNT IS A CORRUPT TEMPLATE, NOT A MISSING RULE.
    // Measured 2026-08-26: a body section pasted inside this comment split one row in half,
    // left its probe EMPTY — so it matched line 1 of anything — and turned 21 prose lines into
    // rows. An empty probe is the dangerous shape: it passes silently. Reject it loudly.
    if (parts.length !== 3 || !parts[0] || !parts[1] || !parts[2]) { malformed.push(raw); continue; }
    rows.push({ id: parts[0], heading: parts[1], probe: parts[2] });
  }
  return { rows, malformed };
}

function ladder(charterText, rows) {
  // ⛔ BOTH COMPARISONS BELOW DIVERGED FROM THE SKILL'S IMPLEMENTATION UNTIL 2026-09-11, and
  // neither divergence was visible on any live charter — which is exactly why a corpus
  // cross-check over the live charters would have printed "identical" while both were live.
  // An instrument that agrees with its twin only because no input distinguishes them is not
  // verified, it is untested. Canonical behaviour was chosen per axis, on merit:
  //
  //   probe   → CASE-INSENSITIVE (was case-sensitive here, insensitive in SKILL.md).
  //             A probe is a quoted fragment of charter prose, prose gets recased by editing,
  //             and a probe miss produces TIER3 — the tier that can refuse. Prefer the
  //             forgiving side where the cost of strictness is a false refusal.
  //   heading → WHOLE-LINE EXACT (was substring-anywhere here, whole-line in SKILL.md).
  //             A heading IS a line. Substring matching lets the string "## Identity"
  //             occurring inside a sentence satisfy a heading check, which is a silent
  //             false tier1 — the same family as the RELOCATED case.
  const haystack = charterText.toLowerCase();
  const charterLines = new Set(charterText.split('\n').map(l => l.replace(/\s+$/, '')));
  return rows.map(r => {
    const idx = haystack.indexOf(r.probe.toLowerCase());
    if (idx < 0) return { ...r, tier: 'TIER3', line: null };
    const line = charterText.slice(0, idx).split('\n').length;
    return { ...r, tier: charterLines.has(r.heading.replace(/\s+$/, '')) ? 'tier1' : 'tier2', line };
  });
}

function run(charterPath, templatePath, acknowledged, quiet, capture) {
  if (!existsSync(charterPath)) fail(`charter not found: ${charterPath}`);
  if (!existsSync(templatePath)) fail(`template not found: ${templatePath}`);
  const charterText = readFileSync(charterPath, 'utf8');
  const { rows, malformed } = parseInventory(readFileSync(templatePath, 'utf8'));
  if (!rows.length) fail(`no usable inventory rows in ${templatePath}`);

  const out = [];
  const results = ladder(charterText, rows);

  if (malformed.length) {
    out.push('⛔ TEMPLATE IS CORRUPT — these rows were skipped and the rules they carry were NOT checked:');
    for (const m of malformed) out.push(`      ${m.slice(0, 100)}`);
    out.push(`      Repair ${templatePath}; every row must read: id | heading | probe`);
    out.push('');
  }

  for (const r of results) {
    const req = REQUIRED.has(r.id) ? ' [REQUIRED]' : '';
    if (r.tier === 'TIER3') out.push(`TIER3  ${r.id.padEnd(32)} probe "${r.probe}" absent${req}`);
    else if (r.tier === 'tier2') out.push(`tier2  ${r.id.padEnd(32)} probe at line ${String(r.line).padEnd(4)} NOTE restructured — template heading absent${req}`);
    else out.push(`tier1  ${r.id.padEnd(32)} probe at line ${String(r.line).padEnd(4)} template heading also present${req}`);
  }

  const missing = results.filter(r => r.tier === 'TIER3' && REQUIRED.has(r.id));
  const blocking = missing.filter(r => !acknowledged.has(r.id));
  const waved = missing.filter(r => acknowledged.has(r.id));

  out.push('');
  if (waved.length) {
    out.push('⛔ ACKNOWLEDGED AS RESTRUCTURED, NOT FOUND — someone asserted these rules are present');
    out.push('   under different wording. That assertion is only as good as the person who made it.');
    for (const r of waved) out.push(`      ${r.id}`);
  }

  if (blocking.length) {
    out.push('⛔ REFUSED — this document is missing a rule that DEFINES a seat.');
    out.push('');
    for (const r of blocking) {
      out.push(`   ${r.id}`);
      out.push(`      no line of the charter contains: "${r.probe}"`);
    }
    out.push('');
    out.push('   Why this blocks rather than warns: SKILL.md § "Two obligations that define a seat"');
    out.push('   says a charter missing its decision-log section is not a seat — "regenerate it, do');
    out.push('   not hand it over". A seat launched without it does not know to read its log on wake');
    out.push('   or write one on close, and nothing downstream notices.');
    out.push('');
    out.push('   ── WHAT WOULD BE ALLOWED, pick one ──────────────────────────────────────────────');
    out.push(`   1. Add the missing section to ${charterPath}. Copy it from`);
    out.push(`      ${templatePath} § "## Decision log — read on wake, write on close. Non-negotiable."`);
    out.push('      and replace the template placeholders with this seat\'s real absolute paths and');
    out.push('      author slug. That is the fix in almost every case.');
    out.push('   2. If the rule IS present under different wording — a genuine restructure — record');
    out.push('      that judgment explicitly rather than silently, by re-running with:');
    out.push(`         --acknowledge-unplaceable=${blocking.map(r => r.id).join(',')}`);
    out.push('      Naming the id is the point: it makes the claim attributable. Never wave through');
    out.push('      an id you have not personally found in the file.');
    out.push('   3. If this document is not meant to be a seat charter, it should not be passed to a');
    out.push('      seat launcher at all.');
    if (!quiet) process.stdout.write(out.join('\n') + '\n');
    if (capture) capture.text = out.join('\n');
    return 1;
  }

  out.push(`PASS — ${results.length} rules checked, every required rule present.`);
  out.push('This is a receipt, not a verdict: the per-id list above is the output. A tier2 note is a');
  out.push('legitimate restructure and is not a failure. A TIER3 on a non-required id means the rule');
  out.push('could not be probed and nobody has read the file to place it — that is still open work.');
  if (!quiet) process.stdout.write(out.join('\n') + '\n');
  if (capture) capture.text = out.join('\n');
  return 0;
}

// ── SELFTEST ───────────────────────────────────────────────────────────────────────────────
// ⛔ THE POLES ARE REAL FILES, AND THE NEGATIVE POLE IS A REAL HISTORICAL FAILURE rather than a
// fixture invented to fail. Wren's pre-2026-08-26 charter is the exact document that was adopted
// as a seat charter with no decision-log rule. If this tool cannot refuse THAT file, it would not
// have caught the incident it was built for.
//
// ⛔ AND THE POSITIVE POLE IS EVERY LIVE CHARTER ON THIS MACHINE. If a working charter fails this
// ladder, read that as evidence about the LADDER before reading it as evidence about the charter.
const POLES = [
  { want: 0, label: 'live: Tinker', p: '/Users/jowolff/.claude/.ai/tinker-seat-charter.md' },
  { want: 0, label: 'live: Sedge',  p: '/Users/jowolff/code/shipyard/repos/newdle-claude-plugins/.ai/sedge-seat-charter.md' },
  { want: 0, label: 'live: Verge',  p: '/Users/jowolff/code/shipyard/.ai/verge-seat-charter.md' },
  { want: 0, label: 'live: Wren',   p: '/Users/jowolff/code/shipyard/repos/newdle-web/.ai/wren-seat-charter.md' },
  { want: 1, label: 'HISTORICAL NEGATIVE: Wren as adopted, pre-2026-08-26',
    p: '/Users/jowolff/agent-scratch/newdle-web/wren-seat-charter.md.pre-decision-log-rule-20260826' },
];

function selftest() {
  let pass = 0, fails = [];
  for (const t of POLES) {
    if (!existsSync(t.p)) { fails.push(`${t.label}: FILE ABSENT ${t.p} — pole unusable, NOT a pass`); continue; }
    const got = run(t.p, DEFAULT_TEMPLATE, new Set(), true);
    if (got === t.want) pass++;
    else fails.push(`${t.label}: wanted exit ${t.want}, got ${got}  (${t.p})`);
  }
  // The acknowledgement escape hatch must actually flip the historical negative to a pass,
  // and must NOT flip it when a DIFFERENT id is named.
  const neg = POLES[POLES.length - 1];
  if (existsSync(neg.p)) {
    const waved = run(neg.p, DEFAULT_TEMPLATE, new Set(['decision-log-read-on-wake', 'decision-log-write-on-close']), true);
    if (waved === 0) pass++; else fails.push(`escape hatch: acknowledging both ids should pass, got ${waved}`);
    const wrong = run(neg.p, DEFAULT_TEMPLATE, new Set(['manage-dont-do']), true);
    if (wrong === 1) pass++; else fails.push(`escape hatch: acknowledging an unrelated id must NOT pass, got ${wrong}`);
  }
  // ⛔ ADDED AFTER A MUTATION TEST CAUGHT THIS SELFTEST BLIND.
  // Deleting the malformed-row rejection in parseInventory left the selftest at 7/7 — the
  // corrupt-template path was never exercised by any pole, so the check that exists to catch a
  // template like the one repaired on 2026-08-26 was itself unwatched.
  // The pole is the REAL pre-repair template, kept as the backup of that repair. Its inventory
  // block held a body section pasted inside the comment: 21 prose lines parsed as rows, and one
  // row left with an EMPTY probe, which matches line 1 of anything and therefore passes silently.
  const CORRUPT_TPL = '/Users/jowolff/agent-scratch/dot-claude/charter-template.md.pre-inventory-repair-20260826';
  const LIVE_CHARTER = POLES[0].p;
  if (existsSync(CORRUPT_TPL) && existsSync(LIVE_CHARTER)) {
    const cap = {};
    run(LIVE_CHARTER, CORRUPT_TPL, new Set(), true, cap);
    if ((cap.text || '').includes('TEMPLATE IS CORRUPT')) pass++;
    else fails.push('corrupt-template pole: the historically corrupt template did not raise "TEMPLATE IS CORRUPT"');
    const cap2 = {};
    run(LIVE_CHARTER, DEFAULT_TEMPLATE, new Set(), true, cap2);
    if (!(cap2.text || '').includes('TEMPLATE IS CORRUPT')) pass++;
    else fails.push('corrupt-template pole: the REPAIRED template was reported corrupt — false positive');
  } else {
    fails.push(`corrupt-template pole: fixture absent (${CORRUPT_TPL}) — pole unusable, NOT a pass`);
  }

  // ⛔ DIVERGENCE POLES, added 2026-09-11. Both of these FAIL against the pre-2026-09-11
  // `ladder()` and pass against `SKILL.md` step 3, which is what made the two implementations
  // disagree. Neither shape occurs in any live charter, which is why nothing caught it: a
  // cross-check over the live corpus printed "identical" while both divergences were live.
  const CASE_ROW = [{ id: 'case-axis', heading: '## Identity', probe: 'Re-Derived At The Moment' }];
  const caseCharter = '## Identity\n\nevery premise is re-derived at the moment you write it.\n';
  const caseTier = ladder(caseCharter, CASE_ROW)[0].tier;
  if (caseTier === 'tier1') pass++;
  else fails.push(`divergence pole (probe case): wanted tier1 from a case-mismatched probe, got ${caseTier}`);

  const HEADING_ROW = [{ id: 'heading-axis', heading: '## Identity', probe: 'announce your name once' }];
  const proseCharter = 'The section named ## Identity was folded into the preamble.\n\nannounce your name once.\n';
  const headingTier = ladder(proseCharter, HEADING_ROW)[0].tier;
  if (headingTier === 'tier2') pass++;
  else fails.push(`divergence pole (heading whole-line): a heading string inside prose must not satisfy the heading check, got ${headingTier}`);

  const total = POLES.length + 6;
  process.stdout.write(`selftest: ${pass}/${total} passed\n`);
  for (const f of fails) process.stdout.write('  FAIL ' + f + '\n');
  process.exit(fails.length ? 1 : 0);
}

// ── CLI ────────────────────────────────────────────────────────────────────────────────────
const argv = process.argv.slice(2);
if (argv.includes('--selftest')) selftest();
const get = k => { const a = argv.find(x => x.startsWith(k + '=')); if (a) return a.slice(k.length + 1);
                   const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
const charter = get('--charter');
if (!charter) fail('usage: charter-ladder.mjs --charter <path> [--template <path>] [--acknowledge-unplaceable=id,id]\n       charter-ladder.mjs --selftest');
const ack = new Set((get('--acknowledge-unplaceable') || '').split(',').map(s => s.trim()).filter(Boolean));
process.exit(run(charter, get('--template') || DEFAULT_TEMPLATE, ack, false));

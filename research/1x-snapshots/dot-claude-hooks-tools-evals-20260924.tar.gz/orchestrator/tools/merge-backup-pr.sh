#!/usr/bin/env zsh
#
# merge-backup-pr.sh — merge THIS SESSION's backup pull request in the state mirror, and nowhere
# else. The narrow self-merge authority granted 2026-08-20: lintel-state ONLY.
#
#   zsh /Users/jowolff/.claude/orchestrator/tools/merge-backup-pr.sh              # merge, after checks
#   zsh /Users/jowolff/.claude/orchestrator/tools/merge-backup-pr.sh --dry-run    # run every check, merge nothing
#   zsh /Users/jowolff/.claude/orchestrator/tools/merge-backup-pr.sh --selftest   # fire every refusal check
#                                                                                 #   against synthetic bad input
#   zsh /Users/jowolff/.claude/orchestrator/tools/merge-backup-pr.sh --check       # read-only. Is there a backup
#                                                                                 #   pull request for this session
#                                                                                 #   waiting? exit 1 = yes, exit
#                                                                                 #   0 = nothing to do. Merges
#                                                                                 #   nothing, fetches nothing,
#                                                                                 #   writes no log. Exists so this
#                                                                                 #   script COULD join the
#                                                                                 #   publisher list in
#                                                                                 #   hooks/publish-stop.mjs. It is
#                                                                                 #   NOT in that list and adding
#                                                                                 #   it is a separate decision --
#                                                                                 #   see WHAT TRIGGERS THIS below.
#   zsh ... --mirror <path>   # point at a different local mirror checkout. Exists so the
#                             # allowlist refusal can be DEMONSTRATED against a repo that is not
#                             # lintel-state; the allowlist below refuses anything but the one slug,
#                             # so this flag cannot widen where a merge can land.
#
# WHY THIS IS NOT A STEP INSIDE backup-state.sh. backup-state.sh holds ONE branch and ONE pull
# request per session, updated in place across runs. A merged pull request cannot be updated —
# the next run would have to open a fresh one, and merging on every run therefore means one pull
# request per run, which is the exact disease the per-session shape cures. So the merge is a
# separate act, taken when the session's backup is worth landing (end of session, or on demand),
# not on every backup.
#
# WHAT IT WILL NEVER DO. Never force-push. Never push to main or any protected branch — the merge
# goes through the pull request via gh, the way a human would. Never --admin, never bypass a
# failing check, never resolve a conflict, never delete a branch.
#
# THE RECORD. Every merge appends a block to backup-merges.log beside this script: when, which
# session, which pull request, how many files, adds/deletes, and the resulting merge commit. That
# file is append-only and is how the owner reviews merges after the fact without reading diffs.
# (The .log suffix is deliberate: sync-to-lintel.sh's DENY list excludes *.log, so this record
# never shows up as an unpublished-file decision in that publisher's reports.)
#
# WHAT TRIGGERS THIS: NOTHING. It is run by hand, and that is the whole current answer.
# Earlier revisions of this header spoke of a "SessionEnd trigger" as though one existed. It does
# not. Verified 2026-08-25 by reading ~/.claude/settings.json and settings.local.json: the only
# hook events registered on this machine are SessionStart, UserPromptSubmit, PreToolUse,
# PostToolUse and Stop. There is no SessionEnd entry, in either file.
#
# SessionEnd is a real Claude Code hook event, but it is a poor host for this: its stdout goes to
# a debug log rather than to the session, its systemMessage is discarded, and it runs against a
# budget of roughly a second and a half -- while this script's live path makes three round trips
# to the GitHub API and a merge. A merge that cannot report and can be killed mid-flight is worse
# than no merge.
#
# The registered event that COULD host it is Stop, via the publisher list in
# hooks/publish-stop.mjs -- the same machinery that runs sync-to-lintel.sh and backup-state.sh
# detached, out of the turn, with a lock, a backoff and a failure channel. --check exists so that
# is possible. This script is deliberately NOT in that list; putting it there is an activation
# decision, and activation is the owner's word.
#
# EXIT CODES
#   0  merged (or --dry-run / --selftest / a clean --check)
#   1  a refusal check fired — nothing merged, PR left open for a human.
#      Under --check ONLY, 1 does not mean refusal: it means "there is a pull request waiting",
#      which is the drift signal hooks/publish-stop.mjs expects from a publisher's --check.
#   2  could not run at all (bad arguments, missing tools)
#   6  DECLINED, not failed — no open pull request for this session, so there was nothing to
#      merge. Defined in tools/publish-exit-codes.sh as PUBLISH_EXIT_NOTHING_TO_MERGE, so this
#      script and publish-run.sh (which would wrap it, were it wired) agree on the number.
#      Self-clears: the next backup that finds drift opens a PR, and the next merge attempt
#      finds it. Every other refusal above still exits 1.

emulate -L zsh
setopt pipe_fail

SOURCE="/Users/jowolff/.claude/orchestrator/state"
MIRROR="/Users/jowolff/code/lintel-state"
ALLOWED_SLUG="thewolff/lintel-state"   # the ONLY repo this script may merge in. Not configurable.
DEL_CAP=50                             # refuse above this many deleted files...
DEL_PCT_CAP=20                         # ...or above this % of main's tracked files deleted.
SCRIPT_DIR="${0:A:h}"
LOG="$SCRIPT_DIR/merge-backup-pr.log"
RECORD="$SCRIPT_DIR/backup-merges.log"

MODE="merge"
while (( $# )); do
  case "$1" in
    --dry-run)  MODE="dry" ;;
    --selftest) MODE="selftest" ;;
    --check)    MODE="check" ;;
    --mirror)   shift; MIRROR="${1:-}"; [[ -n "$MIRROR" ]] || { print -u2 -- "--mirror needs a path"; exit 2; } ;;
    *) print -u2 -- "unknown argument: $1"; exit 2 ;;
  esac
  shift
done

# --check is answered on every session stop if this script is ever added to the publisher list, and
# $LOG is a GIT-TRACKED FILE in this repo -- the same route by which a live key reached
# tools/merge-backup-pr.log on 2026-08-24. A read-only question does not earn a write into tracked
# history, so --check does not tee. Every other mode does.
[[ "$MODE" == "check" ]] || exec > >(tee "$LOG") 2>&1
say() { print -r -- "[merge-backup-pr] $*"; }
refuse() { print -r -- "[merge-backup-pr] REFUSED: $*"; print -r -- "[merge-backup-pr] nothing merged. log: $LOG"; exit 1; }
die() { print -r -- "[merge-backup-pr] CANNOT RUN: $*"; exit 2; }

# The one refusal that is a DECLINE, not a failure: no open pull request exists for this
# session, so there was nothing to merge. That is the ordinary shape of a session that made no
# state changes, not a problem, and it is the case a SessionEnd trigger hits most often -- every
# session that touches no state at all ends this way. Every other refusal in this script keeps
# going through refuse() above and stays exit 1, unchanged.
#
# The code is defined once, in tools/publish-exit-codes.sh, and read from there so this script
# and publish-run.sh (which wraps it when the SessionEnd trigger calls it) cannot come to
# disagree about which number means "declined". If that file is missing, this falls back to
# refuse()'s ordinary exit 1 -- failing in the direction of loud, same as publish-run.sh's own
# fallback when the codes file is unreadable.
CODES="${0:A:h}/publish-exit-codes.sh"
if [[ -r "$CODES" ]]; then source "$CODES"; fi
decline_nothing_to_merge() {
  print -r -- "[merge-backup-pr] DECLINED: $*"
  print -r -- "[merge-backup-pr] nothing merged -- this is the ordinary case, not a failure. log: $LOG"
  if [[ -n "${PUBLISH_EXIT_NOTHING_TO_MERGE:-}" ]]; then
    exit "$PUBLISH_EXIT_NOTHING_TO_MERGE"
  fi
  exit 1
}

# ── the credential scanner, loaded ONCE, AT TOP LEVEL ────────────────────────────────────────
# ⛔ THIS USED TO BE `source "${0:A:h}/lib/credential-scan.sh"` INSIDE check_credentials, AND THAT
# IS A BUG, not a style point. In zsh, $0 inside a function is THE FUNCTION'S NAME, not the script
# -- so ${0:A:h} expanded to the directory of a file named "check_credentials", i.e. whatever the
# CURRENT WORKING DIRECTORY happened to be. The source therefore only found the library when this
# script was run from its own directory, which is how every hand-run had happened to invoke it.
# Run from anywhere else, `source` failed, cred_scan_stdin did not exist, the pipeline returned
# non-zero, and check_credentials refused -- so the failure mode was a mystery refusal on every
# merge rather than an unscanned merge. Failing closed is the right direction and it was still a
# jam: the tool would have refused forever from any other cwd. Caught 2026-08-25 by running the
# selftest from a different directory, which nothing had ever done.
#
# Loading it here, before any function is defined, makes $0 the script and makes a missing library
# fatal and loud instead of a silent degradation into refusal.
CRED_SCAN_LIB="$SCRIPT_DIR/lib/credential-scan.sh"
[[ -r "$CRED_SCAN_LIB" ]] || die "credential scanner missing or unreadable at $CRED_SCAN_LIB — refusing to run at all. An unscanned merge is the one thing this script must never do."
source "$CRED_SCAN_LIB"
whence -w cred_scan_stdin >/dev/null 2>&1 || die "$CRED_SCAN_LIB did not define cred_scan_stdin — refusing to run at all."

# ── the refusal checks, as functions, so --selftest can fire each one ────────────────────────
# Each returns 0 to allow and 1 to refuse, printing its reason. The live path and the selftest
# run THE SAME functions; a guard that has only ever passed is not evidence, and these are built
# to be fired on demand.

check_allowlist() {  # $1 = owner/repo slug derived from the mirror's origin
  [[ "$1" == "$ALLOWED_SLUG" ]] && return 0
  print -r -- "  repo is '$1', not '$ALLOWED_SLUG'. The self-merge authority is lintel-state only."
  return 1
}
check_base() {  # $1 = the PR's base branch
  [[ "$1" == "main" ]] && return 0
  print -r -- "  pull request targets '$1', not main. A retargeted PR is not this session's backup."
  return 1
}
check_head_matches() {  # $1 = PR head oid, $2 = local session-branch oid
  [[ -n "$2" && "$1" == "$2" ]] && return 0
  print -r -- "  PR head is $1 but this machine's copy of the branch is '${2:-missing}'."
  print -r -- "  Content this machine cannot vouch for does not get self-merged."
  return 1
}
check_mergeable() {  # $1 = gh mergeable value
  [[ "$1" == "MERGEABLE" ]] && return 0
  print -r -- "  gh reports mergeable='$1'. Conflicts (or unknown state) are a human's to resolve."
  return 1
}
check_policy_paths() {  # $1 = newline-separated changed paths
  local bad
  bad="$(print -r -- "$1" | grep -E '^(README\.md|\.gitignore|\.github/)' || true)"
  [[ -z "$bad" ]] && return 0
  print -r -- "  the PR touches mirror policy or CI surfaces, which a state backup never does:"
  print -r -- "$bad" | sed 's/^/    /'
  return 1
}
check_deletion_cap() {  # $1 = deleted-file count, $2 = tracked-file count on main
  local dels="$1" tracked="$2"
  (( dels <= DEL_CAP )) || { print -r -- "  $dels files deleted, cap is $DEL_CAP. A deletion this size is reviewed, not self-merged."; return 1; }
  if (( tracked > 0 )) && (( dels * 100 > tracked * DEL_PCT_CAP )); then
    print -r -- "  $dels of $tracked tracked files deleted (> ${DEL_PCT_CAP}%). That is a wipe, not a backup."
    return 1
  fi
  return 0
}
check_credentials() {  # $1 = the PR diff text
  # These patterns require a TOKEN BODY after the prefix, unlike sync-to-lintel.sh's bare-prefix
  # set. The state layer's own audit notes mention prefixes by name in prose ("42 ghp_ files",
  # "github_pat_, a PEM private key") — fired live 2026-08-20 on PR #6 — and a scan that refuses
  # every backup because the state DISCUSSES credentials would refuse forever, and a permanently
  # red guard stops being read. A real secret has a body; prose does not.
  # ⛔ THIS USED TO PRINT THE MATCHING LINES. It caught a live Linear API key on 2026-08-24 and
  # wrote it into tools/merge-backup-pr.log — a git-tracked file, five occurrences including
  # committed history. The scanner exposed the secret it was built to stop. It now reports the
  # pattern name, the count and the location, and never the matched text.
  # The library is sourced at top level above; see the note there for why it is not sourced here.
  if print -r -- "$1" | cred_scan_stdin "the diff"; then
    return 0
  fi
  print -r -- "  Merging makes it main's permanent record; a human decides (and rotates) first."
  return 1
}


# ── which of THIS SESSION's branches is the live one ─────────────────────────────────────────
# ⛔ THE MIDNIGHT JAM THIS CLOSES. backup-state.sh names its branch
# backup-orchestrator-state-<UTC date>-<session tag>, so a session that is still running when UTC
# midnight passes gets a SECOND branch and a SECOND pull request under the SAME session tag. The
# matcher below wildcards the date on purpose (a session is not a day), so it hits both, and this
# script used to call that "ambiguous" and refuse. It was not ambiguous -- the tag is anchored, so
# every match is this session and nobody else's. It was two snapshots of one session, and the
# script had no rule for picking between them.
#
# Live proof, 2026-08-25: session fb6a3512 has PR #21 (branch ...-20260824-fb6a3512, opened
# 22:38Z) and PR #22 (...-20260825-fb6a3512, opened 00:01Z, 83 minutes later). Session 45e53060
# has the same shape across #18 and #19. Both would have refused.
#
# THE RULE: NEWEST WINS, AND THE OLDER ONES ARE STALE, NOT PENDING. Every backup commit is a FULL
# snapshot of the state directory -- backup-state.sh rsyncs with --delete and then commits `add
# -A` (see its steps 4 and 5), so a commit's tree IS the state directory at that instant. The
# newest branch therefore already contains everything the older one carried. Merging an older one
# AFTERWARDS would not add anything; it would drag a stale full snapshot over main and revert
# whatever moved in between. So exactly one is merged, it is the newest, and the rest are named in
# the output as superseded and left open. This script does not close pull requests, the same way
# it does not delete branches.
#
# Ordering is by the DATE IN THE BRANCH NAME first, then by pull-request number, both ascending;
# the last one is the winner. Pull-request number is the tiebreak rather than a timestamp because
# it is monotonic per repository and needs no clock and no second API call -- it settles two
# branches minted on the same UTC date, which is what the "-wt" fallback branch produces.
pick_session_pr() {  # stdin: the PR JSON array. Line 1: "<num>\t<branch>\t<base>\t<oid>" for the
                     # winner. Line 2: the numbers of every superseded PR, space separated.
  /usr/bin/python3 -c '
import json,re,sys
prs = json.load(sys.stdin)
if not prs:
    sys.exit(3)
def sort_key(p):
    m = re.search(r"-(\d{8})-", p["headRefName"])
    return (m.group(1) if m else "", int(p["number"]))
prs.sort(key=sort_key)
w = prs[-1]
print("\t".join([str(w["number"]), w["headRefName"], w["baseRefName"], w["headRefOid"]]))
print(" ".join("#%s" % p["number"] for p in prs[:-1]))
'
}

# ── selftest: every check fired against input built to refuse, then passed with good input ───
if [[ "$MODE" == "selftest" ]]; then
  say "selftest: each refusal check must FIRE on bad input and PASS on good input"
  fails=0
  run_case() {  # $1 label, $2 expected (fire|pass), then the function call
    local label="$1" want="$2"; shift 2
    local out rc
    out="$("$@" 2>&1)"; rc=$?
    if [[ "$want" == "fire" && $rc -ne 0 ]] || [[ "$want" == "pass" && $rc -eq 0 ]]; then
      say "  ok: $label ($want)"
    else
      say "  SELFTEST FAILURE: $label expected to $want but did not. Output:"; print -r -- "$out"
      fails=$(( fails + 1 ))
    fi
  }
  run_case "allowlist refuses another repo"        fire check_allowlist "thewolff/lintel"
  run_case "allowlist passes lintel-state"          pass check_allowlist "$ALLOWED_SLUG"
  run_case "base refuses a non-main target"         fire check_base "release"
  run_case "base passes main"                       pass check_base "main"
  run_case "head refuses an unknown remote commit"  fire check_head_matches "aaaa1111" "bbbb2222"
  run_case "head refuses a missing local branch"    fire check_head_matches "aaaa1111" ""
  run_case "head passes a matching commit"          pass check_head_matches "aaaa1111" "aaaa1111"
  run_case "mergeable refuses CONFLICTING"          fire check_mergeable "CONFLICTING"
  run_case "mergeable refuses UNKNOWN"              fire check_mergeable "UNKNOWN"
  run_case "mergeable passes MERGEABLE"             pass check_mergeable "MERGEABLE"
  run_case "policy refuses a .github workflow"      fire check_policy_paths $'STANDUP.md\n.github/workflows/x.yml'
  run_case "policy refuses the mirror .gitignore"   fire check_policy_paths ".gitignore"
  run_case "policy passes ordinary state files"     pass check_policy_paths $'STANDUP.md\nrunsx/log.md'
  run_case "deletion cap refuses 51 deletions"      fire check_deletion_cap 51 1000
  run_case "deletion cap refuses 30% of the repo"   fire check_deletion_cap 30 100
  run_case "deletion cap passes a small deletion"   pass check_deletion_cap 3 1000
  # PROVE THE SCANNER IS PRESENT, not merely absent. A missing library also makes check_credentials
  # return 1, so the two "fire" cases below pass just as happily when nothing is loaded at all --
  # which is exactly how the $0-in-a-function bug hid. This asserts the function exists first.
  if whence -w cred_scan_stdin >/dev/null 2>&1; then
    say "  ok: cred_scan_stdin is loaded (so the refusals below are the scanner, not its absence)"
  else
    say "  SELFTEST FAILURE: cred_scan_stdin is not defined — the credential 'refusals' below would be an unloaded library, not a scan"
    fails=$(( fails + 1 ))
  fi
  run_case "credential scan refuses a token shape"  fire check_credentials "+ export X=ghp_0123456789abcdef0123456789abcdef0123"
  run_case "credential scan refuses a PEM header"   fire check_credentials "+ -----BEGIN RSA PRIVATE KEY-----"
  run_case "credential scan passes a clean diff"    pass check_credentials "+ nothing to see here"
  run_case "credential scan passes a prose mention" pass check_credentials '+ note: "42 ghp_ files never read; github_pat_, a PEM key mentioned by name"'

  # ── the midnight selection, against the real jam frozen as a fixture ──────────────────────
  # These two objects are PR #21 and PR #22 as they actually stood on 2026-08-25 -- one session
  # tag, two UTC dates, the exact input that used to make this script refuse.
  MIDNIGHT_FIXTURE='[
    {"number":22,"headRefName":"backup-orchestrator-state-20260825-fb6a3512","baseRefName":"main","headRefOid":"dd45b31da9377d33148fa6adf03c176c2e06313f"},
    {"number":21,"headRefName":"backup-orchestrator-state-20260824-fb6a3512","baseRefName":"main","headRefOid":"6d9bdfbed464cbcc80d18a3483fe37579f952590"}
  ]'
  sel_case() {  # $1 label, $2 expected line 1, $3 expected line 2, stdin-json in $4
    local label="$1" want_win="$2" want_sup="$3" json="$4" got_win got_sup out
    out="$(print -r -- "$json" | pick_session_pr)" || { say "  SELFTEST FAILURE: $label — pick_session_pr exited non-zero"; fails=$(( fails + 1 )); return; }
    got_win="$(print -r -- "$out" | sed -n 1p)"
    got_sup="$(print -r -- "$out" | sed -n 2p)"
    if [[ "$got_win" == "$want_win" && "$got_sup" == "$want_sup" ]]; then
      say "  ok: $label"
    else
      say "  SELFTEST FAILURE: $label"
      say "    winner want: $want_win"
      say "    winner got:  $got_win"
      say "    superseded want: '$want_sup'   got: '$got_sup'"
      fails=$(( fails + 1 ))
    fi
  }
  sel_case "midnight: the 08-25 branch wins over the 08-24 one, no refusal" \
    $'22\tbackup-orchestrator-state-20260825-fb6a3512\tmain\tdd45b31da9377d33148fa6adf03c176c2e06313f' \
    '#21' "$MIDNIGHT_FIXTURE"
  sel_case "the ordinary one-PR session is unchanged" \
    $'24\tbackup-orchestrator-state-20260825-06a7ae6a\tmain\tf30408f7f0132538f16ee9db6000203a42148c1a' \
    '' \
    '[{"number":24,"headRefName":"backup-orchestrator-state-20260825-06a7ae6a","baseRefName":"main","headRefOid":"f30408f7f0132538f16ee9db6000203a42148c1a"}]'
  sel_case "same date, the -wt fallback branch: higher PR number wins" \
    $'31\tbackup-orchestrator-state-20260825-aaaaaaaa-wt\tmain\tcccc3333' \
    '#30' \
    '[{"number":30,"headRefName":"backup-orchestrator-state-20260825-aaaaaaaa","baseRefName":"main","headRefOid":"bbbb2222"},
      {"number":31,"headRefName":"backup-orchestrator-state-20260825-aaaaaaaa-wt","baseRefName":"main","headRefOid":"cccc3333"}]'
  sel_case "three days of one long session: the newest date wins, two superseded" \
    $'40\tbackup-orchestrator-state-20260827-bbbbbbbb\tmain\tdddd4444' \
    '#38 #39' \
    '[{"number":39,"headRefName":"backup-orchestrator-state-20260826-bbbbbbbb","baseRefName":"main","headRefOid":"eeee5555"},
      {"number":40,"headRefName":"backup-orchestrator-state-20260827-bbbbbbbb","baseRefName":"main","headRefOid":"dddd4444"},
      {"number":38,"headRefName":"backup-orchestrator-state-20260825-bbbbbbbb","baseRefName":"main","headRefOid":"ffff6666"}]'

  # decline_nothing_to_merge is a separate exit path from refuse(), on purpose: it must land on
  # PUBLISH_EXIT_NOTHING_TO_MERGE (6), never on refuse()'s plain 1, or publish-run.sh would treat
  # an empty session as a real failure. Run in a subshell so its `exit` does not end the selftest.
  NTM_RC=0
  ( decline_nothing_to_merge "selftest: synthetic empty session" >/dev/null 2>&1 ) || NTM_RC=$?
  if [[ "$NTM_RC" == "${PUBLISH_EXIT_NOTHING_TO_MERGE:-6}" ]]; then
    say "  ok: nothing-to-merge declines on code ${PUBLISH_EXIT_NOTHING_TO_MERGE:-6}, not 1"
  else
    say "  SELFTEST FAILURE: nothing-to-merge exited $NTM_RC, expected ${PUBLISH_EXIT_NOTHING_TO_MERGE:-6}"
    fails=$(( fails + 1 ))
  fi

  (( fails == 0 )) || { say "selftest FAILED ($fails case(s))"; exit 1; }
  say "selftest passed: every refusal check fired when it should and passed when it should"
  exit 0
fi

# ── live path ────────────────────────────────────────────────────────────────────────────────
say "=== run started $(date -u '+%Y-%m-%dT%H:%M:%SZ') (mode: $MODE) ==="
[[ -d "$MIRROR/.git" ]] || die "mirror is not a git repo: $MIRROR"
command -v gh >/dev/null || die "gh is not installed"

ORIGIN_URL="$(git -C "$MIRROR" remote get-url origin 2>/dev/null)" || die "mirror has no origin remote"
SLUG="${ORIGIN_URL##*:}"; SLUG="${SLUG##*github.com/}"; SLUG="${SLUG%.git}"
say "mirror: $MIRROR  (origin $SLUG)"

# Check 1 first, before any network call: the authority boundary.
check_allowlist "$SLUG" || refuse "allowlist check fired"

GH_ACCOUNT_TOKEN="$(gh auth token --user "${SLUG%%/*}" 2>/dev/null)" || GH_ACCOUNT_TOKEN=""
[[ -n "$GH_ACCOUNT_TOKEN" ]] || die "gh has no token for ${SLUG%%/*}"

# The session tag, read from the same file backup-state.sh reads — never minted here.
SESSION_TAG=""
[[ -r "$SOURCE/.session-id" ]] && SESSION_TAG="$(tr -cd 'A-Za-z0-9-' < "$SOURCE/.session-id" | cut -c1-8)"
[[ -n "$SESSION_TAG" ]] || SESSION_TAG="nosession"
say "session tag: $SESSION_TAG"

# This session's open backup PR, found by head-branch shape. Date is part of the branch name and
# a session can cross midnight, so match on the tag, not on today's date.
PRS="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr list --repo "$SLUG" --state open \
  --json number,headRefName,baseRefName,headRefOid \
  -q "[.[] | select(.headRefName | test(\"^backup-orchestrator-state-[0-9]{8}-${SESSION_TAG}(-wt)?\$\"))]")"
COUNT="$(print -r -- "$PRS" | /usr/bin/python3 -c 'import json,sys; print(len(json.load(sys.stdin)))')"
if (( COUNT == 0 )); then
  decline_nothing_to_merge "no open backup pull request for session $SESSION_TAG. Only the PR this session opened may be self-merged."
fi

SELECTION="$(print -r -- "$PRS" | pick_session_pr)" || die "could not choose among the $COUNT open PR(s) for session $SESSION_TAG"
SEL_LINE="$(print -r -- "$SELECTION" | sed -n 1p)"
SUPERSEDED="$(print -r -- "$SELECTION" | sed -n 2p)"
IFS=$'\t' read -r PR_NUM BRANCH BASE_REF HEAD_OID <<< "$SEL_LINE"
[[ -n "$PR_NUM" && -n "$BRANCH" && -n "$HEAD_OID" ]] || die "the PR selection came back malformed: '$SEL_LINE'"

# --check answers here and stops: read-only, no fetch, no diff, no merge, nothing written.
if [[ "$MODE" == "check" ]]; then
  say "--check: PR #$PR_NUM ($BRANCH) is waiting for session $SESSION_TAG. Nothing was merged."
  [[ -n "$SUPERSEDED" ]] && say "--check: superseded by it, still open: $SUPERSEDED"
  exit 1
fi

if (( COUNT > 1 )); then
  say "session $SESSION_TAG has $COUNT open backup pull requests. That is a session that crossed"
  say "  UTC midnight, not an ambiguity: the session tag is anchored in the match, so every one of"
  say "  them is this session's, and only the date in the branch name differs."
  say "  merging the NEWEST, #$PR_NUM ($BRANCH) — each backup commit is a full snapshot of the"
  say "  state directory, so it already contains what the older branches carried."
  say "  superseded, left open and NOT merged: $SUPERSEDED"
  say "  ⛔ do not merge a superseded one after this. An older full snapshot dragged over main"
  say "     reverts everything that moved since. Close them, or leave them; never merge them."
fi
say "candidate: PR #$PR_NUM  head $BRANCH @ ${HEAD_OID:0:8}  base $BASE_REF"

# Check 2: base is main.
check_base "$BASE_REF" || refuse "base check fired on PR #$PR_NUM"

# Check 3: the remote head is exactly what this machine pushed.
LOCAL_OID="$(git -C "$MIRROR" rev-parse --verify -q "refs/heads/$BRANCH" 2>/dev/null || print '')"
check_head_matches "$HEAD_OID" "$LOCAL_OID" || refuse "head-identity check fired on PR #$PR_NUM"

# Check 4: cleanly mergeable — no conflict, no unknown state.
MERGEABLE="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr view "$PR_NUM" --repo "$SLUG" --json mergeable -q .mergeable)"
check_mergeable "$MERGEABLE" || refuse "mergeable check fired on PR #$PR_NUM"

# Checks 5–7 measure the diff LOCALLY, from git, never from the GitHub diff API. That API caps a
# pull-request diff at 300 files and returns HTTP 406 above it (hit live 2026-08-20 on PR #6),
# and a check fed an empty string by a failed fetch passes silently — an inert guard, the exact
# defect this script exists to avoid. Local git has the same commits after the fetch below and no
# size cap; if it cannot produce the diff, that is fatal, never a pass.
git -C "$MIRROR" fetch --quiet origin || die "could not fetch origin to measure the diff"
git -C "$MIRROR" cat-file -e "$HEAD_OID" 2>/dev/null || die "PR head $HEAD_OID is not in the local mirror even after a fetch — cannot measure what would merge"
FILE_NAMES="$(git -C "$MIRROR" diff --name-only "origin/main...$HEAD_OID")" || die "git diff --name-only failed"
[[ -n "$FILE_NAMES" ]] || die "the diff of PR #$PR_NUM came back empty — refusing to run content checks against nothing"
N_FILES="$(print -r -- "$FILE_NAMES" | grep -c . || true)"
SHORTSTAT="$(git -C "$MIRROR" diff --shortstat "origin/main...$HEAD_OID")"
DELETED_FILES="$(git -C "$MIRROR" diff --name-status "origin/main...$HEAD_OID" | grep -c '^D' || true)"
TRACKED="$(git -C "$MIRROR" ls-tree -r --name-only origin/main | wc -l | tr -d ' ')"
say "PR #$PR_NUM changes $N_FILES file(s) ($SHORTSTAT), $DELETED_FILES file deletion(s); main tracks $TRACKED"
check_policy_paths "$FILE_NAMES" || refuse "policy-path check fired on PR #$PR_NUM"
check_deletion_cap "$DELETED_FILES" "$TRACKED" || refuse "deletion-cap check fired on PR #$PR_NUM"

# Check 7: no credential-shaped content becomes main's permanent record on a machine's say-so.
DIFF_TEXT="$(git -C "$MIRROR" diff "origin/main...$HEAD_OID")" || die "git diff failed — cannot run the credential scan"
check_credentials "$DIFF_TEXT" || refuse "credential-scan check fired on PR #$PR_NUM"

say "all 7 checks passed: allowlist, session-PR, base, head-identity, mergeable, policy-paths+deletion-cap, credential-scan"

if [[ "$MODE" == "dry" ]]; then
  say "--dry-run: PR #$PR_NUM would be merged. Nothing merged."
  exit 0
fi

# The merge itself: through the pull request, as a human would. A MERGE COMMIT, not a squash, so
# main keeps each backup run's individual commit for after-the-fact review. Never --admin, never
# --delete-branch, never any force flag.
GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr merge "$PR_NUM" --repo "$SLUG" --merge \
  || refuse "gh declined the merge of PR #$PR_NUM (branch protection, or state changed mid-run). Left for a human."

MERGE_OID="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr view "$PR_NUM" --repo "$SLUG" --json mergeCommit -q .mergeCommit.oid)"
PR_URL="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr view "$PR_NUM" --repo "$SLUG" --json url -q .url)"
say "merged PR #$PR_NUM into main as $MERGE_OID"

# ── the record ───────────────────────────────────────────────────────────────────────────────
{
  print -r -- "=== merge $(date -u '+%Y-%m-%dT%H:%M:%SZ') ==="
  print -r -- "session:      $SESSION_TAG"
  print -r -- "pull request: #$PR_NUM  $PR_URL"
  print -r -- "branch:       $BRANCH @ ${HEAD_OID:0:12}"
  print -r -- "scope:        $N_FILES file(s) ($SHORTSTAT), $DELETED_FILES file deletion(s)"
  print -r -- "merge commit: $MERGE_OID"
  print -r -- "checks:       allowlist, session-PR, base=main, head-identity, mergeable, policy-paths, deletion-cap, credential-scan — all passed"
  [[ -n "$SUPERSEDED" ]] && print -r -- "superseded:   $SUPERSEDED — same session, older UTC date, left OPEN and NOT merged. Merging one of these later would revert this."
  print -r -- "to reverse:   a human opens a revert PR of $MERGE_OID (git revert -m 1). This script never reverts."
  print -r -- ""
} >> "$RECORD"
say "record appended to $RECORD"
say "=== done. To reverse: open a revert PR of $MERGE_OID — a human's act, not this script's. ==="

#!/usr/bin/env zsh
#
# sync-to-lintel.sh — carry edits made in the LIVE install into the PUBLISHED repo.
#
#   zsh /Users/jowolff/.claude/orchestrator/tools/sync-to-lintel.sh          # sync, branch, PR (asks first)
#   zsh /Users/jowolff/.claude/orchestrator/tools/sync-to-lintel.sh --yes    # same, no prompt
#   zsh /Users/jowolff/.claude/orchestrator/tools/sync-to-lintel.sh --check  # report only; exit 1 if drift
#
# LIVE      /Users/jowolff/.claude          — source of truth for CONTENT. Has no remote, on purpose.
# PUBLISHED /Users/jowolff/code/lintel      — remote git@github.com:thewolff/lintel.git, private.
#
# Copies LIVE -> PUBLISHED only. Never the other direction, never adds a remote to LIVE, never
# widens the published file set on its own. Announces every step, stops on the first failure,
# and tees the whole run to sync-to-lintel.log beside this script.
# Safe to run from the top every time: nothing assumes state from a previous run.
#
# BRANCH AND PULL REQUEST, NEVER main. Every sync lands on the ONE STANDING BRANCH
# sync-live-to-published and opens (or updates) the one standing pull request against main.
# The branch is force-reset to origin/main on every run, so the PR always shows exactly the
# current live→published delta — one PR, updated in place, instead of one new PR per run.
# This script never checks out, resets, moves or pushes main, master, production, prod or
# release — a review gate is the point, and a machine-authored commit going straight onto the
# published default branch defeats it.
#
# THE BRANCH STARTS AT origin/main, NOT AT THE LOCAL HEAD. Cutting from HEAD would stack each
# unmerged sync on the last one, so a pull request nobody merged would ride into the next one.
# Starting a branch at a remote ref is not the same as checking that ref out, and nothing here
# moves main either locally or on the remote.
#
# == IT NEVER MOVES HEAD IN THE PUBLISHED REPO ===============================================
# $PUB is somebody's checkout. Publishing is not a reason to move it, so this script does not:
# it keeps a linked worktree of its own ($WT, below) and does every write there. $PUB's HEAD,
# its branch and its working tree - clean or dirty - are the same before and after every run,
# including a run that fails partway. An earlier shape switched branch in $PUB itself and
# changed which branch that repository was on as a side effect of a backup; the guards written
# to contain that (switch back afterwards, refuse unless $PUB sits on a given branch) were
# patches over the wrong thing and are gone.
#
# GITHUB ACCOUNT. gh on this machine holds more than one account and the globally active one is
# not necessarily the owner of the published repo. Every gh call below is made with a
# per-invocation token for the account that owns the remote. The global active account is never
# switched.
#
# ══ WHAT DEFINES THE PUBLISHED SET ══════════════════════════════════════════════════════════
# `git -C $PUB ls-files` is the authority — a hand-chosen set, documented in
# /Users/jowolff/code/lintel/MANIFEST.md. The size of that set is deliberately not written down
# here: a copy of another file's number goes stale silently and then this script prints it as
# though quoting. Step 1 below reads the real count from the repo on every run.
# This script updates those paths and nothing else,
# with two narrow exceptions below (NEW_IN_SCOPE_DIRS). Everything else new is a human decision.
# ════════════════════════════════════════════════════════════════════════════════════════════

emulate -L zsh
setopt pipe_fail
setopt extended_glob

LIVE="/Users/jowolff/.claude"
PUB="/Users/jowolff/code/lintel"
# The publisher's own checkout of $PUB, so it never has to move $PUB's HEAD. Deliberately a
# hidden SIBLING of $PUB rather than a directory inside it: outside the repository there is no
# ignore rule to get wrong, and nothing that walks $PUB can wander into it.
WT="${PUB:h}/.${PUB:t}-publish-worktree"
# The tree LIVE is compared against. $PUB in --check (which creates no worktree); $WT on the
# write path, set at step 2b.
CMP_ROOT="$PUB"
SELF_DIR="${0:A:h}"
LOG="$SELF_DIR/sync-to-lintel.log"

MODE="sync"
ASSUME_YES=0
for arg in "$@"; do
  case "$arg" in
    --check) MODE="check" ;;
    --yes|-y) ASSUME_YES=1 ;;
    *) print -u2 -- "unknown argument: $arg (expected --check and/or --yes)"; exit 2 ;;
  esac
done

exec > >(tee "$LOG") 2>&1

step() { print -- ""; print -- "── $1 ──────────────────────────────────"; }
die()  { print -u2 -- ""; print -u2 -- "FAILED: $1"; print -u2 -- "Log: $LOG"; exit "${2:-1}"; }

# ── the exit codes that mean "declined on purpose" ──────────────────────────────────────────
# Defined ONCE, in publish-exit-codes.sh beside this file, and read from there by both this
# script and tools/publish-run.sh. That runner is what turns an exit code into the failure
# marker the Stop hook escalates into a session-blocking banner, so the two must not be able to
# disagree about which numbers are declines — and two copies of the number 4 is exactly how they
# would come to disagree. Missing or unreadable is fatal here rather than silently defaulted:
# the whole point is that there is no second definition anywhere.
[[ -r "$SELF_DIR/publish-exit-codes.sh" ]] || die "missing $SELF_DIR/publish-exit-codes.sh — the shared exit-code definitions" 2
source "$SELF_DIR/publish-exit-codes.sh"

# ─────────────────────────────────────────────────────────────────────────────────────────────
# HELD — tracked paths that are ALLOWED to differ and are NEVER copied.
#
# Each one diverged because a deliberate act changed the published copy, and re-copying the live
# version would undo that act. Every entry traces to a commit in $PUB — do not add an entry you
# cannot trace to one. Paths are relative to either root.
# ─────────────────────────────────────────────────────────────────────────────────────────────
typeset -a HELD_PATHS HELD_WHY

# Commits 4b312f4 + b89e1eb — a comment example in the instruction heuristic quoted the operator
# verbatim, including a typo. Both were replaced with neutral prose. The live file ALSO carries
# real machinery changes, so this one needs a hand-merge, not a skip-forever: take the live
# content, re-apply the same two-line neutralization, and check the result before committing.
HELD_PATHS+=( "orchestrator/hooks/savepoint-guard.mjs" )
HELD_WHY+=(   "redaction 4b312f4+b89e1eb (verbatim operator quote in a comment) — HAND-MERGE, live also has real changes" )

# Commit b89e1eb — the layout note describes where the directory sits, and the true answer is
# different in each tree. Published: its own repo. Live: inside the .claude repo. Copying live
# over it would make the published README state something false about the published repo.
HELD_PATHS+=( "orchestrator/README.md" )
HELD_WHY+=(   "publication-context edit b89e1eb — the sentence is true in each tree and differs between them" )

# Commit 6ae0f5a — the charter symlink was made relative so it resolves in a clone. Live points
# at an absolute path under /Users/jowolff/.claude, which resolves nowhere else.
HELD_PATHS+=( "orchestrator/CHARTER.md" )
HELD_WHY+=(   "symlink made relative in 6ae0f5a — live is absolute and would not resolve in a clone" )

# Commit 95e0dbe — six eval fixtures each carried one string transcribed from the live inbox,
# replaced with a neutral equivalent of the same linguistic shape. Verified 2026-08-20: the live
# copies differ from published in that one line and nothing else.
for s in refint-bare-obligation-no-id-passthrough refint-conversation-smalltalk-passthrough \
         refint-dangling-ref-blocks refint-defined-ref-passthrough \
         refint-names-offending-row refint-untriaged-smalltalk-not-annotated; do
  HELD_PATHS+=( "orchestrator/evals/scenarios/$s/setup.sh" )
  HELD_WHY+=(   "redaction 95e0dbe (transcribed inbox string in a fixture)" )
done

# ─────────────────────────────────────────────────────────────────────────────────────────────
# REPO_OWN — tracked in $PUB with no live counterpart. Written for the published repo. Skipped
# silently; their absence from LIVE is not a deletion.
# ─────────────────────────────────────────────────────────────────────────────────────────────
typeset -a REPO_OWN
# MANIFEST.md documents what the published repo publishes and why; it was brought under version
# control there and has no live counterpart by design. Without this entry the comparison reports
# it as tracked-but-deleted-live on every single run, and a check that can never come back clean
# is a check people stop reading — which now also means a hook consuming a permanently red exit
# status. It belongs here for the same reason README.md and .gitignore do.
REPO_OWN=( "README.md" ".gitignore" "MANIFEST.md" )

# ─────────────────────────────────────────────────────────────────────────────────────────────
# DENY — never copied under ANY circumstance, tracked or not. These are the runtime-state classes
# quoted from /Users/jowolff/code/lintel/.gitignore: the orchestrator writes them while running,
# they carry verbatim operator input, session ids and work content. A regex here overrides
# everything below it. This is the safety belt, not the routing.
# ─────────────────────────────────────────────────────────────────────────────────────────────
typeset -a DENY
DENY=(
  '^orchestrator/state/runs(/|$)'
  '^orchestrator/state/quarantine(/|$)'
  '^orchestrator/state/hook-lab(/|$)'
  '^orchestrator/state/turn-ids(/|$)'
  '^orchestrator/state/audit-samples(/|$)'
  '^orchestrator/state/\.projects(/|$)'
  '^orchestrator/state/rules-flat(/|$)'
  '^orchestrator/state/hook-scope-anchor(/|$)'
  '^orchestrator/state/hook-backups-'
  '^orchestrator/state/LEDGER\.jsonl'
  '^orchestrator/state/REQUESTS(-INBOX)?\.jsonl'
  '^orchestrator/state/(STANDUP|WORKSTREAMS|REGISTRY|ROUTING|EXPERIMENTS|RETRACTIONS|BOOTSTRAP-REPORT|NEXT-ACTION|CODEX-FIXES|JUDGEMENT|REUSE-PLAN-v2|REUSE-PLAN)\.md($|\.)'
  '^orchestrator/state/\.(session-id|turn-state|guard-state|refint-watermark)(/|$)'
  '^orchestrator/state/fix-openclaw-crashloop\.'
  '(^|/)\.git(/|$)'
  '(^|/)node_modules(/|$)'
  '(^|/)__pycache__(/|$)'
  '\.pyc$'
  '(^|/)\.DS_Store$'
  '\.log$'
  '\.credentials\.json$'
)

# ─────────────────────────────────────────────────────────────────────────────────────────────
# NEW_IN_SCOPE_DIRS — the only places a NEW live file is copied without a human deciding first.
# MANIFEST.md defines each of these as a whole directory, so a new member is obviously in scope.
# Every such copy is announced by name. Anything new outside these directories is listed as a
# decision and NOT copied. The per-directory sizes are read from the repo when they are printed,
# never transcribed from MANIFEST.md into this file.
# ─────────────────────────────────────────────────────────────────────────────────────────────
typeset -a NEW_IN_SCOPE_DIRS
NEW_IN_SCOPE_DIRS=(
  "orchestrator/hooks/"
  "orchestrator/evals/"
  "orchestrator/tools/"
  "orchestrator/state/tools/"
  "orchestrator/contracts/"
  "orchestrator/runbooks/"
  "orchestrator/candidates/"
  "skills/new-seat/"
)

# NEW_NOISE — new files that are editor backups or scratch, never machinery. Reported under a
# separate quiet heading so the decision list stays readable.
typeset -a NEW_NOISE
NEW_NOISE=( '\.bak(-|\.|$)' '\.pre-[a-z-]+$' '~$' '\.orig$' '\.rej$' '\.swp$' )

matches_any() {
  local rel="$1"; shift
  local pat
  for pat in "$@"; do [[ "$rel" =~ $pat ]] && return 0; done
  return 1
}
in_list() {
  local rel="$1"; shift
  local a
  for a in "$@"; do [[ "$rel" == "$a" ]] && return 0; done
  return 1
}
held_reason() {
  local rel="$1" i
  for (( i = 1; i <= ${#HELD_PATHS}; i++ )); do
    [[ "${HELD_PATHS[i]}" == "$rel" ]] && { print -- "${HELD_WHY[i]}"; return 0; }
  done
  return 1
}
under_in_scope_dir() {
  local rel="$1" d
  for d in "${NEW_IN_SCOPE_DIRS[@]}"; do [[ "$rel" == "$d"* ]] && return 0; done
  return 1
}
# How many paths the published repo currently tracks under a prefix. Asked of the repo every time
# it is needed, so nothing here can drift out of step with MANIFEST.md the way a transcribed
# number does. In --check the authority is the COMMITTED tree of $CHECK_REF, not a working tree,
# so a dirty or side-branch checkout cannot skew the count.
tracked_count() {
  if [[ "$MODE" == "check" ]]; then
    if [[ -z "$1" || "$1" == "." ]]; then git -C "$PUB" ls-tree -r --name-only "$CHECK_REF"
    else git -C "$PUB" ls-tree -r --name-only "$CHECK_REF" -- "$1"; fi
  else
    if [[ -z "$1" || "$1" == "." ]]; then git -C "$CMP_ROOT" ls-files
    else git -C "$CMP_ROOT" ls-files -- "$1"; fi
  fi | wc -l | tr -d ' '
}

step "[1/7] roots"
[[ -d "$LIVE" ]] || die "LIVE root missing: $LIVE" 2
[[ -d "$PUB"  ]] || die "PUBLISHED root missing: $PUB" 2
git -C "$PUB" rev-parse --is-inside-work-tree >/dev/null 2>&1 || die "$PUB is not a git repo" 2

# ── what --check compares against ───────────────────────────────────────────────────────────
# The committed tree of the last-fetched origin/main, read via plumbing: no worktree, no
# network, read-only. This makes the check independent of the checkout's mood — a dirty
# working tree or a parked side branch (both observed 2026-08-20) can no longer blind or skew
# drift detection. It also puts the check on the same base the write path cuts its branch from,
# so check and sync cannot disagree about what drift is. Falls back to the local HEAD's
# committed tree when no origin/main tracking ref exists (e.g. a remoteless clone).
CHECK_REF=""
if [[ "$MODE" == "check" ]]; then
  if git -C "$PUB" rev-parse --verify -q refs/remotes/origin/main >/dev/null; then
    CHECK_REF="refs/remotes/origin/main"
  else
    CHECK_REF="HEAD"
  fi
fi

print -- "LIVE      $LIVE"
print -- "PUBLISHED $PUB  (HEAD $(git -C "$PUB" rev-parse --short HEAD))"
print -- "published set: $(tracked_count '.') tracked path(s), read from the repo just now"
[[ "$MODE" == "check" ]] && print -- "check base: committed tree of $CHECK_REF ($(git -C "$PUB" rev-parse --short "$CHECK_REF"))"
print -- "mode      $MODE"

step "[2/7] the state of the published checkout"
# THE PUBLISHER NEVER TOUCHES $PUB's WORKING TREE OR HEAD. Everything it writes happens in the
# private worktree set up at step 2b. So a dirty $PUB does not endanger anything on the write
# path, and refusing to publish because someone has unsaved work in the mirror would be refusing
# for a reason that no longer exists.
#
# In --check the comparison base is the committed tree of $CHECK_REF, not this working tree,
# so a dirty checkout no longer kills detection (it used to die here with exit 3, and did — a
# one-line uncommitted fix blinded drift detection for hours on 2026-08-20). Dirty tracked
# paths are still worth a sentence: a repo-side edit in flight is divergence forming, and the
# right response is to say so, not to stop measuring.
DIRTY="$(git -C "$PUB" status --porcelain)"
PUB_BRANCH="$(git -C "$PUB" rev-parse --abbrev-ref HEAD 2>/dev/null || print 'HEAD')"
print -- "checked out on '$PUB_BRANCH' — not read and not modified by the write path below"
if [[ -n "$DIRTY" ]]; then
  if [[ "$MODE" == "check" ]]; then
    print -- "NOTE: $PUB has uncommitted changes — repo-side edits in flight, divergence forming."
    print -- "They do not affect this check (it compares against $CHECK_REF), but they will need a"
    print -- "commit, a HELD entry, or a discard before they mean anything:"
    print -- "$DIRTY"
  else
    print -- "NOTE: $PUB has uncommitted changes. They are left alone: the copy, the commit and the"
    print -- "push below all happen in a separate worktree, and this checkout is never written to."
  fi
else
  print -- "working tree clean"
fi

FETCH_OK=0
# --check DOES NOT CONTACT THE NETWORK, and that is a correctness property rather than a saving.
# This fetch was measured on 2026-08-20 at 1.038s of the Stop hook's 4000ms budget, spent to print
# one informational line: FETCH_OK is read only at step 2b, which --check never reaches, and the
# comparison --check performs is LIVE against $PUB's own working tree (CMP_ROOT=$PUB, set at the
# top of this file), which does not depend on origin at all. So in check mode the fetch bought a
# sentence and nothing else, while putting a remote round trip into the path of every single turn
# — where a slow network reads as a broken check. The write path below still fetches, and still
# refuses to cut a branch when the fetch failed.
if [[ "$MODE" == "check" ]]; then
  print -- "origin not contacted: --check is read-only and local by design. It compares against the"
  print -- "  last-fetched $CHECK_REF; the write path still fetches, which keeps that ref current."
elif git -C "$PUB" remote get-url origin >/dev/null 2>&1; then
  # --prune, and it is load-bearing rather than tidiness. When the standing pull request is
  # merged with "delete branch", the sync branch stops existing on the remote — but a plain fetch
  # leaves refs/remotes/origin/sync-live-to-published behind pointing at the merged tip. The
  # lease on the push at step [7/7] is exactly that ref, so the next run promises the remote a
  # value the remote no longer has and is refused with "stale info". Pruning makes the
  # remote-tracking refs say what the remote actually says, which is the only thing the lease is
  # allowed to be. It removes local records of remote branches that are gone; it deletes nothing
  # on the remote and no local branch.
  if git -C "$PUB" fetch --quiet --prune origin 2>/dev/null; then
    FETCH_OK=1
    AHEAD="$(git -C "$PUB" rev-list --count origin/main..HEAD 2>/dev/null || print 0)"
    BEHIND="$(git -C "$PUB" rev-list --count HEAD..origin/main 2>/dev/null || print 0)"
    print -- "local HEAD vs origin/main: $AHEAD ahead, $BEHIND behind"
    print -- "  (informational: the sync branch below is cut from origin/main, not from HEAD, so a"
    print -- "   stale or ahead local checkout can no longer become the base of a sync. This used"
    print -- "   to be a fatal check and no longer needs to be.)"
  else
    print -- "could not fetch origin (offline or auth) — no verified origin/main to branch from"
  fi
else
  print -- "no origin remote — will commit locally on a new branch and skip the push"
fi

# ── github account preflight ────────────────────────────────────────────────────────────────
# Done here, before anything is copied, so an auth problem costs nothing. --check never needs
# gh and never runs this. GH_ACCOUNT_TOKEN stays empty when there is no remote to push to.
GH_OWNER=""; GH_REPO=""; GH_ACCOUNT_TOKEN=""
if [[ "$MODE" != "check" ]] && git -C "$PUB" remote get-url origin >/dev/null 2>&1; then
  ORIGIN_URL="$(git -C "$PUB" remote get-url origin)"
  SLUG="${ORIGIN_URL##*:}"; SLUG="${SLUG##*github.com/}"; SLUG="${SLUG%.git}"
  GH_OWNER="${SLUG%%/*}"; GH_REPO="${SLUG##*/}"
  [[ -n "$GH_OWNER" && -n "$GH_REPO" ]] || die "could not read owner/repo out of origin URL: $ORIGIN_URL" 2
  command -v gh >/dev/null || die "gh is not installed, so no pull request can be opened" 2
  GH_ACCOUNT_TOKEN="$(gh auth token --user "$GH_OWNER" 2>/dev/null)" || GH_ACCOUNT_TOKEN=""
  if [[ -z "$GH_ACCOUNT_TOKEN" ]]; then
    print -u2 -- "gh has no authenticated account named '$GH_OWNER', which owns $SLUG."
    print -u2 -- "Log in with:  gh auth login --hostname github.com"
    print -u2 -- "(Do not switch the globally active gh account; this script asks for the owner's"
    print -u2 -- " token per invocation with: gh auth token --user $GH_OWNER)"
    die "gh is not authenticated for $GH_OWNER" 2
  fi
  PERM="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh repo view "$SLUG" --json viewerPermission -q .viewerPermission 2>/dev/null || print '')"
  case "$PERM" in
    ADMIN|MAINTAIN|WRITE) print -- "gh: $GH_OWNER has $PERM on $SLUG" ;;
    "") die "gh could not read $SLUG as $GH_OWNER — token expired, or no access" 2 ;;
    *)  die "$GH_OWNER has only $PERM on $SLUG — cannot push a branch or open a pull request" 2 ;;
  esac
fi

# ── the working branch, cut from origin/main ────────────────────────────────────────────────
# The base is the REMOTE main, deliberately. Cutting from HEAD stacks each unmerged sync on top
# of the previous one, so a pull request nobody merged rides into the next one anyway. Creating
# a branch that STARTS at a remote ref does not check out, move or push main.
#
# THE NAME IS A CONSTANT, deliberately. It used to embed a per-run timestamp, which meant the
# PR-dedupe lookup below (`gh pr list --head "$SYNC_BRANCH"`) could never match a previous
# run's PR — so every run opened a new one: twelve identical PRs in 38 minutes on 2026-08-20.
# With one standing name, each run force-resets the branch to origin/main, re-copies, pushes
# with --force-with-lease, and the dedupe finds and updates the one standing PR in place.
SYNC_BRANCH="sync-live-to-published"
case "$SYNC_BRANCH" in
  main|master|production|prod|release) die "refusing to work on a protected branch name: $SYNC_BRANCH" 2 ;;
esac
BASE_SHA=""
if [[ "$MODE" != "check" ]]; then
  step "[2b/7] the publisher's own worktree"
  # ── WHY A WORKTREE, AND NOT A BRANCH SWITCH IN $PUB ───────────────────────────────────────
  # Publishing is not a reason to move somebody else's checkout. The previous shape did
  # `git switch -c` in $PUB, which changed which branch that repository was on as a side effect
  # of a backup running — unannounced, at a moment nobody chose, and with no way back that the
  # publisher was allowed to take. Every patch over that (switch back afterwards, refuse unless
  # $PUB sits on a particular branch) leaves the underlying wrong in place: a tool mutating a
  # human's working tree to do its own bookkeeping.
  #
  # A linked worktree gives this script a checkout of its own. `git worktree add` writes only
  # $WT and the repository's own worktree bookkeeping; it does not read, write, or move $PUB's
  # working tree or HEAD. Everything downstream — the copy, `git add -A`, the credential scan of
  # the STAGED DIFF, the commit, the push — then runs unchanged against a real index and a real
  # working tree, so no existing safety property had to be reimplemented to get here.
  #
  # $WT sits OUTSIDE $PUB deliberately. A worktree nested inside the repository would have to be
  # gitignored to stay invisible, and anything that missed the ignore rule — `git clean`, a
  # status sweep, a future publisher — would be walking through it.
  if [[ -n "$GH_ACCOUNT_TOKEN" ]]; then
    (( FETCH_OK )) || die "could not fetch origin, so origin/main may be stale — refusing to cut a branch from an unverified base" 3
    git -C "$PUB" rev-parse --verify -q refs/remotes/origin/main >/dev/null \
      || die "no origin/main to branch from" 3
    BASE_REF="origin/main"
  else
    # No remote at all: nothing to cut from but the local HEAD commit. Note this reads $PUB's
    # HEAD; it does not move it.
    BASE_REF="$(git -C "$PUB" rev-parse HEAD)" || die "could not read HEAD in $PUB" 3
  fi
  # Pin the base to one commit now and use that commit everywhere below, so a fetch landing
  # mid-run cannot leave the comparison and the commit standing on different bases.
  BASE_FULL="$(git -C "$PUB" rev-parse "$BASE_REF")" || die "could not resolve $BASE_REF" 3
  BASE_SHA="$(git -C "$PUB" rev-parse --short "$BASE_FULL")"

  # A worktree registration whose directory has been deleted is stale bookkeeping, and pruning it
  # is the documented way to clear it. This only removes records of directories that are gone.
  git -C "$PUB" worktree prune 2>/dev/null

  if git -C "$PUB" worktree list --porcelain | grep -qx "worktree $WT"; then
    # Reuse. Every file in here was written by this script, so discarding whatever a previous
    # run left behind costs nobody their work — and it means a run that died mid-copy cannot
    # wedge the publisher until a human comes and tidies up.
    git -C "$WT" checkout --detach --force --quiet "$BASE_FULL" \
      || die "could not point the publisher's worktree at $BASE_SHA" 3
    git -C "$WT" clean -qfd || die "could not clear leftovers from the publisher's worktree" 3
    print -- "reusing the publisher's worktree at $WT, reset to $BASE_REF ($BASE_SHA)"
  elif [[ -e "$WT" ]]; then
    print -u2 -- "$WT exists but is not a registered worktree of $PUB."
    print -u2 -- "This script will not write into a directory it does not own. Inspect it, then"
    print -u2 -- "either remove it or register it with: git -C $PUB worktree add --detach $WT $BASE_SHA"
    die "the publisher's worktree path is occupied by something else" 3
  else
    git -C "$PUB" worktree add --detach --quiet "$WT" "$BASE_FULL" \
      || die "could not create the publisher's worktree at $WT" 3
    print -- "created the publisher's worktree at $WT, detached at $BASE_REF ($BASE_SHA)"
  fi
  CMP_ROOT="$WT"
  print -- "the comparison below is against that worktree, which holds $BASE_REF"
  print -- "$PUB is still on '$PUB_BRANCH' and has not been read or written"
  print -- "no branch has been created yet, nothing copied, nothing committed"
fi

step "[3/7] compare LIVE against the published file set"
typeset -a TO_COPY NEW_COPY HELD_LIST DECISIONS NOISE DELETED SAME

# 3a. Every path already tracked in the published set.
#
# On the write path the authority is the worktree at $WT (which holds $BASE_REF), compared with
# cmp. In --check it is the COMMITTED tree of $CHECK_REF, compared by blob hash: `ls-tree -r`
# gives every tracked path with its committed blob in one git spawn, and one
# `git hash-object --stdin-paths` hashes every live candidate in a second spawn. Two processes
# total, not one per file — the per-file-spawn shape is exactly what blew the Stop hook's
# budget once already (see the measurement note above step 3b). With no .gitattributes and no
# autocrlf in the published repo (verified 2026-08-20), the raw hash equals the committed blob
# hash, so this comparison is byte-equivalent to cmp.
if [[ "$MODE" == "check" ]]; then
  typeset -a CAND CAND_HASH
  while IFS= read -r line; do
    meta="${line%%$'\t'*}"; rel="${line#*$'\t'}"
    [[ -z "$rel" || "$meta" == "$line" ]] && continue
    fmode="${meta%% *}"
    blob="${meta##* }"
    in_list "$rel" "${REPO_OWN[@]}" && continue
    if matches_any "$rel" "${DENY[@]}"; then
      HELD_LIST+=( "$rel  [DENY — runtime state, never copied]" )
      continue
    fi
    live="$LIVE/$rel"
    if [[ "$fmode" == "120000" || -L "$live" ]]; then
      # Symlinks are structural; a content copy would clobber the link. Always held.
      if reason="$(held_reason "$rel")"; then HELD_LIST+=( "$rel  [$reason]" )
      else HELD_LIST+=( "$rel  [symlink — structural, compare by hand]" ); fi
      continue
    fi
    if [[ ! -e "$live" ]]; then
      DELETED+=( "$rel" )
      continue
    fi
    CAND+=( "$rel" ); CAND_HASH+=( "$blob" )
  done < <(git -C "$PUB" ls-tree -r "$CHECK_REF")

  if (( ${#CAND} )); then
    typeset -a LIVE_HASH
    LIVE_HASH=( ${(f)"$(for r in "${CAND[@]}"; do print -r -- "$LIVE/$r"; done \
      | git -C "$PUB" hash-object --stdin-paths)"} )
    (( ${#LIVE_HASH} == ${#CAND} )) \
      || die "hash-object returned ${#LIVE_HASH} hashes for ${#CAND} paths — cannot trust this comparison" 2
    for (( i = 1; i <= ${#CAND}; i++ )); do
      rel="${CAND[i]}"
      if [[ "${LIVE_HASH[i]}" == "${CAND_HASH[i]}" ]]; then
        SAME+=( "$rel" )
      elif reason="$(held_reason "$rel")"; then
        HELD_LIST+=( "$rel  [$reason]" )
      else
        TO_COPY+=( "$rel" )
      fi
    done
  fi
else
  while IFS= read -r rel; do
    [[ -z "$rel" ]] && continue
    in_list "$rel" "${REPO_OWN[@]}" && continue
    if matches_any "$rel" "${DENY[@]}"; then
      HELD_LIST+=( "$rel  [DENY — runtime state, never copied]" )
      continue
    fi
    live="$LIVE/$rel"
    if [[ -L "$CMP_ROOT/$rel" || -L "$live" ]]; then
      # Symlinks are structural; a content copy would clobber the link. Always held.
      if reason="$(held_reason "$rel")"; then HELD_LIST+=( "$rel  [$reason]" )
      else HELD_LIST+=( "$rel  [symlink — structural, compare by hand]" ); fi
      continue
    fi
    if [[ ! -e "$live" ]]; then
      DELETED+=( "$rel" )
      continue
    fi
    if cmp -s "$live" "$CMP_ROOT/$rel"; then
      SAME+=( "$rel" )
    elif reason="$(held_reason "$rel")"; then
      HELD_LIST+=( "$rel  [$reason]" )
    else
      TO_COPY+=( "$rel" )
    fi
  done < <(git -C "$CMP_ROOT" ls-files)
fi

# THE WALK DOES NOT DESCEND INTO DIRECTORIES DENY ALREADY EXCLUDES WHOLESALE.
# Measured 2026-08-20: the walk below visited 8843 files, of which 8504 were under
# orchestrator/state and 8222 were under orchestrator/state/hook-lab alone. Every one of those was
# then discarded by the DENY filter — but only after a regex pass per file per pattern, in shell,
# which cost ~1.9s of the Stop hook's 4000ms budget.
#
# That cost tracked the size of the orchestrator's OWN SCRATCH OUTPUT, which grows without bound:
# every lab run and every backup adds files that can never be published. Pruning at the find level
# makes the walk proportional to what could actually be copied instead — 8843 paths down to ~436.
# This is the part that stops the budget problem from coming back, because the remaining count no
# longer grows when the machinery is merely used.
#
# PRUNING IS ONLY SAFE WHERE DENY EXCLUDES THE WHOLE DIRECTORY, so these are full anchored paths
# rather than bare -name predicates: a directory called `runs` somewhere else under orchestrator/
# is NOT denied, and pruning it by basename would silently change the report. The loop below
# proves the two lists agree instead of trusting that they do, and refuses to run if they drift.
typeset -a PRUNE_PATHS PRUNE_PRED
PRUNE_PATHS=(
  "$LIVE/orchestrator/state/runs"
  "$LIVE/orchestrator/state/quarantine"
  "$LIVE/orchestrator/state/hook-lab"
  "$LIVE/orchestrator/state/turn-ids"
  "$LIVE/orchestrator/state/hook-backups-*"
)
PRUNE_PRED=()
for pp in "${PRUNE_PATHS[@]}"; do
  prel="${pp#$LIVE/}"; prel="${prel%\*}"
  matches_any "$prel" "${DENY[@]}" \
    || die "prune list has drifted from DENY: '$prel' would be skipped by the walk but is not denied" 2
  PRUNE_PRED+=( -path "$pp" -o )
done

# 3b. Live files with no published counterpart, under the roots the published tree covers.
#
# THE TRACKED SET IS READ ONCE. This loop used to ask git whether each live file was tracked, one
# `git ls-files --error-unmatch` process per file. Measured on 2026-08-20: 354 files reach that
# call, a git process costs ~12.4ms, and the loop therefore cost ~4.4s of the Stop hook's 4000ms
# budget on its own — which is what killed the check with SIGTERM.
#
# Raising the budget would not have fixed it, because the cost is O(live files under these roots)
# in PROCESS SPAWNS: it grows every time anyone adds a file, so any number chosen would expire.
# One `git ls-files` into an associative array makes it one spawn and an O(1) hash lookup per
# file, which does not grow. The lookup is exact-string against the same list --error-unmatch
# consults, and every $rel here comes from `find -type f`, so it is a concrete path and not a
# pathspec — the two agree by construction.
typeset -A TRACKED_SET
if [[ "$MODE" == "check" ]]; then
  while IFS= read -r t; do [[ -n "$t" ]] && TRACKED_SET[$t]=1; done \
    < <(git -C "$PUB" ls-tree -r --name-only "$CHECK_REF")
else
  while IFS= read -r t; do [[ -n "$t" ]] && TRACKED_SET[$t]=1; done < <(git -C "$CMP_ROOT" ls-files)
fi

while IFS= read -r abs; do
  rel="${abs#$LIVE/}"
  matches_any "$rel" "${DENY[@]}" && continue
  [[ -n "${TRACKED_SET[$rel]}" ]] && continue
  if matches_any "$rel" "${NEW_NOISE[@]}"; then NOISE+=( "$rel" ); continue; fi
  if under_in_scope_dir "$rel"; then NEW_COPY+=( "$rel" ); else DECISIONS+=( "$rel" ); fi
done < <(find "$LIVE/agents" "$LIVE/orchestrator" "$LIVE/skills/new-seat" \
           \( "${PRUNE_PRED[@]}" -name .git -o -name node_modules \) -prune -o -type f -print 2>/dev/null | sort)

print -- "${#SAME} identical, ${#TO_COPY} drifted, ${#NEW_COPY} new-in-scope, ${#HELD_LIST} held, ${#DECISIONS} for a human, ${#DELETED} deleted-live, ${#NOISE} noise"

step "[4/7] the report — nothing has been changed yet"
if (( ${#TO_COPY} )); then
  print -- ""
  print -- "WILL COPY — tracked in the published repo and drifted:"
  for f in "${TO_COPY[@]}"; do print -- "  $f"; done
fi
if (( ${#NEW_COPY} )); then
  print -- ""
  print -- "WILL ADD — new live files inside a directory MANIFEST.md defines as a whole:"
  # Counts read from the published repo right now, not transcribed from MANIFEST.md.
  scopes=""
  for d in "${NEW_IN_SCOPE_DIRS[@]}"; do scopes+="${scopes:+, }$d currently tracks $(tracked_count "$d") file(s)"; done
  print -- "  ($scopes; MANIFEST.md defines each as a whole, so a new member is in scope)"
  for f in "${NEW_COPY[@]}"; do print -- "  $f"; done
fi
if (( ${#DELETED} )); then
  print -- ""
  print -- "DELETED LIVE but still tracked in the published repo — NOT removed by this script,"
  print -- "because a deletion is a publication decision. Remove by hand if intended:"
  for f in "${DELETED[@]}"; do print -- "  $f"; done
fi
if (( ${#DECISIONS} )); then
  print -- ""
  print -- "FOR A HUMAN — new live files outside any manifest-defined directory. NOT copied."
  print -- "  Widening the published set is not this script's call:"
  for f in "${DECISIONS[@]}"; do print -- "  $f"; done
fi
if (( ${#HELD_LIST} )); then
  print -- ""
  print -- "HELD — allowed to differ, never copied (each traces to a commit in the published repo):"
  for f in "${HELD_LIST[@]}"; do print -- "  $f"; done
fi
if (( ${#NOISE} )); then
  print -- ""
  print -- "ignored as editor backups / scratch:"
  for f in "${NOISE[@]}"; do print -- "  $f"; done
fi

DRIFT_COUNT=$(( ${#TO_COPY} + ${#NEW_COPY} + ${#DELETED} ))
# What the copy loop at step [6/7] actually iterates. DELETED is deliberately NOT in here:
# deletions are a publication decision and this script never applies them, so counting them as
# work for the write path sends it off to branch and copy nothing. DRIFT_COUNT keeps the
# deletions because --check is a question about the whole relationship, not about what a sync
# run would do.
COPY_COUNT=$(( ${#TO_COPY} + ${#NEW_COPY} ))

if [[ "$MODE" == "check" ]]; then
  step "[5/7] --check: reporting only"
  print -- "$DRIFT_COUNT actionable difference(s). Held and human-decision items do not affect the exit status,"
  print -- "because neither ever clears on its own and a permanently red check gets ignored."
  print -- "Log: $LOG"
  (( DRIFT_COUNT == 0 )) && exit 0
  exit 1
fi

# ── the write path is gated on the COPY SET, not on total drift ──────────────────────────────
# It used to be gated on DRIFT_COUNT, which includes deleted-live paths. The copy loop below
# never touches those, so a run whose only difference was deletions passed the gate, cut a
# branch, copied nothing, staged nothing, and died at step [7/7] blaming an ignore file that had
# nothing to filter. Nothing to copy means nothing for a sync run to do, and that is a success.
#
# IT IS A PLAIN exit 0, NOT A DECLINE CODE from publish-exit-codes.sh. That file's own bar is
# that the condition clears without a human; a path deleted live but still tracked in the
# published repo only clears when somebody removes it there, so a decline code would fire on
# every run forever. --check still exits 1 while any remain (DRIFT_COUNT above is unchanged),
# which is where those deletions stay visible to anyone who asks.
if (( COPY_COUNT == 0 )); then
  step "[5/7] nothing to sync"
  print -- "No file drifted and no new in-scope file appeared, so there is nothing to copy."
  if (( ${#DELETED} )); then
    print -- ""
    print -- "${#DELETED} path(s) are still tracked in the published repo with no live counterpart."
    print -- "This script does not remove them — a deletion is a publication decision — so they are"
    print -- "not work a sync run can do. Waiting on a human to remove them by hand in $PUB:"
    for f in "${DELETED[@]}"; do print -- "  $f"; done
    print -- ""
    print -- "Until somebody does, --check keeps exiting 1 and listing them. That is deliberate."
  else
    print -- "The published repo already matches LIVE for every path it tracks."
  fi
  print -- "No branch was created and nothing was committed. $PUB is untouched, still on '$PUB_BRANCH'."
  print -- "Log: $LOG"
  exit 0
fi

# ── quiescence gate ─────────────────────────────────────────────────────────────────────────
# A file modified in the last 120s may still be mid-write, and a torn half-written file must
# never be committed to the published tree. Any such file aborts the WHOLE run with the shared
# "declined on purpose" exit code from publish-exit-codes.sh — the next quiet cycle picks the
# drift up; nothing is retried inside this run. This generalizes the per-script freshness idea
# (MIN_TOOL_AGE_MS) to every file the run would copy.
#
# IT IS A DECLINE, NOT A FAILURE, AND THE EXIT CODE IS HOW THAT TRAVELS. Nothing was lost and
# nobody has to do anything: the writer finishes, the file goes quiet, and the next run copies
# it. tools/publish-run.sh reads the same definition file and keeps this quiet instead of
# writing a failure marker. Before that existed, a correct decline here was shown to the owner
# as "PUBLISHING IS NOT HAPPENING" with a 30-minute backoff attached (2026-08-20T22:55:08Z).
#
# Write path only: --check returns at step [5/7] above and never copies, so it never gates —
# which also means --check can never exit a declined code, and the Stop hook's own reading of
# --check exit codes stays untouched by any of this.
QUIESCE_SECS=120
NOW_EPOCH="$(date +%s)"
typeset -a IN_FLIGHT
for rel in "${TO_COPY[@]}" "${NEW_COPY[@]}"; do
  m="$(stat -f %m "$LIVE/$rel" 2>/dev/null || print 0)"
  (( NOW_EPOCH - m < QUIESCE_SECS )) && IN_FLIGHT+=( "$rel  (modified $((NOW_EPOCH - m))s ago)" )
done
if (( ${#IN_FLIGHT} )); then
  print -u2 -- ""
  print -u2 -- "QUIESCENCE GATE: ${#IN_FLIGHT} file(s) in the copy set changed within the last ${QUIESCE_SECS}s"
  print -u2 -- "and may still be mid-write. Copying a torn file into the published tree is worse than"
  print -u2 -- "waiting one cycle, so this run stops here — nothing was copied, branched or committed:"
  for f in "${IN_FLIGHT[@]}"; do print -u2 -- "  $f"; done
  print -u2 -- "This is a DECLINE, not a failure. Nothing was lost, nothing is broken, and nobody has to"
  print -u2 -- "do anything: the drift is still there and the next run after those files settle takes it."
  die "DECLINED — live tree not quiescent; re-run once the files above have settled" $PUBLISH_EXIT_NOT_QUIESCENT
fi
print -- "quiescence: no file in the copy set modified in the last ${QUIESCE_SECS}s"

step "[5/7] confirm"
print -- "About to copy $((${#TO_COPY} + ${#NEW_COPY})) file(s) into the publisher's own worktree"
print -- "  $WT   (detached at $BASE_REF $BASE_SHA)"
print -- "commit them there on the standing sync branch (force-reset to $BASE_REF each run)"
print -- "  $SYNC_BRANCH"
print -- "and open a pull request against main. Your checkout at $PUB is not touched: it stays on"
print -- "'$PUB_BRANCH' with its working tree exactly as it is now. main is never checked out,"
print -- "moved or pushed."
print -- "To undo: close the pull request without merging and delete the branch. Nothing lands on"
print -- "main until a human merges it, so there is no destructive reversal to perform."
if (( ASSUME_YES )); then
  print -- "--yes given; proceeding without a prompt."
else
  printf 'Type SYNC to proceed: '
  read -r REPLY
  [[ "$REPLY" == "SYNC" ]] || {
    print -- "Not confirmed. No file was copied, no branch was created, nothing was committed."
    print -- "$PUB is untouched, still on '$PUB_BRANCH'."
    exit 1
  }
fi

step "[6/7] branch, then copy"
# The branch is created HERE, after confirmation, and inside the publisher's worktree. $PUB's
# HEAD is not involved: `git switch -C` in a linked worktree moves only that worktree's HEAD.
# -C (not -c): the standing branch usually already exists from the previous run, and resetting
# it to $BASE_FULL is the point — its old tip is a machine-made commit that survives on the
# remote until the force-with-lease push below replaces it, so nothing of anyone's is lost.
git -C "$WT" switch -C "$SYNC_BRANCH" --quiet \
  || die "could not create $SYNC_BRANCH in the publisher's worktree" 3
print -- "created $SYNC_BRANCH in $WT, starting at $BASE_REF ($BASE_SHA)"
print -- "$PUB is still on '$PUB_BRANCH'"

for rel in "${TO_COPY[@]}" "${NEW_COPY[@]}"; do
  # Belt and braces: the deny list is re-checked at the moment of writing, not only at routing.
  matches_any "$rel" "${DENY[@]}" && die "refusing to copy denied path $rel (routing bug)"
  held_reason "$rel" >/dev/null && die "refusing to copy held path $rel (routing bug)"
  mkdir -p "$WT/${rel:h}" || die "mkdir failed for $WT/${rel:h}"
  cp -p "$LIVE/$rel" "$WT/$rel" || die "cp failed for $rel"
  print -- "  copied  $rel"
done

step "[7/7] commit and pull request"
# cd into the WORKTREE, not $PUB. Everything below — add, the credential scan of the staged diff,
# commit, push — is byte-for-byte the same sequence as before against a real index and a real
# working tree; only which working tree changed.
cd "$WT" || die "cd $WT failed"
git add -A -- . || die "git add failed"
if git diff --cached --quiet; then
  # This message used to assert the ignore file was filtering everything, which was one
  # hypothesis stated as a finding — and the wrong one whenever the copy set was empty, which the
  # gate at step [5/7] now rules out before this point is ever reached. Say what is known, list
  # the paths, and name the candidate causes as candidates.
  print -u2 -- ""
  print -u2 -- "$COPY_COUNT file(s) were copied into $WT and the index is still empty."
  print -u2 -- "The copy set was NOT empty — an empty one exits 0 back at step [5/7] — so the copies"
  print -u2 -- "landed and git still sees no change. Two things do that:"
  print -u2 -- "  1. $WT/.gitignore matches the copied paths, so 'git add' skipped them. Check the"
  print -u2 -- "     ignore file against the list below (git check-ignore -v <path> names the rule)."
  print -u2 -- "  2. The copied files are byte-identical to what $BASE_REF already holds, which would"
  print -u2 -- "     mean the comparison at step [3/7] and this index disagree — a bug here, not a"
  print -u2 -- "     publication decision."
  print -u2 -- "The paths this run copied:"
  for f in "${TO_COPY[@]}" "${NEW_COPY[@]}"; do print -u2 -- "  $f"; done
  die "copied $COPY_COUNT file(s) and nothing was staged"
fi

# ── idempotence: an unchanged proposal produces no new side effect ──────────────────────────
# Drift only clears when a human merges, so an unmerged PR means every later run sees the same
# drift and rebuilds the same tree. Comparing the would-be tree (`git write-tree` on the staged
# index) against the tip of the already-pushed sync branch turns "drift persists → act again"
# into "already proposed → say so and stop": no commit, no push, no PR edit, exit 0. The gate
# only fires when the standing PR is genuinely open — a closed-without-merge PR means the
# proposal was rejected, and silently not re-proposing would hide that from the drift report.
if [[ -n "$GH_ACCOUNT_TOKEN" ]]; then
  REMOTE_TREE="$(git rev-parse -q --verify "refs/remotes/origin/$SYNC_BRANCH^{tree}" 2>/dev/null || print '')"
  if [[ -n "$REMOTE_TREE" ]]; then
    PROPOSED_TREE="$(git write-tree)" || die "git write-tree failed"
    if [[ "$PROPOSED_TREE" == "$REMOTE_TREE" ]]; then
      OPEN_PR="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr list --repo "$GH_OWNER/$GH_REPO" --head "$SYNC_BRANCH" --state open --json number -q '.[0].number' 2>/dev/null || print '')"
      if [[ -n "$OPEN_PR" ]]; then
        PR_URL="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr view "$OPEN_PR" --repo "$GH_OWNER/$GH_REPO" --json url -q .url 2>/dev/null || print '')"
        print -- ""
        print -- "Already proposed: the tree this run would push is identical to what pull request"
        print -- "#$OPEN_PR already carries ($PR_URL)."
        print -- "Nothing committed, nothing pushed, the PR untouched. It is waiting on a human merge."
        print -- "Log: $LOG"
        exit 0
      fi
      print -- "note: origin/$SYNC_BRANCH already holds this exact tree, but no open PR points at it"
      print -- "  (closed without merge, or never opened) — proceeding so the proposal exists again."
    fi
  fi
fi

# The same credential shapes PUBLISH.sh gates on, run against what is staged.
# ⛔ THIS USED TO LET `grep` PRINT THE MATCHING LINES into output that is teed to a tracked log —
# the same shape that put a live key into tools/merge-backup-pr.log on 2026-08-24. It was armed and
# had never fired. The scan now reports pattern, count and location, and never the matched text.
source "${0:A:h}/lib/credential-scan.sh"
if ! git diff --cached -U0 | cred_scan_stdin "the staged diff"; then
  git reset --quiet
  die "credential-shaped content in the staged diff — nothing committed, staging area reset"
fi
print -- "credential scan of the staged diff: clean"

SUMMARY="$(git diff --cached --name-only | tr '\n' ' ')"
FILE_LIST="$(git diff --cached --name-only | sed 's/^/- /')"
MSG="sync: carry live orchestrator edits into the published tree

Updated: ${#TO_COPY} drifted file(s), added ${#NEW_COPY} new file(s).
$(git diff --cached --stat)

Held (not copied, each traces to a redaction or publication-context commit):
$(for f in "${HELD_LIST[@]}"; do print -- "  $f"; done)

Synced by orchestrator/tools/sync-to-lintel.sh."

# The branch was cut from origin/main back at step 2b, and the credential scan above ran against
# exactly what is about to land on it.
print -- "committing on $SYNC_BRANCH (base $BASE_SHA — main is not checked out, moved or pushed)"
git commit --quiet -m "$MSG" || die "git commit failed"
NEW_SHA="$(git rev-parse HEAD)"
print -- "committed $NEW_SHA"

if [[ -z "$GH_ACCOUNT_TOKEN" ]]; then
  print -- "no origin remote — commit is local only, on branch $SYNC_BRANCH. No pull request opened."
  print -- ""
  print -- "Done. Files: $SUMMARY"
  print -- "To undo: nothing has left this machine. Delete the branch $SYNC_BRANCH in $PUB by hand"
  print -- "if the sync was unwanted; main was never touched, and $PUB is still on '$PUB_BRANCH'."
  print -- "Log: $LOG"
  exit 0
fi

# --force-with-lease, not --force: the standing branch's remote tip is the previous run's
# machine-made commit, which this run's force-reset deliberately replaces — but only if the
# remote still holds exactly what the last fetch saw. Anything else (a human pushed to the sync
# branch) fails the lease and stops the run instead of overwriting their work.

# ── THE ONE BRANCH THIS SCRIPT MAY OVERWRITE, RESOLVED HERE RATHER THAN INFERRED ─────────────
# The check at the top of this file runs when $SYNC_BRANCH is assigned, hundreds of lines above
# this point, and it only rules out a handful of protected names. This one is different on
# purpose: it names the single branch a lease-backed overwrite is allowed to touch, it is stated
# at the moment of use, and it refuses anything else outright. The duplication of the literal is
# deliberate — a guard that reads the same variable the operation reads cannot catch that
# variable being wrong.
#
# The destination is written as a full refspec for the same reason. `origin "$SYNC_BRANCH"` lets
# push.default, a remote's configured push refspec, or a same-named tag decide where the update
# lands; source and destination spelled out in full leave nothing to resolve.
if [[ "$SYNC_BRANCH" != "sync-live-to-published" ]]; then
  die "refusing a lease-backed overwrite of '$SYNC_BRANCH' — this script may only overwrite the standing sync branch sync-live-to-published, and every other ref on this machine is off limits to it" 2
fi
# The refspec is BUILT WITH printf, not written inline in a double-quoted string. In zsh,
# "refs/heads/$SYNC_BRANCH:refs/heads/..." applies the history modifier `:r` to the parameter
# and produces `refs/heads/sync-live-to-publishedefs/heads/sync-live-to-published` — measured
# here, not theorised. Braces would also work; printf is the form that cannot be read wrong.
PUSH_REFSPEC="$(printf '%s:%s' "refs/heads/$SYNC_BRANCH" "refs/heads/$SYNC_BRANCH")"
print -- "pushing $PUSH_REFSPEC"
git push --force-with-lease -u origin "$PUSH_REFSPEC" || die "push of $SYNC_BRANCH failed — the commit $NEW_SHA is local; re-run after fixing the remote"
print -- "pushed branch $SYNC_BRANCH"

PR_TITLE="sync: carry live orchestrator edits into the published tree"
PR_BODY="Opened by \`orchestrator/tools/sync-to-lintel.sh\`.

**What this is.** The live install at \`$LIVE\` is the source of truth for content and has no
remote. This branch carries the files that drifted there into the published repo. Nothing else
in the published set is touched: the script only writes paths already tracked here, plus new
files inside the two directories MANIFEST.md defines as wholes.

**Why a pull request.** So a human reads the diff before it reaches main. The script does not
push main and cannot merge this.

**Files in this branch (${#TO_COPY} drifted, ${#NEW_COPY} newly added):**

$FILE_LIST

**Held back, deliberately not copied** (each traces to a redaction or publication-context
commit in this repo):

$(for f in "${HELD_LIST[@]}"; do print -- "- $f"; done)

**To reject:** close this pull request without merging and delete the branch. That reverses the
whole run, and it is not a destructive operation — nothing has reached main.

Base of this branch: \`$BASE_SHA\`. Commit: \`$NEW_SHA\`."

EXISTING_PR="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr list --repo "$GH_OWNER/$GH_REPO" --head "$SYNC_BRANCH" --state open --json number -q '.[0].number' 2>/dev/null || print '')"
if [[ -n "$EXISTING_PR" ]]; then
  GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr edit "$EXISTING_PR" --repo "$GH_OWNER/$GH_REPO" \
    --title "$PR_TITLE" --body "$PR_BODY" >/dev/null || die "could not update existing pull request #$EXISTING_PR"
  PR_URL="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr view "$EXISTING_PR" --repo "$GH_OWNER/$GH_REPO" --json url -q .url)"
  print -- "updated existing pull request #$EXISTING_PR"
else
  PR_URL="$(GH_TOKEN="$GH_ACCOUNT_TOKEN" gh pr create --repo "$GH_OWNER/$GH_REPO" \
    --base main --head "$SYNC_BRANCH" --title "$PR_TITLE" --body "$PR_BODY")" \
    || die "gh pr create failed — branch $SYNC_BRANCH is pushed; open the pull request by hand"
  print -- "opened pull request"
fi

print -- ""
print -- "Done. Files: $SUMMARY"
print -- "Pull request: $PR_URL"
print -- "To undo this sync: close that pull request without merging and delete the branch"
print -- "$SYNC_BRANCH. Nothing has reached main, so there is no destructive reversal to run."
print -- "$PUB was never written to and is still on '$PUB_BRANCH'."
print -- "Log: $LOG"

#!/usr/bin/env python3
"""Which seat mail was accepted but never acted on.

⛔ WHY THIS EXISTS. On 2026-09-16 eight replies addressed to Lintel between 07:58:12Z and
08:14:13Z were acked by the mailbox and never reached it. Wren sent four messages in four
minutes, two of them labelled RESEND 1 and 2 of 2, because it could tell its work was
vanishing. They were recovered only because senders' `seat_message` calls happen to be
recorded in `~/.omp/agent/seat-sessions/<seat>/*.jsonl` with the full `arguments.message`.

Retention (`persistent-seat-registry.ts:717-726`, archive on drain) fixes the losing half.
It does not answer the question anyone actually has, which is WHICH messages were lost. That
needs three files joined:

  acks/<id>.json        written on delivery      — the message was accepted
  acks/<id>.turn.json   written on turn start    — the recipient actually woke
  archive/<id>.json     the retained payload     — what it said

An ack with no turn receipt is a message the recipient was never made to read. That is the
exact shape of the eight, and it is detectable TODAY, before retention is running, because
`acks/` alone carries it — the payload is simply unavailable until a seat cycle picks up the
archive code.

Read-only. Touches nothing, writes nothing.

    python3 orchestrator/tools/seatmail-unacted.py [--root DIR] [--since ISO] [--to SEAT]
"""
import argparse
import json
import os
import sys

DEFAULT_ROOT = os.path.expanduser("~/.omp/agent/seat-mailboxes")


def _load(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=DEFAULT_ROOT)
    ap.add_argument("--since", default="", help="ISO instant; compared as a string prefix")
    ap.add_argument("--to", default="", help="only mail addressed to this seat")
    ap.add_argument("--all", action="store_true", help="include mail that DID start a turn")
    args = ap.parse_args()

    acks_dir = os.path.join(args.root, "acks")
    archive_dir = os.path.join(args.root, "archive")
    if not os.path.isdir(acks_dir):
        print(f"no acks/ under {args.root} — wrong root, or nothing has ever been delivered", file=sys.stderr)
        return 2

    names = os.listdir(acks_dir)
    turned = {n[: -len(".turn.json")] for n in names if n.endswith(".turn.json")}
    ack_ids = sorted(n[: -len(".json")] for n in names if n.endswith(".json") and not n.endswith(".turn.json"))

    rows = []
    for ident in ack_ids:
        ack = _load(os.path.join(acks_dir, f"{ident}.json")) or {}
        delivered = str(ack.get("deliveredAt", ""))
        recipient = str(ack.get("to", ""))
        if args.since and delivered < args.since:
            continue
        if args.to and recipient.lower() != args.to.lower():
            continue
        acted = ident in turned
        if acted and not args.all:
            continue
        payload = _load(os.path.join(archive_dir, f"{ident}.json"))
        rows.append({
            "id": ident,
            "deliveredAt": delivered,
            "from": str(ack.get("from", ack.get("sender", "?"))),
            "to": recipient,
            "acted": acted,
            "text": (payload or {}).get("message"),
        })

    rows.sort(key=lambda r: r["deliveredAt"])
    retained = sum(1 for r in rows if r["text"] is not None)

    print(f"# Seat mail accepted but never acted on")
    print()
    print(f"- mailbox root: `{args.root}`")
    print(f"- acks on disk: {len(ack_ids)}; turn receipts: {len(turned)}")
    print(f"- rows reported: {len(rows)}; payload recoverable for {retained} of them")
    if retained == 0 and rows:
        print()
        print("⛔ **No payload is recoverable.** `archive/` is absent or empty, so every message"
              " below exists only as an ack: id, from, to, deliveredAt and nothing else. Recovery"
              " depends on the sender's transcript until the archive code at"
              " `persistent-seat-registry.ts:717-726` is running in the seat that drains.")
    print()
    for row in rows:
        mark = "acted" if row["acted"] else "NO TURN"
        print(f"- `{row['deliveredAt']}` {row['from']} → {row['to']} [{mark}] `{row['id']}`")
        if row["text"]:
            first = " ".join(str(row["text"]).split())[:160]
            print(f"    - {first}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
lab-handover.py — at a seat's close, name every lab this session created whose work is not live.

WHAT IT CHECKS, AND THE RULE IS ONE SENTENCE.
A lab directory created during THIS SESSION fires when it has a target whose live content came
from neither that lab nor a LATER lab created in the same session.

  * a "lab" is a directory directly under orchestrator/build/ whose name ends in `-lab`.
  * a "target" is a deliverable file in it (*.mjs, *.py, *.sh), excluding *.orig / *.base /
    *.merged and anything under a `fixture/` component, whose BASENAME also exists as a file
    under orchestrator/hooks/ or orchestrator/tools/. That live file is the target's live content.
  * a lab is clear on a target when any file of that basename inside the lab hashes equal to the
    live content, OR when some later in-session lab does. Otherwise it fires.

WHY THE "LATER LAB" CLAUSE AND NOT A MARKER. A lab superseded within a session is, by
construction, one whose target now holds a later lab's work. That is a measurable fact about
content already on disk. A marker file, a config list, or a naming convention would each be a
second thing to maintain, and each would go stale silently the first time someone forgot it.
DO NOT REPLACE THIS CLAUSE WITH A MARKER.

SCOPE. Labs only. This is NOT a state checker and must never grow into one; every extension is a
chance to accumulate the noise a tree-scoped version dies of. Note the filename deliberately: an
executable *-check.sh directly under tools/ is discovered and run at EVERY stop by
state-checks-stop.mjs. This tool is not named that, on purpose. It has a boundary (a seat's
close) and it must keep one.

THE INPUT ASSERTION, WHICH IS THE POINT.
The failure this tool was built after was a clean result produced from an empty input: a session
start written in the wrong timezone classified every lab as out-of-session, so the rule fired on
nothing and the nothing read as a pass. So this prints its own inputs before its verdict, and it
REFUSES to report clean when zero labs classify in-session (exit 2). A checker that cannot tell
"nothing is wrong" from "I was handed nothing" is not a checker.

TIME IS EPOCH SECONDS ALL THE WAY THROUGH. No string is ever parsed into a date. Local-time
rendering happens once, at print time, for humans only.

EXIT CODES
  0  no lab fired
  2  inputs could not be established (no session start, or zero labs in session)
  3  at least one lab fired
"""
import argparse, hashlib, json, os, sys, time

HOME = os.path.expanduser("~")
ORCH = os.environ.get("LINTEL_ORCH", os.path.join(HOME, ".claude", "orchestrator"))
BUILD = os.path.join(ORCH, "build")
LIVE_DIRS = [os.path.join(ORCH, "hooks"), os.path.join(ORCH, "tools")]
STATE = os.environ.get("LINTEL_STATE", os.path.join(ORCH, "state"))
PROJECTS = os.path.join(HOME, ".claude", "projects")
DEFAULT_FIRE_LOG = os.path.join(ORCH, "lab-handover-fires.jsonl")

SKIP_SUFFIXES = (".orig", ".base", ".merged")
DELIVERABLE_SUFFIXES = (".mjs", ".py", ".sh")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def local(epoch):
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(epoch))


def resolve_session_id(explicit):
    if explicit:
        return explicit, "argument"
    p = os.path.join(STATE, ".session-id")
    try:
        with open(p) as fh:
            v = fh.read().strip()
        return (v or None), p
    except OSError:
        return None, p


def resolve_session_start(session_id, explicit_epoch):
    """Session start is the BIRTH time of this session's transcript.

    Not the mtime of state/.session-id: that file is re-minted by summon.sh, so a second summon
    while a seat is still open moves it forward and silently empties this tool's input. Measured
    2026-08-25 — it moved mid-run while this tool was being built.
    """
    if explicit_epoch is not None:
        return float(explicit_epoch), "explicit --session-start-epoch"
    if not session_id:
        return None, "no session id"
    cands = []
    try:
        for slug in os.listdir(PROJECTS):
            for name in (session_id + ".jsonl", session_id):
                p = os.path.join(PROJECTS, slug, name)
                if os.path.exists(p):
                    cands.append((os.stat(p).st_birthtime, p))
    except OSError:
        pass
    if not cands:
        return None, "no transcript found for session id under " + PROJECTS
    cands.sort()
    return cands[0][0], cands[0][1]


def live_index(overrides):
    """basename -> (live_path, live_hash). Later dirs do not override earlier ones."""
    idx = {}
    for d in LIVE_DIRS:
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for n in names:
            p = os.path.join(d, n)
            if os.path.isfile(p) and n not in idx:
                idx[n] = (p, sha(p))
    for base, path in overrides.items():
        idx[base] = (path, sha(path))
    return idx


def lab_dirs():
    out = []
    try:
        names = sorted(os.listdir(BUILD))
    except OSError:
        return out
    for n in names:
        p = os.path.join(BUILD, n)
        if os.path.isdir(p) and n.endswith("-lab"):
            out.append((n, p, os.stat(p).st_birthtime))
    return out


def lab_targets(lab_path, live):
    """basename -> {hashes}, for deliverables in this lab that name a live file."""
    found = {}
    for dirpath, dirnames, filenames in os.walk(lab_path):
        rel = os.path.relpath(dirpath, lab_path)
        parts = [] if rel == "." else rel.split(os.sep)
        if "fixture" in parts:
            continue
        for fn in filenames:
            if not fn.endswith(DELIVERABLE_SUFFIXES):
                continue
            if fn.endswith(SKIP_SUFFIXES):
                continue
            if fn not in live:
                continue
            p = os.path.join(dirpath, fn)
            try:
                found.setdefault(fn, set()).add(sha(p))
            except OSError:
                continue
    return found


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--session-id")
    ap.add_argument("--session-start-epoch", type=float)
    ap.add_argument("--live-override", action="append", default=[],
                    metavar="BASENAME=PATH",
                    help="TEST ONLY. Treat PATH's content as the live content for BASENAME. "
                         "Lets the positive case be exercised without mutating a live file.")
    ap.add_argument("--fire-log", default=os.environ.get("LABHANDOVER_FIRE_LOG", DEFAULT_FIRE_LOG))
    ap.add_argument("--no-log", action="store_true")
    ap.add_argument("--json", action="store_true", help="machine-readable summary on stdout")
    args = ap.parse_args()

    overrides = {}
    for spec in args.live_override:
        base, _, path = spec.partition("=")
        if not base or not path:
            print("bad --live-override (want BASENAME=PATH): " + spec, file=sys.stderr)
            return 2
        overrides[base] = path

    sid, sid_src = resolve_session_id(args.session_id)
    start, start_src = resolve_session_start(sid, args.session_start_epoch)

    live = live_index(overrides)
    labs = lab_dirs()

    report = {
        "run_at_epoch": int(time.time()),
        "session_id": sid,
        "session_id_source": sid_src,
        "session_start_epoch": start,
        "session_start_local": local(start) if start else None,
        "session_start_source": start_src,
        "lab_dirs_total": len(labs),
        "in_session_labs": [],
        "out_of_session_labs": [],
        "pairs_evaluated": 0,
        "fires": [],
        "cleared": [],
        "live_overrides": {k: v for k, v in overrides.items()},
    }

    if start is None:
        print("INPUT FAILURE: could not establish a session start (%s). Refusing to report."
              % start_src, file=sys.stderr)
        if args.json:
            print(json.dumps(report))
        return 2

    ins = [(n, p, b) for (n, p, b) in labs if b >= start]
    out = [(n, p, b) for (n, p, b) in labs if b < start]
    report["in_session_labs"] = [{"name": n, "birth_epoch": b, "birth_local": local(b)} for n, p, b in ins]
    report["out_of_session_labs"] = [{"name": n, "birth_epoch": b, "birth_local": local(b)} for n, p, b in out]

    # ---- inputs, printed before any verdict ----
    print("lab-handover — inputs")
    print("  session id      : %s   (%s)" % (sid, sid_src))
    print("  session start   : %s  epoch %d   (%s)" % (local(start), int(start), start_src))
    print("  lab dirs seen   : %d under %s" % (len(labs), BUILD))
    print("  in session      : %d  [%s]" % (len(ins), ", ".join(n for n, _, _ in ins)))
    print("  out of session  : %d  [%s]" % (len(out), ", ".join(n for n, _, _ in out)))
    if overrides:
        print("  live overrides  : %s" % json.dumps(overrides))

    if not ins:
        print("", file=sys.stderr)
        print("INPUT FAILURE: zero labs classified in session. A clean result from an empty input "
              "is not a clean result. Check the session start above against the lab birth times.",
              file=sys.stderr)
        if args.json:
            print(json.dumps(report))
        return 2

    per_lab = {n: lab_targets(p, live) for n, p, b in ins}
    births = {n: b for n, p, b in ins}

    for name, path, birth in ins:
        for base, hashes in sorted(per_lab[name].items()):
            report["pairs_evaluated"] += 1
            live_path, live_hash = live[base]
            if live_hash in hashes:
                report["cleared"].append({"lab": name, "target": base, "by": name})
                continue
            superseded_by = None
            for other, _op, obirth in ins:
                if obirth <= birth or other == name:
                    continue
                if live_hash in per_lab[other].get(base, set()):
                    superseded_by = other
                    break
            if superseded_by:
                report["cleared"].append({"lab": name, "target": base, "by": superseded_by})
                continue
            report["fires"].append({
                "lab": name,
                "lab_birth_epoch": int(birth),
                "target": base,
                "live_path": live_path,
                "live_hash": live_hash,
                "lab_hashes": sorted(hashes),
            })

    print("  pairs evaluated : %d" % report["pairs_evaluated"])
    print("")

    if not report["fires"]:
        print("lab-handover: no lab created this session has an unlanded target. "
              "%d lab/target pairs checked across %d labs." % (report["pairs_evaluated"], len(ins)))
        if args.json:
            print(json.dumps(report))
        return 0

    print("lab-handover: %d unlanded lab target(s) from this session." % len(report["fires"]))
    for f in report["fires"]:
        print("  %s -> %s" % (f["lab"], f["target"]))
        print("     live content at %s does not match this lab, and no later lab in this session "
              "put it there." % f["live_path"])

    if not args.no_log:
        try:
            os.makedirs(os.path.dirname(args.fire_log), exist_ok=True)
            with open(args.fire_log, "a") as fh:
                for f in report["fires"]:
                    row = dict(f)
                    row.update({"ts_epoch": report["run_at_epoch"],
                                "session_id": sid,
                                "session_start_epoch": int(start)})
                    fh.write(json.dumps(row, sort_keys=True) + "\n")
            print("")
            print("  logged %d fire(s) to %s" % (len(report["fires"]), args.fire_log))
        except OSError as e:
            print("  COULD NOT WRITE FIRE LOG %s: %s" % (args.fire_log, e), file=sys.stderr)

    if args.json:
        print(json.dumps(report))
    return 3


if __name__ == "__main__":
    sys.exit(main())

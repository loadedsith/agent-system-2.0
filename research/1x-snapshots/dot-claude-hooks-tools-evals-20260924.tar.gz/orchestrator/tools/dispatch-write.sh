#!/bin/sh
# dispatch-write.sh — the way a row gets into, or changes in, state/LEDGER.jsonl.
#
# WHY THIS FILE EXISTS. Dispatch rows were appended by hand, raw JSON into a file nothing
# validated, and a dispatch that finished could not be amended because the ledger carried no
# identity field. So a finished dispatch got a second row instead of a corrected first one, and
# the ledger accumulated twins that no reader can tell from two real dispatches. Two defects, one
# cause. This tool takes the fields as arguments, constructs the JSON itself, refuses a row the
# checker would reject, and — the whole reason it exists — can rewrite an existing row in place
# instead of appending a near-copy of it.
#
# IT DOES NOT CARRY ITS OWN COPY OF THE RULES. The candidate row is validated by running
# tools/dispatch-schema-check.sh against it, which is the same code path that validates the whole
# file, reading the same dispatch-ledger contract. Field names, types, the outcome vocabulary and
# which outcomes are terminal are all asked of that checker rather than restated here. A second,
# differently-shaped validator in the writer would be a second schema that drifts, which is the
# class of defect being closed. If the writer accepts a row the checker would reject, that is a
# bug in one shared implementation, not a disagreement between two.
#
# Usage:
#   dispatch-write.sh --new --task TEXT --shape TEXT --dispatched-to TEXT --tier TIER
#                     --attempts N --jo-touches N --friction TEXT
#                     [--id DSP-NNN] [--ts STAMP] [--outcome OUTCOME]
#                     [--set key=value ...] [--ledger PATH] [--dry-run]
#
#   dispatch-write.sh --update DSP-NNN [--outcome OUTCOME] [--friction TEXT] [--attempts N] ...
#                     [--set key=value ...] [--reopen] [--ledger PATH] [--dry-run]
#
#   dispatch-write.sh --propose-ids [--ledger PATH]
#
#   dispatch-write.sh --selftest
#
#   --new       appends a fresh row. --id omitted: the next unused DSP-NNN, derived from the
#               ledger. --ts omitted: now, in UTC, ISO 8601 with a trailing Z. --outcome omitted:
#               in-flight, the state a row is born in. Every other required field must be given.
#   --update    rewrites the single row carrying that id, applying only the fields named on this
#               invocation and leaving every other key untouched. Refuses if the id is absent or
#               matches more than one row. Refuses to change a row whose current outcome is
#               terminal unless --reopen is passed.
#   --set       sets any declared optional key. `--set wall_clock_s=412`, `--set note=...`,
#               `--set outcome_label=null`. Numeric and nullable keys are coerced using the types
#               the checker reads out of the contract.
#   --dry-run   validate and print what would be written; write nothing. Under --update it prints
#               the before row and the after row.
#   --selftest  proves the write-half refusals fire: null on a nullable key, the legacy `request`
#               key, and the legacy `pending`/`open` outcomes. Each is legal in the file and
#               refused on write, so the checker's own selftest cannot cover them.
#   --propose-ids  emits to stdout a copy of the whole ledger with DSP-NNN assigned in line order
#               to the rows that lack one, changing nothing else and writing no file. It is a
#               proposal for a human to review and apply. This tool never applies it.
#
# Exit codes: 0 written (or validated, under --dry-run) | 1 the row was rejected | 2 could not run.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
CHECK="$ORCH/tools/dispatch-schema-check.sh"
LEDGER="$ORCH/state/LEDGER.jsonl"

MODE=""; UPDATE_ID=""; DRYRUN=0; REOPEN=0
ASSIGN="$(mktemp)" || { echo "dispatch-write: mktemp failed" >&2; exit 2; }

die() { echo "dispatch-write: $*" >&2; exit 2; }
reject() { echo "REJECTED — $*" >&2; exit 1; }
set_kv() { printf '%s\t%s\n' "$1" "$2" >> "$ASSIGN"; }

while [ "$#" -gt 0 ]; do
  case "$1" in
    --new)           MODE="new"; shift ;;
    --update)        [ "$#" -ge 2 ] || die "--update needs a DSP-NNN"; MODE="update"; UPDATE_ID="$2"; shift 2 ;;
    --propose-ids)   MODE="propose"; shift ;;
    --selftest)      MODE="selftest"; shift ;;
    --id)            [ "$#" -ge 2 ] || die "--id needs a value";            set_kv id "$2"; shift 2 ;;
    --ts)            [ "$#" -ge 2 ] || die "--ts needs a value";            set_kv ts "$2"; shift 2 ;;
    --task)          [ "$#" -ge 2 ] || die "--task needs a value";          set_kv task "$2"; shift 2 ;;
    --shape)         [ "$#" -ge 2 ] || die "--shape needs a value";         set_kv shape "$2"; shift 2 ;;
    --dispatched-to) [ "$#" -ge 2 ] || die "--dispatched-to needs a value"; set_kv dispatched_to "$2"; shift 2 ;;
    --tier)          [ "$#" -ge 2 ] || die "--tier needs a value";          set_kv tier "$2"; shift 2 ;;
    --outcome)       [ "$#" -ge 2 ] || die "--outcome needs a value";       set_kv outcome "$2"; shift 2 ;;
    --attempts)      [ "$#" -ge 2 ] || die "--attempts needs a value";      set_kv attempts "$2"; shift 2 ;;
    --jo-touches)    [ "$#" -ge 2 ] || die "--jo-touches needs a value";    set_kv jo_touches "$2"; shift 2 ;;
    --friction)      [ "$#" -ge 2 ] || die "--friction needs a value";      set_kv friction "$2"; shift 2 ;;
    --set)
      [ "$#" -ge 2 ] || die "--set needs key=value"
      case "$2" in *=*) ;; *) reject "--set must be key=value, got '$2'" ;; esac
      k="${2%%=*}"; v="${2#*=}"; set_kv "$k" "$v"; shift 2 ;;
    --ledger)        [ "$#" -ge 2 ] || die "--ledger needs a value"; LEDGER="$2"; shift 2 ;;
    --reopen)        REOPEN=1; shift ;;
    --dry-run)       DRYRUN=1; shift ;;
    -h|--help)       sed -n '1,60p' "$0"; exit 0 ;;
    *)               die "unknown argument '$1'" ;;
  esac
done

[ -n "$MODE" ] || die "one of --new, --update DSP-NNN, or --propose-ids is required"
command -v python3 >/dev/null || die "python3 not found"
[ -f "$CHECK" ] || die "checker missing at $CHECK"

# --selftest. The checker's selftest cannot cover these three: each is LEGAL in the file and
# refused only on write, which is the whole point of lenient-on-read/narrow-on-write. A checker
# fixture carrying a null wall_clock_s, a `request` key, or a `pending` outcome is required to
# PASS. So the write-half refusals are proved here instead, against a throwaway fixture ledger.
if [ "$MODE" = "selftest" ]; then
  d="$(mktemp -d)" || exit 2
  echo "selftest: fixture ledger in $d (throwaway; the real ledger is never touched)"
  fix="$d/fixture.jsonl"
  printf '%s\n' '{"id":"DSP-001","ts":"2026-08-21T10:00:00Z","task":"seed","shape":"s","dispatched_to":"d","tier":"worker","outcome":"clean","attempts":1,"jo_touches":0,"friction":"none"}' > "$fix"
  base="--new --ledger $fix --dry-run --task t --shape s --dispatched-to d --tier worker --attempts 1 --jo-touches 0 --friction none"
  failed=0
  refuse() {
    _name="$1"; shift
    # shellcheck disable=SC2086
    out="$(sh "$0" $base "$@" 2>&1)"; rc=$?
    if [ "$rc" -eq 0 ]; then
      echo "SELFTEST FAILED: --new ACCEPTED '$_name'" >&2; failed=1
    else
      echo "  refused  $_name  (exit $rc)"
      printf '%s\n' "$out" | head -1 | cut -c1-120 | sed 's/^/       /'
    fi
  }
  refuse "null on wall_clock_s"   --set wall_clock_s=null
  refuse "null on outcome_label"  --set outcome_label=null
  refuse "legacy key 'request'"   --set request=REQ-107
  refuse "outcome pending"        --outcome pending
  refuse "outcome open"           --outcome open
  # shellcheck disable=SC2086
  if sh "$0" $base --set req=REQ-107 --set wall_clock_s=412 >/dev/null 2>&1; then
    echo "  accepted a conforming row (req, a real wall_clock_s, in-flight by default) (exit 0)"
  else
    echo "SELFTEST FAILED: --new rejected a conforming row" >&2; failed=1
  fi
  # shellcheck disable=SC2086
  if sh "$0" $base --outcome clean >/dev/null 2>&1; then
    echo "  accepted a terminal outcome on --new (exit 0)"
  else
    echo "SELFTEST FAILED: --new rejected the terminal outcome 'clean'" >&2; failed=1
  fi
  [ "$failed" -eq 0 ] || { echo "SELFTEST FAILED — fixtures kept at $d" >&2; exit 1; }
  echo "selftest: OK — every write-half refusal fired, and conforming rows were accepted."
  exit 0
fi

[ -f "$LEDGER" ] || die "no ledger at $LEDGER"

TYPES="$(sh "$CHECK" --types)" || die "could not read field types from the contract via $CHECK"
REQUIRED="$(sh "$CHECK" --required)" || die "could not read required fields from the contract via $CHECK"
TERMINAL="$(sh "$CHECK" --terminal-outcomes)" || die "could not read terminal outcomes from the contract via $CHECK"
OUTCOMES="$(sh "$CHECK" --outcomes)" || die "could not read the outcome vocabulary from the contract via $CHECK"
[ -n "$TYPES" ] && [ -n "$REQUIRED" ] && [ -n "$TERMINAL" ] && [ -n "$OUTCOMES" ] \
  || die "the contract parsed empty; refusing to guess a schema"

# ---------------------------------------------------------------- --propose-ids
# The reviewer of this proposal assumes it is wrong, and they are right to: a JSON round-trip
# silently rewrites key order, unicode escaping, float formatting and separators, and none of that
# raises an error. So the id is spliced in TEXTUALLY, immediately after the opening brace, and
# every other byte of the line is the original line's bytes. Then it is proved: each proposed line
# has the id key removed again by an independent regex and is compared byte-for-byte with the line
# it came from. If a single line fails that, the whole proposal is abandoned rather than emitted.
if [ "$MODE" = "propose" ]; then
  echo "PROPOSAL ONLY — this is stdout, not a file. Nothing was written to $LEDGER." >&2
  echo "It splices an id into rows that lack one and changes no other byte. Review it, then apply" >&2
  echo "it yourself if you want it; no tool here applies it for you." >&2
  DW_LEDGER="$LEDGER" python3 - <<'PY'
import json, os, re, sys

ledger = os.environ["DW_LEDGER"]
with open(ledger, encoding="utf-8", newline="") as fh:
    raw = fh.read()
lines = raw.split("\n")          # a trailing "" preserves the file's final newline exactly

ID_RE = re.compile(r"^DSP-(\d+)$")
# Independent of how the splice was built: this is the reviewer's own removal.
STRIP_RE = re.compile(r'^(\s*\{)"id":"DSP-\d+",?')

hi = 0
for line in lines:
    if not line.strip():
        continue
    try:
        row = json.loads(line)
    except Exception:
        continue
    if isinstance(row, dict):
        m = ID_RE.match(row.get("id") if isinstance(row.get("id"), str) else "")
        if m:
            hi = max(hi, int(m.group(1)))

# Next id comes from the highest id present, never from a row count: a count-derived id starts
# reusing ids the moment any row is removed, and the contract says ids are never reused.
nxt = hi + 1
assigned = 0
skipped_have_id = 0
skipped_unparseable = 0
out = []

for line in lines:
    if not line.strip():
        out.append(line)
        continue
    try:
        row = json.loads(line)
    except Exception:
        sys.stderr.write("propose-ids: a line is not JSON; left exactly as found\n")
        skipped_unparseable += 1
        out.append(line)
        continue
    if not isinstance(row, dict):
        sys.stderr.write("propose-ids: a line is not a JSON object; left exactly as found\n")
        skipped_unparseable += 1
        out.append(line)
        continue
    if "id" in row:
        skipped_have_id += 1
        out.append(line)
        continue

    m = re.match(r"^(\s*\{)(.*)$", line, re.S)
    if not m:
        sys.stderr.write("propose-ids: a JSON object line did not start with '{'; left as found\n")
        skipped_unparseable += 1
        out.append(line)
        continue
    prefix, rest = m.group(1), m.group(2)
    frag = '"id":"DSP-%03d"' % nxt
    if rest.lstrip().startswith("}"):
        proposed = prefix + frag + rest          # empty object: no comma to add
    else:
        proposed = prefix + frag + "," + rest

    # Proof, per line, before it is allowed into the output.
    back = STRIP_RE.sub(r"\1", proposed, count=1)
    if back != line:
        sys.stderr.write("propose-ids: ABORTED — a proposed line is not the original line plus an "
                         "id. Nothing is emitted.\n")
        sys.exit(2)
    try:
        parsed = json.loads(proposed)
    except Exception as exc:
        sys.stderr.write(f"propose-ids: ABORTED — a proposed line does not parse: {exc}\n")
        sys.exit(2)
    got_id = parsed.pop("id", None)
    if got_id != "DSP-%03d" % nxt or parsed != row:
        sys.stderr.write("propose-ids: ABORTED — a proposed line changed something other than id.\n")
        sys.exit(2)

    out.append(proposed)
    assigned += 1
    nxt += 1

sys.stdout.write("\n".join(out))

sys.stderr.write("propose-ids: %d row(s) assigned an id" % assigned)
if assigned:
    sys.stderr.write(" (DSP-%03d through DSP-%03d)" % (hi + 1, nxt - 1))
sys.stderr.write("\n")
sys.stderr.write("propose-ids: %d row(s) already had an id and were left untouched\n" % skipped_have_id)
if skipped_unparseable:
    sys.stderr.write("propose-ids: %d line(s) were not usable rows and were left as found\n"
                     % skipped_unparseable)
if assigned == 0:
    sys.stderr.write("propose-ids: nothing to assign — every row already carries an id. The "
                     "output is byte-identical to the input and applying it would be a no-op.\n")
sys.stderr.write("propose-ids: verified — every proposed line, with the id key removed again, is "
                 "byte-identical to the line it came from.\n")
PY
  exit $?
fi

# ---------------------------------------------------------------- build the candidate
BEFORE="$(mktemp)" || die "mktemp failed"
CAND="$(mktemp)" || die "mktemp failed"

DW_MODE="$MODE" DW_LEDGER="$LEDGER" DW_ASSIGN="$ASSIGN" DW_TYPES="$TYPES" \
DW_REQUIRED="$REQUIRED" DW_TERMINAL="$TERMINAL" DW_OUTCOMES="$OUTCOMES" DW_UPDATE_ID="$UPDATE_ID" \
DW_REOPEN="$REOPEN" DW_BEFORE="$BEFORE" DW_CAND="$CAND" DW_NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
python3 - <<'PY'
import json, os, re, sys

mode      = os.environ["DW_MODE"]
ledger    = os.environ["DW_LEDGER"]
types     = dict(l.split("\t") for l in os.environ["DW_TYPES"].split("\n") if l)
required  = [l for l in os.environ["DW_REQUIRED"].split("\n") if l]
terminal  = {l for l in os.environ["DW_TERMINAL"].split("\n") if l}
outcomes  = dict(l.split("\t") for l in os.environ["DW_OUTCOMES"].split("\n") if l)
update_id = os.environ["DW_UPDATE_ID"]
reopen    = os.environ["DW_REOPEN"] == "1"

# Why a field has no safe default. This is prose about consequences, not schema; the field list
# itself comes from the contract via the checker.
WHY = {
    "task":          "it is what the row is a record of; a dispatch with no task is an id and a shrug",
    "shape":         "it is how dispatches get compared to each other, and it cannot be inferred after the fact",
    "dispatched_to": "it names who did the work; guessing it would invent a witness",
    "tier":          "it decides how the row counts in any tier breakdown, and a wrong tier is worse than a missing row",
    "attempts":      "it is a count of something that happened; defaulting it to 1 would assert a fact nobody observed",
    "jo_touches":    "it measures how much a human had to intervene, which is the number the ledger exists to move",
    "friction":      "an empty friction field and 'nothing got in the way' are different statements",
}

assigns = []
with open(os.environ["DW_ASSIGN"], encoding="utf-8") as fh:
    for line in fh:
        line = line.rstrip("\n")
        if not line:
            continue
        k, _, v = line.partition("\t")
        assigns.append((k, v))

def coerce(key, raw):
    t = types.get(key, "string")
    if t.startswith("nullable-") and raw == "null":
        return None
    base = t.replace("nullable-", "")
    if base in ("int", "number"):
        try:
            return int(raw) if base == "int" or re.fullmatch(r"-?\d+", raw) else float(raw)
        except ValueError:
            print(f"REJECTED — --set {key}={raw!r}: the contract declares {key} as {t}, and that "
                  f"is not a number.", file=sys.stderr)
            sys.exit(1)
    return raw

def read_rows():
    rows = []
    for n, line in enumerate(open(ledger, encoding="utf-8"), 1):
        s = line.rstrip("\n")
        if not s.strip():
            rows.append((n, s, None))
            continue
        try:
            rows.append((n, s, json.loads(s)))
        except Exception:
            rows.append((n, s, None))
    return rows

if mode == "new":
    for k, v in assigns:
        # `request` collides with REQUESTS.jsonl, where the same key holds Jo's ask in free prose
        # rather than an id. Two meanings for one key name across two ledgers is how a query ends
        # up looking correct and being silently wrong.
        if k == "request":
            print("REJECTED — 'request' is the legacy spelling and is refused on write. Use "
                  "--set req=REQ-NNN. In state/REQUESTS.jsonl the key 'request' holds Jo's ask in "
                  "free prose, not an id; one key name meaning two things across two ledgers is "
                  "how a correct-looking query goes silently wrong. The 5 rows that already spell "
                  "it that way keep it — nothing rewrites them.", file=sys.stderr)
            sys.exit(1)
        # null is what rows already carry, not something anyone should record on purpose.
        if v == "null" and types.get(k, "string").startswith("nullable-"):
            print(f"REJECTED — --set {k}=null. The contract declares {k} nullable because existing "
                  f"rows carry null, not because null is a value. A measurement that was never "
                  f"taken is an absent key, not a recorded nothing: omit {k} entirely. The "
                  f"existing nulls stay as they are; nothing rewrites them.", file=sys.stderr)
            sys.exit(1)

    row = {}
    for k, v in assigns:
        row[k] = coerce(k, v)

    oc = row.get("outcome")
    if isinstance(oc, str) and outcomes.get(oc) == "non-terminal" and oc != "in-flight":
        print(f"REJECTED — outcome '{oc}' is refused on write. A live dispatch is 'in-flight', "
              f"which is the only non-terminal outcome --new accepts. 'pending' and 'open' stay "
              f"declared because rows hold them and the checker has to pass on the file as it is, "
              f"but nothing distinguishes the two and guessing which was meant would put a false "
              f"judgment into an audit log. The rows that hold them are left alone.", file=sys.stderr)
        sys.exit(1)
    row.setdefault("ts", os.environ["DW_NOW"])
    # in-flight is the state a row is born in: dispatched, not yet resolved.
    row.setdefault("outcome", "in-flight")
    if "id" not in row:
        hi = 0
        for _, _, r in read_rows():
            if isinstance(r, dict):
                m = re.match(r"^DSP-(\d+)$", r.get("id") if isinstance(r.get("id"), str) else "")
                if m:
                    hi = max(hi, int(m.group(1)))
        row["id"] = "DSP-%03d" % (hi + 1)
    missing = [k for k in required if k not in row]
    if missing:
        for k in missing:
            why = WHY.get(k, "there is no value that would be true by default")
            print(f"REJECTED — '{k}' was not supplied and has no safe default: {why}.", file=sys.stderr)
        print(f"nothing was written to {ledger}", file=sys.stderr)
        sys.exit(1)
    clash = [n for n, _, r in read_rows() if isinstance(r, dict) and r.get("id") == row["id"]]
    if clash:
        print(f"REJECTED — id {row['id']} is already used in {ledger} on line {clash[0]}. "
              f"Omit --id and the next unused one is derived for you.", file=sys.stderr)
        sys.exit(1)
    ordered = {k: row[k] for k in ("id", "ts") if k in row}
    ordered.update({k: v for k, v in row.items() if k not in ordered})
    open(os.environ["DW_CAND"], "w", encoding="utf-8").write(json.dumps(ordered, ensure_ascii=False) + "\n")
    open(os.environ["DW_BEFORE"], "w", encoding="utf-8").write("")
    sys.exit(0)

# --update
hits = [(n, r) for n, _, r in read_rows() if isinstance(r, dict) and r.get("id") == update_id]
if not hits:
    print(f"REJECTED — no row in {ledger} carries id {update_id}. If the ledger has no ids yet, "
          f"--propose-ids emits a back-fill proposal for a human to apply.", file=sys.stderr)
    sys.exit(1)
if len(hits) > 1:
    lines = ", ".join(str(n) for n, _ in hits)
    print(f"REJECTED — id {update_id} matches {len(hits)} rows in {ledger} (lines {lines}). "
          f"An ambiguous id is not an identity; fix the duplication before updating.", file=sys.stderr)
    sys.exit(1)

n, before = hits[0]
cur = before.get("outcome")
if isinstance(cur, str) and cur in terminal and not reopen:
    print(f"REJECTED — {update_id} currently holds the terminal outcome '{cur}'. A finished "
          f"dispatch quietly re-opening is the same silent drift as a twin row, arriving from the "
          f"other direction. Pass --reopen if you mean it.", file=sys.stderr)
    sys.exit(1)

for k, v in assigns:
    if k == "id":
        print("REJECTED — --update will not change a row's id. The id is the handle the update "
              "was found by; changing it in the same breath makes the row unfindable.", file=sys.stderr)
        sys.exit(1)
after = dict(before)
for k, v in assigns:
    after[k] = coerce(k, v)

open(os.environ["DW_BEFORE"], "w", encoding="utf-8").write(json.dumps(before, ensure_ascii=False) + "\n")
open(os.environ["DW_CAND"], "w", encoding="utf-8").write(json.dumps(after, ensure_ascii=False) + "\n")
sys.exit(0)
PY
rc=$?
[ "$rc" -eq 0 ] || exit "$rc"

# ---------------------------------------------------------------- validate through the checker
# The candidate is validated alone rather than inside a copy of the ledger, so pre-existing rows
# the checker already objects to cannot mask or manufacture a verdict here.
if ! OUT="$(sh "$CHECK" "$CAND" 2>&1)"; then
  echo "REJECTED — the row does not conform to the dispatch-ledger contract:" >&2
  printf '%s\n' "$OUT" | sed -n '/^FAIL/,$p' | sed 's/^/  /' >&2
  echo "  nothing was written to $LEDGER" >&2
  exit 1
fi

ROW="$(cat "$CAND")"

if [ "$DRYRUN" -eq 1 ]; then
  if [ "$MODE" = "update" ]; then
    echo "OK (dry run) — $UPDATE_ID would be rewritten in place in $LEDGER. Nothing was written."
    echo "before:"; sed 's/^/  /' "$BEFORE"
    echo "after:";  sed 's/^/  /' "$CAND"
  else
    echo "OK (dry run) — this row is valid and was NOT written:"
    printf '%s\n' "$ROW"
  fi
  exit 0
fi

# ---------------------------------------------------------------- write
if [ "$MODE" = "new" ]; then
  printf '%s\n' "$ROW" >> "$LEDGER" || die "append to $LEDGER failed"
  echo "appended to $LEDGER:"
  printf '%s\n' "$ROW"
  echo
  echo "to reverse: remove the last line of $LEDGER (it is the row printed above, and only that"
  echo "row was added). No copy of the file was made before this run; take one first if you want one."
  exit 0
fi

# --update: rewrite atomically — temp file in the same directory, then mv over the original, so a
# reader never sees a half-written ledger and a failed write leaves the original intact.
BACKUP="$LEDGER.pre-update-$(date -u +%Y%m%dT%H%M%SZ)"
cp "$LEDGER" "$BACKUP" || die "could not take a backup at $BACKUP; nothing was written"
if ! DW_LEDGER="$LEDGER" DW_CAND="$CAND" DW_UPDATE_ID="$UPDATE_ID" python3 - <<'PY'
import json, os, sys, tempfile
ledger = os.environ["DW_LEDGER"]
after = open(os.environ["DW_CAND"], encoding="utf-8").read().rstrip("\n")
want = os.environ["DW_UPDATE_ID"]
lines, hits = [], 0
for line in open(ledger, encoding="utf-8"):
    s = line.rstrip("\n")
    try:
        row = json.loads(s)
    except Exception:
        lines.append(s); continue
    if isinstance(row, dict) and row.get("id") == want:
        hits += 1
        lines.append(after)
    else:
        lines.append(s)
if hits != 1:
    sys.stderr.write(f"dispatch-write: expected exactly one row with id {want}, found {hits}; "
                     f"nothing was written\n")
    sys.exit(2)
d = os.path.dirname(os.path.abspath(ledger))
fd, tmp = tempfile.mkstemp(dir=d, prefix=".dispatch-write.")
with os.fdopen(fd, "w", encoding="utf-8") as fh:
    fh.write("\n".join(lines) + "\n")
os.replace(tmp, ledger)
PY
then
  die "the in-place rewrite failed; $LEDGER is unchanged and a backup sits at $BACKUP"
fi

echo "rewrote $UPDATE_ID in place in $LEDGER"
echo "before:"; sed 's/^/  /' "$BEFORE"
echo "after:";  sed 's/^/  /' "$CAND"
echo
echo "to reverse: cp $BACKUP $LEDGER"
exit 0

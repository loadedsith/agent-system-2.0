#!/bin/sh
# issues-ledger-check.sh — does the GitHub issue tracker still agree with REQUESTS.jsonl?
#
# WHY THIS FILE EXISTS. On 2026-08-21 the still-owed rows of the ledger were imported into
# github.com/thewolff/lintel-tasks (private, issues only, zero files) so Jo can browse
# obligations from a phone. That surface has exactly the failure mode TASKS.md had before
# tools/tasklist-ledger-check.sh existed: nothing keeps it in step with the ledger except
# somebody remembering. Every applicable issue carries the complete `REQ-NNN` key in its title
# or a `Ledger row: REQ-NNN` body marker, and this is the checker that makes forgetting loud.
# One direction only: the ledger is authoritative, the issue mirrors it, and nothing here writes.
#
# WHAT IT CHECKS. Every scope word below is load-bearing; see the widening note further down.
#   - an applicable row still owed (non-terminal) with no OPEN issue naming it
#   - an OPEN issue naming an applicable terminal row (finished business shown as a live obligation)
#   - an OPEN issue naming an applicable row that does not exist
#   - an applicable OPEN issue with no canonical title/body join (it cannot be joined)
#   - two OPEN issues naming the same applicable row (the join must be one-to-one)
#   - a CLOSED issue naming an applicable row that is still owed and that no open issue names
#         (the issue was closed and the row was not moved — the half-done update)
#
# THE LAST CHECK ADDS DIAGNOSIS, NOT DETECTION, AND SAYING SO IS THE POINT. That condition was
# already red before 2026-08-24: an owed row whose only issue is closed has no OPEN issue naming
# it, so check one fired on it anyway. What the new check adds is WHICH REPAIR APPLIES. Check one
# says "the tracker never showed this", whose repair is re-running the importer. The new one says
# "somebody closed the issue and left the row owed", whose repair is deciding whether the row is
# actually finished. This file already argues that those two repairs are different and must not be
# confused; before, one message covered both.
#
# ⛔ AND IT DOES NOT CATCH THE CASE IT WAS COMMISSIONED FOR. On 2026-08-24 Jo found REQ-261 sitting
# non-terminal after its work was built, verified and armed. Its issue #126 was OPEN at the time —
# which is why all three checkers were green, and green was the correct answer: an open issue
# naming a non-terminal row is exactly what agreement looks like. No join check of any scope can
# see that defect, because BOTH SIDES agreed and both were wrong about the world. Do not read this
# check as closing that hole. It closes the adjacent one.
#
# THE PAIRING RULE — READ THIS BEFORE TREATING A RED RUN AS A CHORE. Closing an issue is not
# work that happens later. Whatever marks a ledger row terminal closes that row's issue in the
# SAME action. There is deliberately no --fix mode: a repair path built before anyone knows how
# often the pairing breaks is a guess about how often it breaks, and if the pairing holds
# because it is one action, a --fix mode is unnecessary rather than deferred.
#
# So a red run does not mean "a chore is pending." It means the pairing was broken, and the
# pairing is the thing to fix. This matters because a checker that sits red gets muted, and a
# muted checker returns you to the state this one was built to end: nothing keeping the tracker
# in step with the ledger except somebody remembering.
#
# AN APPLICABLE OWED ROW WITH NO ISSUE MEANS THE DISPOSABLE-HAND RECONCILIATION DID NOT LAND.
# Every successful non-terminal append emits a bounded `DISPOSABLE_HAND_REQUIRED` receipt naming
# `request-issues-reconcile.sh --apply --only REQ-NNN`. Lintel dispatches that command; neither
# Lintel nor Tinker inventories or mutates the tracker inline. The reconciler is idempotent: it
# searches the complete open-and-closed tracker before every mutation, reuses or reopens a
# canonical match, creates only when none exists, then records the validated URL back in the row's
# existing context-touch field. A red check therefore means the hand failed, was not dispatched,
# or the pairing was later broken. The ledger remains authoritative throughout.
#
# ONE-TO-ONE IS DELIBERATE AND THE DUPLICATE CHECK IS NOT AN OVERSIGHT. If the remainder of a
# `partial` row deserves its own visible item, it deserves its own REQ-NNN — splitting a row is
# something the request ledger already knows how to do. Splitting at the tracker instead would
# put a piece of work somewhere the ledger cannot see, which is the exact asymmetry this join
# exists to prevent. It also keeps "does the tracker agree with the ledger" a clean yes or no,
# and that binary is the whole value of the thing.
#
# THE VOCABULARY IS NOT DEFINED HERE, deliberately — same rule as its siblings
# tools/tasklist-ledger-check.sh and tools/requests-schema-check.sh. Which states are terminal
# comes from tools/request-states.sh, which parses the contract and owns that answer. A checker
# with its own copy of that list is one edit away from re-raising closed work.
#
# GITHUB ACCOUNT. gh on this machine holds more than one account and the globally active one is
# not the owner of the tracker. The one gh call below runs with a per-invocation token for the
# repo's owner (same pattern as tools/backup-state.sh and tools/sync-to-lintel.sh); the global
# active account is never switched.
#
# NETWORK IS A PRECONDITION, NOT A VERDICT. gh unauthenticated, offline, or refusing to answer
# is exit 2 — could not run — never a clean pass and never a disagreement. Getting that wrong
# turns a network hiccup into a false alarm or, worse, a silent all-clear.
#
# Usage:
#   issues-ledger-check.sh [ledger.jsonl] [owner/repo]
#   issues-ledger-check.sh --selftest    # prove the checker can fail, one defect class at a
#                                        # time, against throwaway fixtures; no network
#
# Selftest plumbing: ILC_ISSUES_FILE, when set, is read instead of calling gh. Documented here
# so the exemption is visible; a live run never sets it.
#
# Exit codes: 0 they agree | 1 they disagree | 2 could not run the check.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
LEDGER_DEFAULT="$ORCH/state/REQUESTS.jsonl"
REPO_DEFAULT="thewolff/lintel-tasks"

case "${1:-}" in
  --selftest) SELFTEST=1; LEDGER="$LEDGER_DEFAULT"; REPO="$REPO_DEFAULT" ;;
  *)          SELFTEST=0; LEDGER="${1:-$LEDGER_DEFAULT}"; REPO="${2:-$REPO_DEFAULT}" ;;
esac

command -v python3 >/dev/null || { echo "preflight: python3 not found" >&2; exit 2; }
[ -f "$ORCH/tools/issues-ledger-check.py" ] || {
  echo "preflight: validator missing at $ORCH/tools/issues-ledger-check.py" >&2; exit 2; }
[ -f "$ORCH/tools/request-states.sh" ] || {
  echo "preflight: the state predicate is missing at $ORCH/tools/request-states.sh" >&2; exit 2; }
[ -f "$ORCH/tools/request_issues_reconcile.py" ] || {
  echo "preflight: applicability classifier missing at $ORCH/tools/request_issues_reconcile.py" >&2; exit 2; }

fetch_issues() {
  # Writes the FULL issue list, open and closed (GitHub API JSON, possibly several concatenated
  # pages), to $1. `state=all` rather than `state=open` since 2026-08-24; the validator partitions
  # them and every check names its own scope, because widening this one word made the open-only
  # assumption false for all five existing checks at once.
  # Returns 2 on any failure to answer: no gh, no token for the owner, network down, API error.
  _out="$1"
  if [ -n "${ILC_ISSUES_FILE:-}" ]; then
    [ -f "$ILC_ISSUES_FILE" ] || { echo "preflight: ILC_ISSUES_FILE set but unreadable" >&2; return 2; }
    cat "$ILC_ISSUES_FILE" > "$_out"
    return 0
  fi
  command -v gh >/dev/null || { echo "preflight: gh is not installed; cannot read the tracker" >&2; return 2; }
  _owner="${REPO%%/*}"
  _tok="$(gh auth token --user "$_owner" 2>/dev/null || echo '')"
  if [ -z "$_tok" ]; then
    echo "preflight: gh has no authenticated account named '$_owner' (which owns $REPO)." >&2
    echo "           Log in with: gh auth login --hostname github.com — do not switch the" >&2
    echo "           globally active account; this script asks for a per-invocation token." >&2
    return 2
  fi
  if ! GH_TOKEN="$_tok" gh api "repos/$REPO/issues?state=all&per_page=100" --paginate > "$_out" 2>"$_out.err"; then
    echo "preflight: gh could not list issues in $REPO — offline, or the API refused:" >&2
    sed 's/^/           /' "$_out.err" >&2
    rm -f "$_out.err"
    return 2
  fi
  rm -f "$_out.err"

  # COMPLETENESS ASSERTION (added 2026-08-28). A CHECK THAT SCORES AN UNVERIFIED LISTING CAN
  # PRINT "OK" ON DATA IT NEVER CHECKED WAS WHOLE. On 2026-08-28 this check reported twelve
  # consecutive rows (REQ-285..297) as untracked; all twelve issues existed and were open, and
  # the twelve mapped to twelve CONSECUTIVE issue numbers — the signature of a dropped page, not
  # of a data defect, which would be scattered. The tracker had just crossed 261 issues, so the
  # fetch newly spanned three pages where it had spanned two.
  #
  # THE FALSE ALARM WAS THE LUCKY CASE. A short fetch that still happens to cover every owed row
  # prints OK — a green verdict computed from data it never verified. That is the same family as
  # a guard whose suppressor is broken: the failure wears the good outcome's face.
  #
  # So: ask the repository for its own open count and refuse to score a listing that disagrees.
  # EXIT 2, "could not run", NEVER a verdict — an incomplete listing is missing evidence, not a
  # finding, and reporting it as either OK or a defect would be a lie in one direction or the
  # other. ILC_ISSUES_FILE returns above this point, so fixtures and the selftest are unaffected.
  #
  # WHY THE COUNTS ARE COMPARABLE: GitHub counts pull requests in open_issues_count, and the
  # /issues endpoint returns PRs too, so both sides are counted the same way — open entries,
  # PRs included. Measured 2026-08-28 on thewolff/lintel-tasks: listing open 245, repo
  # open_issues_count 245, delta 0, zero PRs present.
  _repo_json="$_out.repo"
  if ! GH_TOKEN="$_tok" gh api "repos/$REPO" > "$_repo_json" 2>/dev/null; then
    echo "preflight: listed the issues but could not read $REPO's own open count to verify the" >&2
    echo "           listing is complete; refusing to score an unverified listing." >&2
    rm -f "$_repo_json"
    return 2
  fi
  if ! ILC_LIST="$_out" ILC_REPO="$_repo_json" python3 - <<'ILCPY'
import json, os, sys
try:
    items = json.load(open(os.environ["ILC_LIST"]))
    repo = json.load(open(os.environ["ILC_REPO"]))
except Exception as e:
    print(f"           could not parse the listing or the repo record: {e}", file=sys.stderr)
    sys.exit(1)
if isinstance(items, dict):
    items = [items]
listed_open = sum(1 for i in items if i.get("state") == "open")
claimed = repo.get("open_issues_count")
if not isinstance(claimed, int):
    print("           the repo record carries no open_issues_count to compare against", file=sys.stderr)
    sys.exit(1)
if listed_open != claimed:
    print(f"           the listing holds {listed_open} open entrie(s) but {repo.get('full_name')} "
          f"reports {claimed}. The listing is INCOMPLETE — most likely a dropped page.",
          file=sys.stderr)
    sys.exit(1)
sys.exit(0)
ILCPY
  then
    echo "preflight: refusing to score an incomplete issue listing (see above)." >&2
    rm -f "$_repo_json"
    return 2
  fi
  rm -f "$_repo_json"
  return 0
}

run_check() {
  _ledger="$1"
  [ -f "$_ledger" ] || { echo "preflight: no ledger at $_ledger" >&2; return 2; }
  _term="$(sh "$ORCH/tools/request-states.sh" --terminal 2>/dev/null)"
  _nonterm="$(sh "$ORCH/tools/request-states.sh" --non-terminal 2>/dev/null)"
  _src="$(sh "$ORCH/tools/request-states.sh" --source 2>/dev/null)"
  # NO FALLBACK LIST. If the contract cannot be read this refuses to run rather than assuming
  # which states are finished business — the assumption that re-raised every dropped row.
  if [ -z "$_term" ] || [ -z "$_nonterm" ]; then
    echo "FAIL: the state vocabulary could not be read via tools/request-states.sh — refusing to" >&2
    echo "      guess which states are terminal. Fix the contract parse first." >&2
    return 2
  fi
  _issues="$(mktemp)" || return 2
  fetch_issues "$_issues" || { _rc=$?; rm -f "$_issues"; return "$_rc"; }
  ILC_TERMINAL="$_term" ILC_NONTERMINAL="$_nonterm" ILC_SOURCE="$_src" \
  ILC_LEDGER="$_ledger" ILC_ISSUES="$_issues" \
    python3 "$ORCH/tools/issues-ledger-check.py"
  _rc=$?
  rm -f "$_issues"
  return "$_rc"
}

if [ "$SELFTEST" -ne 1 ]; then
  run_check "$LEDGER"
  exit $?
fi

# --selftest. A checker that has only ever passed is not evidence. Every fixture below is a
# throwaway in a fresh mktemp -d; no network, no gh, and the real ledger is never read.
d="$(mktemp -d)" || exit 2
echo "selftest: fixtures in $d (throwaway; no network is used and the real ledger is never read)"

led="$d/ledger.jsonl"
{
  printf '%s\n' '{"id":"REQ-001","ts":"2026-08-20T10:00:00Z","request":"finished thing","state":"delivered","touches":[],"note":""}'
  printf '%s\n' '{"id":"REQ-002","ts":"2026-08-20T10:00:00Z","request":"owed thing","state":"open","touches":[],"note":""}'
  printf '%s\n' '{"id":"REQ-003","ts":"2026-08-20T10:00:00Z","request":"closed as dropped","state":"dropped","touches":[],"note":""}'
  printf '%s\n' '{"id":"REQ-004","ts":"2026-08-20T10:00:00Z","request":"Implement the Creator Studio sidebar in the product repository","state":"open","touches":[],"note":""}'
} > "$led"

# Issue-list fixtures are the GitHub API shape the validator actually reads: an array of
# objects carrying number and body. An agreeing tracker names exactly the one owed row.
# Third argument is the issue state. It is REQUIRED by the validator since 2026-08-24 — a
# fixture without it is itself a defect class, tested below.
iss() { printf '{"number":%s,"state":"%s","title":"t","body":"Ledger row: %s\\n\\nbody"}' "$1" "$3" "$2"; }
printf '[{"number":1,"state":"open","title":"REQ-002: owed thing","body":"Standalone body without a ledger marker"}]\n' > "$d/agreeing.json"
printf '[]\n'                                                      > "$d/owed-row-with-no-issue.json"
printf '[%s,%s]\n' "$(iss 1 REQ-002 open)" "$(iss 2 REQ-001 open)" > "$d/issue-names-terminal-row.json"
printf '[%s,%s]\n' "$(iss 1 REQ-002 open)" "$(iss 2 REQ-003 open)" > "$d/issue-names-dropped-row.json"
printf '[%s,%s]\n' "$(iss 1 REQ-002 open)" "$(iss 2 REQ-404 open)" > "$d/issue-names-missing-row.json"
printf '[%s,{"number":2,"state":"open","title":"t","body":"no join key here"}]\n' "$(iss 1 REQ-002 open)" \
                                                                    > "$d/issue-with-no-reference.json"
printf '[%s,%s]\n' "$(iss 1 REQ-002 open)" "$(iss 2 REQ-002 open)" > "$d/two-issues-name-one-row.json"

# The 2026-08-24 additions. The first must FAIL; the two after it must PASS, and they are the
# fixtures that prove the widened fetch did not turn correct history into false alarms.
printf '[%s]\n' "$(iss 2 REQ-002 closed)"                             > "$d/closed-issue-left-row-owed.json"
printf '[%s,%s]\n' "$(iss 1 REQ-002 open)" "$(iss 2 REQ-001 closed)"  > "$d/closed-issue-names-terminal-row.json"
printf '[%s,%s]\n' "$(iss 1 REQ-002 open)" "$(iss 2 REQ-002 closed)"  > "$d/row-refiled-under-new-issue.json"
printf '[{"number":1,"title":"t","body":"Ledger row: REQ-002"}]\n'    > "$d/issue-with-no-state.json"

failed=0
for name in owed-row-with-no-issue issue-names-terminal-row issue-names-dropped-row \
            issue-names-missing-row issue-with-no-reference two-issues-name-one-row \
            closed-issue-left-row-owed; do
  out="$(ILC_ISSUES_FILE="$d/$name.json" run_check "$led" 2>&1)"; rc=$?
  if [ "$rc" -ne 1 ]; then
    echo "SELFTEST FAILED: defect class '$name' produced exit $rc, wanted 1" >&2
    printf '%s\n' "$out" | sed 's/^/      /' >&2
    failed=1
  else
    echo "  caught  $name  (exit $rc)"
    printf '%s\n' "$out" | grep -E '^  (#|REQ-)' | head -1 | sed 's/^/       /'
  fi
done

# THE CLOSED-ISSUE CHECK MUST NAME THE RIGHT REPAIR, not merely go red. The condition also trips
# the untracked check, so exit 1 alone would not prove the new check ran at all — assert on the
# message that distinguishes them.
out="$(ILC_ISSUES_FILE="$d/closed-issue-left-row-owed.json" run_check "$led" 2>&1)"
if printf '%s\n' "$out" | /usr/bin/grep -q 'is closed but'; then
  echo "  named   closed-issue-left-row-owed reports the closed-issue repair, not just 'untracked'"
else
  echo "SELFTEST FAILED: the closed-issue defect went red without naming the closed issue —" >&2
  echo "                 that is the untracked check firing, not the new one." >&2
  printf '%s\n' "$out" | sed 's/^/      /' >&2
  failed=1
fi

# MUST NOT FLAG. These two are the whole risk of widening the fetch: correct history read as a
# defect. A closed issue naming a delivered row is the pairing rule working, and a row re-filed
# under a new open issue is still tracked.
for name in closed-issue-names-terminal-row row-refiled-under-new-issue; do
  out="$(ILC_ISSUES_FILE="$d/$name.json" run_check "$led" 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "SELFTEST FAILED: '$name' is correct history and was flagged (exit $rc)" >&2
    printf '%s\n' "$out" | sed 's/^/      /' >&2
    failed=1
  else
    echo "  passed  $name  (correct history, not a defect)"
  fi
done

# A list with no state field cannot be scoped, so it is could-not-run rather than a guess.
out="$(ILC_ISSUES_FILE="$d/issue-with-no-state.json" run_check "$led" 2>&1)"; rc=$?
if [ "$rc" -ne 2 ]; then
  echo "SELFTEST FAILED: an issue with no state field produced exit $rc, wanted 2" >&2
  printf '%s\n' "$out" | sed 's/^/      /' >&2
  failed=1
else
  echo "  caught  issue-with-no-state  (exit 2, could-not-run — refuses to assume open)"
fi

# The tracker being unreachable is could-not-run, never a verdict. Simulate gh failing by
# putting a stub that always fails first on PATH, with ILC_ISSUES_FILE unset.
stub="$d/bin"; mkdir -p "$stub"
printf '#!/bin/sh\nexit 1\n' > "$stub/gh"; chmod +x "$stub/gh"
out="$(PATH="$stub:$PATH" ILC_ISSUES_FILE= run_check "$led" 2>&1)"; rc=$?
if [ "$rc" -ne 2 ]; then
  echo "SELFTEST FAILED: an unreachable tracker produced exit $rc, wanted 2 (could not run)" >&2
  printf '%s\n' "$out" | sed 's/^/      /' >&2
  failed=1
else
  echo "  caught  tracker-unreachable  (exit 2, could-not-run — not a pass, not a failure)"
fi

if ILC_ISSUES_FILE="$d/agreeing.json" run_check "$led" >/dev/null 2>&1; then
  echo "  passed  a tracker that agrees with its ledger (exit 0)"
else
  echo "SELFTEST FAILED: the checker rejected a tracker that agrees with its ledger" >&2
  ILC_ISSUES_FILE="$d/agreeing.json" run_check "$led" 2>&1 | sed 's/^/      /' >&2
  failed=1
fi

if [ "$failed" -ne 0 ]; then
  echo "SELFTEST FAILED — see above. Fixtures kept at $d for inspection." >&2
  exit 1
fi
echo "selftest: OK — every defect class above was caught, the unreachable case was exit 2, and an agreeing pair passed."
exit 0

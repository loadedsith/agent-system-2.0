# Proposed wiring for drift-detect.sh into summon.sh

**Status: proposal only. `summon.sh` has not been edited.** Wiring the door is a
separate decision.

## The proposed line

Add exactly this one line to `/Users/jowolff/.claude/orchestrator/summon.sh`,
anywhere after the log/output section is set up:

```sh
[ -x /Users/jowolff/.claude/orchestrator/tools/drift-detect.sh ] && zsh /Users/jowolff/.claude/orchestrator/tools/drift-detect.sh 2>&1 | sed 's/^/[drift] /' || true
```

## Why this cannot fail the caller

- `[ -x ... ] &&` — if the script is absent, unreadable, or not executable, the
  test is false and nothing runs.
- `| sed ...` — the pipeline's exit status is the last command's (`sed`), so the
  detector's non-zero "drift found" exit never propagates. This holds only while
  `summon.sh` does not set `pipefail`; if it ever does, wrap the whole line in a
  subshell that ends in `true`.
- `|| true` — belt and braces: the whole compound statement exits 0 regardless,
  so an `errexit` or `err_return` setting in `summon.sh` cannot trip on it.
- `2>&1` — the detector's stderr is folded into the prefixed output rather than
  leaking raw onto the terminal.
- The detector itself is read-only: it runs `diff`, `cmp`, and `sed` against two
  directories and writes nothing to either tree.

## If the detector is broken or absent

Nothing happens: the session starts normally with no drift report and no error,
because the executable test skips a missing script and the pipeline plus `|| true`
swallow any failure or non-zero exit from a broken one. The cost of a broken
detector is a silently missing report, never a blocked session.

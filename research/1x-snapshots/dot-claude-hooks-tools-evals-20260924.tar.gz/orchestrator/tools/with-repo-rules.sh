#!/bin/zsh
# with-repo-rules.sh — launch a separately-launched Claude worker that ACTUALLY RECEIVES a
# repository's rules, instead of the 11-byte `@AGENTS.md` shim it gets today.
#
#   zsh /Users/jowolff/.claude/orchestrator/tools/with-repo-rules.sh <repo-path> -- <claude args...>
#
# Example (headless):
#   zsh .../with-repo-rules.sh /Users/jowolff/code/shipyard/repos/newdle-web -- \
#       -p "…brief…" --model sonnet --max-budget-usd 2
# Example (background worker):
#   zsh .../with-repo-rules.sh /Users/jowolff/code/shipyard -- --bg --name Rook "…brief…"
#
# Safe to run from the top every time. It regenerates the flattened rules if they are stale and
# REFUSES to launch if it cannot, because a stale rules file that looks current is worse than none.
emulate -L zsh
setopt pipe_fail

ORCH_HOME=/Users/jowolff/.claude/orchestrator
FLATTEN="$ORCH_HOME/tools/flatten-rules.mjs"

REPO="${1:?usage: with-repo-rules.sh <repo-path> -- <claude args...>}"; shift
[[ "${1:-}" == "--" ]] && shift

[[ -d "$REPO" ]] || { print -u2 -- "No such repo directory: $REPO"; exit 1; }

print -u2 -- "[1/3] flattening rules for $REPO ..."
if ! node "$FLATTEN" --check "$REPO" >/dev/null 2>&1; then
  node "$FLATTEN" "$REPO" >/dev/null || {
    print -u2 -- "FAILED to flatten $REPO. Not launching — a worker with no rules is the bug this fixes."
    print -u2 -- "Run: node $FLATTEN $REPO"
    exit 1
  }
  print -u2 -- "      regenerated"
else
  print -u2 -- "      current"
fi

print -u2 -- "[2/3] locating the generated directory ..."
ADDDIR="$(node "$FLATTEN" --check "$REPO" --json 2>/dev/null | python3 -c '
import json,sys,os
r=json.load(sys.stdin)[0]
# outFile is <dir>/.claude/rules/<file>.md ; the --add-dir target is <dir>
print(os.path.dirname(os.path.dirname(os.path.dirname(r["outFile"]))))')"
[[ -n "$ADDDIR" && -d "$ADDDIR" ]] || { print -u2 -- "Could not resolve the generated rules directory."; exit 1; }
print -u2 -- "      $ADDDIR"

print -u2 -- "[3/3] launching claude with the rules attached ..."
export CLAUDE_CODE_ADDITIONAL_DIRECTORIES_CLAUDE_MD=1
exec claude --add-dir "$ADDDIR" "$@"

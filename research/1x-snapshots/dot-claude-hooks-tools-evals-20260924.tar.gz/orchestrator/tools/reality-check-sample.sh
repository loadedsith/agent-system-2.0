#!/bin/sh
# reality-check-sample.sh — build a verification brief for a rotating sample of still-owed rows.
#
# WHY THIS EXISTS. Every checker in this directory compares one RECORD to another RECORD. On
# 2026-08-24 Jo found by eye a ledger row whose work was finished, verified and running while its
# state still said open — and all three join checkers were green, correctly, because the ledger,
# the tracker and the task list all agreed. THEY AGREED AND THEY WERE ALL WRONG ABOUT THE WORLD.
# No record-versus-record check of any scope can see that. This is the first instrument here that
# looks at the world instead.
#
# WHAT IT DOES NOT DO, AND THE REASON IS MEASURED RATHER THAN CAUTIOUS. It does not decide whether
# a row's claim is still true. Five mechanical instruments that tried to decide that from note
# prose were built and measured against the live ledger on 2026-08-24; all five failed, two of
# them by attaching a claim to the wrong artifact. The full table is in the header of
# reality-check-sample.py. The short version: the note is prose written for a human, the claim and
# the artifact share a sentence, and nothing marks which claim is about which artifact.
#
# SO THE DIVISION OF LABOUR IS DELIBERATE. This script does the part a machine does exactly —
# find every artifact a note names, and report what is true of it right now. A human, or a worker
# dispatched with the brief, does the part that needs judgment. It costs no model calls to run.
#
# READ-ONLY, AND PROVEN RATHER THAN ASSERTED. The ledger's sha256 is recorded before the run and
# recomputed after; a mismatch fails loudly. A comment saying "read-only" is a claim, a checksum
# that has to match is a check. Nothing here writes to the ledger, the tracker, or any state file.
#
# SAFE FROM COLD. Re-running is always correct; the sample for a given day is the same every time,
# so two runs on one day produce the same brief rather than drifting.
#
# Usage:
#   reality-check-sample.sh [--size N] [--day YYYY-MM-DD] [--out FILE] [--ledger FILE]
#     --size    rows to sample (default 8)
#     --day     which rotation window to render (default today) — also makes a run reproducible
#     --out     write the brief here instead of stdout
#     --ledger  read this ledger instead of the live one. A SELFTEST INJECTION POINT, documented
#               here so the exemption is visible rather than hidden; a live run never passes it.
#   reality-check-sample.sh --selftest
#               prove the tool can fail, against throwaway fixtures, with no live ledger read.
#
# Exit codes: 0 brief produced | 1 the read-only guarantee was violated | 2 could not run.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
LEDGER="$ORCH/state/REQUESTS.jsonl"
SIZE=8
DAY=""
OUT=""
SELFTEST=0

while [ $# -gt 0 ]; do
  case "$1" in
    --size)   SIZE="${2:?--size needs a number}";   shift 2 ;;
    --day)    DAY="${2:?--day needs YYYY-MM-DD}";   shift 2 ;;
    --out)    OUT="${2:?--out needs a path}";       shift 2 ;;
    --ledger) LEDGER="${2:?--ledger needs a path}"; shift 2 ;;
    --selftest) SELFTEST=1; shift ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

if [ "$SELFTEST" -eq 1 ]; then
  # A tool that has only ever succeeded is not evidence. Every fixture is a throwaway and the live
  # ledger is never read.
  d="$(mktemp -d)" || exit 2
  echo "selftest: fixtures in $d (throwaway; the live ledger is never read)"
  fail=0
  fx="$d/ledger.jsonl"
  i=1
  while [ "$i" -le 6 ]; do
    printf '{"id":"REQ-00%s","ts":"2026-08-20T10:00:00Z","request":"r%s","state":"open","touches":[],"note":"names /Users/jowolff/.claude/CLAUDE.md and /Users/jowolff/nope/missing-%s here."}\n' "$i" "$i" "$i" >> "$fx"
    i=$((i+1))
  done

  out="$(sh "$0" --ledger "$fx" --size 3 --day 2026-08-24 2>&1)"; rc=$?
  if [ "$rc" -eq 0 ] && printf '%s' "$out" | /usr/bin/grep -q 'were not sampled'; then
    echo "  passed  produces a brief and states what it did not look at"
  else
    echo "SELFTEST FAILED: a normal run exited $rc or omitted the not-sampled statement" >&2
    fail=1
  fi

  # Existence must be reported both ways, or the tool is not looking at the world at all.
  if printf '%s' "$out" | /usr/bin/grep -q 'CLAUDE.md` | yes' && printf '%s' "$out" | /usr/bin/grep -q 'missing-.*| \*\*NO\*\*'; then
    echo "  passed  reports a present path as present and an absent one as absent"
  else
    echo "SELFTEST FAILED: path existence was not reported both ways" >&2
    fail=1
  fi

  # The rotation must reach every row rather than resampling the same ones.
  all="$(for dd in 2026-08-24 2026-08-25; do sh "$0" --ledger "$fx" --size 3 --day "$dd" 2>/dev/null; done | /usr/bin/grep -o 'REQ-00[0-9]' | sort -u | wc -l | tr -d ' ')"
  if [ "$all" = "6" ]; then
    echo "  passed  two consecutive windows cover all 6 rows with no repeat"
  else
    echo "SELFTEST FAILED: two windows covered $all of 6 rows" >&2
    fail=1
  fi

  # THE READ-ONLY GUARANTEE, TESTED BY BREAKING IT. A stub python3 that mutates the ledger stands
  # in for the sampler; the front door must notice and refuse. Asserting read-only would be a
  # claim, and a checksum that has to match is a check.
  stub="$d/bin"; mkdir -p "$stub"
  printf '#!/bin/sh\nprintf "mutated\\n" >> "%s"\nexit 0\n' "$fx" > "$stub/python3"
  chmod +x "$stub/python3"
  out2="$(PATH="$stub:$PATH" sh "$0" --ledger "$fx" --size 3 --day 2026-08-24 2>&1)"; rc2=$?
  if [ "$rc2" -eq 1 ] && printf '%s' "$out2" | /usr/bin/grep -q 'READ-ONLY GUARANTEE VIOLATED'; then
    echo "  caught  a ledger that changed mid-run (exit 1, refuses to stand behind the brief)"
  else
    echo "SELFTEST FAILED: a ledger mutated mid-run produced exit $rc2 without the violation notice" >&2
    printf '%s\n' "$out2" | sed 's/^/      /' >&2
    fail=1
  fi

  if [ "$fail" -ne 0 ]; then
    echo "SELFTEST FAILED — fixtures kept at $d" >&2
    exit 1
  fi
  echo "selftest: OK — briefs render, existence is reported both ways, the rotation covers everything, and a mid-run change is refused."
  exit 0
fi

command -v python3 >/dev/null || { echo "preflight: python3 not found" >&2; exit 2; }
command -v shasum  >/dev/null || { echo "preflight: shasum not found" >&2; exit 2; }
[ -f "$LEDGER" ] || { echo "preflight: no ledger at $LEDGER" >&2; exit 2; }
[ -f "$ORCH/tools/reality-check-sample.py" ] || {
  echo "preflight: the sampler is missing at $ORCH/tools/reality-check-sample.py" >&2; exit 2; }

# THE VOCABULARY IS NOT DEFINED HERE, deliberately — same rule as every sibling checker.
# tools/request-states.sh parses it out of the contract and owns that answer. A copy here would be
# one edit away from sampling rows that are finished business.
NONTERM="$(sh "$ORCH/tools/request-states.sh" --non-terminal 2>/dev/null)"
if [ -z "$NONTERM" ]; then
  echo "FAIL: the state vocabulary could not be read via tools/request-states.sh — refusing to" >&2
  echo "      guess which states are still owed." >&2
  exit 2
fi

SHA_BEFORE="$(shasum -a 256 "$LEDGER" | cut -d' ' -f1)"

set -- --ledger "$LEDGER" --orch "$ORCH" --nonterminal "$NONTERM" --size "$SIZE"
[ -n "$DAY" ] && set -- "$@" --day "$DAY"

if [ -n "$OUT" ]; then
  python3 "$ORCH/tools/reality-check-sample.py" "$@" > "$OUT" || exit 2
else
  python3 "$ORCH/tools/reality-check-sample.py" "$@" || exit 2
fi

SHA_AFTER="$(shasum -a 256 "$LEDGER" | cut -d' ' -f1)"
if [ "$SHA_BEFORE" != "$SHA_AFTER" ]; then
  echo "READ-ONLY GUARANTEE VIOLATED: REQUESTS.jsonl changed during this run. Do not trust the" >&2
  echo "      brief above — it may describe rows that have since moved." >&2
  echo "      before $SHA_BEFORE" >&2
  echo "      after  $SHA_AFTER" >&2
  exit 1
fi

[ -n "$OUT" ] && echo "brief written to $OUT (ledger sha256 unchanged: $SHA_BEFORE)"
exit 0

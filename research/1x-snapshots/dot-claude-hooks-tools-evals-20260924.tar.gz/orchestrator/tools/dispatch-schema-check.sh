#!/bin/sh
# dispatch-schema-check.sh — does every row of state/LEDGER.jsonl carry the keys and values the
# dispatch-ledger contract declares?
#
# WHY THIS FILE EXISTS. The dispatch ledger grew one key at a time, by hand: 159 rows carrying 23
# distinct key sets, several closed vocabularies nobody had written down, and no identity field at
# all. Nothing failed at write time, because a row with an invented key is still valid JSON and
# still counts. The missing identity is the expensive part — with no id there is no way to amend a
# row, so a finished dispatch left a second row instead of correcting the first. This is the
# checker that makes both visible.
#
# THE SCHEMA IS NOT DEFINED HERE, deliberately — the same rule the request-ledger tools follow. It
# is read out of contracts/dispatch-ledger.md, from the outcome-vocabulary, dispatch-fields,
# tier-vocabulary, outcome-label-vocabulary, friction-code-vocabulary and ts-source-vocabulary
# blocks. If the contract cannot be parsed this exits 2 rather than inventing a schema.
#
# Usage:
#   dispatch-schema-check.sh [ledger.jsonl] [dispatch-ledger-contract.md]
#   dispatch-schema-check.sh --required            # required key names, one per line
#   dispatch-schema-check.sh --types               # "key<TAB>type", one per line
#   dispatch-schema-check.sh --outcomes            # "outcome<TAB>terminal|non-terminal"
#   dispatch-schema-check.sh --terminal-outcomes   # terminal outcome names, one per line
#   dispatch-schema-check.sh --tiers               # declared tier values
#   dispatch-schema-check.sh --outcome-labels      # declared outcome_label values
#   dispatch-schema-check.sh --friction-codes      # declared friction_code values
#   dispatch-schema-check.sh --ts-sources          # declared ts_source values
#   dispatch-schema-check.sh --selftest            # prove the checker can fail, one defect class
#                                                  # at a time, against throwaway fixtures
#
# Exit codes: 0 every row conforms | 1 at least one row does not | 2 could not run the check.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
CONTRACT_DEFAULT="$ORCH/contracts/dispatch-ledger.md"

parse_fields() {
  awk '
    /dispatch-fields:begin/ { inblock = 1; next }
    /dispatch-fields:end/   { inblock = 0; next }
    inblock {
      line = $0
      sub(/^[[:space:]]*>[[:space:]]*/, "", line)
      if (match(line, /^-[[:space:]]*`[a-z_]+`[[:space:]]*(—|--)[[:space:]]*(required|optional)[[:space:]]*(—|--)[[:space:]]*(nullable-string|nullable-int|string|int|number|array|object)/)) {
        name = line; sub(/^-[[:space:]]*`/, "", name); sub(/`.*$/, "", name)
        rest = line; sub(/^-[[:space:]]*`[a-z_]+`[[:space:]]*(—|--)[[:space:]]*/, "", rest)
        req = (rest ~ /^required/) ? "required" : "optional"
        sub(/^(required|optional)[[:space:]]*(—|--)[[:space:]]*/, "", rest)
        typ = "string"
        if      (rest ~ /^nullable-string/) typ = "nullable-string"
        else if (rest ~ /^nullable-int/)    typ = "nullable-int"
        else if (rest ~ /^string/)          typ = "string"
        else if (rest ~ /^int/)             typ = "int"
        else if (rest ~ /^number/)          typ = "number"
        else if (rest ~ /^array/)           typ = "array"
        else if (rest ~ /^object/)          typ = "object"
        print name "\t" req "\t" typ
      }
    }
  ' "$1"
}

parse_outcomes() {
  awk '
    /outcome-vocabulary:begin/ { inblock = 1; next }
    /outcome-vocabulary:end/   { inblock = 0; next }
    inblock {
      line = $0
      sub(/^[[:space:]]*>[[:space:]]*/, "", line)
      if (match(line, /^-[[:space:]]*`[a-z-]+`[[:space:]]*(—|--)[[:space:]]*(non-terminal|terminal)/)) {
        name = line; sub(/^-[[:space:]]*`/, "", name); sub(/`.*$/, "", name)
        rest = line; sub(/^-[[:space:]]*`[a-z-]+`[[:space:]]*(—|--)[[:space:]]*/, "", rest)
        print name "\t" ((rest ~ /^non-terminal/) ? "non-terminal" : "terminal")
      }
    }
  ' "$1"
}

# The four simple closed vocabularies share one parse; only the marker name differs.
parse_vocab() {
  awk -v block="$2" '
    index($0, block ":begin") { inblock = 1; next }
    index($0, block ":end")   { inblock = 0; next }
    inblock {
      line = $0
      sub(/^[[:space:]]*>[[:space:]]*/, "", line)
      if (match(line, /^-[[:space:]]*`[a-zA-Z-]+`[[:space:]]*(—|--)/)) {
        name = line; sub(/^-[[:space:]]*`/, "", name); sub(/`.*$/, "", name)
        print name
      }
    }
  ' "$1"
}

CONTRACT_ARG="${LINTEL_DISPATCH_CONTRACT:-$CONTRACT_DEFAULT}"

case "${1:-}" in
  --required)          parse_fields "${2:-$CONTRACT_ARG}" | awk -F'\t' '$2=="required"{print $1}'; exit 0 ;;
  --types)             parse_fields "${2:-$CONTRACT_ARG}" | cut -f1,3; exit 0 ;;
  --outcomes)          parse_outcomes "${2:-$CONTRACT_ARG}"; exit 0 ;;
  --terminal-outcomes) parse_outcomes "${2:-$CONTRACT_ARG}" | awk -F'\t' '$2=="terminal"{print $1}'; exit 0 ;;
  --tiers)             parse_vocab "${2:-$CONTRACT_ARG}" tier-vocabulary; exit 0 ;;
  --outcome-labels)    parse_vocab "${2:-$CONTRACT_ARG}" outcome-label-vocabulary; exit 0 ;;
  --friction-codes)    parse_vocab "${2:-$CONTRACT_ARG}" friction-code-vocabulary; exit 0 ;;
  --ts-sources)        parse_vocab "${2:-$CONTRACT_ARG}" ts-source-vocabulary; exit 0 ;;
  --continuity)        parse_vocab "${2:-$CONTRACT_ARG}" continuity-vocabulary; exit 0 ;;
  --selftest)          shift; SELFTEST=1; CONTRACT="${1:-$CONTRACT_ARG}" ;;
  *)                   SELFTEST=0; LEDGER="${1:-$ORCH/state/LEDGER.jsonl}"; CONTRACT="${2:-$CONTRACT_ARG}" ;;
esac

command -v python3 >/dev/null || { echo "preflight: python3 not found" >&2; exit 2; }
[ -f "$CONTRACT" ] || { echo "preflight: no dispatch-ledger contract at $CONTRACT" >&2; exit 2; }
[ -f "$ORCH/tools/dispatch-schema-check.py" ] || {
  echo "preflight: validator missing at $ORCH/tools/dispatch-schema-check.py" >&2; exit 2; }

run_check() {
  _ledger="$1"
  _fields="$(parse_fields "$CONTRACT")"
  _outcomes="$(parse_outcomes "$CONTRACT")"
  _tiers="$(parse_vocab "$CONTRACT" tier-vocabulary)"
  _labels="$(parse_vocab "$CONTRACT" outcome-label-vocabulary)"
  _codes="$(parse_vocab "$CONTRACT" friction-code-vocabulary)"
  _tssrc="$(parse_vocab "$CONTRACT" ts-source-vocabulary)"
  # DELIBERATELY NOT REQUIRED BELOW. Every other vocabulary here refuses to run when its block is
  # missing, because those blocks have always existed and their absence means a damaged contract.
  # This one is new as of 2026-08-24 and the contract may not carry it yet, so an empty result
  # means "not declared" rather than "damaged" — the validator then leaves `continuity` unchecked
  # and SAYS SO in its header, instead of the checker breaking on every run until the contract
  # catches up. Ordering that the other way round would take the whole dispatch check red.
  _cont="$(parse_vocab "$CONTRACT" continuity-vocabulary)"
  [ -n "$_fields" ]   || { echo "FAIL: no field declarations found between the dispatch-fields markers in $CONTRACT" >&2; return 2; }
  [ -n "$_outcomes" ] || { echo "FAIL: no outcomes found between the outcome-vocabulary markers in $CONTRACT" >&2; return 2; }
  [ -n "$_tiers" ]    || { echo "FAIL: no tiers found between the tier-vocabulary markers in $CONTRACT" >&2; return 2; }
  [ -n "$_labels" ]   || { echo "FAIL: no outcome labels found between the outcome-label-vocabulary markers in $CONTRACT" >&2; return 2; }
  [ -n "$_codes" ]    || { echo "FAIL: no friction codes found between the friction-code-vocabulary markers in $CONTRACT" >&2; return 2; }
  [ -n "$_tssrc" ]    || { echo "FAIL: no ts sources found between the ts-source-vocabulary markers in $CONTRACT" >&2; return 2; }
  [ -f "$_ledger" ] || { echo "preflight: no ledger at $_ledger" >&2; return 2; }
  DSC_FIELDS="$_fields" DSC_OUTCOMES="$_outcomes" DSC_TIERS="$_tiers" \
  DSC_OUTCOME_LABELS="$_labels" DSC_FRICTION_CODES="$_codes" DSC_TS_SOURCES="$_tssrc" \
  DSC_CONTINUITY="$_cont" \
  DSC_LEDGER="$_ledger" DSC_CONTRACT="$CONTRACT" \
    python3 "$ORCH/tools/dispatch-schema-check.py"
}

if [ "$SELFTEST" -ne 1 ]; then
  run_check "$LEDGER"
  exit $?
fi

# --selftest. A checker that has only ever passed is not evidence, and a checker that passes
# vacuously is worse than none: it converts an unexamined file into an examined one in the
# reader's mind. One throwaway fixture per defect class, each required to fail, then a conforming
# fixture required to pass. Fixtures live in a fresh mktemp -d; nothing here goes near the real
# ledger.
d="$(mktemp -d)" || exit 2
echo "selftest: fixtures in $d (throwaway; the real ledger is never touched)"
good='{"id":"DSP-001","ts":"2026-08-21T10:00:00Z","task":"do the thing","shape":"bounded read","dispatched_to":"builder","tier":"worker","outcome":"clean","attempts":1,"jo_touches":0,"friction":"none"}'

printf '%s\n' \
  "unknown-key|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\",\"priority\":\"high\"}" \
  "missing-required-key|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "missing-id|{\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "unknown-outcome|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"kumquat\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "outcome-typo-in-flght|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"in-flght\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "unknown-tier|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"deputy\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "unknown-friction-code|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\",\"friction_code\":\"vibes\"}" \
  "unknown-outcome-label|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\",\"outcome_label\":\"mostly-used\"}" \
  "unknown-ts-source|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\",\"ts_source\":\"guessed\"}" \
  "malformed-id|{\"id\":\"dispatch-2\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "duplicate-id|$good" \
  "malformed-timestamp|{\"id\":\"DSP-002\",\"ts\":\"tuesday\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "naive-timestamp-no-offset|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "wrong-type-attempts|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":\"one\",\"jo_touches\":0,\"friction\":\"none\"}" \
  "wrong-type-jo-touches|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"t\",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":1.5,\"friction\":\"none\"}" \
  "empty-task|{\"id\":\"DSP-002\",\"ts\":\"2026-08-21T10:00:00Z\",\"task\":\"   \",\"shape\":\"s\",\"dispatched_to\":\"d\",\"tier\":\"worker\",\"outcome\":\"clean\",\"attempts\":1,\"jo_touches\":0,\"friction\":\"none\"}" \
  "unparseable-line|{\"id\":\"DSP-002\", this is not json" \
  "not-an-object|[\"id\",\"DSP-002\"]" \
| while IFS='|' read -r name row; do
    f="$d/$name.jsonl"
    printf '%s\n%s\n' "$good" "$row" > "$f"
    out="$(run_check "$f" 2>&1)"; rc=$?
    if [ "$rc" -eq 0 ]; then
      echo "SELFTEST FAILED: the checker PASSED a ledger carrying defect class '$name'" >&2
      printf '%s\n' "$out" | sed 's/^/      /' >&2
      : > "$d/.failed"
    else
      echo "  caught  $name  (exit $rc)"
      printf '%s\n' "$out" | grep '^  L' | head -1 | sed 's/^/       /'
    fi
  done

printf '%s\n' "$good" > "$d/conforming.jsonl"
if run_check "$d/conforming.jsonl" >/dev/null 2>&1; then
  echo "  passed  a conforming one-row ledger (exit 0)"
else
  echo "SELFTEST FAILED: the checker rejected a conforming ledger" >&2
  run_check "$d/conforming.jsonl" 2>&1 | sed 's/^/      /' >&2
  : > "$d/.failed"
fi

# THE OPTIONAL CONTINUITY VOCABULARY, ADDED 2026-08-24 WITH ITS OWN FIXTURES. An adversarial review
# caught that the feature shipped with manual checks and nothing in this selftest — and a check that
# is never exercised reports success by silence, which is the defect this whole block exists to
# prevent. Both directions are asserted: unenforced when the contract carries no block, and refusing
# a value outside the block when it does.
cont_contract="$d/contract-with-continuity.md"
sed 's|^- `ts_source` — optional.*|&\
- `continuity` — optional — string — one of the values in the continuity vocabulary below.|' \
    "$CONTRACT" > "$cont_contract"
printf '%s\n' '<!-- continuity-vocabulary:begin -->' '- `fresh` — a new agent.' \
       '- `reused` — an agent that had already worked in this session.' \
       '<!-- continuity-vocabulary:end -->' >> "$cont_contract"

printf '%s\n' "$good" | sed 's/}$/, "continuity": "recycled"}/' > "$d/continuity-bad.jsonl"
printf '%s\n' "$good" | sed 's/}$/, "continuity": "reused"}/'   > "$d/continuity-ok.jsonl"

_saved_contract="$CONTRACT"
CONTRACT="$cont_contract"
out="$(run_check "$d/continuity-bad.jsonl" 2>&1)"; rc=$?
if [ "$rc" -eq 1 ] && printf '%s' "$out" | /usr/bin/grep -q "continuity 'recycled' is not in the contract"; then
  echo "  caught  continuity-outside-vocabulary  (exit 1)"
else
  echo "SELFTEST FAILED: a continuity value outside the declared block produced exit $rc" >&2
  printf '%s\n' "$out" | sed 's/^/      /' >&2
  : > "$d/.failed"
fi
if run_check "$d/continuity-ok.jsonl" >/dev/null 2>&1; then
  echo "  passed  a declared continuity value (exit 0)"
else
  echo "SELFTEST FAILED: a declared continuity value was rejected" >&2
  : > "$d/.failed"
fi
CONTRACT="$_saved_contract"

# FIELD DECLARED, VOCABULARY BLOCK ABSENT: an open vocabulary, accepted but ANNOUNCED. This is a
# distinct state from the field being undeclared, and the difference is not cosmetic — an undeclared
# FIELD is an unknown key and is rejected outright, while a declared field with no vocabulary block
# accepts any value. The first fixture written here conflated the two and this assertion caught it.
field_only="$d/contract-field-no-vocab.md"
sed 's|^- `ts_source` — optional.*|&\
- `continuity` — optional — string — one of the values in the continuity vocabulary below.|' \
    "$_saved_contract" > "$field_only"
_saved2="$CONTRACT"
CONTRACT="$field_only"
out="$(run_check "$d/continuity-bad.jsonl" 2>&1)"; rc=$?
CONTRACT="$_saved2"
if [ "$rc" -eq 0 ] && printf '%s' "$out" | /usr/bin/grep -q 'unenforced:.*continuity'; then
  echo "  passed  no continuity block — accepted AND announced as unenforced"
else
  echo "SELFTEST FAILED: an undeclared continuity vocabulary was not announced (exit $rc)" >&2
  printf '%s\n' "$out" | sed 's/^/      /' >&2
  : > "$d/.failed"
fi

if [ -f "$d/.failed" ]; then
  echo "SELFTEST FAILED — see above. Fixtures kept at $d for inspection." >&2
  exit 1
fi
echo "selftest: OK — every defect class above was caught, and a conforming ledger passed."
exit 0

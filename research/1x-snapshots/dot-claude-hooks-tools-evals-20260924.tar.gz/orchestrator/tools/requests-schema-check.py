#!/usr/bin/env python3
"""Row-by-row validator behind tools/requests-schema-check.sh.

This file holds NO vocabulary and NO schema. Everything it enforces arrives in the environment,
parsed out of the request-ledger contract by the shell driver:

    RSC_FIELDS   "name\\trequired|optional\\tstring|array" per declared field
    RSC_TOUCH    declared touch type names, one per line
    RSC_STATES   declared state names, one per line (from tools/request-states.sh)
    RSC_LEDGER   path to the .jsonl to validate
    RSC_CONTRACT path the declarations came from, for the header

Run it directly and it exits 2, because without those it has nothing to enforce and guessing a
schema is the defect this whole tool exists to prevent.

Exit codes: 0 every row conforms | 1 at least one row does not | 2 could not run the check.
"""

import json
import os
import re
import sys

ID_RE = re.compile(r"^REQ-\d{3,}$")
# ISO 8601 with an explicit offset or a trailing Z. A naive local timestamp is rejected: the
# ledger is read by hooks that sort rows, and an offsetless stamp silently sorts wrong.
TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:?\d{2})$")


def env(name):
    v = os.environ.get(name)
    if v is None or v == "":
        sys.stderr.write(
            f"requests-schema-check.py: {name} not set. This validator is driven by\n"
            f"tools/requests-schema-check.sh, which parses the contract and passes the schema in.\n"
            f"Run that instead; this file declares no schema of its own, deliberately.\n"
        )
        sys.exit(2)
    return v


def main():
    ledger = env("RSC_LEDGER")
    contract = env("RSC_CONTRACT")
    states = set(env("RSC_STATES").split("\n"))
    touch_types = set(env("RSC_TOUCH").split("\n"))

    fields = {}
    for line in env("RSC_FIELDS").split("\n"):
        parts = line.split("\t")
        if len(parts) != 3:
            sys.stderr.write(f"requests-schema-check.py: unparseable RSC_FIELDS line: {line!r}\n")
            return 2
        fields[parts[0]] = {"required": parts[1] == "required", "type": parts[2]}

    required = {k for k, v in fields.items() if v["required"]}
    known = set(fields)

    problems = []          # (line_no, message)
    seen_ids = {}
    rows = 0

    with open(ledger, "r", encoding="utf-8") as fh:
        for n, raw in enumerate(fh, 1):
            if not raw.strip():
                continue
            rows += 1
            try:
                row = json.loads(raw)
            except Exception as exc:
                problems.append((n, f"unparseable JSON: {exc}"))
                continue
            if not isinstance(row, dict):
                problems.append((n, f"not a JSON object (got {type(row).__name__})"))
                continue

            rid = row.get("id")
            label = rid if isinstance(rid, str) else "<no id>"

            for key in sorted(required - set(row)):
                extra = ""
                # Name the near-miss, because the whole defect class is a plausible wrong key
                # sitting where the right one should be, still parsing, still counting.
                for present in sorted(set(row) - known):
                    extra = (f" (row carries undeclared key '{present}' — if that is this field "
                             f"under the wrong name, rename it to '{key}')")
                    break
                problems.append((n, f"{label}: missing required key '{key}'{extra}"))

            for key in sorted(set(row) - known):
                problems.append(
                    (n, f"{label}: unknown key '{key}' — not declared in the request-fields block. "
                        f"Declare it there or remove it; nothing reads it as written.")
                )

            for key, spec in fields.items():
                if key not in row:
                    continue
                val = row[key]
                if spec["type"] == "array" and not isinstance(val, list):
                    problems.append((n, f"{label}: key '{key}' must be an array, got {type(val).__name__}"))
                elif spec["type"] == "string" and not isinstance(val, str):
                    problems.append((n, f"{label}: key '{key}' must be a string, got {type(val).__name__}"))

            if isinstance(rid, str):
                if not ID_RE.match(rid):
                    problems.append((n, f"{label}: id is not of the form REQ-NNN"))
                elif rid in seen_ids:
                    problems.append((n, f"{label}: duplicate id, already used on line {seen_ids[rid]}"))
                else:
                    seen_ids[rid] = n

            ts = row.get("ts")
            if isinstance(ts, str) and not TS_RE.match(ts):
                problems.append(
                    (n, f"{label}: ts {ts!r} is not ISO 8601 with an explicit offset or trailing Z")
                )

            req = row.get("request")
            if isinstance(req, str) and not req.strip():
                problems.append(
                    (n, f"{label}: 'request' is empty — the row would render as a blank line in "
                        f"every open-obligations list that prints it")
                )

            st = row.get("state")
            if isinstance(st, str) and st not in states:
                problems.append(
                    (n, f"{label}: state '{st}' is not in the contract's state-vocabulary block")
                )

            touches = row.get("touches")
            if isinstance(touches, list):
                for i, t in enumerate(touches):
                    where = f"{label}: touches[{i}]"
                    if not isinstance(t, dict):
                        problems.append((n, f"{where} is not an object (got {type(t).__name__})"))
                        continue
                    tt = t.get("type")
                    if tt is None:
                        problems.append((n, f"{where} has no 'type'"))
                    elif tt not in touch_types:
                        problems.append(
                            (n, f"{where} type '{tt}' is not in the contract's touch-vocabulary block")
                        )
                    txt = t.get("text")
                    if txt is None:
                        problems.append(
                            (n, f"{where} has no 'text' — a typed touch with no quote is a tally "
                                f"mark, and the contract counts weight, not tallies")
                        )
                    elif not isinstance(txt, str) or not txt.strip():
                        problems.append((n, f"{where} 'text' is empty"))
                    for extra_key in sorted(set(t) - {"type", "text"}):
                        problems.append((n, f"{where} carries unknown key '{extra_key}'"))

    print(f"contract: {contract}")
    print(f"ledger:   {ledger}")
    print(f"rows:     {rows}")
    print(f"required: {' '.join(sorted(required))}")
    print(f"states:   {' '.join(sorted(states))}")
    print(f"touches:  {' '.join(sorted(touch_types))}")

    if not problems:
        print()
        print("OK — every row carries exactly the declared keys, with declared values.")
        return 0

    affected = len({n for n, _ in problems})
    print()
    print(f"FAIL — {len(problems)} problem(s) across {affected} row(s):")
    for n, msg in problems:
        print(f"  L{n}: {msg}")
    return 1


if __name__ == "__main__":
    sys.exit(main())

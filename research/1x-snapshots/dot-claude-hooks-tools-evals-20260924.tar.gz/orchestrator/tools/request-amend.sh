#!/bin/sh
# request-amend.sh — the way an EXISTING row of state/REQUESTS.jsonl gets changed.
#
# WHY THIS FILE EXISTS. tools/request-append.sh can only append (its final act is a `>>`), so a
# row containing a wrong statement stayed wrong forever, or got rewritten by hand in python —
# 305 of 307 measured direct writes were exactly that shape (hooks/ledger-write-guard.mjs header,
# measured 2026-08-26), into a file nothing validates at write time. Worse: nothing on this
# machine could transition a row's state, so the ledger had no supported way to CLOSE an
# obligation — every delivered/dropped/deferred row got there by hand. This is the writer that
# closes both gaps. ledger-write-guard.mjs's own header files the request: "build a writer that
# can mutate a row, then widen this."
#
# IT DOES NOT CARRY ITS OWN COPY OF THE RULES — same law as request-append.sh:
#   - the amended row is validated by tools/requests-schema-check.sh, the same code path that
#     validates the whole file. The candidate row is validated ALONE, so pre-existing rows the
#     checker already objects to cannot mask or manufacture a verdict here.
#   - terminal-vs-non-terminal is answered by tools/request-states.sh --is-terminal, the one
#     predicate both savepoint hooks already share. No state names appear in this file.
#
# HISTORY IS A SIDECAR, DELIBERATELY. Every amendment appends a record — timestamp, id, the
# original line verbatim, the new row, which fields changed, and why — to <ledger>.amendments
# (state/REQUESTS.jsonl.amendments in the installed layout), BEFORE the ledger is touched, so no
# mutation can ever exist without its trace. It is NOT extra rows in REQUESTS.jsonl:
# hooks/savepoint-restore.sh reads that file line by line and injects every non-terminal row's
# request and note into every session start, so history rows appended there would be read aloud
# as open obligations forever. And it is NOT a field inside the row: the contract's
# request-fields block declares exactly six keys and the shared checker rejects any other.
# The sidecar's distinct filename is read by no hook (savepoint-restore.sh reads only
# $STATE/REQUESTS.jsonl; the guard's prefilter matches redirects resolving to that exact path).
#
# REOPENING IS GATED. A terminal row (Jo closed it) does not go back to non-terminal by accident:
# the contract says of `dropped` "Never re-raise or re-litigate it", and savepoint-restore prints
# "re-raising one means a new row". So terminal -> non-terminal is refused unless --reopen is
# given explicitly, for the one honest use: a row that was closed IN ERROR, where the closure
# itself is the wrong statement being amended. The sidecar records reopened=true.
# Terminal -> terminal (e.g. dropped -> delivered) is an ordinary correction and needs no flag.
#
# Usage:
#   request-amend.sh --id REQ-NNN [--state STATE] [--request TEXT] [--note TEXT]
#                    [--add-touch TYPE=TEXT ...] [--drop-key KEY ...] [--why TEXT]
#                    [--reopen] [--ledger PATH] [--sidecar PATH] [--dry-run]
#   request-amend.sh --batch-context-map URLS.json [--why TEXT]
#                    [--ledger PATH] [--sidecar PATH] [--dry-run]
#   request-amend.sh --selftest
#
#   --id         required. The row to amend. `id` and `ts` are immutable: there is no flag to
#                change either, on purpose — a new identity or a new birth time is a new row.
#   --state      new state; must be declared in the contract's state vocabulary.
#   --request    replacement request text.
#   --note       replacement note ("" is legal; the contract allows an empty note).
#   --add-touch  repeatable; appends {type,text} to the row's touches array.
#   --drop-key   repeatable; removes an UNDECLARED key from the row (e.g. the historical `ask`
#                defect). The dropped value is preserved verbatim in the sidecar's `before`.
#                Declared keys cannot be dropped.
#   --why        recorded in the sidecar next to the change. Optional but encouraged.
#   --batch-context-map
#                JSON object mapping REQ-NNN to a GitHub issue URL. Adds each URL as a
#                `context` touch in one validated, atomic ledger replacement and one backup.
#   --dry-run    validate and print the amendment summary; write nothing, not even the sidecar.
#
# Exit codes: 0 amended (or validated, under --dry-run) | 1 refused | 2 could not run.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
CHECK="${RA_CHECK:-$ORCH/tools/requests-schema-check.sh}"
STATES="${RA_STATES:-$ORCH/tools/request-states.sh}"
LEDGER="$ORCH/state/REQUESTS.jsonl"
SIDECAR=""

ID=""; NEW_STATE=""; NEW_REQUEST=""; NEW_NOTE=""; HAVE_NOTE=0; WHY=""; DRYRUN=0; REOPEN=0; BATCH_MAP=""
TOUCHFILE="$(mktemp)" || { echo "request-amend: mktemp failed" >&2; exit 2; }
DROPFILE="$(mktemp)"  || { echo "request-amend: mktemp failed" >&2; exit 2; }

die()    { echo "request-amend: $*" >&2; exit 2; }
reject() { echo "REFUSED — $*" >&2; exit 1; }

[ "${1:-}" = "--selftest" ] && SELFTEST=1 || SELFTEST=0

if [ "$SELFTEST" -ne 1 ]; then
while [ "$#" -gt 0 ]; do
  case "$1" in
    --id)      [ "$#" -ge 2 ] || die "--id needs a value";      ID="$2"; shift 2 ;;
    --state)   [ "$#" -ge 2 ] || die "--state needs a value";   NEW_STATE="$2"; shift 2 ;;
    --request) [ "$#" -ge 2 ] || die "--request needs a value"; NEW_REQUEST="$2"; shift 2 ;;
    --note)    [ "$#" -ge 2 ] || die "--note needs a value";    NEW_NOTE="$2"; HAVE_NOTE=1; shift 2 ;;
    --why)     [ "$#" -ge 2 ] || die "--why needs a value";     WHY="$2"; shift 2 ;;
    --ledger)  [ "$#" -ge 2 ] || die "--ledger needs a value";  LEDGER="$2"; shift 2 ;;
    --sidecar) [ "$#" -ge 2 ] || die "--sidecar needs a value"; SIDECAR="$2"; shift 2 ;;
    --batch-context-map)
      [ "$#" -ge 2 ] || die "--batch-context-map needs a JSON file"
      BATCH_MAP="$2"; shift 2 ;;
    --add-touch)
      [ "$#" -ge 2 ] || die "--add-touch needs TYPE=TEXT"
      case "$2" in *=*) ;; *) reject "--add-touch must be TYPE=TEXT, got '$2'" ;; esac
      printf '%s\n' "$2" >> "$TOUCHFILE"; shift 2 ;;
    --drop-key)
      [ "$#" -ge 2 ] || die "--drop-key needs a key name"
      printf '%s\n' "$2" >> "$DROPFILE"; shift 2 ;;
    --reopen)  REOPEN=1; shift ;;
    --dry-run) DRYRUN=1; shift ;;
    -h|--help) sed -n '1,58p' "$0"; exit 0 ;;
    *) die "unknown argument '$1'. id and ts are immutable by design; there is no flag for them." ;;
  esac
done

command -v python3 >/dev/null || die "python3 not found"
[ -f "$CHECK" ]  || die "shared checker missing at $CHECK"
[ -f "$STATES" ] || die "state predicate missing at $STATES"
[ -f "$LEDGER" ] || die "no ledger at $LEDGER"
[ -n "$SIDECAR" ] || SIDECAR="$LEDGER.amendments"

if [ -n "$BATCH_MAP" ]; then
  [ -f "$BATCH_MAP" ] || die "no batch context map at $BATCH_MAP"
  [ -z "$ID" ] || reject "--batch-context-map cannot be combined with --id"
  [ -z "$NEW_STATE" ] && [ -z "$NEW_REQUEST" ] && [ "$HAVE_NOTE" -eq 0 ] \
    && [ ! -s "$TOUCHFILE" ] && [ ! -s "$DROPFILE" ] && [ "$REOPEN" -eq 0 ] \
    || reject "--batch-context-map cannot be combined with single-row changes"
else
  [ -n "$ID" ] || reject "--id is missing. Amendment is addressed by id; there is no default."

  if [ -z "$NEW_STATE" ] && [ -z "$NEW_REQUEST" ] && [ "$HAVE_NOTE" -eq 0 ] \
     && [ ! -s "$TOUCHFILE" ] && [ ! -s "$DROPFILE" ]; then
    reject "no change requested. Pass at least one of --state, --request, --note, --add-touch, --drop-key."
  fi
fi

# ── BATCH CONTEXT IMPORT — same schema, history, backup, race, and atomicity guarantees ─────
if [ -n "$BATCH_MAP" ]; then
  RA_LEDGER="$LEDGER" RA_SIDECAR="$SIDECAR" RA_BATCH_MAP="$BATCH_MAP" \
  RA_WHY="$WHY" RA_DRYRUN="$DRYRUN" RA_CHECK_TOOL="$CHECK" \
  python3 - <<'PYEOF'
import datetime
import json
import os
import re
import subprocess
import sys
import tempfile

E = os.environ
ledger = E["RA_LEDGER"]
sidecar = E["RA_SIDECAR"]
dry = E["RA_DRYRUN"] == "1"

def refuse(message):
    sys.stderr.write("REFUSED — %s\n" % message)
    sys.exit(1)

def cannot(message):
    sys.stderr.write("request-amend: %s\n" % message)
    sys.exit(2)

def reject_duplicate_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            refuse("batch context map repeats key %s. Nothing was written." % key)
        result[key] = value
    return result

try:
    with open(E["RA_BATCH_MAP"], encoding="utf-8") as handle:
        url_map = json.load(handle, object_pairs_hook=reject_duplicate_pairs)
except SystemExit:
    raise
except Exception as exc:
    refuse("batch context map is not valid JSON: %s. Nothing was written." % exc)

if not isinstance(url_map, dict) or not url_map:
    refuse("batch context map must be a non-empty JSON object. Nothing was written.")

issue_url = re.compile(r"https://github[.]com/[^/]+/[^/]+/issues/[1-9][0-9]*")
for rid, url in url_map.items():
    if not isinstance(rid, str) or re.fullmatch(r"REQ-[0-9]+", rid) is None:
        refuse("batch context map has invalid request id %r. Nothing was written." % rid)
    if not isinstance(url, str) or issue_url.fullmatch(url) is None:
        refuse("batch context map has invalid GitHub issue URL for %s. Nothing was written." % rid)

with open(ledger, "rb") as handle:
    original_bytes = handle.read()
lines = original_bytes.splitlines(keepends=True)
rows = {}
for line_index, raw in enumerate(lines):
    stripped = raw.strip()
    if not stripped:
        continue
    try:
        row = json.loads(stripped.decode("utf-8"))
    except Exception:
        continue
    if not isinstance(row, dict) or not isinstance(row.get("id"), str):
        continue
    rid = row["id"]
    if rid in rows:
        refuse("id %s appears more than once in %s. Nothing was written." % (rid, ledger))
    rows[rid] = (line_index, raw, row)

missing = sorted(set(url_map) - set(rows))
if missing:
    refuse("batch context map names absent ledger rows: %s. Nothing was written."
           % ", ".join(missing))

order = ["id", "ts", "request", "state", "touches", "note"]
new_lines = list(lines)
records = []
changed_ids = []
at = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
for rid in sorted(url_map, key=lambda value: int(value.split("-")[1])):
    line_index, before_raw, row = rows[rid]
    url = url_map[rid]
    touches = row.get("touches")
    if not isinstance(touches, list):
        refuse("%s has a non-array touches field. Nothing was written." % rid)
    if any(isinstance(touch, dict) and touch.get("type") == "context"
           and touch.get("text") == url for touch in touches):
        continue
    new_row = dict(row)
    new_row["touches"] = touches + [{"type": "context", "text": url}]
    ordered = {key: new_row[key] for key in order if key in new_row}
    for key in new_row:
        if key not in ordered:
            ordered[key] = new_row[key]
    after_text = json.dumps(ordered, ensure_ascii=False)
    before_text = before_raw.decode("utf-8").rstrip("\n").rstrip("\r")
    suffix = b"\n" if before_raw.endswith(b"\n") else b""
    new_lines[line_index] = after_text.encode("utf-8") + suffix
    changed_ids.append(rid)
    records.append({
        "at": at,
        "id": rid,
        "line": line_index + 1,
        "changed": ["added touch context"],
        "why": E["RA_WHY"],
        "reopened": False,
        "before": before_text,
        "after": after_text,
    })

if not changed_ids:
    print("OK — every batch context URL is already present; nothing was written.")
    sys.exit(0)

new_content = b"".join(new_lines)
with tempfile.TemporaryDirectory(prefix="request-amend-batch-") as temp_dir:
    candidate = os.path.join(temp_dir, "candidate.jsonl")
    with open(candidate, "wb") as handle:
        handle.write(new_content)
    result = subprocess.run(
        ["sh", E["RA_CHECK_TOOL"], candidate],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        body = (result.stdout or "") + (result.stderr or "")
        sys.stderr.write(
            "REFUSED — the batch-amended ledger does not conform to the request-ledger contract:\n"
        )
        for line in body.splitlines():
            sys.stderr.write("  %s\n" % line)
        sys.stderr.write("  nothing was written to %s\n" % ledger)
        sys.exit(1)

if dry:
    print("OK (dry run) — %d context touches are valid and were NOT written:" % len(changed_ids))
    print("  rows: %s" % ", ".join(changed_ids))
    sys.exit(0)

stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup = "%s.pre-amend-batch-context-%s" % (ledger, stamp)
if os.path.exists(backup):
    backup += "-%d" % os.getpid()
with open(backup, "wb") as handle:
    handle.write(original_bytes)

with open(sidecar, "a", encoding="utf-8") as handle:
    for record in records:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")

with open(ledger, "rb") as handle:
    now_bytes = handle.read()
if now_bytes != original_bytes:
    refuse("the ledger changed while this batch amendment was being prepared. Nothing was "
           "written to it; re-run. The sidecar records describe an attempt that did not land, "
           "and the backup at %s matches the pre-attempt file." % backup)

fd, temporary_path = tempfile.mkstemp(
    dir=os.path.dirname(os.path.abspath(ledger)) or ".",
    prefix=".request-amend-batch-",
)
try:
    with os.fdopen(fd, "wb") as handle:
        handle.write(new_content)
    os.replace(temporary_path, ledger)
except Exception as exc:
    try:
        os.unlink(temporary_path)
    except Exception:
        pass
    cannot("replace failed: %s. The ledger is unchanged; backup: %s" % (exc, backup))

print("batch-amended %d rows in %s" % (len(changed_ids), ledger))
print("  rows: %s" % ", ".join(changed_ids))
print("  history: appended %d records to %s" % (len(records), sidecar))
print()
print("to reverse the whole batch:")
print("  cp '%s' '%s'" % (backup, ledger))
PYEOF
  rc=$?
  rm -f "$TOUCHFILE" "$DROPFILE"
  exit $rc
fi

# ── STATE TRANSITION GATE — asked of the shared predicate, never answered here ────────────────
# The current state is read out of the row below; the new state's standing is asked first so an
# undeclared state is refused with the vocabulary's own words before anything is constructed.
if [ -n "$NEW_STATE" ]; then
  sh "$STATES" --is-terminal "$NEW_STATE" >/dev/null 2>&1
  case $? in
    0|1) : ;;  # declared (terminal or not) — fine either way at this point
    *) reject "state '$NEW_STATE' is not declared in the contract's state vocabulary. Declared: $(sh "$STATES" --all 2>/dev/null | cut -f1 | tr '\n' ' ')" ;;
  esac
fi

# ── LOCATE, CONSTRUCT, VALIDATE, RECORD, REPLACE — one python process, smallest possible race ─
# Everything from reading the ledger to os.replace happens in one process. Immediately before
# the replace, the file is re-read and compared byte-for-byte to what was read at the start;
# if another writer appended in between, this aborts rather than silently discarding their row.
RA_OUT="$(mktemp -d)" || die "mktemp failed"

RA_LEDGER="$LEDGER" RA_SIDECAR="$SIDECAR" RA_ID="$ID" RA_STATE="$NEW_STATE" \
RA_REQUEST="$NEW_REQUEST" RA_NOTE="$NEW_NOTE" RA_HAVE_NOTE="$HAVE_NOTE" \
RA_TOUCHES="$TOUCHFILE" RA_DROPS="$DROPFILE" RA_WHY="$WHY" RA_REOPEN="$REOPEN" \
RA_DRYRUN="$DRYRUN" RA_STATES_TOOL="$STATES" RA_CHECK_TOOL="$CHECK" RA_TMP="$RA_OUT" \
python3 - <<'PYEOF'
import datetime, json, os, subprocess, sys, tempfile

E = os.environ
ledger, sidecar, rid = E["RA_LEDGER"], E["RA_SIDECAR"], E["RA_ID"]
dry = E["RA_DRYRUN"] == "1"

def refuse(msg):
    sys.stderr.write("REFUSED — %s\n" % msg)
    sys.exit(1)

def cannot(msg):
    sys.stderr.write("request-amend: %s\n" % msg)
    sys.exit(2)

# Read once, in binary, keeping every byte of every line we are not amending.
with open(ledger, "rb") as fh:
    original_bytes = fh.read()
lines = original_bytes.splitlines(keepends=True)

hits = []
for i, raw in enumerate(lines):
    s = raw.strip()
    if not s:
        continue
    try:
        row = json.loads(s.decode("utf-8"))
    except Exception:
        continue
    if isinstance(row, dict) and row.get("id") == rid:
        hits.append((i, raw, row))

if not hits:
    refuse("no row with id %s in %s. Nothing was written." % (rid, ledger))
if len(hits) > 1:
    refuse("id %s appears on %d lines of %s (lines %s). The target is ambiguous; fix the "
           "duplicate first (that is itself an amendment — amend one of them under a fresh "
           "understanding of which is real). Nothing was written."
           % (rid, len(hits), ledger, ", ".join(str(i + 1) for i, _, _ in hits)))

line_idx, before_raw, row = hits[0]
before_text = before_raw.decode("utf-8").rstrip("\n").rstrip("\r")
old_state = row.get("state")

# ── the transition, judged by the shared predicate ────────────────────────────────────────────
def is_terminal(state):
    """0 terminal, 1 non-terminal, None undeclared/unusable — straight from request-states.sh."""
    if not isinstance(state, str) or not state:
        return None
    r = subprocess.run(["sh", E["RA_STATES_TOOL"], "--is-terminal", state],
                       capture_output=True)
    return {0: True, 1: False}.get(r.returncode)

new_state = E["RA_STATE"]
if new_state:
    old_term, new_term = is_terminal(old_state), is_terminal(new_state)
    if new_term is None:
        refuse("state '%s' is not declared in the contract. Nothing was written." % new_state)
    if old_term is True and new_term is False and E["RA_REOPEN"] != "1":
        refuse("row %s is in terminal state '%s' — Jo closed it. Reopening it is not an "
               "ordinary amendment: the contract says of dropped rows 'Never re-raise or "
               "re-litigate it', and the restore hook's own rule is that re-raising closed "
               "business means a NEW row (request-append.sh). If the CLOSURE ITSELF was the "
               "mistake being corrected, say so explicitly with --reopen and it will be "
               "allowed and recorded. Nothing was written." % (rid, old_state))

# ── construct the amended row, canonical key order, nothing invented ──────────────────────────
changed = []
new_row = dict(row)

for key in [l for l in open(E["RA_DROPS"], encoding="utf-8").read().splitlines() if l]:
    if key in ("id", "ts", "request", "state", "touches", "note"):
        refuse("--drop-key %s: declared keys cannot be dropped, only undeclared ones. "
               "Nothing was written." % key)
    if key not in new_row:
        refuse("--drop-key %s: the row carries no such key. Nothing was written." % key)
    del new_row[key]
    changed.append("dropped %s" % key)

if E["RA_REQUEST"]:
    new_row["request"] = E["RA_REQUEST"]; changed.append("request")
if new_state:
    new_row["state"] = new_state; changed.append("state %s -> %s" % (old_state, new_state))
if E["RA_HAVE_NOTE"] == "1":
    new_row["note"] = E["RA_NOTE"]; changed.append("note")

touches = new_row.get("touches") if isinstance(new_row.get("touches"), list) else []
for line in open(E["RA_TOUCHES"], encoding="utf-8"):
    line = line.rstrip("\n")
    if not line:
        continue
    typ, _, text = line.partition("=")
    touches = touches + [{"type": typ, "text": text}]
    changed.append("added touch %s" % typ)
if touches != row.get("touches"):
    new_row["touches"] = touches

order = ["id", "ts", "request", "state", "touches", "note"]
ordered = {k: new_row[k] for k in order if k in new_row}
for k in new_row:
    if k not in ordered:
        ordered[k] = new_row[k]
after_text = json.dumps(ordered, ensure_ascii=False)

# Content comparison, not text comparison: serialization spacing differs between historical
# hand-written rows and json.dumps, so a byte compare would let a semantic no-op through
# (or a pure re-format masquerade as a change). Parsed equality is the honest test.
if ordered == row:
    refuse("the amended row is identical in content to what line %d already says. Nothing to "
           "do, nothing was written." % (line_idx + 1))

# ── validate the amended row ALONE through the shared checker ─────────────────────────────────
cand = os.path.join(E["RA_TMP"], "candidate.jsonl")
with open(cand, "w", encoding="utf-8") as fh:
    fh.write(after_text + "\n")
r = subprocess.run(["sh", E["RA_CHECK_TOOL"], cand], capture_output=True, text=True)
if r.returncode != 0:
    sys.stderr.write("REFUSED — the amended row does not conform to the request-ledger contract:\n")
    body = (r.stdout or "") + (r.stderr or "")
    tail = body[body.index("FAIL"):] if "FAIL" in body else body
    for l in tail.splitlines():
        sys.stderr.write("  %s\n" % l)
    if "unknown key" in body:
        sys.stderr.write("  (an undeclared key already on the row can be removed with "
                         "--drop-key KEY; its value stays in the sidecar's before record)\n")
    sys.stderr.write("  nothing was written to %s\n" % ledger)
    sys.exit(1)

record = {
    "at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "id": rid,
    "line": line_idx + 1,
    "changed": changed,
    "why": E["RA_WHY"],
    "reopened": bool(new_state) and is_terminal(old_state) is True and is_terminal(new_state) is False,
    "before": before_text,
    "after": after_text,
}

if dry:
    print("OK (dry run) — this amendment is valid and was NOT written:")
    print("  row %s, line %d of %s" % (rid, line_idx + 1, ledger))
    print("  changed: %s" % "; ".join(changed))
    print("  before: %s" % before_text)
    print("  after:  %s" % after_text)
    sys.exit(0)

# ── backup, history, replace — in that order, so no mutation can outrun its trace ─────────────
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup = "%s.pre-amend-%s-%s" % (ledger, rid, stamp)
if os.path.exists(backup):
    backup += "-%d" % os.getpid()
with open(backup, "wb") as fh:
    fh.write(original_bytes)

with open(sidecar, "a", encoding="utf-8") as fh:
    fh.write(json.dumps(record, ensure_ascii=False) + "\n")

new_lines = list(lines)
new_lines[line_idx] = (after_text + "\n").encode("utf-8")
new_content = b"".join(new_lines)

# The race check: if any other writer touched the ledger since our read, stand down.
with open(ledger, "rb") as fh:
    now_bytes = fh.read()
if now_bytes != original_bytes:
    refuse("the ledger changed while this amendment was being prepared (another writer is "
           "active). Nothing was written to it; re-run. The sidecar's last record describes "
           "this attempt and no applied change — the backup at %s matches the pre-attempt "
           "file." % backup)

fd, tmppath = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(ledger)) or ".",
                               prefix=".request-amend-")
try:
    with os.fdopen(fd, "wb") as fh:
        fh.write(new_content)
    os.replace(tmppath, ledger)
except Exception as exc:
    try: os.unlink(tmppath)
    except Exception: pass
    cannot("replace failed: %s. The ledger is UNCHANGED (os.replace is atomic); the sidecar's "
           "last record describes an attempt that did not land. Backup: %s" % (exc, backup))

print("amended %s (line %d) in %s" % (rid, line_idx + 1, ledger))
print("  changed: %s" % "; ".join(changed))
print("  before: %s" % before_text)
print("  after:  %s" % after_text)
print("  history: appended to %s" % sidecar)
print()
print("to reverse, either of:")
print("  cp '%s' '%s'      # whole-file restore to the pre-amend state" % (backup, ledger))
print("  %s --id %s ...                              # amend it back; the sidecar holds the 'before' row verbatim" % (os.path.abspath(sys.argv[0] if sys.argv[0] != '-' else 'request-amend.sh'), rid))
sys.exit(0)
PYEOF
rc=$?
rm -rf "$RA_OUT" "$TOUCHFILE" "$DROPFILE"
exit $rc
fi


mkbatchfix() {
  printf '%s\n' \
    '{"id":"REQ-001","ts":"2026-05-30T10:00:00Z","request":"First","state":"open","touches":[],"note":""}' \
    '{"id":"REQ-005","ts":"2026-05-30T10:20:00Z","request":"Fifth","state":"blocked","touches":[],"note":""}' \
    >"$1"
}
# ══ --selftest ═══════════════════════════════════════════════════════════════════════════════
# Both poles, per the house rule: a valid amendment must land, a malformed one must be refused
# by the SHARED checker, and every refusal must leave the fixture byte-identical. Fixtures live
# in a fresh mktemp -d; the real ledger is never named anywhere below.
d="$(mktemp -d)" || exit 2
echo "selftest: fixtures in $d (throwaway; the real ledger is never touched)"
SELF="$0"
FAILED=0
say_fail() { echo "SELFTEST FAILED: $*" >&2; FAILED=1; }

mkfix() {
  # 5 rows: open / delivered / dropped / one with the historical `ask` defect / unicode+quotes.
  # The last line deliberately has NO trailing newline.
  printf '%s\n' \
    '{"id":"REQ-001","ts":"2026-08-20T10:00:00Z","request":"an open thing","state":"open","touches":[{"type":"original","text":"do it"}],"note":""}' \
    '{"id":"REQ-002","ts":"2026-08-20T11:00:00Z","request":"a finished thing","state":"delivered","touches":[],"note":"done"}' \
    '{"id":"REQ-003","ts":"2026-08-20T12:00:00Z","request":"a called-off thing","state":"dropped","touches":[],"note":"Do not re-raise"}' > "$1"
  printf '%s\n' '{"id":"REQ-004","ts":"2026-08-20T13:00:00Z","ask":"text under the wrong key","state":"open","touches":[],"note":""}' >> "$1"
  printf '%s' '{"id":"REQ-005","ts":"2026-08-20T14:00:00Z","request":"unicode über \"quoted\" \\ backslash","state":"open","touches":[],"note":"café"}' >> "$1"
}

F="$d/fix.jsonl"; SC="$d/fix.jsonl.amendments"

# 1. THE POLE THAT MUST SUCCEED: close an open obligation, the primary operation.
mkfix "$F"
if sh "$SELF" --id REQ-001 --state delivered --note "landed in run 7" \
     --why "selftest: the closing transition" --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e1"; then
  got=$(python3 -c 'import json;print(json.loads([l for l in open("'"$F"'") if "REQ-001" in l][0])["state"])')
  [ "$got" = "delivered" ] || say_fail "close transition wrote state '$got', wanted delivered"
  grep -q '"REQ-005"' "$F" || say_fail "close transition lost the final (no-newline) row"
  [ "$(tail -c 1 "$F" | od -An -c | tr -d ' \n')" != '\n' ] || say_fail "close transition ADDED a trailing newline to the untouched last row"
  [ -f "$SC" ] && python3 -c '
import json,sys
r=json.loads(open("'"$SC"'").readline())
assert r["id"]=="REQ-001" and "before" in r and "after" in r and r["reopened"] is False, r
assert "state open -> delivered" in " ".join(r["changed"]), r["changed"]
' || say_fail "sidecar record missing or malformed after the close transition"
  ls "$F".pre-amend-REQ-001-* >/dev/null 2>&1 || say_fail "no backup file was made before the write"
else
  say_fail "the valid closing transition (open -> delivered) was refused: $(cat "$d/e1")"
fi

# 2. Reversal really reverses: whole-file restore from the backup matches the pre-amend bytes.
mkfix "$F"; rm -f "$SC" "$F".pre-amend-* ; sha0=$(shasum -a 256 "$F" | cut -d' ' -f1)
sh "$SELF" --id REQ-001 --state delivered --ledger "$F" --sidecar "$SC" >/dev/null 2>&1
cp "$F".pre-amend-REQ-001-* "$F" 2>/dev/null
sha1=$(shasum -a 256 "$F" | cut -d' ' -f1)
[ "$sha0" = "$sha1" ] || say_fail "restoring the printed backup did not reproduce the original file"

# Refusal cases. Each must exit non-zero AND leave the fixture byte-identical.
refused() { # name, expected-grep, args...
  name="$1"; want="$2"; shift 2
  mkfix "$F"; rm -f "$SC" "$F".pre-amend-*
  b=$(shasum -a 256 "$F" | cut -d' ' -f1)
  if sh "$SELF" "$@" --ledger "$F" --sidecar "$SC" >"$d/o" 2>"$d/e"; then
    say_fail "'$name' was ACCEPTED and should have been refused"
  else
    grep -qi "$want" "$d/e" "$d/o" || say_fail "'$name' was refused but not for the stated reason (wanted /$want/): $(cat "$d/e")"
  fi
  a=$(shasum -a 256 "$F" | cut -d' ' -f1)
  [ "$b" = "$a" ] || say_fail "'$name' modified the ledger despite refusing"
  echo "  refused $name"
}

refused "nonexistent id"                 "no row with id"      --id REQ-999 --state delivered
refused "undeclared state"               "not declared"        --id REQ-001 --state kumquat
refused "terminal->open without --reopen" "reopen"             --id REQ-002 --state open
refused "terminal->open of a dropped row" "reopen"             --id REQ-003 --state open
refused "no change requested"            "no change"           --id REQ-001
refused "no-op amendment"                 "identical"          --id REQ-001 --state open
refused "undeclared touch type"          "contract"            --id REQ-001 --add-touch kumquat=hi
refused "empty request text"             "contract\|empty"     --id REQ-001 --request " "
refused "dropping a declared key"        "declared keys"       --id REQ-001 --drop-key note
refused "dropping an absent key"         "no such key"         --id REQ-001 --drop-key priority

# closing a row that is already closed, to the SAME state, is a no-op and refused as one
refused "re-closing an already-delivered row" "identical"      --id REQ-002 --state delivered

# 3. duplicate id in the ledger -> ambiguous target, refused
mkfix "$F"; rm -f "$SC"
# the fixture's last line has no trailing newline by design, so the duplicate needs its own line
printf '\n%s\n' '{"id":"REQ-001","ts":"2026-08-21T10:00:00Z","request":"a duplicate","state":"open","touches":[],"note":""}' >> "$F"
b=$(shasum -a 256 "$F" | cut -d' ' -f1)
if sh "$SELF" --id REQ-001 --state delivered --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e"; then
  say_fail "duplicate-id ledger: the ambiguous amendment was ACCEPTED"
else
  grep -q "ambiguous" "$d/e" || say_fail "duplicate-id refusal did not say ambiguous"
fi
[ "$b" = "$(shasum -a 256 "$F" | cut -d' ' -f1)" ] || say_fail "duplicate-id refusal modified the ledger"
echo "  refused duplicate id (ambiguous target)"

# 4. empty ledger -> refused, no row
: > "$F"; rm -f "$SC"
sh "$SELF" --id REQ-001 --state delivered --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e" \
  && say_fail "empty ledger: accepted an amendment against nothing" \
  || { grep -q "no row" "$d/e" || say_fail "empty-ledger refusal did not say 'no row'"; echo "  refused empty ledger"; }

# 5. --reopen allows the deliberate reopen, and records it
mkfix "$F"; rm -f "$SC" "$F".pre-amend-*
if sh "$SELF" --id REQ-002 --state open --reopen --why "closed in error" \
     --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e"; then
  python3 -c '
import json
r=json.loads(open("'"$SC"'").readline())
assert r["reopened"] is True and r["why"]=="closed in error", r
' || say_fail "--reopen landed but the sidecar did not record reopened=true with the reason"
  echo "  allowed --reopen, recorded reopened=true"
else
  say_fail "--reopen was refused: $(cat "$d/e")"
fi

# 6. terminal -> terminal correction needs no flag
mkfix "$F"; rm -f "$SC" "$F".pre-amend-*
sh "$SELF" --id REQ-003 --state delivered --why "was actually done" --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e" \
  || say_fail "terminal->terminal correction (dropped -> delivered) was refused: $(cat "$d/e")"
echo "  allowed terminal->terminal correction without --reopen"

# 7. fixing the historical wrong-key defect: --request plus --drop-key ask
mkfix "$F"; rm -f "$SC" "$F".pre-amend-*
if sh "$SELF" --id REQ-004 --request "text under the RIGHT key" --drop-key ask \
     --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e"; then
  python3 -c '
import json
row=[json.loads(l) for l in open("'"$F"'") if l.strip()][3]
assert row.get("request")=="text under the RIGHT key" and "ask" not in row, row
r=json.loads(open("'"$SC"'").readline())
assert "wrong key" in r["before"], r["before"]  # the dropped value survives in history
' || say_fail "wrong-key repair did not produce the right row, or history lost the dropped value"
  echo "  repaired the wrong-key (ask) defect row, history kept the dropped value"
else
  say_fail "wrong-key repair was refused: $(cat "$d/e")"
fi
# ...and WITHOUT --drop-key the same repair is refused by the shared checker (unknown key)
refused "wrong-key repair without --drop-key" "unknown key\|contract" --id REQ-004 --request "right key"

# 8. awkward content round-trips: unicode, embedded quotes, a very long note
mkfix "$F"; rm -f "$SC" "$F".pre-amend-*
LONG=$(python3 -c 'print("n"*8000 + " — ünïcode \"quoted\" $(not expanded) `backticks` end")')
if sh "$SELF" --id REQ-005 --note "$LONG" --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e"; then
  python3 -c '
import json
rows=[json.loads(l) for l in open("'"$F"'") if l.strip()]
row=[r for r in rows if r["id"]=="REQ-005"][0]
n=row["note"]
assert len(n)>8000 and n.endswith("end") and "ünïcode" in n and "\"quoted\"" in n and "$(not expanded)" in n, n[:80]
assert row["request"].startswith("unicode über"), row["request"]
' || say_fail "long/unicode/quoted note did not round-trip intact"
  echo "  round-tripped an 8000-char note with unicode, quotes, backticks, and \$() intact"
else
  say_fail "long/unicode note amendment was refused: $(cat "$d/e")"
fi

# 9. untouched lines are byte-identical after an amendment (whole-file diff minus the one line)
mkfix "$F"; rm -f "$SC" "$F".pre-amend-*
cp "$F" "$d/before-copy"
sh "$SELF" --id REQ-001 --note "changed" --ledger "$F" --sidecar "$SC" >/dev/null 2>&1
python3 -c '
b=open("'"$d"'/before-copy","rb").read().splitlines(keepends=True)
a=open("'"$F"'","rb").read().splitlines(keepends=True)
assert len(a)==len(b), (len(a), len(b))
diff=[i for i in range(len(a)) if a[i]!=b[i]]
assert diff==[0], diff  # only line 1 (REQ-001) changed
' || say_fail "an amendment changed bytes on lines other than the target"
echo "  every untouched line is byte-identical after an amendment"

# 10. dry-run writes nothing at all — no ledger change, no sidecar, no backup
mkfix "$F"; rm -f "$SC" "$F".pre-amend-*
b=$(shasum -a 256 "$F" | cut -d' ' -f1)
sh "$SELF" --id REQ-001 --state delivered --dry-run --ledger "$F" --sidecar "$SC" >"$d/o" 2>&1 \
  || say_fail "dry-run of a valid amendment did not exit 0"
grep -q "NOT written" "$d/o" || say_fail "dry-run output does not say it wrote nothing"
[ "$b" = "$(shasum -a 256 "$F" | cut -d' ' -f1)" ] || say_fail "dry-run modified the ledger"
[ ! -e "$SC" ] || say_fail "dry-run wrote the sidecar"
ls "$F".pre-amend-* >/dev/null 2>&1 && say_fail "dry-run made a backup file"
echo "  dry-run validated and wrote nothing (no ledger change, no sidecar, no backup)"


# 11. Batch context import lands atomically, is idempotent, and rejects malformed URLs.
mkbatchfix "$F"
cat >"$d/map.json" <<'EOF'
{"REQ-001":"https://github.com/thewolff/lintel-tasks/issues/9001","REQ-005":"https://github.com/thewolff/lintel-tasks/issues/9005"}
EOF
if sh "$SELF" --batch-context-map "$d/map.json" --why "selftest: issue URL import" \
     --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e"; then
  python3 -c '
import json
rows={r["id"]:r for r in map(json.loads, open("'"$F"'"))}
for rid, number in [("REQ-001", 9001), ("REQ-005", 9005)]:
    want="https://github.com/thewolff/lintel-tasks/issues/%d" % number
    assert {"type":"context","text":want} in rows[rid]["touches"], rows[rid]
records=[json.loads(line) for line in open("'"$SC"'") if line.strip()]
assert [r["id"] for r in records] == ["REQ-001", "REQ-005"], records
' || say_fail "batch context import did not add both URLs or sidecar records"
  backups=$(printf '%s\n' "$F".pre-amend-batch-context-* | wc -l | tr -d ' ')
  [ "$backups" = "1" ] || say_fail "batch context import made $backups backups, wanted exactly one"
  sum_before=$(shasum -a 256 "$F" | cut -d' ' -f1)
  history_before=$(wc -l <"$SC" | tr -d ' ')
  sh "$SELF" --batch-context-map "$d/map.json" --why "selftest: idempotence" \
    --ledger "$F" --sidecar "$SC" >/dev/null 2>"$d/e" \
    || say_fail "idempotent batch rerun exited nonzero: $(cat "$d/e")"
  [ "$sum_before" = "$(shasum -a 256 "$F" | cut -d' ' -f1)" ] \
    || say_fail "idempotent batch rerun changed the ledger"
  [ "$history_before" = "$(wc -l <"$SC" | tr -d ' ')" ] \
    || say_fail "idempotent batch rerun appended history"
  echo "  batch context import landed once and the second run was byte-idempotent"
else
  say_fail "valid batch context import was refused: $(cat "$d/e")"
fi

mkbatchfix "$F"
printf '%s\n' '{"REQ-001":"https://example.invalid/issues/1"}' >"$d/bad-map.json"
b=$(shasum -a 256 "$F" | cut -d' ' -f1)
if sh "$SELF" --batch-context-map "$d/bad-map.json" \
     --ledger "$F" --sidecar "$SC" >"$d/o" 2>"$d/e"; then
  say_fail "batch import accepted a non-GitHub issue URL"
else
  grep -qi "valid GitHub issue URL" "$d/e" "$d/o" \
    || say_fail "malformed batch URL refusal did not name the invalid URL"
fi
[ "$b" = "$(shasum -a 256 "$F" | cut -d' ' -f1)" ] \
  || say_fail "malformed batch URL refusal modified the ledger"
echo "  refused malformed batch context URL without writing"
if [ "$FAILED" -ne 0 ]; then
  echo "SELFTEST FAILED — see above. Fixtures kept at $d for inspection." >&2
  exit 1
fi
echo "selftest: OK — the closing transition lands, every refusal class refuses, refusals never write."
exit 0

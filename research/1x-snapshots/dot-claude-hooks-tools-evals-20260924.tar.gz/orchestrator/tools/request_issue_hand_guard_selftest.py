#!/usr/bin/env python3
"""Targeted contract tests for disposable-hand GitHub issue reconciliation guards."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HOOK = ROOT / "orchestrator/hooks/request-issue-hand-guard.mjs"
CORE = ROOT / "orchestrator/tools/request_issues_reconcile.py"
WRAPPER = ROOT / "orchestrator/tools/request-issues-reconcile.sh"


def request(
    request_id: str,
    *,
    state: str = "open",
    touches: list[dict[str, str]] | None = None,
) -> dict[str, object]:
    return {
        "id": request_id,
        "request": "Keep Lintel machinery reconciled",
        "state": state,
        "note": "Test fixture for the disposable-hand guard.",
        "acceptance": ["The fixture is reconciled."],
        "touches": touches or [],
        "updated_at": "2026-09-18T00:00:00Z",
    }


class RequestIssueHandGuardTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.state = Path(self.temp.name)
        self.ledger = self.state / "REQUESTS.jsonl"
        self.session_id = "session-test"
        (self.state / ".session-id").write_text(self.session_id + "\n", encoding="utf-8")
        self.env = os.environ | {
            "LINTEL_STATE": str(self.state),
            "REQUEST_ISSUE_LEDGER": str(self.ledger),
            "REQUEST_ISSUE_CORE": str(CORE),
            "REQUEST_ISSUE_REPO": "thewolff/lintel-tasks",
        }

    def tearDown(self) -> None:
        self.temp.cleanup()

    def invoke(self, payload: dict[str, object]) -> dict[str, object] | None:
        completed = subprocess.run(
            ["node", str(HOOK)],
            input=json.dumps(payload),
            text=True,
            capture_output=True,
            env=self.env,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        return json.loads(completed.stdout) if completed.stdout.strip() else None

    def pretool(self, command: str, *, agent_id: str | None = None) -> dict[str, object] | None:
        payload: dict[str, object] = {
            "hook_event_name": "PreToolUse",
            "tool_name": "Bash",
            "tool_input": {"command": command},
            "session_id": self.session_id,
            "agent_type": "orchestrator",
        }
        if agent_id is not None:
            payload["agent_id"] = agent_id
        return self.invoke(payload)

    def stop(self, *, session_id: str | None = None) -> dict[str, object] | None:
        return self.invoke(
            {
                "hook_event_name": "Stop",
                "session_id": session_id or self.session_id,
                "agent_type": "orchestrator",
                "stop_hook_active": False,
            }
        )

    def test_top_level_wrapper_reconciliation_is_denied(self) -> None:
        result = self.pretool(f"sh {WRAPPER} --apply")
        self.assertEqual(result["hookSpecificOutput"]["permissionDecision"], "deny")

    def test_top_level_direct_core_reconciliation_is_denied(self) -> None:
        result = self.pretool(f"python3 {CORE} --ledger {self.ledger}")
        self.assertEqual(result["hookSpecificOutput"]["permissionDecision"], "deny")

    def test_disposable_hand_reconciliation_is_allowed(self) -> None:
        self.assertIsNone(self.pretool(f"sh {WRAPPER} --apply", agent_id="hand-123"))

    def test_offline_pending_probe_is_allowed_inline(self) -> None:
        self.assertIsNone(self.pretool(f"python3 {CORE} --ledger {self.ledger} --pending-hand"))

    def test_stop_blocks_when_applicable_request_lacks_issue_touch(self) -> None:
        self.ledger.write_text(json.dumps(request("REQ-001")) + "\n", encoding="utf-8")
        result = self.stop()
        self.assertEqual(result["decision"], "block")
        self.assertIn("REQ-001", result["reason"])
        self.assertIn("disposable", result["reason"].lower())

    def test_stop_allows_when_applicable_request_has_exact_issue_touch(self) -> None:
        row = request(
            "REQ-001",
            touches=[{"type": "context", "text": "https://github.com/thewolff/lintel-tasks/issues/123"}],
        )
        self.ledger.write_text(json.dumps(row) + "\n", encoding="utf-8")
        self.assertIsNone(self.stop())

    def test_stop_ignores_foreign_session(self) -> None:
        self.ledger.write_text(json.dumps(request("REQ-001")) + "\n", encoding="utf-8")
        self.assertIsNone(self.stop(session_id="foreign-session"))


if __name__ == "__main__":
    unittest.main()

#!/bin/sh
# request-append.sh — the way a row gets into state/REQUESTS.jsonl.
#
# WHY THIS FILE EXISTS. Rows used to be appended by hand, a shell heredoc writing raw JSON straight
# into the ledger. On 2026-08-20 fifteen of them went in with the request text under the key `ask`
# instead of `request`; both hooks that surface open obligations read `request`, so those rows were
# counted, listed by id, and blank. Nothing failed, because the wrong key still parses. Hand-writing
# JSON into a file nothing validates is the defect. This takes the fields as arguments, constructs
# the JSON itself, and refuses to write a row that would not survive the checker.
#
# IT DOES NOT CARRY ITS OWN COPY OF THE RULES. The candidate row is validated by running
# tools/requests-schema-check.sh against it, which is the same code path that validates the whole
# file, reading the same request-ledger contract. A second, differently-shaped validator here would be a
# second schema that drifts, which is the class of defect being closed. If the writer accepts a row
# the checker would reject, that is a bug in one shared implementation, not a disagreement.
#
# A successful non-terminal append emits a DISPOSABLE_HAND_REQUIRED receipt naming the bounded
# reconciliation command. The caller dispatches the command to a disposable hand; this writer
# never inventories or mutates GitHub inline. The optional request-issue hand guard is built but
# inactive and is not registered in global settings, so this receipt records the required route
# rather than claiming live PreToolUse or Stop enforcement.
#
# Usage:
#   request-append.sh --request TEXT --state STATE [--note TEXT] [--id REQ-NNN] [--ts STAMP]
#                     [--touch TYPE=TEXT ...] [--ledger PATH] [--dry-run]
#
#   --id      omitted: the next unused REQ-NNN, derived from the ledger.
#   --ts      omitted: now, in UTC, ISO 8601 with a trailing Z.
#   --note    omitted: empty string. The key is always written; the contract requires it present.
#   --touch   repeatable. TYPE must be a declared touch type, TEXT must be non-empty and should
#             quote what Jo actually said. Zero touches is legal.
#   --dry-run validate and print the row, write nothing.
#
# Exit codes: 0 row appended (or validated, under --dry-run) | 1 the row was rejected | 2 could not
# run at all.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
CHECK="$ORCH/tools/requests-schema-check.sh"
LEDGER="$ORCH/state/REQUESTS.jsonl"
STATES="$ORCH/tools/request-states.sh"

ID=""; TS=""; REQUEST=""; STATE=""; NOTE=""; DRYRUN=0
TOUCHFILE="$(mktemp)" || { echo "request-append: mktemp failed" >&2; exit 2; }

die() { echo "request-append: $*" >&2; exit 2; }
reject() { echo "REJECTED — $*" >&2; exit 1; }

while [ "$#" -gt 0 ]; do
  case "$1" in
    --id)      [ "$#" -ge 2 ] || die "--id needs a value";      ID="$2"; shift 2 ;;
    --ts)      [ "$#" -ge 2 ] || die "--ts needs a value";      TS="$2"; shift 2 ;;
    --request) [ "$#" -ge 2 ] || die "--request needs a value"; REQUEST="$2"; shift 2 ;;
    --state)   [ "$#" -ge 2 ] || die "--state needs a value";   STATE="$2"; shift 2 ;;
    --note)    [ "$#" -ge 2 ] || die "--note needs a value";    NOTE="$2"; shift 2 ;;
    --ledger)  [ "$#" -ge 2 ] || die "--ledger needs a value";  LEDGER="$2"; shift 2 ;;
    --touch)
      [ "$#" -ge 2 ] || die "--touch needs TYPE=TEXT"
      case "$2" in *=*) ;; *) reject "--touch must be TYPE=TEXT, got '$2'" ;; esac
      printf '%s\n' "$2" >> "$TOUCHFILE"; shift 2 ;;
    --dry-run) DRYRUN=1; shift ;;
    -h|--help) sed -n '1,40p' "$0"; exit 0 ;;
    *) die "unknown argument '$1'" ;;
  esac
done

command -v python3 >/dev/null || die "python3 not found"
[ -x "$CHECK" ] || [ -f "$CHECK" ] || die "checker missing at $CHECK"
[ -f "$STATES" ] || die "state predicate missing at $STATES"
[ -f "$LEDGER" ] || die "no ledger at $LEDGER"

# Say which field and why, before anything is built. These two are the fields with no safe default:
# a row with no ask is the exact thing that rendered blank, and a guessed state would be a lie
# about whether Jo is still owed something.
[ -n "$REQUEST" ] || reject "--request is missing. It is the field both surfacing hooks print; a row without it is counted, listed by id, and nameless. There is no default for it."
[ -n "$STATE" ]   || reject "--state is missing. It decides whether the row is still owed. Declared values: $(sh "$ORCH/tools/request-states.sh" --all 2>/dev/null | cut -f1 | tr '\n' ' ')"

if [ -z "$TS" ]; then
  TS="$(date -u +%Y-%m-%dT%H:%M:%SZ)" || die "could not produce a timestamp"
fi

if [ -z "$ID" ]; then
  ID="$(RA_LEDGER="$LEDGER" python3 -c '
import json, os, re, sys
hi = 0
for line in open(os.environ["RA_LEDGER"], encoding="utf-8"):
    line = line.strip()
    if not line:
        continue
    try:
        rid = json.loads(line).get("id", "")
    except Exception:
        continue
    m = re.match(r"^REQ-(\d+)$", rid if isinstance(rid, str) else "")
    if m:
        hi = max(hi, int(m.group(1)))
sys.stdout.write("REQ-%03d" % (hi + 1))
')" || die "could not derive the next id from $LEDGER"
fi

ROW="$(RA_ID="$ID" RA_TS="$TS" RA_REQUEST="$REQUEST" RA_STATE="$STATE" RA_NOTE="$NOTE" \
       RA_TOUCHES="$TOUCHFILE" python3 -c '
import json, os, sys
touches = []
with open(os.environ["RA_TOUCHES"], encoding="utf-8") as fh:
    for line in fh:
        line = line.rstrip("\n")
        if not line:
            continue
        typ, _, text = line.partition("=")
        touches.append({"type": typ, "text": text})
row = {
    "id":       os.environ["RA_ID"],
    "ts":       os.environ["RA_TS"],
    "request":  os.environ["RA_REQUEST"],
    "state":    os.environ["RA_STATE"],
    "touches":  touches,
    "note":     os.environ["RA_NOTE"],
}
sys.stdout.write(json.dumps(row, ensure_ascii=False))
')" || die "could not construct the row"

# Uniqueness is the one property a single-row check cannot see, so it is asked of the real ledger.
if RA_LEDGER="$LEDGER" RA_ID="$ID" python3 -c '
import json, os, sys
want = os.environ["RA_ID"]
for n, line in enumerate(open(os.environ["RA_LEDGER"], encoding="utf-8"), 1):
    line = line.strip()
    if not line:
        continue
    try:
        if json.loads(line).get("id") == want:
            sys.stdout.write(str(n)); sys.exit(0)
    except Exception:
        pass
sys.exit(1)
' > /dev/null 2>&1; then
  reject "id $ID is already used in $LEDGER. Omit --id and the next unused one is derived for you."
fi

# Validate the candidate through the checker itself — same contract, same rules, one
# implementation. The candidate is validated alone rather than appended to a copy of the ledger,
# so pre-existing rows the checker already objects to cannot mask or manufacture a verdict here.
CAND="$(mktemp)" || die "mktemp failed"
printf '%s\n' "$ROW" > "$CAND"
if ! OUT="$(sh "$CHECK" "$CAND" 2>&1)"; then
  echo "REJECTED — the row does not conform to the request-ledger contract:" >&2
  printf '%s\n' "$OUT" | sed -n '/^FAIL/,$p' | sed 's/^/  /' >&2
  echo "  nothing was written to $LEDGER" >&2
  exit 1
fi

if [ "$DRYRUN" -eq 1 ]; then
  echo "OK (dry run) — this row is valid and was NOT written:"
  printf '%s\n' "$ROW"
  exit 0
fi

printf '%s\n' "$ROW" >> "$LEDGER" || die "append to $LEDGER failed"
echo "appended $ID to $LEDGER"
printf '%s\n' "$ROW"
echo
echo "to reverse: remove the last line of $LEDGER (it is the row printed above, and only that row"
echo "was added). A copy of the file from before this run was not made; if you need one, take it"
echo "before the next append."

if ! sh "$STATES" --is-terminal "$STATE"; then
  echo
  echo "DISPOSABLE_HAND_REQUIRED request_issue_reconciliation $ID guard=inactive command=$ORCH/tools/request-issues-reconcile.sh --apply --only $ID"
fi
exit 0

#!/usr/bin/env python3
"""Targeted contract tests for request_issues_reconcile.py."""

import importlib.util
import pathlib
import sys
import unittest

HERE = pathlib.Path(__file__).resolve().parent
MODULE_PATH = HERE / "request_issues_reconcile.py"


def load_module():
    spec = importlib.util.spec_from_file_location("request_issues_reconcile", MODULE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {MODULE_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class ReconciliationContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.subject = load_module()

    def test_applicability_includes_machinery_and_internal_default(self):
        cases = [
            ({"request": "Fix the Lintel request router", "note": ""}, "machinery"),
            ({"request": "Answer Jo's unresolved operating question", "note": ""}, "internal-default"),
            (
                {
                    "request": "Fix newdle-web launcher handling in Lintel",
                    "note": "This changes the orchestrator seat launcher, not product code.",
                },
                "machinery",
            ),
            (
                {
                    "request": "Teach managerial agents to follow repository rules",
                    "note": "This is agent machinery.",
                },
                "machinery",
            ),
            (
                {
                    "request": "Repair rules-injection for AGENTS.md",
                    "note": "The change is orchestrator machinery.",
                },
                "machinery",
            ),
            (
                {
                    "request": "Stand up a deputy resident agent for newdle-web",
                    "note": "The seat will own product-repository work.",
                },
                "machinery",
            ),
            (
                {
                    "request": "A background seat deadlocked while inspecting newdle-api",
                    "note": "Repair the disposable orchestration path.",
                },
                "machinery",
            ),
            (
                {
                    "request": "Seats hand their repository environment to disposable workers",
                    "note": "The example repository is newdle-web.",
                },
                "machinery",
            ),
            (
                {
                    "request": "Fix save-point injection before newdle-api work",
                    "note": "This is a harness boundary.",
                },
                "machinery",
            ),
            (
                {
                    "request": "Lintel must close its own tracker issues",
                    "note": "newdle-web may be mentioned in the evidence.",
                },
                "machinery",
            ),
            (
                {
                    "request": "INCIDENT: inbox rows are triaged without disposition",
                    "note": "The example mentions newdle-mobile, but the defect is in local request bookkeeping.",
                },
                "machinery",
            ),
        ]
        for row, expected_reason in cases:
            with self.subTest(row=row):
                applicable, reason = self.subject.classify_row(row)
                self.assertTrue(applicable)
                self.assertIn(expected_reason, reason)

    def test_applicability_excludes_product_owned_work(self):
        cases = [
            {"request": "Fix the newdle-web feed card", "note": "Owned by Wren in the product repository."},
            {"request": "Deploy newdle-api to production", "note": "API repository work."},
            {"request": "Repair the kitchen editor", "note": "Owned by the kitchen repository."},
            {"request": "Finish the Creator Studio marketing page", "note": ""},
            {"request": "Rebuild the Resend marketing audience", "note": ""},
            {"request": "Audit the data-viz product experience", "note": ""},
            {
                "request": "Repair the generic feed regression",
                "note": "Owned by the newdle-web product repository.",
            },
            {
                "request": "Assess newdle-mobile API v3 compatibility",
                "note": "Lintel recorded the request; no hand or seat is allowed to take it.",
            },
            {
                "request": "Fix the /studio marketing header after Wren-commissioned design work",
                "note": "A disposable hand produced design options for product implementation.",
            },
            {
                "request": "Remove the /studio caption",
                "note": "Lintel dispatched Wren and must not implement the product change inline.",
            },
        ]
        for row in cases:
            with self.subTest(row=row):
                applicable, reason = self.subject.classify_row(row)
                self.assertFalse(applicable)
                self.assertIn("product-owned", reason)

    def test_join_key_search_covers_title_and_body_with_boundaries(self):
        self.assertEqual({"REQ-463"}, self.subject.issue_join_keys({
            "title": "REQ-463 — title join",
            "body": "No canonical ledger line is present.",
        }))
        self.assertEqual({"REQ-448"}, self.subject.issue_join_keys({
            "title": "Guard half",
            "body": "Ledger row: REQ-448 (guard half)",
        }))
        self.assertNotIn("REQ-12", self.subject.issue_join_keys({
            "title": "REQ-120 is not a substring match",
            "body": "",
        }))
        superseding = {
            "title": "REQ-110 — durable task tracking",
            "body": "Ledger row: REQ-110\n\nSUPERSEDES/ABSORBS REQ-027.",
        }
        self.assertEqual({"REQ-110"}, self.subject.issue_join_keys(superseding))
        self.assertEqual(
            {"REQ-027", "REQ-110"},
            self.subject.issue_candidate_keys(superseding),
        )

    def test_untrusted_issue_fields_are_validated(self):
        valid = {
            "number": 17,
            "state": "open",
            "title": "REQ-017 — example",
            "body": "Ledger row: REQ-017",
            "html_url": "https://github.com/thewolff/lintel-tasks/issues/17",
        }
        self.subject.validate_issue(valid, "thewolff/lintel-tasks", expected_key="REQ-017")
        mutations = {
            "number": "17",
            "state": "pending",
            "title": 3,
            "body": None,
            "html_url": "https://evil.example/issues/17",
        }
        for field, value in mutations.items():
            bad = dict(valid)
            bad[field] = value
            with self.subTest(field=field):
                with self.assertRaises(self.subject.ReconciliationError):
                    self.subject.validate_issue(bad, "thewolff/lintel-tasks", expected_key="REQ-017")

    def test_pending_hand_reconciliation_requires_exact_target_issue_touch(self):
        valid_url = "https://github.com/thewolff/lintel-tasks/issues/17"
        base = {
            "id": "REQ-017",
            "ts": "2026-01-01T00:00:00Z",
            "request": "Fix Lintel request routing",
            "state": "open",
            "touches": [],
            "note": "",
        }
        cases = [
            (base, ["REQ-017"]),
            ({**base, "touches": [{"type": "context", "text": valid_url}]}, []),
            ({**base, "touches": [{"type": "context", "text": valid_url + "?tab=activity"}]}, ["REQ-017"]),
            ({**base, "touches": [{"type": "context", "text": "https://evil.example/thewolff/lintel-tasks/issues/17"}]}, ["REQ-017"]),
            ({**base, "touches": [{"type": "context", "text": "https://github.com/other/repo/issues/17"}]}, ["REQ-017"]),
            ({**base, "state": "delivered"}, []),
            (
                {
                    **base,
                    "request": "Fix the newdle-web feed card",
                    "note": "Owned by Wren in the product repository.",
                },
                [],
            ),
        ]
        for row, expected in cases:
            with self.subTest(row=row):
                self.assertEqual(
                    expected,
                    self.subject.pending_hand_reconciliation_ids(
                        [row], "thewolff/lintel-tasks"
                    ),
                )

    def test_plan_reuses_open_reopens_closed_creates_absent_and_skips_product(self):
        rows = [
            {"id": "REQ-001", "ts": "2026-01-01T00:00:00Z", "request": "Fix Lintel", "state": "open", "touches": [], "note": ""},
            {"id": "REQ-002", "ts": "2026-01-01T00:00:00Z", "request": "Fix orchestrator", "state": "partial", "touches": [], "note": ""},
            {"id": "REQ-003", "ts": "2026-01-01T00:00:00Z", "request": "Answer internal question", "state": "blocked", "touches": [], "note": ""},
            {"id": "REQ-004", "ts": "2026-01-01T00:00:00Z", "request": "Fix newdle-web feed card", "state": "open", "touches": [], "note": "Owned by Wren in the product repository."},
        ]
        issues = [
            {"number": 11, "state": "open", "title": "REQ-001 — open", "body": "body", "html_url": "https://github.com/thewolff/lintel-tasks/issues/11"},
            {"number": 12, "state": "closed", "title": "closed", "body": "Ledger row: REQ-002", "html_url": "https://github.com/thewolff/lintel-tasks/issues/12"},
        ]
        plan = {item.request_id: item for item in self.subject.plan_inventory(rows, issues, "thewolff/lintel-tasks")}
        self.assertEqual("reuse-open", plan["REQ-001"].action)
        self.assertEqual("reopen", plan["REQ-002"].action)
        self.assertEqual("create", plan["REQ-003"].action)
        self.assertEqual("skip", plan["REQ-004"].action)

    def test_duplicate_open_issues_fail_closed(self):
        row = {"id": "REQ-009", "ts": "2026-01-01T00:00:00Z", "request": "Fix Tinker", "state": "open", "touches": [], "note": ""}
        issues = [
            {"number": 1, "state": "open", "title": "REQ-009 — one", "body": "", "html_url": "https://github.com/thewolff/lintel-tasks/issues/1"},
            {"number": 2, "state": "open", "title": "two", "body": "Ledger row: REQ-009", "html_url": "https://github.com/thewolff/lintel-tasks/issues/2"},
        ]
        with self.assertRaises(self.subject.ReconciliationError):
            self.subject.plan_inventory([row], issues, "thewolff/lintel-tasks")

    def test_issue_body_is_standalone_and_declares_authority(self):
        row = {
            "id": "REQ-021",
            "ts": "2026-01-01T00:00:00Z",
            "request": "Make the request router idempotent",
            "state": "partial",
            "touches": [{"type": "original", "text": "Please fix duplicate routing."}],
            "note": "Done when a second run creates no issue.",
        }
        body = self.subject.issue_body(row, pathlib.Path("/tmp/REQUESTS.jsonl"))
        for text in (
            "Make the request router idempotent",
            "partial",
            "Done when a second run creates no issue.",
            "REQ-021",
            "/tmp/REQUESTS.jsonl",
            "local request ledger is authoritative",
            "Acceptance criteria",
        ):
            self.assertIn(text, body)

    def test_second_plan_after_creation_is_idempotent(self):
        row = {"id": "REQ-031", "ts": "2026-01-01T00:00:00Z", "request": "Fix Lintel", "state": "open", "touches": [], "note": ""}
        first = self.subject.plan_inventory([row], [], "thewolff/lintel-tasks")
        self.assertEqual("create", first[0].action)
        created = [{
            "number": 31,
            "state": "open",
            "title": "REQ-031 — Fix Lintel",
            "body": self.subject.issue_body(row, pathlib.Path("/tmp/REQUESTS.jsonl")),
            "html_url": "https://github.com/thewolff/lintel-tasks/issues/31",
        }]
        second = self.subject.plan_inventory([row], created, "thewolff/lintel-tasks")
        self.assertEqual("reuse-open", second[0].action)

    def test_complete_listing_retries_a_transient_open_count_mismatch(self):
        issue = {
            "number": 31,
            "state": "open",
            "title": "REQ-031 — Fix Lintel",
            "body": "Ledger row: REQ-031",
            "html_url": "https://github.com/thewolff/lintel-tasks/issues/31",
        }
        responses = iter(
            [
                [[issue]],
                {"open_issues_count": 2},
                [[issue]],
                {"open_issues_count": 1},
            ]
        )
        original_run_gh = self.subject._run_gh
        original_delay = self.subject.FETCH_RETRY_SECONDS
        self.subject._run_gh = lambda _args, _token: next(responses)
        self.subject.FETCH_RETRY_SECONDS = 0
        try:
            self.assertEqual(
                [issue],
                self.subject.fetch_all_issues("thewolff/lintel-tasks", "token"),
            )
        finally:
            self.subject._run_gh = original_run_gh
            self.subject.FETCH_RETRY_SECONDS = original_delay

    def test_apply_rechecks_only_rows_that_need_a_mutation(self):
        rows = [
            {
                "id": "REQ-041",
                "ts": "2026-01-01T00:00:00Z",
                "request": "Fix Lintel routing",
                "state": "open",
                "touches": [],
                "note": "",
            },
            {
                "id": "REQ-042",
                "ts": "2026-01-01T00:00:00Z",
                "request": "Fix Tinker dispatch",
                "state": "open",
                "touches": [],
                "note": "",
            },
        ]
        existing = {
            "number": 41,
            "state": "open",
            "title": "REQ-041 — Fix Lintel routing",
            "body": "Ledger row: REQ-041",
            "html_url": "https://github.com/thewolff/lintel-tasks/issues/41",
        }
        created = {
            "number": 42,
            "state": "open",
            "title": self.subject.issue_title(rows[1]),
            "body": self.subject.issue_body(rows[1], pathlib.Path("/tmp/REQUESTS.jsonl")),
            "html_url": "https://github.com/thewolff/lintel-tasks/issues/42",
        }
        inventory = self.subject.plan_inventory(
            rows, [existing], "thewolff/lintel-tasks"
        )
        snapshots = iter([[existing], [existing, created]])
        fetch_count = 0
        original_fetch = self.subject.fetch_all_issues
        original_run_gh = self.subject._run_gh

        def fake_fetch(_repo, _token):
            nonlocal fetch_count
            fetch_count += 1
            return next(snapshots)

        self.subject.fetch_all_issues = fake_fetch
        self.subject._run_gh = lambda _args, _token: created
        try:
            final_inventory, actions = self.subject.apply_reconciliation(
                rows,
                inventory,
                "thewolff/lintel-tasks",
                "token",
                pathlib.Path("/tmp/REQUESTS.jsonl"),
            )
        finally:
            self.subject.fetch_all_issues = original_fetch
            self.subject._run_gh = original_run_gh

        self.assertEqual(2, fetch_count)
        self.assertEqual(
            [{"request_id": "REQ-042", "action": "created", "url": created["html_url"]}],
            actions,
        )
        self.assertTrue(all(item.action == "reuse-open" for item in final_inventory))


if __name__ == "__main__":
    unittest.main(verbosity=2)

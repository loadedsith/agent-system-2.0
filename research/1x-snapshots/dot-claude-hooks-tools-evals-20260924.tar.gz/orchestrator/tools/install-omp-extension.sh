#!/bin/bash
# install-omp-extension — build a staged OMP extension, back up the live file with
# verification, and overwrite ONLY on a clean build.
#
# WHY THIS EXISTS, and it is a specific failure rather than a general principle.
# On 2026-09-15 Tinker stated the rule "bun build to exit 0 BEFORE the copy, never after",
# Lintel made it standing for this adapter, and Tinker broke it within the hour — by editing
# the live file in place and building it afterwards. The build happened to pass. "It passed"
# is luck, not discipline.
#
# The diagnosis that matters: the editing tool makes in-place the path of least resistance,
# so the rule required choosing the harder path at the moment of action. A discipline with
# that shape is not installed. This script moves the gate from memory into mechanism — if
# the script is the thing that overwrites, nobody has to remember the order.
#
# THE HAZARD IT GUARDS. A throwing handler in an OMP extension is converted to
# {block:true} and denies every tool call machine-wide (runner.ts:1487-1494). One syntax
# error in the seat adapter bricks all eleven seats. The build costs milliseconds.
#
# EVERY GATE REFUSES RATHER THAN WARNS. A check that cannot run must never read as a pass:
# that is the dominant defect class on this machine, observed across seven independent
# instruments on 2026-09-15. There is no --force.
#
# Usage:
#   install-omp-extension.sh <staged-source.ts> <live-target.ts> [expected-live-md5]
#
# Supplying the expected current live md5 is strongly recommended: it turns "I think I know
# what I am replacing" into a refusal when the live file is not what you measured against.

set -u

die() { printf 'install-omp-extension: REFUSED — %s\n' "$1" >&2; exit 1; }

STAGED="${1:-}"
TARGET="${2:-}"
EXPECT="${3:-}"

[ -n "$STAGED" ] && [ -n "$TARGET" ] || die "usage: $0 <staged-source> <live-target> [expected-live-md5]"
[ -f "$STAGED" ] || die "staged source does not exist: $STAGED"
[ -f "$TARGET" ] || die "live target does not exist: $TARGET (this script replaces, it does not create)"

command -v bun >/dev/null 2>&1 || die "bun not on PATH; cannot run the build gate, so refusing rather than copying unverified"
command -v md5 >/dev/null 2>&1 || die "md5 not on PATH; cannot verify the backup, so refusing"

# The plugin root the adapter requires at import time. Resolved from the newest installed
# version rather than hardcoded, because a hardcoded version silently rots.
if [ -z "${NEWDLE_PLUGIN_ROOT:-}" ]; then
  CACHE="$HOME/.claude/plugins/cache/contextpress/newdle"
  [ -d "$CACHE" ] || die "no plugin cache at $CACHE and NEWDLE_PLUGIN_ROOT unset"
  NEWEST=$(ls -1 "$CACHE" 2>/dev/null | sort -V | tail -1)
  [ -n "$NEWEST" ] || die "plugin cache $CACHE is empty"
  NEWDLE_PLUGIN_ROOT="$CACHE/$NEWEST"
  printf 'resolved NEWDLE_PLUGIN_ROOT=%s\n' "$NEWDLE_PLUGIN_ROOT"
fi
export NEWDLE_PLUGIN_ROOT

LIVE_MD5=$(md5 -q "$TARGET") || die "could not hash the live target"
printf 'live now:      %s  %s\n' "$LIVE_MD5" "$TARGET"

if [ -n "$EXPECT" ]; then
  [ "$LIVE_MD5" = "$EXPECT" ] || die "live target is $LIVE_MD5 but you expected $EXPECT — it changed under you; re-measure before replacing it"
  printf 'expectation:   MATCHED\n'
else
  printf 'expectation:   (none supplied — pass the expected md5 as arg 3 to make this a gate)\n'
fi

STAGED_MD5=$(md5 -q "$STAGED") || die "could not hash the staged source"
printf 'staged source: %s  %s\n' "$STAGED_MD5" "$STAGED"

if [ "$STAGED_MD5" = "$LIVE_MD5" ]; then
  printf 'install-omp-extension: nothing to do — staged source is byte-identical to the live file.\n'
  exit 0
fi

# ── GATE 1: the build. Before anything is touched. ────────────────────────────────────────
OUT=$(mktemp -t omp-ext-build) || die "mktemp failed"
trap 'rm -f "$OUT"' EXIT
printf '\n=== GATE 1: build ===\n'
if ! bun build "$STAGED" --target=bun --outfile="$OUT" 2>&1; then
  die "build FAILED — live file untouched. A throwing extension denies every tool call machine-wide."
fi
[ -s "$OUT" ] || die "build reported success but produced no output — refusing to copy on an unexplained result"
printf 'build:         exit 0, %s bytes\n' "$(wc -c < "$OUT" | tr -d ' ')"

# ── GATE 2: back up, and VERIFY the backup before the overwrite, not after. ───────────────
printf '\n=== GATE 2: backup, verified before overwrite ===\n'
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP="${TARGET}.pre-install-${STAMP}"
[ -e "$BACKUP" ] && die "backup path already exists: $BACKUP"
cp -p "$TARGET" "$BACKUP" || die "backup copy failed — nothing overwritten"
BACKUP_MD5=$(md5 -q "$BACKUP") || die "could not hash the backup"
[ "$BACKUP_MD5" = "$LIVE_MD5" ] || die "backup is $BACKUP_MD5 but live was $LIVE_MD5 — the backup is not a faithful copy, so the change would be irreversible; nothing overwritten"
printf 'backup:        %s  %s\n' "$BACKUP_MD5" "$BACKUP"
printf 'backup:        VERIFIED equal to live\n'

# ── The overwrite. Only reachable with both gates passed. ─────────────────────────────────
printf '\n=== INSTALL ===\n'
cp "$STAGED" "$TARGET" || die "copy failed after backup; restore with: cp '$BACKUP' '$TARGET'"
POST_MD5=$(md5 -q "$TARGET") || die "could not hash the installed file"
[ "$POST_MD5" = "$STAGED_MD5" ] || die "installed file is $POST_MD5 but staged was $STAGED_MD5 — the install did not land cleanly; restore with: cp '$BACKUP' '$TARGET'"

printf '\n=== MEASURED DELTA ===\n'
printf 'before:        %s\n' "$LIVE_MD5"
printf 'after:         %s\n' "$POST_MD5"
printf 'reversal:      cp %s %s\n' "$BACKUP" "$TARGET"
printf 'then confirm:  md5 -q %s  ->  %s\n' "$TARGET" "$LIVE_MD5"
printf '\nNOTE: an OMP extension change does not reach a session that started before it.\n'
printf 'Every live seat needs a relaunch to pick this up. The install is not the adoption.\n'

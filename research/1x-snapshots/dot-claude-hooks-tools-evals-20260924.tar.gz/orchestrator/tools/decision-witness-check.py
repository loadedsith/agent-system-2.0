#!/usr/bin/env python3
"""decision-witness-check — report decisions the record still calls open while the disk says they
were acted on.

WHAT PROBLEM THIS IS A SUBSET OF, AND WHY IT IS ONLY A SUBSET. "Was this decision acted on?" is
undecidable in general: the act can be a config change, a conversation, a habit, or nothing at all,
and no reader of a filesystem can tell those apart. This tool does not attempt it. It checks exactly
one thing, and only where a human volunteered the means to check it: a row may carry a WITNESS, a
path plus a literal string that would be present if and only if the decision had been carried out.
Where that string is present and the row still reads `state: open`, the record and the disk
disagree, and the disagreement is reported.

THE LIVE CASE IT WAS BUILT FROM. DEC-023 proposed promoting an evidence rule into the charter. The
rule is live in the charter. The row reads `state: open, chose: null`. Nothing detected it — a
person hand-typed the discrepancy into the save point. With a witness on that row this is one line
of output.

WHAT IT WILL NEVER DO.
  * It NEVER closes a row. A witness proves the work happened; it does not say which option was
    chosen, and writing "answered" without that loses the only thing the record existed to keep.
    Closing stays `decision-write.sh answer`, human-driven.
  * It NEVER guesses a witness. A row without one is not checked, and the output says how many
    those are. A coverage figure with an unstated denominator is not a measurement, so the
    denominator is printed whether or not anything was flagged.
  * It NEVER uses a line number. Witnesses are literal strings; `decision-write.sh` refuses a
    numeric one, because a line number drifts silently and still resolves, so the check would keep
    passing while pointing at the wrong content.

FAILURE BEHAVIOUR. Missing ledger -> exit 0 with a stated "source absent", because a missing
decisions file is a fact about the fleet and not an error in this tool. A malformed row is skipped,
counted, and named. A witness path that does not exist is UNCHECKED, never a pass and never a flag.
A witness file too large to read is UNCHECKED for the same reason.

USAGE  decision-witness-check.py [--ledger PATH] [--json] [--exit-nonzero-on-flag]
EXIT   0 always in report mode; 1 with --exit-nonzero-on-flag if anything was flagged.
"""
import argparse, json, os, sys

MAX_WITNESS_BYTES = 8 * 1024 * 1024


def check(path):
    """Return a plain dict. No printing, so savepoint-generate.py can import this."""
    r = {
        "source": path,
        "source_present": os.path.isfile(path),
        "rows_total": 0,
        "malformed": 0,
        "first_malformed_line": None,
        "open_total": 0,
        "checked": 0,            # open rows with a witness whose path could be read
        "flagged": [],           # open + witness string present on disk
        "witness_string_absent": 0,
        "unchecked_no_witness": 0,
        "unchecked_path_missing": 0,
        "unchecked_unreadable": 0,
    }
    if not r["source_present"]:
        return r
    rows = []
    with open(path, encoding="utf-8") as fh:
        for i, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            r["rows_total"] += 1
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                r["malformed"] += 1
                if r["first_malformed_line"] is None:
                    r["first_malformed_line"] = i

    for row in rows:
        if not isinstance(row, dict) or row.get("state") != "open":
            continue
        r["open_total"] += 1
        w = row.get("witness")
        if not isinstance(w, dict) or not w.get("path") or not w.get("contains"):
            r["unchecked_no_witness"] += 1
            continue
        wpath, needle = w["path"], w["contains"]
        if not os.path.isfile(wpath):
            r["unchecked_path_missing"] += 1
            continue
        try:
            if os.path.getsize(wpath) > MAX_WITNESS_BYTES:
                r["unchecked_unreadable"] += 1
                continue
            text = open(wpath, encoding="utf-8", errors="replace").read()
        except OSError:
            r["unchecked_unreadable"] += 1
            continue
        r["checked"] += 1
        if needle in text:
            r["flagged"].append({
                "id": row.get("id", "?"),
                "question": row.get("question", ""),
                "witness_path": wpath,
                "witness_contains": needle,
            })
        else:
            r["witness_string_absent"] += 1
    return r


def coverage_line(r):
    """One line, denominator always stated, even when nothing was flagged."""
    if not r["source_present"]:
        return "SOURCE ABSENT — %s not found; nothing checked" % r["source"]
    unchecked = (r["unchecked_no_witness"] + r["unchecked_path_missing"]
                 + r["unchecked_unreadable"])
    line = ("%d open; %d checked against a witness, %d NOT checked (%d no witness, "
            "%d witness path missing, %d witness unreadable)"
            % (r["open_total"], r["checked"], unchecked, r["unchecked_no_witness"],
               r["unchecked_path_missing"], r["unchecked_unreadable"]))
    if r["malformed"]:
        line += (" — WARNING: %d malformed row(s) skipped, first at line %s"
                 % (r["malformed"], r["first_malformed_line"]))
    return line


def flag_lines(r, qlimit=90):
    out = []
    for f in r["flagged"]:
        q = " ".join((f["question"] or "").split())
        if len(q) > qlimit:
            q = q[: qlimit - 1].rstrip() + "…"
        out.append("%s STILL OPEN but its witness is on disk: %s — %s contains %r"
                   % (f["id"], q, f["witness_path"], f["witness_contains"]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ledger", default=os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "state", "DECISIONS.jsonl"))
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--exit-nonzero-on-flag", action="store_true")
    a = ap.parse_args()
    r = check(a.ledger)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print("coverage: " + coverage_line(r))
        if r["flagged"]:
            print("ACTED ON BUT NEVER CLOSED — the record and the disk disagree. This tool does "
                  "not close them; `decision-write.sh answer --id ... --chose ...` does.")
            for line in flag_lines(r):
                print("  " + line)
        elif r["source_present"]:
            print("no disagreement among the rows that could be checked "
                  "(see the coverage line for how many could not)")
    if a.exit_nonzero_on_flag and r["flagged"]:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/bin/sh
# state-vocab-check.sh — does the contract's declared request-state vocabulary match the ledger?
#
# The request-ledger contract declares one line per state between the markers `state-vocabulary:begin` and
# `state-vocabulary:end`, each of the shape:
#
#     - `delivered` — terminal — prose
#     - `open` — non-terminal — prose
#
# This script parses that list and diffs it against the distinct values of `.state` in
# state/REQUESTS.jsonl. It exits non-zero on a difference in EITHER direction: a state that
# appears in the data but is not declared, or a state that is declared but appears nowhere.
#
# Usage:
#   state-vocab-check.sh [ledger.jsonl] [request-ledger-contract.md]
#   state-vocab-check.sh --selftest      # prove the checker can fail: run it against a fixture
#                                        # ledger carrying an invented state, expect a failure
#
# Exit codes: 0 vocabulary matches | 1 mismatch | 2 could not run the check at all.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
LEDGER="${1:-$ORCH/state/REQUESTS.jsonl}"
CONTRACT="${2:-${LINTEL_STATE_CONTRACT:-$ORCH/contracts/request-ledger.md}}"

parse_contract_states() {
  # Print declared states, one "name<TAB>terminality" pair per line.
  awk '
    /state-vocabulary:begin/ { inblock = 1; next }
    /state-vocabulary:end/   { inblock = 0; next }
    inblock {
      line = $0
      sub(/^[[:space:]]*>[[:space:]]*/, "", line)
      if (match(line, /^-[[:space:]]*`[a-z_-]+`[[:space:]]*(—|--)[[:space:]]*(non-terminal|terminal)([[:space:]]|$|—|--)/)) {
        name = line
        sub(/^-[[:space:]]*`/, "", name)
        sub(/`.*$/, "", name)
        rest = line
        sub(/^-[[:space:]]*`[a-z_-]+`[[:space:]]*(—|--)[[:space:]]*/, "", rest)
        term = (rest ~ /^non-terminal/) ? "non-terminal" : "terminal"
        print name "\t" term
      }
    }
  ' "$1"
}

selftest() {
  fixture="$(mktemp -d)/REQUESTS.jsonl" || { echo "selftest: mktemp failed" >&2; exit 2; }
  # One row per declared state, plus one row carrying a state nobody declared.
  parse_contract_states "$CONTRACT" | cut -f1 | while read -r s; do
    printf '{"id":"REQ-FIXTURE","state":"%s"}\n' "$s" >> "$fixture"
  done
  printf '{"id":"REQ-FIXTURE","state":"kumquat"}\n' >> "$fixture"
  echo "selftest: running the check against $fixture (contains the invented state 'kumquat')"
  sh "$0" "$fixture" "$CONTRACT"
  rc=$?
  if [ "$rc" -eq 0 ]; then
    echo "SELFTEST FAILED: the checker passed a ledger containing an undeclared state" >&2
    exit 1
  fi
  echo "selftest: OK — the checker exited $rc on the fixture, so it is capable of failing"
  exit 0
}

case "${1:-}" in --selftest) shift; CONTRACT="${1:-${LINTEL_STATE_CONTRACT:-$ORCH/contracts/request-ledger.md}}"; selftest ;; esac

command -v jq >/dev/null || { echo "preflight: jq not found" >&2; exit 2; }
[ -f "$LEDGER" ]  || { echo "preflight: no ledger at $LEDGER" >&2; exit 2; }
[ -f "$CONTRACT" ] || { echo "preflight: no request-ledger contract at $CONTRACT" >&2; exit 2; }

tmp="$(mktemp -d)" || exit 2
trap 'rm -rf "$tmp"' EXIT

parse_contract_states "$CONTRACT" | cut -f1 | sort -u > "$tmp/declared"
if [ ! -s "$tmp/declared" ]; then
  echo "FAIL: no state declarations found between the state-vocabulary markers in $CONTRACT" >&2
  exit 2
fi

if ! jq -r 'if type == "object" then (.state // "NO_STATE") else "NOT_AN_OBJECT" end' "$LEDGER" \
     > "$tmp/raw" 2> "$tmp/jqerr"; then
  echo "FAIL: $LEDGER did not parse as JSON lines:" >&2
  sed 's/^/  /' "$tmp/jqerr" >&2
  exit 2
fi
sort -u "$tmp/raw" > "$tmp/observed"

undeclared="$(comm -13 "$tmp/declared" "$tmp/observed")"
unused="$(comm -23 "$tmp/declared" "$tmp/observed")"

echo "contract: $CONTRACT"
echo "ledger:   $LEDGER"
echo "declared: $(tr '\n' ' ' < "$tmp/declared")"
echo "observed: $(tr '\n' ' ' < "$tmp/observed")"

rc=0
if [ -n "$undeclared" ]; then
  rc=1
  echo
    echo "FAIL — states in the data that the contract does not declare:"
  for s in $undeclared; do
    n="$(grep -c "^$s\$" "$tmp/raw")"
    echo "  $s  ($n rows)"
  done
fi
if [ -n "$unused" ]; then
  rc=1
  echo
    echo "FAIL — states the contract declares that appear nowhere in the data:"
  for s in $unused; do echo "  $s"; done
fi

if [ "$rc" -eq 0 ]; then
  echo
  echo "OK — contract vocabulary and ledger states match exactly."
  echo "terminality:"
  parse_contract_states "$CONTRACT" | sort | sed 's/^/  /'
fi
exit "$rc"

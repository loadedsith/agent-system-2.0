#!/bin/sh
# decision-witness-check.sh — the wrapper that makes decision-witness-check.py discoverable.
#
# WHY THIS FILE EXISTS, AND IT IS A DEFECT FIX RATHER THAN PLUMBING. The batch install of
# 2026-08-25 placed decision-witness-check.py directly under tools/ with no wrapper. The stop-time
# discovery scheme runs executable *-check.sh files in this directory and nothing else, so the
# checker was installed, correct, and INVISIBLE — it would never have run, and nothing would have
# said so. The discovery scheme caught it forty minutes after install and announced it loudly,
# which is the one behaviour that separates this from the failures it exists to find.
#
# WHAT IT CHECKS. Every decision row still open is supposed to carry a witness: a path plus a
# string that, if present on disk, means the decision was ACTED ON. A row whose witness is
# satisfied while the row still reads open is the exact defect that let an evidence rule land in
# Lintel's charter while nobody had answered whether it should.
#
# EXIT BEHAVIOUR — AND THE FIRST VERSION OF THIS PARAGRAPH WAS WRONG, WHICH IS WHY IT IS LONG.
# It said a non-zero exit halts the turn, and called that correct for a real disagreement. The
# checker cannot do that as installed: the blocking branch at decision-witness-check.py:154 is
# gated on --exit-nonzero-on-flag, an opt-in flag, and discovery calls this wrapper with no
# arguments. Four crash shapes were probed and all four exit 0 — normal run, ledger absent, ledger
# is a directory, and a malformed witness field. THERE IS NO REACHABLE NON-ZERO PATH.
#
# So this REPORTS AND NEVER HALTS, and that is the right behaviour rather than a gap to close.
# A stop-time turn-blocker for a bookkeeping mismatch is disproportionate: today's whole lesson is
# that a blocking hook costs availability a loud one does not. DO NOT ADD THE FLAG.
#
# The wrong version of this paragraph is the same defect as the checker being installed where it
# could not run: a description promising behaviour the thing does not have. It was caught by
# Tinker reading the source rather than by anyone reading this file.
set -e
exec python3 "$(dirname "$0")/decision-witness-check.py" "$@"

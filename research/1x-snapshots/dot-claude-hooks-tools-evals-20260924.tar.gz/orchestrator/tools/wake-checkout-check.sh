#!/bin/sh
# wake-checkout-check.sh — answer "is my checkout stale?" BEFORE a seat restates state.
#
# ── THE FAILURE THIS EXISTS FOR ──────────────────────────────────────────────────────────────
#
# On 2026-09-15 three seats reported that their wake-time ledger was a function of a stale
# checkout, AND that the session-start injection inherited the same staleness rather than
# correcting it — so the seat and its briefing agreed on a wrong answer, which is the worst
# available shape: two sources, one error, full confidence. Galley had it three consecutive wakes
# and opened by reporting merged work as unpushed. Wren's digest stopped four entries short.
# Caspian's checkout sat 98 commits behind.
#
# Galley's own rule was "treat my first message of any wake as unverified until I have fetched".
# That is a good habit and a bad system, because it depends on remembering. This is the version
# that does not.
#
# ── WHY IT COMPARES BY CONTENT AND NEVER BY COMMIT DISTANCE ──────────────────────────────────
#
# ⛔ `git diff main..origin/main` reports differences in BOTH directions and cannot tell "the
# remote has an entry I lack" from "I have an entry the remote lacks". Measured 2026-09-15 in this
# repository: branches reporting 16 to 82 differing journal paths held ZERO entries that main
# lacked — every difference was the branch being behind. A distance check would have reported all
# of them as findings. So this script asks, per path, whether the path-and-blob exists on the
# remote side. One direction at a time, by content.
#
# Also measured the same day, and it is why "has a remote" is not the question: 86 of 179
# repositories on this machine have a remote whose URL is a local filesystem path on the same
# disk. This script reports the remote's URL kind so a same-disk remote cannot read as durability.
#
# ── WHAT IT DOES NOT DO ──────────────────────────────────────────────────────────────────────
#
# It does not fix anything, pull anything, or change the working tree. `git fetch` updates
# remote-tracking refs only — no checkout, no merge, no rebase, no stash. It is safe to run in a
# checkout shared with another live agent, which is the normal condition here.
#
# It states facts and issues no instructions. That is deliberate: content injected into a model's
# context cannot carry authority, measured twice on this machine (2026-09-11 against
# before_agent_start, 2026-09-15 against tool_result), and a model is right to decline unsigned
# imperatives. The facts are the deliverable; what to do about them belongs to the reader.
#
# Usage:  sh wake-checkout-check.sh [repo-path]        # defaults to the current directory
#         WAKE_CHECK_NO_FETCH=1 sh wake-checkout-check.sh   # skip the network, report refs as-is
#
# Exit:   0 = checkout is current, or there is nothing to compare against
#         1 = ⛔ STALE: the remote holds durable entries this checkout does not
#         2 = could not determine (not a repository, no remote, fetch failed)

set -u

REPO="${1:-$PWD}"
LOG_DIR="${WAKE_CHECK_LOG_DIR:-.ai/decision-log}"

cd "$REPO" 2>/dev/null || { echo "wake-check: not a directory: $REPO"; exit 2; }
git rev-parse --git-dir >/dev/null 2>&1 || { echo "wake-check: not a git repository: $REPO"; exit 2; }

REPO_TOP="$(git rev-parse --show-toplevel 2>/dev/null || echo "$REPO")"

# ── The remote, and what KIND of remote it is ────────────────────────────────────────────────
REMOTE_URL="$(git remote get-url origin 2>/dev/null || true)"
if [ -z "$REMOTE_URL" ]; then
  # Not a failure of this script and not necessarily a fault: this repository may have no remote
  # on purpose. But it IS the condition under which nothing here is replicated, so it is stated in
  # as many words rather than exiting quietly.
  echo "WAKE CHECKOUT CHECK — $REPO_TOP"
  echo "⛔ NO REMOTE. This repository has no 'origin', so nothing in it is replicated anywhere and"
  echo "   there is no mainline to compare against. Staleness is undefined; loss is total on disk"
  echo "   failure. Local branches: $(git for-each-ref --format='%(refname)' refs/heads | wc -l | tr -d ' ')."
  exit 2
fi

case "$REMOTE_URL" in
  /*|file://*) REMOTE_KIND="⛔ SAME-DISK PATH — this is not off-machine replication" ;;
  *) REMOTE_KIND="network" ;;
esac

# ── Fetch: refs only, never the working tree ─────────────────────────────────────────────────
FETCH_STATE="skipped (WAKE_CHECK_NO_FETCH set)"
if [ -z "${WAKE_CHECK_NO_FETCH:-}" ]; then
  if git fetch --quiet --prune origin 2>/dev/null; then
    FETCH_STATE="ok"
  else
    FETCH_STATE="⛔ FAILED — every figure below is as stale as the refs on disk"
  fi
fi

# ── Resolve the mainline ref, without assuming it is called main ─────────────────────────────
MAINLINE=""
for candidate in refs/remotes/origin/HEAD refs/remotes/origin/main refs/remotes/origin/master; do
  if git rev-parse --verify -q "$candidate" >/dev/null 2>&1; then
    MAINLINE="$(git rev-parse --abbrev-ref "$candidate" 2>/dev/null)"
    [ -n "$MAINLINE" ] && break
  fi
done
[ -z "$MAINLINE" ] && { echo "wake-check: no origin/HEAD, origin/main or origin/master to compare against"; exit 2; }

echo "WAKE CHECKOUT CHECK — $REPO_TOP"
echo "remote: $REMOTE_URL  [$REMOTE_KIND]"
echo "fetch: $FETCH_STATE   mainline: $MAINLINE   local HEAD: $(git rev-parse --abbrev-ref HEAD 2>/dev/null)"

# ── The content comparison, both directions, per path ────────────────────────────────────────
# `git ls-tree -r` gives path-and-blob for a tree. A path present on both sides at DIFFERENT
# blobs is its own case and is reported separately: that is the one a distance check calls safe
# and which bit two repositories on this machine today.
#
# ⛔ TEMP FILES, NOT `comm <(...)`. The first version of this script used process substitution,
# which is not POSIX, so under its own `#!/bin/sh` shebang it printed a syntax error to stderr
# and then REPORTED THREE ZEROS AND EXITED 0 — a check that read as "clean" because it could not
# run. That is the single failure mode this whole script exists to prevent, reproduced inside the
# script itself on its first execution. The guard below is why it cannot happen silently again.
TMPD="$(mktemp -d "${TMPDIR:-/tmp}/wake-check-XXXXXX")" || { echo "wake-check: mktemp failed"; exit 2; }
trap 'rm -rf "$TMPD"' EXIT HUP INT TERM

git ls-tree -r "$MAINLINE" -- "$LOG_DIR" 2>/dev/null | awk '{print $3" "$4}' | sort > "$TMPD/remote_full"
git ls-tree -r HEAD        -- "$LOG_DIR" 2>/dev/null | awk '{print $3" "$4}' | sort > "$TMPD/local_full"
awk 'NF{print $2}' "$TMPD/remote_full" | sort -u > "$TMPD/remote_paths"
awk 'NF{print $2}' "$TMPD/local_full"  | sort -u > "$TMPD/local_paths"

# ⛔ THE SELF-CHECK. Zero entries on BOTH sides means either this repository keeps no decision log
# at $LOG_DIR, or the comparison failed. Those are different facts and a bare "0 missing" cannot
# tell them apart, which is precisely how the broken version looked healthy.
if [ ! -s "$TMPD/remote_paths" ] && [ ! -s "$TMPD/local_paths" ]; then
  echo "⛔ NOTHING TO COMPARE: no entries under $LOG_DIR on either side."
  echo "   This is NOT a clean result. Either this repository keeps its record elsewhere — set"
  echo "   WAKE_CHECK_LOG_DIR to point at it — or the tree read failed. Not reporting staleness."
  exit 2
fi

comm -23 "$TMPD/remote_paths" "$TMPD/local_paths" > "$TMPD/missing_here"
comm -13 "$TMPD/remote_paths" "$TMPD/local_paths" > "$TMPD/missing_there"
comm -12 "$TMPD/remote_paths" "$TMPD/local_paths" > "$TMPD/both"

MISSING_HERE="$(cat "$TMPD/missing_here")"
MISSING_THERE="$(cat "$TMPD/missing_there")"

# Same path, different content. Compared on the blob, so a whitespace-only edit counts and an
# mtime difference does not.
DIVERGED=""
while IFS= read -r p; do
  [ -n "$p" ] || continue
  rb="$(awk -v p="$p" '$2==p{print $1}' "$TMPD/remote_full")"
  lb="$(awk -v p="$p" '$2==p{print $1}' "$TMPD/local_full")"
  if [ -n "$rb" ] && [ -n "$lb" ] && [ "$rb" != "$lb" ]; then
    DIVERGED="$DIVERGED$p
"
  fi
done < "$TMPD/both"

n_missing_here=$(printf '%s' "$MISSING_HERE" | grep -c . || true)
n_missing_there=$(printf '%s' "$MISSING_THERE" | grep -c . || true)
n_diverged=$(printf '%s' "$DIVERGED" | grep -c . || true)

echo "$LOG_DIR — compared by content, per path:"
echo "  on $MAINLINE but NOT in this checkout: $n_missing_here"
echo "  in this checkout but NOT on $MAINLINE: $n_missing_there"
echo "  present both sides at DIFFERENT content: $n_diverged"

if [ "$n_missing_here" -gt 0 ]; then
  echo "⛔ THIS CHECKOUT IS MISSING DURABLE ENTRIES. Any wake summary written from it will be"
  echo "   incomplete, and will not say so. Missing:"
  printf '%s\n' "$MISSING_HERE" | sed 's|^|     |'
fi
if [ "$n_diverged" -gt 0 ]; then
  echo "⛔ SAME PATH, DIFFERENT CONTENT — the case a commit-distance check reports as clean:"
  printf '%s' "$DIVERGED" | sed 's|^|     |'
fi
if [ "$n_missing_there" -gt 0 ]; then
  echo "NOT REPLICATED — present here, absent from $MAINLINE, so these exist on this disk only:"
  printf '%s\n' "$MISSING_THERE" | sed 's|^|     |'
fi

# Commit distance is reported LAST and labelled, because it is the number people reach for first
# and it is the one that misled three seats today.
AHEAD="$(git rev-list --count "$MAINLINE..HEAD" 2>/dev/null || echo '?')"
BEHIND="$(git rev-list --count "HEAD..$MAINLINE" 2>/dev/null || echo '?')"
echo "commit distance, for context only and NOT the basis of anything above: $AHEAD ahead, $BEHIND behind"

[ "$n_missing_here" -gt 0 ] && exit 1
exit 0

#!/usr/bin/env python3
"""Row-by-row validator behind tools/dispatch-schema-check.sh.

This file holds NO vocabulary and NO schema. Everything it enforces arrives in the environment,
parsed out of the dispatch-ledger contract by the shell driver:

    DSC_FIELDS         "name\\trequired|optional\\ttype" per declared field
    DSC_OUTCOMES       "name\\tterminal|non-terminal" per declared outcome
    DSC_TIERS          declared tier names, one per line
    DSC_OUTCOME_LABELS declared outcome_label values, one per line
    DSC_FRICTION_CODES declared friction_code values, one per line
    DSC_TS_SOURCES     declared ts_source values, one per line
    DSC_LEDGER         path to the .jsonl to validate
    DSC_CONTRACT       path the declarations came from, for the header

Run it directly and it exits 2, because without those it has nothing to enforce and guessing a
schema is the defect this whole tool exists to prevent.

Exit codes: 0 every row conforms | 1 at least one row does not | 2 could not run the check.
"""

import json
import os
import re
import sys

ID_RE = re.compile(r"^DSP-\d+$")
# ISO 8601 with an explicit offset or a trailing Z. A naive local timestamp is rejected: rows are
# sorted by ts, and an offsetless stamp silently sorts wrong.
TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:?\d{2})$")

# Which closed vocabulary governs which key. The membership lists come from the contract; only
# the pairing lives here, and a key with no pairing is an open vocabulary by construction.
VOCAB_KEYS = {
    "tier": "DSC_TIERS",
    "outcome_label": "DSC_OUTCOME_LABELS",
    "friction_code": "DSC_FRICTION_CODES",
    "ts_source": "DSC_TS_SOURCES",
}

# Vocabularies whose contract block may legitimately be absent. An empty value means the contract
# does not declare it yet, which leaves the key an OPEN vocabulary rather than failing the run —
# and the header says which ones were unenforced, because an unenforced check that stays quiet is
# indistinguishable from one that passed.
OPTIONAL_VOCAB_KEYS = {
    "continuity": "DSC_CONTINUITY",
}


def env(name):
    v = os.environ.get(name)
    if v is None or v == "":
        sys.stderr.write(
            f"dispatch-schema-check.py: {name} not set. This validator is driven by\n"
            f"tools/dispatch-schema-check.sh, which parses the contract and passes the schema in.\n"
            f"Run that instead; this file declares no schema of its own, deliberately.\n"
        )
        sys.exit(2)
    return v


def type_ok(spec_type, val):
    """True when val satisfies the declared type word. bool is not an int here: JSON true/false
    landing in a counter field is a defect, not a 1."""
    if spec_type == "nullable-string":
        return val is None or isinstance(val, str)
    if spec_type == "nullable-int":
        return val is None or (isinstance(val, int) and not isinstance(val, bool))
    if spec_type == "string":
        return isinstance(val, str)
    if spec_type == "int":
        return isinstance(val, int) and not isinstance(val, bool)
    if spec_type == "number":
        return isinstance(val, (int, float)) and not isinstance(val, bool)
    if spec_type == "array":
        return isinstance(val, list)
    if spec_type == "object":
        return isinstance(val, dict)
    return False


def main():
    ledger = env("DSC_LEDGER")
    contract = env("DSC_CONTRACT")

    outcomes = {}
    for line in env("DSC_OUTCOMES").split("\n"):
        parts = line.split("\t")
        if len(parts) != 2:
            sys.stderr.write(f"dispatch-schema-check.py: unparseable DSC_OUTCOMES line: {line!r}\n")
            return 2
        outcomes[parts[0]] = parts[1]

    vocabs = {key: set(env(var).split("\n")) for key, var in VOCAB_KEYS.items()}
    unenforced = []
    for key, var in OPTIONAL_VOCAB_KEYS.items():
        raw = os.environ.get(var, "").strip()
        if raw:
            vocabs[key] = set(raw.split("\n"))
        else:
            unenforced.append(key)

    fields = {}
    for line in env("DSC_FIELDS").split("\n"):
        parts = line.split("\t")
        if len(parts) != 3:
            sys.stderr.write(f"dispatch-schema-check.py: unparseable DSC_FIELDS line: {line!r}\n")
            return 2
        fields[parts[0]] = {"required": parts[1] == "required", "type": parts[2]}

    required = {k for k, v in fields.items() if v["required"]}
    known = set(fields)

    problems = []          # (line_no, message)
    seen_ids = {}
    rows = 0

    with open(ledger, "r", encoding="utf-8") as fh:
        for n, raw in enumerate(fh, 1):
            if not raw.strip():
                continue
            rows += 1
            try:
                row = json.loads(raw)
            except Exception as exc:
                problems.append((n, f"unparseable JSON: {exc}"))
                continue
            if not isinstance(row, dict):
                problems.append((n, f"not a JSON object (got {type(row).__name__})"))
                continue

            rid = row.get("id")
            label = rid if isinstance(rid, str) else "<no id>"

            for key in sorted(required - set(row)):
                extra = ""
                # Name the near-miss, because the defect class is a plausible wrong key sitting
                # where the right one should be, still parsing, still counting.
                for present in sorted(set(row) - known):
                    extra = (f" (row carries undeclared key '{present}' — if that is this field "
                             f"under the wrong name, rename it to '{key}')")
                    break
                if key == "id":
                    extra = (" — the ledger predates this field; "
                             "tools/dispatch-write.sh --propose-ids emits a back-fill proposal")
                problems.append((n, f"{label}: missing required key '{key}'{extra}"))

            for key in sorted(set(row) - known):
                problems.append(
                    (n, f"{label}: unknown key '{key}' — not declared in the dispatch-fields block. "
                        f"Declare it there or remove it; nothing reads it as written.")
                )

            for key, spec in fields.items():
                if key not in row:
                    continue
                if not type_ok(spec["type"], row[key]):
                    got = "null" if row[key] is None else type(row[key]).__name__
                    problems.append(
                        (n, f"{label}: key '{key}' must be {spec['type']}, got {got}")
                    )

            if isinstance(rid, str):
                if not ID_RE.match(rid):
                    problems.append((n, f"{label}: id is not of the form DSP-NNN"))
                elif rid in seen_ids:
                    problems.append((n, f"{label}: duplicate id, already used on line {seen_ids[rid]}"))
                else:
                    seen_ids[rid] = n

            ts = row.get("ts")
            if isinstance(ts, str) and not TS_RE.match(ts):
                problems.append(
                    (n, f"{label}: ts {ts!r} is not ISO 8601 with an explicit offset or trailing Z")
                )

            task = row.get("task")
            if isinstance(task, str) and not task.strip():
                problems.append(
                    (n, f"{label}: 'task' is empty — the row records a dispatch that cannot be "
                        f"identified by anything but its id")
                )

            oc = row.get("outcome")
            if isinstance(oc, str) and oc not in outcomes:
                problems.append(
                    (n, f"{label}: outcome '{oc}' is not in the contract's outcome-vocabulary block")
                )

            for key, allowed in vocabs.items():
                val = row.get(key)
                if val is None:
                    continue
                if isinstance(val, str) and val not in allowed:
                    problems.append(
                        (n, f"{label}: {key} '{val}' is not in the contract's "
                            f"{key.replace('_', '-')}-vocabulary block")
                    )

    terminal = sorted(k for k, v in outcomes.items() if v == "terminal")
    nonterminal = sorted(k for k, v in outcomes.items() if v != "terminal")

    print(f"contract:     {contract}")
    print(f"ledger:       {ledger}")
    print(f"rows:         {rows}")
    print(f"required:     {' '.join(sorted(required))}")
    print(f"terminal:     {' '.join(terminal)}")
    print(f"non-terminal: {' '.join(nonterminal)}")
    if unenforced:
        # Named rather than silent: a vocabulary nobody declared and a vocabulary that passed look
        # identical from the outside, and this fleet spent today finding checks that could not fail.
        print(f"unenforced:   {' '.join(sorted(unenforced))} "
              "(no vocabulary block in the contract, so any value is accepted)")

    if not problems:
        print()
        print("OK — every row carries exactly the declared keys, with declared values.")
        return 0

    affected = len({n for n, _ in problems})
    print()
    print(f"FAIL — {len(problems)} problem(s) across {affected} row(s):")
    for n, msg in problems:
        print(f"  L{n}: {msg}")
    return 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env zsh
# credential-scan.sh — find credential-shaped content and report WHERE it is, never WHAT it is.
#
# ⛔ WHY THIS EXISTS, AND IT IS NOT HYPOTHETICAL. On 2026-08-24 a live Linear API key was found in
# `tools/merge-backup-pr.log`, a git-tracked file, five occurrences including committed history. It
# got there because the scanner that CAUGHT it printed the matching lines as its refusal message,
# and the run was teed to that log. THE CREDENTIAL SCANNER WROTE OUT THE SECRET IT CAUGHT.
#
# A second copy of the same shape sat unfired in `sync-to-lintel.sh`, using `grep` as both the test
# and the printer. Both call sites now use this function instead.
#
# ── THE RULE ─────────────────────────────────────────────────────────────────────────────
# The test and the report are separate operations. `grep -q` decides; a second pass locates. The
# matched text is never captured into a variable, never echoed, never logged.
#
# ── AND THE OPPOSITE FAILURE, WHICH IS REAL TOO ──────────────────────────────────────────
# A refusal saying only "something was found" sends a human hunting, and hunting means opening the
# file and reading the secret anyway — so the quiet version must still be ACTIONABLE. This names the
# pattern, the count, and the file (or the diff line), which is enough to act on without display.
#
# ── WHAT IT DELIBERATELY DOES NOT DO ─────────────────────────────────────────────────────
# It does not decide whether a hit is real. Prose that discusses credentials by name is not a
# credential, and `merge-backup-pr.sh` learned that live: an audit note saying "42 ghp_ files"
# refused a backup until the patterns were given bodies. The patterns below all require a body.
#
# usage:  cred_scan_stdin <label>     # reads stdin; 0 = clean, 1 = found (report on stdout)
# The caller decides what to do about a 1. This function never exits the shell.

cred_scan_stdin() {
  emulate -L zsh
  local label="${1:-input}"
  local body tmp found=0
  tmp="$(mktemp)" || return 2
  cat > "$tmp"

  # name → pattern. Every pattern requires a BODY, so prose naming a prefix does not match.
  local -a names pats
  names=( "anthropic key" "linear key" "github token" "github oauth" "github pat"
          "aws access key" "private key block" "jwt" "slack token" )
  pats=( 'sk-ant-[A-Za-z0-9_-]{16,}'
         'lin_api_[A-Za-z0-9]{16,}'
         'ghp_[A-Za-z0-9]{36}'
         'gho_[A-Za-z0-9]{36}'
         'github_pat_[A-Za-z0-9_]{22,}'
         'AKIA[A-Z0-9]{12}'
         'BEGIN [A-Z ]*PRIVATE KEY'
         'eyJ[A-Za-z0-9_-]{16,}\.eyJ'
         'xox[baprs]-[A-Za-z0-9-]{10,}' )

  local i n where
  for (( i = 1; i <= ${#names}; i++ )); do
    # THE TEST. -q: decides and prints nothing. The matched text never exists as a value here.
    if /usr/bin/grep -qE "${pats[$i]}" "$tmp"; then
      (( found++ ))
      # THE REPORT, built from line NUMBERS only. `cut -d: -f1` discards the matched text before it
      # can reach a variable — the whole point of the separation.
      n="$(/usr/bin/grep -cE "${pats[$i]}" "$tmp")"
      where="$(/usr/bin/grep -nE "${pats[$i]}" "$tmp" | cut -d: -f1 | tr '\n' ',' | sed 's/,$//')"
      if (( found == 1 )); then
        print -r -- "  credential-shaped content in ${label}. Locations only — nothing is reproduced here."
      fi
      print -r -- "    ${names[$i]}: ${n} hit(s) at line(s) ${where}"
    fi
  done

  # For a unified diff, name the FILES rather than only diff-relative line numbers: a path is what
  # a person acts on, and it is not secret.
  if (( found )); then
    local files
    files="$(/usr/bin/grep -E '^\+\+\+ b/' "$tmp" | sed 's|^+++ b/||' | sort -u | tr '\n' ' ')"
    [[ -n "$files" ]] && print -r -- "    files in this diff: ${files}"
    print -r -- "    to inspect deliberately, open the location above yourself — this tool will not print it."
  fi

  rm -f "$tmp"
  (( found )) && return 1
  return 0
}

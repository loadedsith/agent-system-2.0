#!/bin/sh
# requests-schema-check.sh — does every row of REQUESTS.jsonl carry the keys the contract declares?
#
# WHY THIS FILE EXISTS. On 2026-08-20 fifteen rows were appended with the request text under the
# key `ask` instead of `request`. Both hooks that surface open obligations read `request`
# (hooks/savepoint-restore.sh, hooks/savepoint-guard.mjs), so those rows rendered as blank lines:
# counted, listed by id, and nameless. Nothing failed at write time, because a row with the wrong
# key is still valid JSON and still counts. tools/state-vocab-check.sh already guards the ledger's
# state *values*; nothing guarded its *keys*. This is that checker.
#
# THE SCHEMA IS NOT DEFINED HERE, deliberately — same rule as tools/request-states.sh. It is read
# out of the request-ledger contract's `request-fields` and `touch-vocabulary` blocks, and the state vocabulary
# comes from tools/request-states.sh, which owns it. Three vocabularies, three declarations, no
# copies. If the contract cannot be parsed this exits 2 rather than inventing a schema.
#
# Usage:
#   requests-schema-check.sh [ledger.jsonl] [request-ledger-contract.md]
#   requests-schema-check.sh --required            # required key names, one per line
#   requests-schema-check.sh --types               # "key<TAB>string|array", one per line
#   requests-schema-check.sh --touch-types         # declared touch type names, one per line
#   requests-schema-check.sh --selftest            # prove the checker can fail, one defect class
#                                                  # at a time, against throwaway fixtures
#
# Exit codes: 0 every row conforms | 1 at least one row does not | 2 could not run the check.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
CONTRACT_DEFAULT="$ORCH/contracts/request-ledger.md"

# The parse is deliberately the same shape as tools/state-vocab-check.sh and
# tools/request-states.sh, which own the state vocabulary. Those two duplicate the awk, not the
# vocabulary; this file follows the same rule for the field and touch blocks.
parse_fields() {
  awk '
    /request-fields:begin/ { inblock = 1; next }
    /request-fields:end/   { inblock = 0; next }
    inblock {
      line = $0
      sub(/^[[:space:]]*>[[:space:]]*/, "", line)
      if (match(line, /^-[[:space:]]*`[a-z_-]+`[[:space:]]*(—|--)[[:space:]]*(required|optional)[[:space:]]*(—|--)[[:space:]]*(string|array)/)) {
        name = line; sub(/^-[[:space:]]*`/, "", name); sub(/`.*$/, "", name)
        rest = line; sub(/^-[[:space:]]*`[a-z_-]+`[[:space:]]*(—|--)[[:space:]]*/, "", rest)
        req = (rest ~ /^required/) ? "required" : "optional"
        sub(/^(required|optional)[[:space:]]*(—|--)[[:space:]]*/, "", rest)
        typ = (rest ~ /^array/) ? "array" : "string"
        print name "\t" req "\t" typ
      }
    }
  ' "$1"
}

parse_touch_types() {
  awk '
    /touch-vocabulary:begin/ { inblock = 1; next }
    /touch-vocabulary:end/   { inblock = 0; next }
    inblock {
      line = $0
      sub(/^[[:space:]]*>[[:space:]]*/, "", line)
      if (match(line, /^-[[:space:]]*`[a-z_-]+`[[:space:]]*(—|--)/)) {
        name = line; sub(/^-[[:space:]]*`/, "", name); sub(/`.*$/, "", name)
        print name
      }
    }
  ' "$1"
}

case "${1:-}" in
  --required)    parse_fields "${2:-${LINTEL_STATE_CONTRACT:-$CONTRACT_DEFAULT}}" | awk -F'\t' '$2=="required"{print $1}'; exit 0 ;;
  --types)       parse_fields "${2:-${LINTEL_STATE_CONTRACT:-$CONTRACT_DEFAULT}}" | cut -f1,3; exit 0 ;;
  --touch-types) parse_touch_types "${2:-${LINTEL_STATE_CONTRACT:-$CONTRACT_DEFAULT}}"; exit 0 ;;
  --selftest)    shift; SELFTEST=1; CONTRACT="${1:-${LINTEL_STATE_CONTRACT:-$CONTRACT_DEFAULT}}" ;;
  *)             SELFTEST=0; LEDGER="${1:-$ORCH/state/REQUESTS.jsonl}"; CONTRACT="${2:-${LINTEL_STATE_CONTRACT:-$CONTRACT_DEFAULT}}" ;;
esac

command -v python3 >/dev/null || { echo "preflight: python3 not found" >&2; exit 2; }
[ -f "$CONTRACT" ] || { echo "preflight: no request-ledger contract at $CONTRACT" >&2; exit 2; }
[ -f "$ORCH/tools/requests-schema-check.py" ] || {
  echo "preflight: validator missing at $ORCH/tools/requests-schema-check.py" >&2; exit 2; }

run_check() {
  _ledger="$1"
  _fields="$(parse_fields "$CONTRACT")"
  _touch="$(parse_touch_types "$CONTRACT")"
  _states="$(LINTEL_STATE_CONTRACT="$CONTRACT" sh "$ORCH/tools/request-states.sh" --all 2>/dev/null | cut -f1)"
  [ -n "$_fields" ] || { echo "FAIL: no field declarations found between the request-fields markers in $CONTRACT" >&2; return 2; }
  [ -n "$_touch" ]  || { echo "FAIL: no touch types found between the touch-vocabulary markers in $CONTRACT" >&2; return 2; }
  [ -n "$_states" ] || { echo "FAIL: the state vocabulary could not be read via tools/request-states.sh" >&2; return 2; }
  [ -f "$_ledger" ] || { echo "preflight: no ledger at $_ledger" >&2; return 2; }
  RSC_FIELDS="$_fields" RSC_TOUCH="$_touch" RSC_STATES="$_states" \
  RSC_LEDGER="$_ledger" RSC_CONTRACT="$CONTRACT" \
    python3 "$ORCH/tools/requests-schema-check.py"
}

if [ "$SELFTEST" -ne 1 ]; then
  run_check "$LEDGER"
  exit $?
fi

# --selftest. A checker that has only ever passed is not evidence. Build one throwaway fixture per
# defect class, require a non-zero exit from each, then require exit 0 from a conforming fixture.
# Fixtures live in a fresh mktemp -d and are left there; nothing here writes near the real ledger.
d="$(mktemp -d)" || exit 2
echo "selftest: fixtures in $d (throwaway; the real ledger is never touched)"
good='{"id":"REQ-001","ts":"2026-08-20T10:00:00Z","request":"do the thing","state":"open","touches":[{"type":"original","text":"do the thing"}],"note":""}'

printf '%s\n' \
  "wrong-key-ask-not-request|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"ask\":\"do it\",\"state\":\"open\",\"touches\":[],\"note\":\"\"}" \
  "missing-required-key|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"state\":\"open\",\"touches\":[],\"note\":\"\"}" \
  "unknown-key|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"request\":\"do it\",\"state\":\"open\",\"touches\":[],\"note\":\"\",\"priority\":\"high\"}" \
  "unknown-state|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"request\":\"do it\",\"state\":\"kumquat\",\"touches\":[],\"note\":\"\"}" \
  "unparseable-line|{\"id\":\"REQ-002\", this is not json" \
  "not-an-object|[\"id\",\"REQ-002\"]" \
  "wrong-type-for-key|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"request\":\"do it\",\"state\":\"open\",\"touches\":\"none\",\"note\":\"\"}" \
  "empty-request-text|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"request\":\"\",\"state\":\"open\",\"touches\":[],\"note\":\"\"}" \
  "touch-missing-text|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"request\":\"do it\",\"state\":\"open\",\"touches\":[{\"type\":\"ack\"}],\"note\":\"\"}" \
  "touch-unknown-type|{\"id\":\"REQ-002\",\"ts\":\"2026-08-20T10:00:00Z\",\"request\":\"do it\",\"state\":\"open\",\"touches\":[{\"type\":\"decision\",\"text\":\"x\"}],\"note\":\"\"}" \
  "duplicate-id|$good" \
  "malformed-id|{\"id\":\"request-2\",\"ts\":\"2026-08-20T10:00:00Z\",\"request\":\"do it\",\"state\":\"open\",\"touches\":[],\"note\":\"\"}" \
  "malformed-timestamp|{\"id\":\"REQ-002\",\"ts\":\"tuesday\",\"request\":\"do it\",\"state\":\"open\",\"touches\":[],\"note\":\"\"}" \
| while IFS='|' read -r name row; do
    f="$d/$name.jsonl"
    printf '%s\n%s\n' "$good" "$row" > "$f"
    out="$(run_check "$f" 2>&1)"; rc=$?
    if [ "$rc" -eq 0 ]; then
      echo "SELFTEST FAILED: the checker PASSED a ledger carrying defect class '$name'" >&2
      printf '%s\n' "$out" | sed 's/^/      /' >&2
      : > "$d/.failed"
    else
      echo "  caught  $name  (exit $rc)"
      printf '%s\n' "$out" | grep '^  L' | head -1 | sed 's/^/       /'
    fi
  done

printf '%s\n' "$good" > "$d/conforming.jsonl"
if run_check "$d/conforming.jsonl" >/dev/null 2>&1; then
  echo "  passed  a conforming one-row ledger (exit 0)"
else
  echo "SELFTEST FAILED: the checker rejected a conforming ledger" >&2
  run_check "$d/conforming.jsonl" 2>&1 | sed 's/^/      /' >&2
  : > "$d/.failed"
fi

if [ -f "$d/.failed" ]; then
  echo "SELFTEST FAILED — see above. Fixtures kept at $d for inspection." >&2
  exit 1
fi
echo "selftest: OK — every defect class above was caught, and a conforming ledger passed."
exit 0

#!/bin/sh
# request-issues-reconcile.sh — reconcile applicable non-terminal ledger rows to GitHub Issues.
#
# This is the disposable-hand front door. REQUESTS.jsonl stays authoritative: the Python core
# inventories and validates the complete open+closed tracker, creates or reopens only missing
# applicable issues under --apply, and this wrapper records canonical issue URLs back into the
# existing row `touches` field through request-amend.sh. Lintel and Tinker dispatch this command;
# they do not perform the network inventory or mutations inline.
#
# Usage:
#   request-issues-reconcile.sh [request_issues_reconcile.py options]
#
# Common forms:
#   request-issues-reconcile.sh --inventory /path/to/inventory.md
#   request-issues-reconcile.sh --apply --only REQ-NNN
#   request-issues-reconcile.sh --apply --inventory /path/to/inventory.md \
#       --actions-file /path/to/actions.json --url-map /path/to/urls.json
#
# The default ledger is orchestrator/state/REQUESTS.jsonl and the configured private tracker is
# thewolff/lintel-tasks. --apply is the only mode that changes GitHub or the ledger.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ORCH/tools/request_issues_reconcile.py"
AMEND="$ORCH/tools/request-amend.sh"
LEDGER="$ORCH/state/REQUESTS.jsonl"
REPO="thewolff/lintel-tasks"
APPLY=0
URL_DEST=""

need=""
for arg in "$@"; do
  if [ -n "$need" ]; then
    case "$need" in
      ledger) LEDGER="$arg" ;;
      repo) REPO="$arg" ;;
      url) URL_DEST="$arg" ;;
    esac
    need=""
    continue
  fi
  case "$arg" in
    --ledger) need="ledger" ;;
    --repo) need="repo" ;;
    --url-map) need="url" ;;
    --apply) APPLY=1 ;;
  esac
done

[ -z "$need" ] || { echo "request-issues-reconcile: --$need needs a value" >&2; exit 2; }
[ -f "$CORE" ] || { echo "request-issues-reconcile: core missing at $CORE" >&2; exit 2; }
[ -f "$AMEND" ] || { echo "request-issues-reconcile: ledger writer missing at $AMEND" >&2; exit 2; }
[ -f "$LEDGER" ] || { echo "request-issues-reconcile: ledger missing at $LEDGER" >&2; exit 2; }
command -v gh >/dev/null || { echo "request-issues-reconcile: gh is not installed" >&2; exit 2; }
command -v python3 >/dev/null || { echo "request-issues-reconcile: python3 is not installed" >&2; exit 2; }

OWNER="${REPO%%/*}"
TOKEN="$(gh auth token --user "$OWNER" 2>/dev/null || true)"
[ -n "$TOKEN" ] || {
  echo "request-issues-reconcile: gh has no token for '$OWNER', owner of $REPO" >&2
  exit 2
}

TMP="$(mktemp -d)" || { echo "request-issues-reconcile: mktemp failed" >&2; exit 2; }
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
MAP="$TMP/urls.json"

GH_TOKEN="$TOKEN" python3 "$CORE" --ledger "$LEDGER" --repo "$REPO" "$@" --url-map "$MAP"
rc=$?
[ "$rc" -eq 0 ] || exit "$rc"

if [ -n "$URL_DEST" ]; then
  mkdir -p "$(dirname "$URL_DEST")" || exit 2
  cp "$MAP" "$URL_DEST" || exit 2
fi

if [ "$APPLY" -eq 1 ]; then
  if python3 -c 'import json, sys; sys.exit(0 if json.load(open(sys.argv[1], encoding="utf-8")) else 1)' "$MAP"; then
    sh "$AMEND" --ledger "$LEDGER" --batch-context-map "$MAP" \
      --why "GitHub issue reconciliation: preserve canonical execution-surface URL; local ledger remains authoritative"
    rc=$?
    [ "$rc" -eq 0 ] || exit "$rc"
  else
    echo "request-issues-reconcile: no applicable issue URLs to preserve"
  fi
fi

exit 0

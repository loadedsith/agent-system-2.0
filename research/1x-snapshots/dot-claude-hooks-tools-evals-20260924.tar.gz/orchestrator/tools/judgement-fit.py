#!/usr/bin/env python3
"""judgement-fit — the per-section cap verdict AT WRITE TIME, before the generator runs.

WHY THIS EXISTS. savepoint-generate.py enforces the per-section byte caps on the judgement file
only when it is asked to build a save point. So the author's loop was: write the prose -> run the
generator -> learn the verdict -> hand-cut -> run the generator again. Measured by the run that
commissioned this tool (its figure, not re-derived here): 164 refusals across 554 generator runs,
in 81 episodes averaging 2.02 hand-rewrite rounds each.

⛔ THIS DOES NOT REDUCE THE CUTTING. Every byte over cap still has to be cut by hand, by a person,
and that is the part that costs. What this deletes is the GENERATE STEP from the failure loop: the
verdict arrives while the file is open, with a per-section byte target attached, instead of after
the writing is finished. The loop goes from write->generate->learn->cut->generate to
write->check->cut->check. Same cutting. Earlier, and with a destination.

SINGLE SOURCE OF TRUTH. The caps and the block-splitter are IMPORTED from savepoint-generate.py,
never copied. A second copy of CAPS would drift silently and the drift would show up as a save
point that passed this check and was refused by the generator -- exactly the failure this removes.

READ-ONLY. Never writes, trims, or edits anything.

EXIT  0 every section within cap · 1 at least one section over cap · 2 usage/IO/assert failure.

USAGE
  judgement-fit.py                    # the live JUDGEMENT.md
  judgement-fit.py path/to/draft.md   # a draft, before it is installed
  judgement-fit.py --tsv [FILE]       # machine-readable: section<TAB>bytes<TAB>cap<TAB>blocks
"""
import importlib.util, os, sys

GEN = os.environ.get("LINTEL_SAVEPOINT_GENERATE",
                     "/Users/jowolff/.claude/orchestrator/tools/savepoint-generate.py")
STATE = os.environ.get("LINTEL_STATE", "/Users/jowolff/.claude/orchestrator/state")
DEFAULT_TARGET = os.path.join(STATE, "JUDGEMENT.md")


def die(msg):
    sys.stderr.write("judgement-fit: %s\n" % msg)
    sys.exit(2)


def load_generator():
    """Import savepoint-generate.py and ASSERT the two things we take from it are really there.

    An import that half-succeeds is the false-clean this whole tool is meant to avoid: a missing
    CAPS dict would default to 'nothing is over cap' and report a confident PASS from no data.
    """
    if not os.path.isfile(GEN):
        die("generator not found at %s -- cannot read the caps; refusing to guess them" % GEN)
    spec = importlib.util.spec_from_file_location("savepoint_generate", GEN)
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
    except SystemExit:
        die("generator exited during import; cannot read caps from %s" % GEN)
    except Exception as e:
        die("generator failed to import (%s: %s); cannot read caps from %s" % (type(e).__name__, e, GEN))
    caps = getattr(mod, "CAPS", None)
    if not isinstance(caps, dict) or not caps:
        die("generator exposes no non-empty CAPS dict; refusing to report a verdict from no caps")
    for k, v in caps.items():
        if not isinstance(v, int) or v <= 0:
            die("cap for section %s is not a positive int (%r)" % (k, v))
    split = getattr(mod, "split_blocks", None)
    if not callable(split):
        die("generator exposes no split_blocks(); refusing to guess block granularity")
    return caps, split, getattr(mod, "TRUNC_NOTE", "")


def read_sections(path, caps):
    """Parse `## NAME` sections. Same shape savepoint-generate.read_judgement uses.

    ASSERT THE INPUT. Every measurement below is meaningless if the file is missing, empty, or
    contains no recognised section heading -- and each of those states would otherwise produce a
    clean PASS from nothing. Six false cleans on this machine on 2026-08-25 had exactly that shape.
    """
    if not os.path.isfile(path):
        die("not a readable file: %s" % path)
    raw = open(path, "rb").read()
    if len(raw.strip()) == 0:
        die("input is empty: %s -- a PASS from an empty file is a false clean" % path)
    text = raw.decode("utf-8")
    import re
    sections, order, cur = {}, [], None
    for line in text.splitlines():
        m = re.match(r"^##\s+(\w+)\s*$", line)
        if m:
            cur = m.group(1).upper()
            sections[cur] = []
            order.append(cur)
        elif cur:
            sections[cur].append(line)
    if not sections:
        die("no `## SECTION` headings found in %s (%d bytes read) -- refusing to report a clean "
            "verdict on a file this tool could not parse" % (path, len(raw)))
    sections = {k: "\n".join(v).strip() for k, v in sections.items()}
    unknown = sorted(set(sections) - set(caps))
    if unknown:
        die("unknown section(s) %s in %s; the generator will refuse these. Allowed: %s"
            % (unknown, path, sorted(caps)))
    missing = sorted(set(caps) - set(sections))
    return sections, order, missing, len(raw)


def main():
    args = [a for a in sys.argv[1:]]
    tsv = False
    if "--tsv" in args:
        tsv = True
        args.remove("--tsv")
    if args and args[0] in ("-h", "--help"):
        sys.stdout.write(__doc__)
        return 2
    target = os.path.abspath(args[0]) if args else DEFAULT_TARGET

    caps, split_blocks, _note = load_generator()
    sections, order, missing, filebytes = read_sections(target, caps)

    rows = []
    for name in order:
        body = sections[name]
        b = len(body.encode())
        cap = caps[name]
        blocks = len(split_blocks(body)) if body else 0
        rows.append((name, b, cap, blocks))

    over = [r for r in rows if r[1] > r[2]]
    unfittable = [r for r in over if r[3] < 2]

    if tsv:
        for name, b, cap, blocks in rows:
            sys.stdout.write("%s\t%d\t%d\t%d\n" % (name, b, cap, blocks))
        sys.stdout.write("caps_from\t%s\n" % GEN)
        sys.stdout.write("file\t%s\t%d\n" % (target, filebytes))
        return 1 if over else 0

    # VERDICT FIRST. This is the line the author acts on, so nothing precedes it.
    if not over:
        worst = min((c - b, n) for n, b, c, _ in rows) if rows else (0, "")
        print("FITS: every section within cap. Tightest is %s with %d bytes to spare."
              % (worst[1], worst[0]))
    elif unfittable:
        print("OVER CAP, AND THE GENERATOR WILL REFUSE: %s"
              % ", ".join("%s (%d over, %d block%s -- needs >=2 to be fitted)"
                          % (n, b - c, k, "" if k == 1 else "s") for n, b, c, k in unfittable))
    else:
        print("OVER CAP by %d bytes total in %d section(s). The generator would FIT (drop the "
              "last-listed blocks) rather than refuse -- cut by hand to keep them."
              % (sum(b - c for _, b, c, _ in over), len(over)))

    print("")
    print("file:  %s  (%d bytes)" % (target, filebytes))
    print("caps:  %s" % GEN)
    if missing:
        print("note:  section(s) %s absent from this file; the generator emits them empty."
              % ", ".join(missing))
    print("")
    print("%-9s %8s %8s %9s %7s  %s" % ("SECTION", "BYTES", "CAP", "OVER/FREE", "BLOCKS", "VERDICT"))
    print("%-9s %8s %8s %9s %7s  %s" % ("-" * 9, "-" * 8, "-" * 8, "-" * 9, "-" * 7, "-" * 34))
    for name, b, cap, blocks in rows:
        d = b - cap
        if d > 0 and blocks < 2:
            v = "CUT %d BYTES -- generator REFUSES" % d
        elif d > 0:
            v = "CUT %d BYTES (else tail blocks drop)" % d
        elif cap - b < 120:
            v = "%d spare -- one sentence over" % (cap - b)
        else:
            v = "%d spare" % (cap - b)
        print("%-9s %8d %8d %9s %7d  %s" % (name, b, cap, ("+%d" % d) if d > 0 else str(cap - b),
                                            blocks, v))
    print("")
    print("⛔ This does not cut anything for you. Every byte over cap is still a hand cut.")
    print("   What it removes is the generate-to-find-out step: the number above is the same")
    print("   number savepoint-generate.py would print, available while the file is still open.")
    return 1 if over else 0


if __name__ == "__main__":
    sys.exit(main())

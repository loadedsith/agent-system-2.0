#!/usr/bin/env python3
"""Recover seat_message payloads from senders' own transcripts.

WHY THIS EXISTS. The seat mailbox at ~/.omp/agent/seat-mailboxes holds only `acks`
and `inbox`; the drain deletes the only copy of a payload. On 2026-09-16 that
destroyed fourteen replies addressed to Lintel. The sender's own session transcript
retains the full `arguments.message`, so it is the recovery path of record until an
archive-on-drain exists.

TWO RECORD SHAPES, AND MISSING ONE IS A SILENT FALSE NEGATIVE. A seat_message call
appears either as a top-level {"type":"toolCall"} record OR as a toolCall part inside
a {"type":"message"} record with role "assistant". A filter that reads only the first
reports "no replies" while replies are sitting there — measured, 2026-09-16 08:37Z.

    seat-mail-recover.py --since 2026-09-16T08:00:00Z            # list every payload
    seat-mail-recover.py --since ... --seat wren --full          # print them verbatim
    seat-mail-recover.py --since ... --to lintel --full
"""
import argparse
import glob
import json
import os

ROOT = os.path.expanduser("~/.omp/agent/seat-sessions")


def payloads(path, since):
    """Yield (timestamp, arguments) for every seat_message call at or after `since`."""
    with open(path, encoding="utf-8", errors="replace") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except ValueError:
                continue
            stamp = record.get("timestamp", "")
            if stamp < since:
                continue
            call = record.get("toolCall")
            if record.get("type") == "toolCall" and isinstance(call, dict):
                if call.get("name") == "seat_message":
                    yield stamp, call.get("arguments") or {}
            content = (record.get("message") or {}).get("content")
            if isinstance(content, list):
                for part in content:
                    if not isinstance(part, dict):
                        continue
                    if part.get("type") == "toolCall" and part.get("name") == "seat_message":
                        yield stamp, part.get("arguments") or part.get("input") or {}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--since", required=True, help="ISO timestamp floor, e.g. 2026-09-16T08:00:00Z")
    parser.add_argument("--seat", help="only this sender slug")
    parser.add_argument("--to", help="only payloads addressed to this target (case-insensitive)")
    parser.add_argument("--full", action="store_true", help="print the payload verbatim")
    args = parser.parse_args()

    seats = [args.seat] if args.seat else sorted(
        name for name in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, name))
    )
    found = 0
    for seat in seats:
        for path in sorted(glob.glob(os.path.join(ROOT, seat, "*.jsonl"))):
            for stamp, arguments in payloads(path, args.since):
                target = str(arguments.get("target", "?"))
                if args.to and target.lower() != args.to.lower():
                    continue
                message = arguments.get("message") or ""
                found += 1
                print(f"{seat}\t{stamp}\t-> {target}\t{len(message)} chars")
                if args.full:
                    print(message)
                    print("-" * 78)
    if not found:
        print(f"no seat_message payloads at or after {args.since}"
              f"{' from ' + args.seat if args.seat else ''}"
              f"{' to ' + args.to if args.to else ''}")


if __name__ == "__main__":
    main()

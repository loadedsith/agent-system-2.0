# judge — an evaluator that is not the dispatcher

`dispatch-contract.sh` writes a `done_when` clause set into `runs/<run>/CONTRACTS.jsonl` before a
worker starts. Nothing in this fleet judged against it. `dispatch-contract.sh check` pairs
existence only, and says so itself: *"This compares agent slugs, not dispatches."*

## The trap this exists to avoid

The obvious build hands a judge the worker's sealed report and asks whether it meets the contract.
That is self-grading once removed: the worker wrote the claim *and* the only evidence the judge
sees. A worker that misdescribes its run passes cleanly.

So the rule, enforced in the brief text and mechanically in `lint`:

> **The sealed report is the CLAIM UNDER TEST. It is never the proof.**
> The proof is the harness-written subagent transcript, and the artifacts on disk.
> A clause supported only by the report's own assertion is a **fail**, not a pass.

This is the same independence `transcript-auditor` relies on: the harness writes the transcript,
and the worker cannot author it.

## Use

    node judge.mjs evidence <run-id> <agent-slug> [--contract-file F] [--agent-id ID]
    node judge.mjs brief    <run-id> <agent-slug> [same] [--verdict-out PATH]
    node judge.mjs lint     <verdict-jsonl> [--contract-file F | --run R --agent A]
    node judge.mjs selftest

`evidence` builds the dossier: contract clauses, the paired transcript (or a loud NO TRANSCRIPT
PAIRED), the artifacts with hashes, the sealed report marked NOT EVIDENCE with a live re-hash
against its manifest line, and a per-clause worksheet with judgeability prechecks.

`brief` wraps that dossier in a dispatch prompt for a judge agent, with the verdict schema and the
lint command it must run.

`lint` is the falsifiability guard. It **rejects** any clause marked `pass` whose `evidence_class`
is `report` or `none`, any pass with an empty `evidence` field, any clause missing
`what_a_fail_would_look_like`, and (given the contract) any `done_when` clause left unjudged.

`selftest` proves lint can fail: it builds a rubber-stamp verdict that must be rejected and an
evidence-backed one that must be accepted, and exits non-zero if either goes the wrong way.

## What a clean verdict rules out, and what it does not

**Rules out:** that a clause passed on the worker's own say-so. Every pass names a transcript
record, a command with its output, or a file the judge hashed itself.

**Does not rule out:** that the cited evidence says what the judge claims — `lint` checks the
*shape* of a verdict, never its truth. Nor that the `done_when` clauses were worth passing; a weak
contract passed honestly tells you nothing. Nor anything about a dispatch that never declared a
contract at all.

## Two limits worth knowing before you trust it

1. **Pairing a contract to a transcript is inferred, not joined.** No `LEDGER.jsonl` row carries an
   agentId, so without `--agent-id` the pairing is `agentType` plus a time window, and the dossier
   prints that basis and its ambiguity rather than presenting a match as fact.
2. **`state/tools/transcript-extract.mjs` hardcodes one project directory** (`-Users-jowolff`) and
   is blind to sessions launched from any other cwd — including the live fleet's own, under
   `-Users-jowolff--claude`. This tool walks every project directory and hands the extractor
   absolute paths, which its `resolve()` accepts. The extractor is not modified; `state/tools/` is
   not this tool's to edit.

## Reversal

This directory is new and nothing outside it references it. To reverse the whole thing, remove
`/Users/jowolff/.claude/orchestrator/tools/judge/`. No file outside that directory was changed to
install it.

## A third limit, added 2026-08-24 after a coordinator relay

**`end_turn` is not a completion signal on this harness, so `--returns` is not a "did the worker
finish" test.** Measured across every subagent transcript written on 2026-08-24 (21 files):
**14 carry zero `stop_reason=end_turn` records**, and most of those workers finished normally.
`transcript-extract.mjs --returns` and `--packet` both filter on that field, so a judge reading
`(no end_turn assistant message)` as "the worker returned nothing" will be wrong on two thirds of
this fleet's dispatches. The dossier now prints that warning next to the `--returns` line.

Judge from `--tools` (what the worker DID) and the artifacts. `--grep` is not `end_turn`-gated and
will find the worker's words when you need them.

**And "Request interrupted by user" is not a reliable death marker.** It also appears when a
coordinator sends a mid-run message to a live worker — verified on this tool's own build
transcript, which carries the marker and did not die.

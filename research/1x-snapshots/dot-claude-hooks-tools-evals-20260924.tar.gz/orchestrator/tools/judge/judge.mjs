#!/usr/bin/env node
// judge.mjs — an evaluator that is not the dispatcher, and not the worker.
//
// WHY THIS EXISTS. dispatch-contract.sh records a done-condition BEFORE a worker runs, and
// nothing in this fleet ever judges against it. Its own `check` subcommand stops at existence
// pairing and says so: "This compares agent slugs, not dispatches".
//
// THE TRAP THIS TOOL IS BUILT AROUND. The obvious judge is handed the worker's sealed report and
// asked whether it meets the contract. That is self-grading once removed: the worker wrote both
// the claim and the only evidence the judge sees, so a worker that misdescribes its own run
// passes cleanly. So:
//
//     THE SEALED REPORT IS THE CLAIM UNDER TEST. IT IS NEVER THE PROOF.
//     The proof is the harness-written subagent transcript and the artifacts on disk.
//
// A clause supported only by the report's own assertion is a FAIL, not a pass. `lint` enforces
// that mechanically so it does not depend on a judge remembering it.
//
// WHAT THIS TOOL DOES NOT DO. It decides nothing. `evidence` gathers, `brief` formats a dispatch,
// `lint` rejects verdicts that cannot be evidence-backed. The judging is done by a dispatched
// agent reading the dossier; this file is the plumbing that makes that agent's job falsifiable.
//
// usage:
//   node judge.mjs evidence <run-id> <agent-slug> [--contract-file F] [--agent-id ID] [--window-min N]
//   node judge.mjs brief    <run-id> <agent-slug> [same flags] [--verdict-out PATH]
//   node judge.mjs lint     <verdict-jsonl> [--contract-file F | --run R --agent A]
//   node judge.mjs selftest
//
// Exit codes: 0 ok | 1 refused / verdict rejected | 2 could not run.
//
// READ-ONLY on everything under state/. This file writes nothing except where you point `lint`
// and `selftest`, and selftest writes only into a fresh mkdtemp directory.

import { readFileSync, readdirSync, existsSync, statSync, writeFileSync, mkdtempSync } from 'node:fs';
import { join } from 'node:path';
import { homedir, tmpdir } from 'node:os';
import { createHash } from 'node:crypto';

const HOME = homedir();
const STATE = join(HOME, '.claude', 'orchestrator', 'state');
const RUNS = join(STATE, 'runs');
const PROJECTS = join(HOME, '.claude', 'projects');
const EXTRACT = join(STATE, 'tools', 'transcript-extract.mjs');
const SELF = join(HOME, '.claude', 'orchestrator', 'tools', 'judge', 'judge.mjs');

const EVIDENCE_CLASSES = ['transcript', 'artifact', 'report', 'none'];
const VERDICTS = ['pass', 'fail', 'unjudgeable'];

function die(msg, code = 2) { console.error('judge: ' + msg); process.exit(code); }
function refuse(msg) { die('REFUSED — ' + msg, 1); }

function sha16(p) {
  try { return createHash('sha256').update(readFileSync(p)).digest('hex').slice(0, 16); }
  catch { return 'unreadable'; }
}
function sha256(p) { return createHash('sha256').update(readFileSync(p)).digest('hex'); }

function readJsonl(p) {
  if (!existsSync(p)) return [];
  return readFileSync(p, 'utf8').split('\n').filter(l => l.trim()).map((l, i) => {
    try { return { __line: i + 1, ...JSON.parse(l) }; }
    catch { return { __line: i + 1, __unparseable: l.slice(0, 200) }; }
  });
}
function ls(d) { try { return readdirSync(d); } catch { return []; } }

// ---------------------------------------------------------------------------
// Transcript discovery.
//
// transcript-extract.mjs hardcodes ONE project directory (-Users-jowolff). Sessions launched from
// any other cwd land in a different project directory and are invisible to it. Verified
// 2026-08-24: the live fleet's transcripts sit under
// ~/.claude/projects/-Users-jowolff--claude/<session>/subagents/, which that constant misses.
// This walks every project directory instead. Nothing here edits the extractor — the dossier
// hands it ABSOLUTE paths, which its own resolve() accepts, so the limitation is routed around
// rather than patched. state/tools/ is not this tool's to modify.
function allTranscripts() {
  const out = [];
  for (const proj of ls(PROJECTS)) {
    const pdir = join(PROJECTS, proj);
    let sessions;
    try { if (!statSync(pdir).isDirectory()) continue; sessions = ls(pdir); } catch { continue; }
    for (const s of sessions) {
      const sub = join(pdir, s, 'subagents');
      if (!existsSync(sub)) continue;
      for (const f of ls(sub)) {
        if (!f.endsWith('.jsonl')) continue;
        const p = join(sub, f);
        let st; try { st = statSync(p); } catch { continue; }
        let mt = {};
        const mp = p.replace(/\.jsonl$/, '.meta.json');
        if (existsSync(mp)) { try { mt = JSON.parse(readFileSync(mp, 'utf8')); } catch { mt = {}; } }
        out.push({
          id: f.replace(/^agent-|\.jsonl$/g, ''),
          path: p, project: proj, session: s,
          bytes: st.size, mtime: st.mtime,
          agentType: mt.agentType ?? null,
          description: mt.description ?? null,
        });
      }
    }
  }
  return out;
}

// Pairing is by (agentType, time window) because nothing in the fleet records an agentId next to
// a contract: no LEDGER.jsonl row carries an agentId field (checked 2026-08-24). That makes every
// unpinned pairing INFERRED, and the dossier says so rather than presenting it as a join.
// --agent-id pins it and is the only pairing that is not a guess.
function pairTranscripts(contract, opts) {
  const all = allTranscripts();
  if (opts.agentId) {
    const want = opts.agentId.replace(/^agent-/, '');
    const hit = all.find(t => t.id === want);
    if (!hit) return { basis: 'pinned by --agent-id', confidence: 'none', matches: [], note: '--agent-id ' + opts.agentId + ' matched no transcript under ' + PROJECTS };
    return { basis: 'pinned by --agent-id', confidence: 'exact', matches: [hit] };
  }
  const t0 = Date.parse(contract.ts);
  if (Number.isNaN(t0)) return { basis: 'time window', confidence: 'none', matches: [], note: 'contract ts "' + contract.ts + '" did not parse' };
  const lo = t0 - 5 * 60 * 1000;
  const hi = t0 + opts.windowMin * 60 * 1000;
  const matches = all
    .filter(t => t.agentType === contract.agent && t.mtime.getTime() >= lo && t.mtime.getTime() <= hi)
    .sort((a, b) => a.mtime - b.mtime);
  return {
    basis: 'agentType == "' + contract.agent + '" and transcript mtime within [-5min, +' + opts.windowMin + 'min] of contract ts ' + contract.ts,
    confidence: matches.length === 1 ? 'single match (still inferred, not a join)'
      : matches.length === 0 ? 'none'
      : matches.length + ' candidates — AMBIGUOUS, pin one with --agent-id or judge none',
    matches,
  };
}

// ---------------------------------------------------------------------------
// Clause pre-check. Not a verdict — judgeability triage, so the judge knows before it starts
// which clauses no evidence source on this machine can settle.
function clausePrecheck(clause) {
  const c = clause.toLowerCase();
  const notes = [];
  if (/before and after|unchanged|byte-identical|did not change/.test(c)) {
    notes.push('NEEDS A BEFORE-STATE. Nothing outside the run captured the pre-run bytes. If the only "before" figure lives in the worker\'s own report, this clause is report-only evidence and cannot pass.');
  }
  if (/exists|contains|\bfile\b|report\b/.test(c)) {
    notes.push('Artifact-checkable: stat and hash the named path yourself, now.');
  }
  if (/exit \d|exits \d|exit code|passes|runs clean|green/.test(c)) {
    notes.push('Tool-call-checkable: --tools on the transcript shows whether the command ran and what it returned. Re-running it yourself proves the state now, not the state then — say which you did.');
  }
  if (/every|\ball \b|each\b/.test(c)) {
    notes.push('UNIVERSAL QUANTIFIER. A sample does not settle it. State the coverage you achieved and name the uncovered remainder.');
  }
  if (notes.length === 0) notes.push('No pre-check pattern fired. Choose the evidence source yourself and name it.');
  return notes;
}

function grepTerms(clause) {
  const terms = new Set();
  for (const m of clause.matchAll(/[A-Za-z0-9_.\-\/]+\.(sh|mjs|py|json|jsonl|md|ts|tsx)\b/g)) terms.add(m[0]);
  for (const m of clause.matchAll(/\b[A-Z][A-Z0-9_\-]{3,}\b/g)) terms.add(m[0]);
  for (const w of clause.split(/[^A-Za-z0-9_\-]+/)) if (w.length >= 8) terms.add(w);
  return [...terms].slice(0, 6);
}

// ---------------------------------------------------------------------------
function loadContracts(run, agent, contractFile) {
  let rows, src;
  if (contractFile) {
    src = contractFile;
    if (!existsSync(src)) refuse('no contract file at ' + src);
    rows = readJsonl(src);
  } else {
    src = join(RUNS, run, 'CONTRACTS.jsonl');
    if (!existsSync(src)) refuse('no contracts for run "' + run + '" (' + src + ' does not exist). Nothing was declared before dispatch, so there is nothing to judge against. That absence IS the finding — report it, do not invent a contract.');
    rows = readJsonl(src);
  }
  const mine = rows.filter(r => (!agent || r.agent === agent));
  if (mine.length === 0) refuse('no contract in ' + src + ' for agent "' + agent + '"');
  return { src, rows: mine };
}

function dossier(run, agent, opts) {
  const { src, rows } = loadContracts(run, agent, opts.contractFile);
  const L = [];
  const p = s => L.push(s);

  p('# JUDGE EVIDENCE DOSSIER');
  p('# run: ' + run + '   agent: ' + agent + '   built: ' + new Date().toISOString().replace(/\.\d+Z$/, 'Z'));
  p('# contract source: ' + src + '  sha256=' + sha16(src));
  p('');
  p('## 0. The rule this dossier exists to enforce');
  p('');
  p("The worker's sealed report is the CLAIM UNDER TEST. It is never the proof. A done_when");
  p('clause supported only by the report\'s own assertion is a FAIL, not a pass. Independent');
  p('evidence is section 2 (harness-written transcript) and section 3 (artifacts on disk).');
  p('');

  if (rows.length > 1) {
    p('!! ' + rows.length + ' contract rows match this run+agent. dispatch-contract.sh keys on agent slug,');
    p('!! not on dispatch, so repeat dispatches to one slug collapse. Judge each row separately, or');
    p('!! say plainly which dispatch you judged and which you did not.');
    p('');
  }

  rows.forEach((contract, ci) => {
    p('## 1. Contract row ' + (ci + 1) + '/' + rows.length + '  (line ' + contract.__line + ' of the source)');
    p('   declared: ' + contract.ts + (contract.dispatch_id ? '   dispatch_id: ' + contract.dispatch_id : ''));
    p('');
    (contract.done_when ?? []).forEach((c, i) => p('   done_when[' + (i + 1) + '] ' + c));
    if ((contract.not_doing ?? []).length) {
      p('');
      contract.not_doing.forEach((c, i) => p('   not_doing[' + (i + 1) + ']  ' + c + '   <- a violation here is a FAIL even if every done_when passes'));
    }
    if ((contract.escalate_if ?? []).length) {
      p('');
      contract.escalate_if.forEach((c, i) => p('   escalate_if[' + (i + 1) + '] ' + c + '   <- if this fired and the worker did not come back, that is a FAIL'));
    }
    p('');

    const pair = pairTranscripts(contract, opts);
    p('## 2. INDEPENDENT EVIDENCE — harness-written transcript');
    p('   pairing basis: ' + pair.basis);
    p('   confidence:    ' + pair.confidence);
    if (pair.note) p('   note:          ' + pair.note);
    if (pair.matches.length === 0) {
      p('');
      p('   NO TRANSCRIPT PAIRED. This is a finding, not a gap to work around. Either the dispatch');
      p('   was not a harness subagent at all (a script run, a separately-launched session), or the');
      p('   pairing heuristic missed it. Until a transcript is named, every clause here can only be');
      p('   judged from artifacts on disk; anything else is report-only and must be marked fail or');
      p('   unjudgeable. Re-run with --agent-id to pin one if you can identify it.');
    }
    pair.matches.forEach(t => {
      p('');
      p('   transcript: ' + t.path);
      p('     agentType=' + t.agentType + '  description=' + JSON.stringify(t.description));
      p('     ' + t.bytes + 'B  mtime=' + t.mtime.toISOString() + '  sha256=' + sha16(t.path));
      p('     read it with (the absolute path sidesteps the extractor single-project-dir constant):');
      p('       node ' + EXTRACT + ' --drops');
      p('       node ' + EXTRACT + ' --tools   ' + t.path + '    <- START HERE');
      p('       node ' + EXTRACT + ' --turns   ' + t.path);
      p('       node ' + EXTRACT + ' --returns ' + t.path + '    <- SEE WARNING BELOW');
      p('');
      p('     !! --returns FILTERS ON stop_reason=end_turn, WHICH IS NOT A COMPLETION SIGNAL ON');
      p('     !! THIS HARNESS. Measured 2026-08-24 across every subagent transcript written that');
      p('     !! day: 14 of 21 carry ZERO end_turn records, and most of those workers finished');
      p('     !! normally. So "(no end_turn assistant message)" from --returns means NOTHING about');
      p('     !! whether the worker finished, and a judge that reads it as "the worker returned');
      p('     !! nothing" will be wrong most of the time. Judge from --tools (what the worker DID)');
      p('     !! and the artifacts. If you need the worker\'s words, --grep is not end_turn-gated.');
      p('     !! "Request interrupted by user" is NOT a reliable death marker either: it also');
      p('     !! appears when a coordinator sends a mid-run message to a live worker. Verified on');
      p('     !! this tool\'s own build transcript, which carries the marker and did not die.');
    });
    p('');

    const runDir = join(RUNS, run);
    p('## 3. INDEPENDENT EVIDENCE — artifacts on disk');
    p('   run directory: ' + runDir);
    const walk = (d, depth = 0) => {
      for (const f of ls(d).sort()) {
        const fp = join(d, f);
        let st; try { st = statSync(fp); } catch { continue; }
        if (st.isDirectory()) { p('   ' + '  '.repeat(depth) + f + '/'); if (depth < 2) walk(fp, depth + 1); }
        else p('   ' + '  '.repeat(depth) + f + '  ' + st.size + 'B  ' + st.mtime.toISOString() + '  sha256=' + sha16(fp));
      }
    };
    if (existsSync(runDir)) walk(runDir); else p('   (run directory does not exist)');
    p('');
    p('   Artifacts named by the clauses themselves live outside this directory. Stat and hash them');
    p('   yourself; a path quoted from the report is the report speaking, not the disk.');
    p('');

    p('## 4. THE CLAIM UNDER TEST — the worker sealed report(s). NOT EVIDENCE.');
    const man = join(runDir, 'reports', 'MANIFEST.jsonl');
    const mrows = readJsonl(man).filter(r => !agent || r.agent === agent);
    if (mrows.length === 0) {
      p('   No sealed report for this agent in this run.');
      p('   A declared contract with no sealed report is UNANSWERED — every clause is unjudgeable on');
      p('   the report side, though transcript and artifact evidence may still settle some.');
    }
    mrows.forEach(r => {
      const now = existsSync(r.path) ? sha256(r.path) : null;
      const state = now === null ? 'GONE' : now === r.sha256 ? 'matches seal' : 'CHANGED SINCE SEAL';
      p('   ' + r.path);
      p('     sealed ' + r.ts + '  ' + r.bytes + 'B  ' + state);
      if (state === 'CHANGED SINCE SEAL') {
        p('     recorded ' + r.sha256);
        p('     now      ' + now);
        p('     A report edited after sealing is itself a finding. Report it above your verdicts.');
      }
    });
    p('');

    p('## 5. PER-CLAUSE WORKSHEET');
    (contract.done_when ?? []).forEach((c, i) => {
      p('');
      p('   [' + (i + 1) + '] ' + c);
      clausePrecheck(c).forEach(n => p('       precheck: ' + n));
      const terms = grepTerms(c);
      if (terms.length && pair.matches.length) {
        p('       suggested searches (a zero result rules out literal presence and nothing more):');
        terms.forEach(t => p("         node " + EXTRACT + " --grep " + pair.matches[0].path + " '" + t.replace(/'/g, "'\\''") + "'"));
      }
    });
    p('');
  });

  return L.join('\n');
}

// ---------------------------------------------------------------------------
function briefText(run, agent, opts) {
  const d = dossier(run, agent, opts);
  const out = opts.verdictOut || ('<mint one: zsh ' + STATE + '/tools/worker-report.sh path ' + run + ' judge-' + agent.replace(/[^A-Za-z0-9]+/g, '-') + '>');
  return [
    'You are judging one dispatch against the done-condition declared BEFORE it ran.',
    'You did not write the brief, you did not do the work, and you did not dispatch it.',
    '',
    '## The one rule that makes this worth doing',
    '',
    "The worker's sealed report is the CLAIM UNDER TEST. It is never the proof. The worker wrote",
    'both its claim and, if you let it, the only evidence you would see — so judging the report',
    'against the contract is self-grading once removed.',
    '',
    'Your evidence is (a) the harness-written subagent transcript, which the worker cannot author,',
    'and (b) the artifacts on disk, which you stat and hash yourself. A done_when clause supported',
    "only by the report's own assertion is a FAIL, not a pass. A clause no evidence source can",
    'settle is UNJUDGEABLE — say so; that is a finding about the contract, not a failure of your run.',
    '',
    '"Every clause passed" is a result you must be able to return. If you cannot describe what a',
    'failing clause would have looked like, you are not judging, you are rubber-stamping.',
    '',
    '## Your dossier',
    '',
    d,
    '',
    '## What to write',
    '',
    'One JSONL file, one object per done_when clause, at:',
    '  ' + out,
    '',
    'Each object:',
    '  {"clause_index":1,',
    '   "clause":"<the clause verbatim>",',
    '   "verdict":"pass|fail|unjudgeable",',
    '   "evidence_class":"transcript|artifact|report|none",',
    '   "evidence":"<absolute path, the exact command you ran, or the transcript rec# — openable>",',
    '   "what_a_fail_would_look_like":"<one sentence: the observation that would have flipped this>"}',
    '',
    'Then run this, and paste its output into your report:',
    '  node ' + SELF + ' lint ' + out,
    '',
    'lint REJECTS any clause marked pass whose evidence_class is "report" or "none". That is',
    'mechanical, not advisory: a verdict that cannot show independent evidence does not become a',
    'verdict.',
    '',
    'Above the JSONL, in prose: any not_doing violation, any escalate_if that fired without the',
    'worker coming back, and whether the sealed report still matches its manifest hash.',
    '',
  ].join('\n');
}

// ---------------------------------------------------------------------------
function lint(file, contractClauses) {
  if (!existsSync(file)) refuse('no verdict file at ' + file);
  const rows = readJsonl(file);
  if (rows.length === 0) refuse(file + ' has no parseable rows. An empty verdict is not a clean verdict.');
  const problems = [];
  const seen = new Map();

  rows.forEach(r => {
    const where = 'line ' + r.__line;
    if (r.__unparseable) { problems.push(where + ': unparseable JSON: ' + r.__unparseable); return; }
    if (typeof r.clause_index !== 'number') problems.push(where + ': clause_index missing or not a number');
    else {
      if (seen.has(r.clause_index)) problems.push(where + ': clause_index ' + r.clause_index + ' already judged on line ' + seen.get(r.clause_index));
      seen.set(r.clause_index, r.__line);
    }
    if (!r.clause || !String(r.clause).trim()) problems.push(where + ': clause text missing — a verdict that does not quote its clause cannot be checked against the contract');
    if (!VERDICTS.includes(r.verdict)) problems.push(where + ': verdict "' + r.verdict + '" is not one of ' + VERDICTS.join('|'));
    if (!EVIDENCE_CLASSES.includes(r.evidence_class)) problems.push(where + ': evidence_class "' + r.evidence_class + '" is not one of ' + EVIDENCE_CLASSES.join('|'));
    if (r.verdict === 'pass') {
      if (r.evidence_class === 'report') problems.push(where + ': PASS on report-only evidence. This is the exact failure the judge exists to prevent — the worker wrote the claim and the proof. Downgrade to fail, or find transcript/artifact evidence.');
      if (r.evidence_class === 'none') problems.push(where + ': PASS with no evidence class. A pass with no evidence is a rubber stamp.');
      if (!r.evidence || !String(r.evidence).trim()) problems.push(where + ': PASS with an empty evidence field. Name the path, the command, or the transcript record.');
    }
    if (!r.what_a_fail_would_look_like || !String(r.what_a_fail_would_look_like).trim()) {
      problems.push(where + ': no "what_a_fail_would_look_like". A check that cannot describe its own failure did not disconfirm anything.');
    }
  });

  if (contractClauses) {
    contractClauses.forEach((c, i) => {
      if (!seen.has(i + 1)) problems.push('contract done_when[' + (i + 1) + '] was never judged: ' + c);
    });
    [...seen.keys()].forEach(k => {
      if (k < 1 || k > contractClauses.length) problems.push('clause_index ' + k + ' is outside the contract\'s ' + contractClauses.length + ' done_when clause(s)');
    });
  }

  const n = v => rows.filter(r => r.verdict === v).length;
  console.log('judge lint: ' + file);
  console.log('  ' + rows.length + ' clause verdict(s): ' + n('pass') + ' pass, ' + n('fail') + ' fail, ' + n('unjudgeable') + ' unjudgeable');
  if (contractClauses) console.log('  contract has ' + contractClauses.length + ' done_when clause(s)');
  console.log('');
  if (problems.length === 0) {
    console.log('ACCEPTED. Every clause is judged, and every pass names independent evidence.');
    console.log('');
    console.log('WHAT THIS DOES NOT ESTABLISH: that the evidence cited actually says what the judge says');
    console.log('it says — lint checks the shape of a verdict, never its truth. Nor that the done_when');
    console.log('clauses were worth passing. A weak contract passed honestly still tells you nothing.');
    return 0;
  }
  console.log('REJECTED — ' + problems.length + ' problem(s):');
  problems.forEach(x => console.log('  - ' + x));
  return 1;
}

// ---------------------------------------------------------------------------
// selftest: the falsifiability demonstration, baked in so it is not a claim in a report.
// It builds a rubber-stamp verdict that MUST be rejected and an evidence-backed one that MUST be
// accepted. If lint ever passes the rubber stamp, this exits non-zero and the tool is broken.
function selftest() {
  const dir = mkdtempSync(join(tmpdir(), 'judge-selftest-'));
  const clauses = ['the checker exits 0 on the whole file', 'no protected file changed during the run'];

  const stamp = join(dir, 'rubber-stamp.jsonl');
  writeFileSync(stamp, [
    { clause_index: 1, clause: clauses[0], verdict: 'pass', evidence_class: 'report', evidence: 'the report says it exits 0', what_a_fail_would_look_like: 'the report saying otherwise' },
    { clause_index: 2, clause: clauses[1], verdict: 'pass', evidence_class: 'none', evidence: '', what_a_fail_would_look_like: 'a change' },
  ].map(o => JSON.stringify(o)).join('\n') + '\n');

  const real = join(dir, 'evidence-backed.jsonl');
  writeFileSync(real, [
    { clause_index: 1, clause: clauses[0], verdict: 'pass', evidence_class: 'transcript', evidence: 'rec#118 tool_use Bash "sh check.sh" -> RESULT exit 0', what_a_fail_would_look_like: 'no such Bash call in the transcript, or a non-zero result line' },
    { clause_index: 2, clause: clauses[1], verdict: 'unjudgeable', evidence_class: 'none', evidence: '', what_a_fail_would_look_like: 'a pre-run hash recorded outside the worker to diff against' },
  ].map(o => JSON.stringify(o)).join('\n') + '\n');

  console.log('# selftest — a judge that cannot fail is not a judge.\n');
  console.log("## case A: rubber stamp (all pass, evidence is the worker's own report). MUST be rejected.");
  const a = lint(stamp, clauses);
  console.log('');
  console.log('## case B: evidence-backed, with one honest unjudgeable. MUST be accepted.');
  const b = lint(real, clauses);
  console.log('');
  console.log('scratch: ' + dir);
  if (a === 1 && b === 0) { console.log('\nSELFTEST PASS: lint rejects the rubber stamp and accepts the evidence-backed verdict.'); return 0; }
  console.log('\nSELFTEST FAIL: expected reject(A)=1 got ' + a + '; expected accept(B)=0 got ' + b + '.');
  return 1;
}

// ---------------------------------------------------------------------------
const argv = process.argv.slice(2);
const cmd = argv[0];
function flag(name, dflt) { const i = argv.indexOf(name); return i === -1 ? dflt : argv[i + 1]; }

if (!cmd || cmd === '-h' || cmd === '--help') {
  console.log(readFileSync(new URL(import.meta.url), 'utf8')
    .split('\n').filter(l => l.startsWith('//'))
    .map(l => l.replace(/^\/\/ ?/, '')).join('\n'));
  process.exit(0);
}

const opts = {
  contractFile: flag('--contract-file', null),
  agentId: flag('--agent-id', null),
  windowMin: Number(flag('--window-min', 120)),
  verdictOut: flag('--verdict-out', null),
};

switch (cmd) {
  case 'evidence': {
    const run = argv[1], agent = argv[2];
    if (!run || !agent || run.startsWith('--')) refuse('usage: judge.mjs evidence <run-id> <agent-slug>');
    console.log(dossier(run, agent, opts));
    break;
  }
  case 'brief': {
    const run = argv[1], agent = argv[2];
    if (!run || !agent || run.startsWith('--')) refuse('usage: judge.mjs brief <run-id> <agent-slug>');
    console.log(briefText(run, agent, opts));
    break;
  }
  case 'lint': {
    const file = argv[1];
    if (!file || file.startsWith('--')) refuse('usage: judge.mjs lint <verdict-jsonl> [--contract-file F | --run R --agent A]');
    let clauses = null;
    const run = flag('--run', null), agent = flag('--agent', null);
    if (opts.contractFile || (run && agent)) {
      const { rows } = loadContracts(run, agent, opts.contractFile);
      if (rows.length === 1) clauses = rows[0].done_when ?? [];
      else console.log('judge lint: ' + rows.length + ' contract rows matched; clause-coverage check skipped (say which dispatch you judged).\n');
    }
    process.exit(lint(file, clauses));
  }
  case 'selftest':
    process.exit(selftest());
  default:
    die('unknown command "' + cmd + '". One of: evidence | brief | lint | selftest');
}

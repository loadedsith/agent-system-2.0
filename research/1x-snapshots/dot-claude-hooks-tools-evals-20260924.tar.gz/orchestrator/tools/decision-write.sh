#!/bin/sh
# decision-write.sh — open a pending decision, or close one with Jo's answer.
#
# WHY THIS EXISTS. The fleet had no record of a decision it was WAITING ON. `touches: decide` in the
# request ledger records a decision Jo HAS made; nothing recorded one outstanding. So the desktop
# widget's "decisions for Jo" lane had no producer and rendered "no source file" — correctly, and
# that gap is what this closes.
#
# ⛔ IT WRITES UNDER state/, SO TINKER DOES NOT RUN IT. This tool lives in tools/, which is Tinker's
# surface. The file it writes, state/DECISIONS.jsonl, is Lintel's. Tinker built and tested this
# against throwaway fixtures and has never run it against the live path. Lintel runs it.
#
# THE ONE DESIGN RULE WORTH KNOWING. A recommendation is OPTIONAL, because a decision can honestly
# have none — Lintel put one to Jo today with the words "I have not read the ticket and have no
# basis. Record it with no recommendation rather than inventing one." But an optional field that can
# simply be omitted gets omitted by accident, and then "none was offered" and "the author forgot"
# look identical on Jo's screen. So OMITTING IT IS ALSO A CHOICE YOU HAVE TO MAKE: pass either
# --recommendation TEXT or --no-recommendation, and passing neither is refused. The absence lands on
# the record as a decision rather than as a gap.
#
# usage:
#   decision-write.sh open  --question TEXT --option TEXT [--option TEXT ...]
#                           (--recommendation TEXT | --no-recommendation)
#                           [--provenance TEXT] [--ledger PATH] [--dry-run]
#                           [--witness-path PATH --witness-contains TEXT]
#   decision-write.sh answer --id DEC-NNN --chose TEXT [--ledger PATH] [--dry-run]
#   decision-write.sh witness --id DEC-NNN --witness-path PATH --witness-contains TEXT
#                           [--replace] [--ledger PATH] [--dry-run]
#
# THE OPTIONAL WITNESS, AND WHAT IT IS FOR. The failure this ledger keeps hitting is not a decision
# nobody recorded — it is a decision that was recorded, then ACTED ON, and never closed. DEC-023 is
# the live example: the rule it proposes is live in the charter and the row still reads open. Nothing
# noticed; a person hand-typed the discrepancy into the save point.
#
# A witness is the tractable subset of that problem. It is a PATH plus a LITERAL STRING that would be
# on disk if and only if the decision had been acted on. Given one, decision-witness-check.py can
# report the disagreement between the record and the disk. It NEVER closes the row — closing stays
# `answer`, with a human in it, because the disagreement says the work happened and not which option
# was chosen.
#
# The general problem is undecidable and this does not pretend otherwise: a decision with no witness
# is simply not checked, and the checker states how many those are. Four refusals keep the field
# honest — a witness is both halves or neither, the string may not be a line number, the path may
# not carry a :NNN suffix (a line number drifts silently and still resolves, which is worse than
# failing), and a string under twelve characters matches by accident.
#
# WHY THERE IS A THIRD SUBCOMMAND, AND WHY IT IS CALLED `witness`. Every row written before the
# field existed carries none, and `open` is the only place a witness could be set — so backfilling
# ten existing rows through `open` would have MINTED TEN NEW DECISIONS duplicating them. Caught
# 2026-08-25 by the coordinator reading this file, after this tool's own author recommended exactly
# that backfill. Hence `witness`: it amends ONE field on ONE existing row and nothing else.
#
# It is named for the field it touches, not for the act. `amend` would have been the generic name,
# and a generic name is an invitation — the next person wanting to fix a typo in a `question` finds
# an `amend` subcommand and reasonably expects it to do that. `witness` cannot be misread as a
# general mutator, and the ledger is one where general mutation is exactly what must stay hard.
#
# ⛔ IT NEVER CLOSES ANYTHING. `witness` cannot touch state, chose, or answered_ts. Closing a
# decision stays `answer`, with a human in it.
#
# `answer` REWRITES THE ROW IN PLACE rather than appending a second one, so the file holds one row
# per decision. It refuses to answer a row that is already answered — re-answering would silently
# overwrite what Jo chose the first time.
#
# ⛔ THE REWRITE IS ATOMIC AT THE RENAME AND NOT SAFE AGAINST A CONCURRENT WRITER. `answer` reads
# every row, mutates one in memory, writes a temp file and os.replace()s it over the ledger. The
# RENAME is atomic, so no reader ever sees a half-written file. The READ-MODIFY-WRITE around it is
# not: any row appended by another process between the read and the replace is silently discarded,
# and there is no lock and no re-read. `witness` inherits that mechanism exactly rather than
# inventing a second one — a divergent second rewrite path would be worse — but the hazard is real
# and this ledger has an active concurrent writer. Run `answer` and `witness` when nothing else is
# writing, and treat a lost row as a live possibility rather than a theoretical one.
#
# Exit codes: 0 written | 1 refused (bad input, or a state that must not be overwritten) | 2 could
# not run (missing file, no python3).

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
LEDGER="$ORCH/state/DECISIONS.jsonl"
MODE=""
DRY=0
QUESTION=""
CHOSE=""
ID=""
PROV=""
REC=""
REC_SET=0
WPATH=""
WCONTAINS=""
REPLACE=0
OPTS_FILE=""

case "${1:-}" in
  open|answer|witness) MODE="$1"; shift ;;
  *) echo "usage: decision-write.sh open|answer|witness ..." >&2; exit 2 ;;
esac

OPTS_FILE="$(mktemp)" || exit 2
trap 'rm -f "$OPTS_FILE"' EXIT

while [ $# -gt 0 ]; do
  case "$1" in
    --question)          QUESTION="${2:?--question needs text}"; shift 2 ;;
    --option)            printf '%s\n' "${2:?--option needs text}" >> "$OPTS_FILE"; shift 2 ;;
    --recommendation)    REC="${2:?--recommendation needs text}"; REC_SET=1; shift 2 ;;
    --no-recommendation) REC=""; REC_SET=1; shift ;;
    --provenance)        PROV="${2:?--provenance needs text}"; shift 2 ;;
    --witness-path)      WPATH="${2:?--witness-path needs a path}"; shift 2 ;;
    --witness-contains)  WCONTAINS="${2:?--witness-contains needs text}"; shift 2 ;;
    --replace)           REPLACE=1; shift ;;
    --id)                ID="${2:?--id needs DEC-NNN}"; shift 2 ;;
    --chose)             CHOSE="${2:?--chose needs text}"; shift 2 ;;
    --ledger)            LEDGER="${2:?--ledger needs a path}"; shift 2 ;;
    --dry-run)           DRY=1; shift ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

command -v python3 >/dev/null || { echo "preflight: python3 not found" >&2; exit 2; }

DW_MODE="$MODE" DW_LEDGER="$LEDGER" DW_QUESTION="$QUESTION" DW_CHOSE="$CHOSE" \
DW_ID="$ID" DW_PROV="$PROV" DW_REC="$REC" DW_REC_SET="$REC_SET" \
DW_OPTS_FILE="$OPTS_FILE" DW_DRY="$DRY" \
DW_WPATH="$WPATH" DW_WCONTAINS="$WCONTAINS" DW_REPLACE="$REPLACE" \
python3 - <<'ENDOFPY'
import json, os, re, sys, datetime

mode   = os.environ["DW_MODE"]
path   = os.environ["DW_LEDGER"]
dry    = os.environ["DW_DRY"] == "1"

def refuse(msg):
    sys.stderr.write("REFUSED — %s\n" % msg)
    sys.exit(1)

def cannot(msg):
    sys.stderr.write("CANNOT RUN — %s\n" % msg)
    sys.exit(2)

rows = []
if os.path.exists(path):
    with open(path, encoding="utf-8") as fh:
        for n, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as e:
                cannot("%s:%d is not valid JSON: %s" % (path, n, e))

now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def read_witness_args(required):
    """THE FOUR WITNESS REFUSALS, IN ONE PLACE. `open` and `witness` both call this, so the rules
    cannot drift apart — a backfill subcommand with looser validation than the writer would be a
    hole in exactly the field the checker trusts."""
    wpath = os.environ.get("DW_WPATH", "").strip()
    wcontains = os.environ.get("DW_WCONTAINS", "").strip()
    if required and not (wpath or wcontains):
        refuse("witness mode needs --witness-path and --witness-contains. Amending a row to no "
               "witness at all is not a thing this does; it would silently un-check a row.")
    # Both halves or neither: half a witness is a checker that silently checks nothing, which reads
    # on the output exactly like a decision nobody acted on.
    if bool(wpath) != bool(wcontains):
        refuse("a witness is --witness-path AND --witness-contains, or neither. Given one half, "
               "the checker would report the row as unchecked and nothing would say why.")
    if wcontains:
        if re.match(r"^[:\s]*\d+\s*$", wcontains):
            refuse("--witness-contains %r is a line number. A line number drifts silently and "
                   "still resolves to a line, so the check would keep passing while pointing at "
                   "the wrong content. Quote a distinctive literal string from the file instead."
                   % wcontains)
        if re.search(r":\d+$", wpath):
            refuse("--witness-path %r carries a :NNN line suffix. The witness is a path plus a "
                   "literal string; strip the line number." % wpath)
        if len(wcontains) < 12:
            refuse("--witness-contains is %d characters. A short string matches by accident and "
                   "an accidental match is a false 'this was acted on'." % len(wcontains))
    return {"path": wpath, "contains": wcontains} if wcontains else None

if mode == "open":
    q = os.environ["DW_QUESTION"].strip()
    if len(q) < 12:
        refuse("--question is %d characters. A decision Jo cannot act on without asking what it "
               "means is not recorded, it is deferred." % len(q))
    opts = [l.rstrip("\n") for l in open(os.environ["DW_OPTS_FILE"], encoding="utf-8")] \
        if os.path.getsize(os.environ["DW_OPTS_FILE"]) else []
    opts = [o for o in opts if o.strip()]
    if len(opts) < 2:
        refuse("a decision needs at least two --option values; %d given. One option is not a "
               "decision, it is a notification." % len(opts))
    if os.environ["DW_REC_SET"] != "1":
        refuse("pass either --recommendation TEXT or --no-recommendation. Omitting it silently "
               "makes 'none was offered' and 'the author forgot' identical on Jo's screen, and "
               "the whole point of the optional field is that the absence is deliberate.")
    rec = os.environ["DW_REC"].strip()
    witness = read_witness_args(required=False)

    # An empty string and a missing key are different things downstream; keep the key present and
    # null so a reader can tell "explicitly none" from "written by something that did not know
    # about this field".
    nums = [int(m.group(1)) for r in rows
            for m in [re.match(r"^DEC-(\d+)$", str(r.get("id", "")))] if m]
    new = {
        "id": "DEC-%03d" % ((max(nums) + 1) if nums else 1),
        "ts": now,
        "question": q,
        "options": opts,
        "recommendation": rec if rec else None,
        "provenance": os.environ["DW_PROV"].strip() or None,
        "state": "open",
        "chose": None,
        "answered_ts": None,
        # Present-and-null rather than absent, for the same reason `recommendation` is: a reader
        # must be able to tell "no witness was offered" from "written before this field existed".
        "witness": witness,
    }
    line = json.dumps(new, ensure_ascii=False)
    if dry:
        # THE ID IS NOT PREDICTIVE IN A DRY RUN AND THE OUTPUT SAYS SO. Nothing is appended, so a
        # script dry-running four opens in a row derives the same next id four times. That is
        # correct behaviour and it reads exactly like an id-collision bug — which is worse than a
        # confusing output, because a dry run exists to be believed. Reported by Lintel 2026-08-24
        # on the first real use.
        print("DRY RUN — would append to %s:\n%s" % (path, line))
        print("         (id shown is the next one available NOW; nothing is written in a dry run, "
              "so several dry opens in a row all show the same id. Live, they increment.)")
        sys.exit(0)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(line + "\n")
    print("opened %s" % new["id"])
    print("  %s" % q)
    print("  options: %s" % " | ".join(opts))
    print("  recommendation: %s" % (rec if rec else "NONE OFFERED (explicitly)"))
    print("  witness: %s" % ("%s contains %r" % (witness["path"], witness["contains"]) if witness
                             else "NONE — this row will be reported as unchecked"))
    sys.exit(0)

if mode == "answer":
    rid = os.environ["DW_ID"].strip()
    chose = os.environ["DW_CHOSE"].strip()
    if not re.match(r"^DEC-\d+$", rid):
        refuse("--id must look like DEC-NNN, got %r" % rid)
    if not chose:
        refuse("--chose is empty. Closing a decision without recording what was chosen loses the "
               "only thing the record existed to keep.")
    hit = [r for r in rows if r.get("id") == rid]
    if not hit:
        refuse("no row %s in %s" % (rid, path))
    r = hit[0]
    if r.get("state") != "open":
        refuse("%s is already %s and was answered %r. Re-answering would overwrite what Jo chose "
               "the first time; append a NEW decision instead if the question came back."
               % (rid, r.get("state"), r.get("chose")))
    r["state"] = "answered"
    r["chose"] = chose
    r["answered_ts"] = now
    out = "\n".join(json.dumps(x, ensure_ascii=False) for x in rows) + "\n"
    if dry:
        print("DRY RUN — would rewrite %s, setting %s to answered (%s)" % (path, rid, chose))
        sys.exit(0)
    tmp = path + ".tmp-write"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(out)
    os.replace(tmp, path)   # atomic: a reader never sees a half-written ledger
    print("answered %s — %s" % (rid, chose))
    sys.exit(0)

if mode == "witness":
    rid = os.environ["DW_ID"].strip()
    if not re.match(r"^DEC-\d+$", rid):
        refuse("--id must look like DEC-NNN, got %r" % rid)
    w = read_witness_args(required=True)

    hit = [r for r in rows if r.get("id") == rid]
    if not hit:
        # AN UNKNOWN ID IS A REFUSAL, NOT A NO-OP. Doing nothing quietly is the failure mode that
        # reads as success: a backfill script would report ten green lines having amended nothing.
        refuse("no row %s in %s. Nothing was written. An id that does not exist is a typo or a "
               "stale list, and either way silently doing nothing would look exactly like "
               "success." % (rid, path))
    r = hit[0]
    if r.get("state") != "open":
        refuse("%s is %s (chose %r). A witness on a closed row checks nothing — the checker only "
               "ever looks at open rows — so this would add a field nobody reads and noise to "
               "every future diff." % (rid, r.get("state"), r.get("chose")))
    existing = r.get("witness")
    if isinstance(existing, dict) and existing.get("contains") and os.environ["DW_REPLACE"] != "1":
        refuse("%s already carries a witness (%s contains %r). Overwriting it silently is how a "
               "check quietly stops checking what it was aimed at. Pass --replace if you mean to "
               "re-aim it." % (rid, existing.get("path"), existing.get("contains")))

    # ONLY `witness` MOVES. Every other key on this row is left exactly as parsed — no state, no
    # chose, no answered_ts, no question, options, recommendation, provenance, id or ts.
    before = {k: v for k, v in r.items() if k != "witness"}
    r["witness"] = w
    after = {k: v for k, v in r.items() if k != "witness"}
    if before != after:
        cannot("internal: fields other than `witness` changed on %s; nothing written" % rid)

    out = "\n".join(json.dumps(x, ensure_ascii=False) for x in rows) + "\n"
    if dry:
        print("DRY RUN — would rewrite %s, setting the witness on %s to %s contains %r"
              % (path, rid, w["path"], w["contains"]))
        print("         (nothing is written in a dry run)")
        sys.exit(0)
    tmp = path + ".tmp-write"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(out)
    os.replace(tmp, path)   # same mechanism as `answer`: atomic rename, unlocked read-modify-write
    print("witnessed %s" % rid)
    print("  %s contains %r" % (w["path"], w["contains"]))
    print("  state is still %r — witnessing never closes a decision; `answer` does." % r.get("state"))
    sys.exit(0)

cannot("unknown mode %r" % mode)
ENDOFPY

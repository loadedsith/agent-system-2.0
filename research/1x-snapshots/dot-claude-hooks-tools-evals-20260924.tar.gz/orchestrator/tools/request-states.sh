#!/bin/sh
# request-states.sh — THE terminal-state predicate for REQUESTS.jsonl rows.
#
# WHY THIS FILE EXISTS. Two hooks each carried their own copy of the predicate, and both copies
# said the same wrong thing: `state != delivered` means open. That reopened every `dropped` and
# `deferred` row as live work on every session start — including rows whose own note reads
# "Do not re-raise unprompted". CODEX-FIXES item 6. One predicate, one place, two consumers:
#   - hooks/savepoint-restore.sh   (SessionStart, prints OPEN OBLIGATIONS)
#   - hooks/savepoint-guard.mjs    (Stop, lists open obligations in its block reason)
#
# THE VOCABULARY IS NOT DEFINED HERE. It is read out of the request-ledger contract's
# `state-vocabulary` block, which CODEX-FIXES item 5 settled and which
# orchestrator/tools/state-vocab-check.sh already diffs against the live ledger. This file only
# parses that block. Adding a state, or moving one between terminal and non-terminal, is an edit
# to the contract and to nothing else.
#
# NO FALLBACK LIST, DELIBERATELY. If the contract cannot be read or the block cannot be parsed this
# prints nothing and exits 3. A hardcoded copy here would be a second vocabulary that drifts
# silently, which is the defect being fixed. Both callers degrade loudly on exit 3 rather than
# guessing: they fall back to the old `!= delivered` behaviour AND say on their own output that
# the predicate was unavailable, so an over-raised dropped row is never silent again.
#
# Usage:
#   request-states.sh --terminal        # terminal state names, one per line
#   request-states.sh --non-terminal    # non-terminal state names, one per line
#   request-states.sh --all             # "name<TAB>terminal|non-terminal", one per line
#   request-states.sh --source          # where the vocabulary came from, or "unavailable"
#   request-states.sh --is-terminal S   # exit 0 if S is terminal, 1 if not, 3 if unknown/unusable
#   request-states.sh --selftest        # prove the parser can fail; see the block at the bottom
#
# Contract path: $LINTEL_STATE_CONTRACT, else <this file>/../contracts/request-ledger.md.
# Exit codes: 0 answered | 1 --is-terminal said no | 2 bad usage | 3 vocabulary unavailable.

set -u

_self_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd 2>/dev/null) || _self_dir=""
CONTRACT="${LINTEL_STATE_CONTRACT:-$_self_dir/../contracts/request-ledger.md}"

# The parse is deliberately the same shape as tools/state-vocab-check.sh, which owns the
# contract-vs-ledger diff. That checker duplicates this awk, not the vocabulary; if the block's
# line format ever changes, both parsers change and the checker fails loudly first.
_parse() {
  [ -f "$CONTRACT" ] || return 3
  awk '
    /state-vocabulary:begin/ { inblock = 1; next }
    /state-vocabulary:end/   { inblock = 0; next }
    inblock {
      line = $0
      sub(/^[[:space:]]*>[[:space:]]*/, "", line)
      if (match(line, /^-[[:space:]]*`[a-z_-]+`[[:space:]]*(—|--)[[:space:]]*(non-terminal|terminal)([[:space:]]|$|—|--)/)) {
        name = line
        sub(/^-[[:space:]]*`/, "", name)
        sub(/`.*$/, "", name)
        rest = line
        sub(/^-[[:space:]]*`[a-z_-]+`[[:space:]]*(—|--)[[:space:]]*/, "", rest)
        term = (rest ~ /^non-terminal/) ? "non-terminal" : "terminal"
        print name "\t" term
      }
    }
  ' "$CONTRACT"
}

_all=$(_parse) || _all=""
[ -n "$_all" ] || _all=""

_require_vocab() {
  if [ -z "$_all" ]; then
    echo "request-states: no state vocabulary parsed from $CONTRACT" >&2
    exit 3
  fi
}

case "${1:-}" in
  --terminal)     _require_vocab; printf '%s\n' "$_all" | awk -F'\t' '$2=="terminal"{print $1}' ;;
  --non-terminal) _require_vocab; printf '%s\n' "$_all" | awk -F'\t' '$2=="non-terminal"{print $1}' ;;
  --all)          _require_vocab; printf '%s\n' "$_all" ;;
  --source)
    if [ -z "$_all" ]; then echo "unavailable"; exit 3; fi
    echo "contract:$CONTRACT" ;;
  --is-terminal)
    _require_vocab
    [ "$#" -ge 2 ] || { echo "usage: request-states.sh --is-terminal <state>" >&2; exit 2; }
    _hit=$(printf '%s\n' "$_all" | awk -F'\t' -v s="$2" '$1==s{print $2}')
    [ -n "$_hit" ] || { echo "request-states: '$2' is not a declared state" >&2; exit 3; }
    [ "$_hit" = "terminal" ] ;;
  --selftest)
    # A predicate that has never been seen to fail is not a predicate. Point the parser at a
    # contract with no vocabulary block and confirm it reports unavailable instead of inventing one.
    _empty=$(mktemp) || exit 2
    printf 'a contract with no vocabulary block\n' > "$_empty"
    if LINTEL_STATE_CONTRACT="$_empty" sh "$0" --terminal >/dev/null 2>&1; then
      echo "SELFTEST FAILED: --terminal succeeded against a contract with no vocabulary block" >&2
      rm -f "$_empty"; exit 1
    fi
    rm -f "$_empty"
    # And confirm it answers correctly against the real contract.
    _t=$(sh "$0" --terminal 2>/dev/null) || { echo "SELFTEST FAILED: --terminal failed on $CONTRACT" >&2; exit 1; }
    echo "selftest: OK — unavailable is reported, not guessed; live terminal set:"
    printf '%s\n' "$_t" | sed 's/^/  /'
    ;;
  *) echo "usage: request-states.sh --terminal|--non-terminal|--all|--source|--is-terminal <s>|--selftest" >&2; exit 2 ;;
esac

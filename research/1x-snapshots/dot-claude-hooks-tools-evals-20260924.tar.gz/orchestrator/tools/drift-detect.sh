#!/usr/bin/env zsh
#
# drift-detect.sh — compare the LIVE orchestrator tree against the PUBLISHED copy
# staged for the public repo, and report every difference that is NOT a known
# redaction.
#
#   zsh /Users/jowolff/.claude/orchestrator/tools/drift-detect.sh
#
# Exit 0 = no unexpected drift. Exit 1 = unexpected drift found. Exit 2 = a root
# is missing (cannot compare). Read-only: this script never writes to either tree.
#
# ─────────────────────────────────────────────────────────────────────────────
# THE ALLOWLIST — edit this array, nothing else, to record a new redaction.
#
# Each entry is a path RELATIVE to either root (no leading slash). A file listed
# here is allowed to differ between the two trees; it is reported under "expected
# divergence" and does not affect the exit status. A file NOT listed here that
# differs is drift.
#
# Every entry below was derived from an actual redaction commit in
# /Users/jowolff/code/lintel — do not add an entry you cannot trace to one.
# ─────────────────────────────────────────────────────────────────────────────
typeset -a ALLOWLIST
ALLOWLIST=(
  # Commits 53044d1 + 91a0fea ("Neutralize a verbatim user quote in the
  # savepoint-guard comment" / "correct transcribed misspelling in heuristic
  # comment example"). A comment in the instruction heuristic quoted the
  # operator verbatim, including a typo; both were replaced with neutral prose.
  # Comment-only in both commits — no behaviour difference.
  "hooks/savepoint-guard.mjs"

  # Commit 95e0dbe ("evals: neutralize transcribed quotations in refint
  # fixtures"). Six eval fixtures each carried one string transcribed from a
  # live inbox; each was replaced with a neutral equivalent of the same
  # linguistic shape. One line changed per file.
  "evals/scenarios/refint-bare-obligation-no-id-passthrough/setup.sh"
  "evals/scenarios/refint-conversation-smalltalk-passthrough/setup.sh"
  "evals/scenarios/refint-dangling-ref-blocks/setup.sh"
  "evals/scenarios/refint-defined-ref-passthrough/setup.sh"
  "evals/scenarios/refint-names-offending-row/setup.sh"
  "evals/scenarios/refint-untriaged-smalltalk-not-annotated/setup.sh"
)

# ─────────────────────────────────────────────────────────────────────────────
# EXCLUSIONS — paths that are runtime state or tooling noise, not machinery.
# Extended regexes matched against the root-relative path.
#
# The first block is quoted from /Users/jowolff/code/lintel/.gitignore, which is
# the authoritative statement of what the published tree deliberately omits: the
# orchestrator writes these while running, they carry operator input and session
# ids, and they are regenerated per machine. Comparing them would report drift on
# every run forever.
#
# The second block is generic tooling noise that is never machinery.
# ─────────────────────────────────────────────────────────────────────────────
typeset -a EXCLUDE
EXCLUDE=(
  # -- runtime state, per lintel/.gitignore --------------------------------
  '^state/runs(/|$)'                 # per-run working dirs; unbounded, machine-local
  '^state/quarantine(/|$)'           # quarantined artifacts; machine-local
  '^state/hook-lab(/|$)'             # hook experiment scratch; machine-local
  '^state/turn-ids(/|$)'             # per-turn id files; regenerated every session
  '^state/hook-backups-[^/]*(/|$)'   # timestamped hook backups; one dir per edit session
  '^state/LEDGER\.jsonl'             # append-only ledger + its .pre-* snapshots; grows every turn
  '^state/REQUESTS(-INBOX)?\.jsonl$' # live request queues; carry operator input verbatim
  '^state/(STANDUP|WORKSTREAMS|REGISTRY|ROUTING|EXPERIMENTS|RETRACTIONS|BOOTSTRAP-REPORT)\.md$' # rewritten in-place as work proceeds
  '^state/\.(session-id|turn-state|guard-state|refint-watermark)$'  # dotfile cursors; rewritten per turn

  # -- generic noise -------------------------------------------------------
  '(^|/)\.git(/|$)'                  # VCS internals, not machinery
  '(^|/)node_modules(/|$)'           # installed dependencies, not machinery
  '\.log$'                           # run logs; written by the machinery, not part of it
  '(^|/)\.DS_Store$'                 # Finder metadata; gitignored in the published tree
)

emulate -L zsh
setopt pipe_fail

LIVE_ROOT="/Users/jowolff/.claude/orchestrator"
PUB_ROOT="/Users/jowolff/code/lintel/orchestrator"
# The charter lives outside both roots and is symlinked in as CHARTER.md, so it
# is compared explicitly as an extra pair rather than by the recursive walk.
LIVE_CHARTER="/Users/jowolff/.claude/agents/orchestrator.md"
PUB_CHARTER="/Users/jowolff/code/lintel/agents/orchestrator.md"

for d in "$LIVE_ROOT" "$PUB_ROOT"; do
  [[ -d "$d" ]] || { print -u2 -- "drift-detect: missing root: $d"; exit 2; }
done
for f in "$LIVE_CHARTER" "$PUB_CHARTER"; do
  [[ -f "$f" ]] || { print -u2 -- "drift-detect: missing charter file: $f"; exit 2; }
done

is_excluded() {
  local rel="$1" pat
  for pat in "${EXCLUDE[@]}"; do
    [[ "$rel" =~ $pat ]] && return 0
  done
  return 1
}

is_allowlisted() {
  local rel="$1" a
  for a in "${ALLOWLIST[@]}"; do
    [[ "$rel" == "$a" ]] && return 0
  done
  return 1
}

typeset -a DIFFER ONLY_LIVE ONLY_PUB EXPECTED OTHER

# -x prunes .git and node_modules during the walk so we never descend into them.
# Everything else is filtered from the output, because -x matches basenames only
# and most of our exclusions are path-scoped.
while IFS= read -r line; do
  case "$line" in
    "Files "*" differ")
      # "Files <LIVE>/<rel> and <PUB>/<rel> differ"
      rel="${line#Files $LIVE_ROOT/}"
      rel="${rel%% and *}"
      is_excluded "$rel" && continue
      if is_allowlisted "$rel"; then EXPECTED+=("$rel"); else DIFFER+=("$rel"); fi
      ;;
    "Only in "*)
      dir="${line#Only in }"; dir="${dir%%: *}"
      name="${line##*: }"
      if [[ "$dir" == "$LIVE_ROOT" ]]; then rel="$name"
      elif [[ "$dir" == "$PUB_ROOT" ]]; then rel="$name"
      elif [[ "$dir" == "$LIVE_ROOT/"* ]]; then rel="${dir#$LIVE_ROOT/}/$name"
      elif [[ "$dir" == "$PUB_ROOT/"* ]]; then rel="${dir#$PUB_ROOT/}/$name"
      else OTHER+=("$line"); continue
      fi
      is_excluded "$rel" && continue
      if [[ "$dir" == "$LIVE_ROOT"* ]]; then ONLY_LIVE+=("$rel"); else ONLY_PUB+=("$rel"); fi
      ;;
    "")  ;;
    *)   OTHER+=("$line") ;;   # e.g. type mismatches; never silently dropped
  esac
done < <(diff -rq -x '.git' -x 'node_modules' "$LIVE_ROOT" "$PUB_ROOT" 2>/dev/null)

# The charter pair, compared by content.
if ! cmp -s "$LIVE_CHARTER" "$PUB_CHARTER"; then
  if is_allowlisted "CHARTER.md"; then EXPECTED+=("CHARTER.md (agents/orchestrator.md)")
  else DIFFER+=("CHARTER.md (agents/orchestrator.md)")
  fi
fi

n_unexpected=$(( ${#DIFFER} + ${#ONLY_LIVE} + ${#ONLY_PUB} + ${#OTHER} ))
n_expected=${#EXPECTED}

print -- "$n_unexpected unexpected differences, $n_expected expected"
print -- ""

if (( ${#DIFFER} )); then
  print -- "DRIFT — files differing (not traceable to a redaction):"
  for f in "${DIFFER[@]}"; do print -- "  $f"; done
  print -- ""
fi
if (( ${#ONLY_LIVE} )); then
  print -- "DRIFT — present only in LIVE ($LIVE_ROOT):"
  for f in "${ONLY_LIVE[@]}"; do print -- "  $f"; done
  print -- ""
fi
if (( ${#ONLY_PUB} )); then
  print -- "DRIFT — present only in PUBLISHED ($PUB_ROOT):"
  for f in "${ONLY_PUB[@]}"; do print -- "  $f"; done
  print -- ""
fi
if (( ${#OTHER} )); then
  print -- "DRIFT — unparsed diff output (treated as drift on purpose):"
  for f in "${OTHER[@]}"; do print -- "  $f"; done
  print -- ""
fi

if (( n_expected )); then
  print -- "expected divergence (known redactions, not drift):"
  for f in "${EXPECTED[@]}"; do print -- "  $f"; done
  print -- ""
fi

(( n_unexpected == 0 )) && exit 0
exit 1

#!/bin/sh
# run-open.sh — mint a run id and DECLARE that the run exists.
#
# WHY THIS EXISTS, AND IT IS A DEFECT FIX RATHER THAN AN AMBITION. Nothing on this machine marked
# the beginning of a run. An id was invented in prose, in a message, and no tool ever observed the
# moment — so anything asking "was this run ever real?" had to guess from text. The dispatch check
# built on 2026-08-24 has ONE true-positive class and TWO false ones: it fires on work done inline,
# and it fires on a run merely NAMED as the next thing someone will take. Both exist because a token
# of run-id shape is indistinguishable from a run.
#
# A DECLARED RUN IS NOT A GUESS. Ask this tool for an id and the run exists; do not ask, and the
# token in your prose is just a token.
#
# ⛔ IT NEVER GATES WORK. If the declaration cannot be written — read-only disk, missing directory,
# anything — it still prints an id and exits 0. A dispatch blocked because an id could not be minted
# would be far worse than the problem this solves. The failure mode is a gap in the record, which is
# the status quo, not a stopped agent.
#
# ⛔ WHAT THE RESIDUE BECOMES, so a future reader meets it here rather than rediscovering it:
# ids can still be minted by hand and will be. So this does not close the guessing problem, it MOVES
# it: from false positives on prose tokens that merely look like run ids, to SILENCE on runs nobody
# declared. That is a better trade — a false alarm trains a reader to ignore the instrument, and a
# silence does not — but it is a trade, and anything built on declared ids inherits it.
#
# ⛔ AND IT DOES NOTHING ON ITS OWN. The dispatch-check hook does not read declarations yet. Until it
# does, this tool changes no behaviour anywhere. See the report for run `id-issuer-20260825`.
#
# NO CONTRACT IS WRITTEN. `state/tools/dispatch-contract.sh` exists and was used for 1 run in 156,
# because its only consumer — the judge — was built on 2026-08-24 and has run once. Automating a
# producer for a reader with one data point is the error this fleet spent a night finding. If judging
# becomes routine the contract acquires a real reader and this tool adds it in a line.
# ⛔ DEADLINE, RECORDED WHILE NOBODY IS ATTACHED TO THE OUTCOME: if the judge is still unused on
# 2026-09-25, the contract mechanism retires and we say so.
#
# usage:
#   run-open.sh <slug>              print a new run id and declare it
#   run-open.sh --inline <slug>     declare a run that will be done INLINE, with no worker dispatched
#   run-open.sh --list              list declared run ids
#   run-open.sh <slug> --runs-dir D declare into D instead (TEST INJECTION POINT, documented so the
#                                   exemption is visible; a live run never passes it)
#
# Exit: 0 always, except 2 for a malformed slug — which is a usage error, not a work stoppage.

# ⛔ LC_ALL=C IS LOAD-BEARING, NOT HYGIENE. Under en_US.UTF-8 the glob class [a-z] follows the
# locale collation, which interleaves case — so `Demo` matched [a-z0-9-] and the slug check below
# ACCEPTED it. Measured 2026-08-25: `run-open.sh Demo` exited 0 and would have minted `Demo-<date>`.
# That id is invisible to the dispatch check, whose extractor is [a-z][a-z0-9-]*-[0-9]{8} — so the
# run would have been declared and then never recognised, which is worse than not declaring it.
LC_ALL=C
export LC_ALL

RUNS="/Users/jowolff/.claude/orchestrator/state/runs"
SLUG=""
while [ $# -gt 0 ]; do
  case "$1" in
    --runs-dir) RUNS="${2:?--runs-dir needs a path}"; shift 2 ;;
    --list)     LIST=1; shift ;;
    --inline)   INLINE=1; shift ;;
    -*)         echo "unknown argument: $1" >&2; exit 2 ;;
    *)          SLUG="$1"; shift ;;
  esac
done

if [ "${LIST:-0}" = 1 ]; then
  # The declared set is the marker files, NOT the directory listing. A run directory is also created
  # lazily by worker-report.sh when somebody writes the first report, long after the run began — so
  # directory-existence conflates "declared" with "someone wrote something". The marker is the only
  # thing that means a person opened this run deliberately.
  ls -1 "$RUNS"/*/.declared 2>/dev/null | sed 's|/.declared$||' | sed "s|^$RUNS/||"
  exit 0
fi

[ -n "$SLUG" ] || { echo "usage: run-open.sh <slug>" >&2; exit 2; }
case "$SLUG" in
  *[!a-z0-9-]*|-*|*-) echo "slug must be lowercase letters, digits and inner hyphens: '$SLUG'" >&2; exit 2 ;;
esac

ID="${SLUG}-$(date +%Y%m%d)"
# COLLISION. A second run of the same slug on the same day is a different run, not the same one.
# The test is BOTH the marker and the directory: an undeclared directory of this name was created
# lazily by worker-report.sh for a run somebody already opened by hand, and handing that id back
# would silently merge two runs' reports into one folder.
N=2
while [ -e "$RUNS/$ID/.declared" ] || [ -d "$RUNS/$ID" ]; do
  ID="${SLUG}-$(date +%Y%m%d)-$N"
  N=$((N + 1))
  [ "$N" -gt 99 ] && break   # never loop forever; a 99th run of one slug in one day is not real
done

# THE DECLARATION. Everything below is best-effort: the id is already decided and will be printed
# whatever happens here.
# MARKER FORMAT: line 1 is a UTC timestamp. An optional line 2 of `inline` says the run will be
# carried out in the main thread with no worker dispatched.
#
# ⛔ WHY `--inline` EXISTS, because it looks like a nicety and is not. The dispatch check flags a
# DECLARED run with no dispatch on record. Work done inline leaves no Task call, so a declared inline
# run would be flagged forever — and the only way to avoid that would be to NOT declare inline runs,
# which makes the declared set a lie and quietly punishes declaring. `--inline` is a DECLARED signal:
# the author says which kind of run it is, rather than any tool inferring it from prose. Nothing
# guesses; if it goes undeclared, the check simply says nothing about it.
mkdir -p "$RUNS/$ID" 2>/dev/null && {
  printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$RUNS/$ID/.declared" 2>/dev/null
  [ "${INLINE:-0}" = 1 ] && printf 'inline\n' >> "$RUNS/$ID/.declared" 2>/dev/null
}

printf '%s\n' "$ID"

# ⛔ THE SECOND UNENFORCED LINK, AND IT CAUGHT ITS AUTHOR WITHIN THE HOUR.
# Declaring a run makes "is this a real run?" answerable. It does NOT make a dispatch attributable:
# tools/dispatch-spine.py recovers a run id only by finding it in the Task/Agent PROMPT or its
# description (see RUNID / run_ids() in that file). A worker dispatched without the id in its prompt
# is invisible to the spine, so a correctly declared, correctly dispatched run reads as undispatched
# and the Stop check fires — correctly.
#
# Measured 2026-08-25: `phoenix-usage-20260825` was declared, two workers were dispatched for it, and
# the spine found 0 of 1100 rows naming it, because neither delegation prompt contained the id.
#
# So the reminder is printed at the one moment the id is in front of somebody. It goes to STDERR,
# never stdout, so `ID=$(run-open.sh slug)` still captures the bare id and nothing else.
[ "${INLINE:-0}" = 1 ] || cat >&2 <<'EOF'
run-open: put this id in the PROMPT of every worker you dispatch for it (the description alone is
          not enough on its own, though it also counts). The dispatch record is reconstructed by
          searching prompts for the id — a worker sent without it cannot be attributed to this run,
          and the Stop check will report the run as undispatched.
EOF

if [ ! -e "$RUNS/$ID/.declared" ]; then
  echo "run-open: NOTE — the id above is valid and the declaration could not be written." >&2
  echo "          Nothing is blocked. Anything reading declared runs will not see this one." >&2
fi
exit 0

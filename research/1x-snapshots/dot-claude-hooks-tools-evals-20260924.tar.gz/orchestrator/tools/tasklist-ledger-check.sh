#!/bin/sh
# tasklist-ledger-check.sh — does the human-readable task list still agree with REQUESTS.jsonl?
#
# WHY THIS FILE EXISTS. state/.projects/lintel-machinery/TASKS.md is the human face of the ledger,
# and on 2026-08-20 it went stale within hours of being written: items finished that morning were
# still shown as open in front of the owner. THE DEFECT WAS NOT CARELESSNESS, IT WAS THE ABSENCE OF
# A JOIN KEY — a grep for the ledger's id pattern across the whole list returned ZERO matches, so
# keeping the two in step depended entirely on somebody remembering. Every item now ends with a
# `*ledger: REQ-NNN*` line, and this is the checker that makes forgetting loud.
#
# WHAT IT CHECKS, all four directions:
#   - an item checked while its row is still owed  (the box claims work the authority does not)
#   - an item unchecked while its row is terminal  (finished business shown as a live obligation)
#   - an item referencing a row that does not exist
#   - a row still owed with no item referencing it (work the owner's list never shows them)
#   - an item with no `ledger:` reference at all
#
# THE VOCABULARY IS NOT DEFINED HERE, deliberately — same rule as tools/requests-schema-check.sh.
# Which states are terminal comes from tools/request-states.sh, which parses the contract and owns
# that answer. This matters more here than anywhere: `deferred` and `dropped` are FINISHED BUSINESS,
# and a checker with its own copy of that list is one edit away from re-raising closed work.
#
# `(part)` MEANS ADVISORY. An item tagged `REQ-NNN (part)` is one piece of a larger row, so the
# row's state does not decide that box. The row must still exist, and every advisory reference is
# LISTED IN THE OUTPUT rather than silently skipped — an exemption nobody can see is a second
# stale list waiting to happen.
#
# Usage:
#   tasklist-ledger-check.sh [tasks.md] [ledger.jsonl]
#   tasklist-ledger-check.sh --selftest      # prove the checker can fail, one defect class at a
#                                            # time, against throwaway copies of both files
#
# Exit codes: 0 they agree | 1 they disagree | 2 could not run the check.

set -u

ORCH="$(cd "$(dirname "$0")/.." && pwd)"
TASKS_DEFAULT="$ORCH/state/.projects/lintel-machinery/TASKS.md"
LEDGER_DEFAULT="$ORCH/state/REQUESTS.jsonl"

case "${1:-}" in
  --selftest) SELFTEST=1; TASKS="$TASKS_DEFAULT"; LEDGER="$LEDGER_DEFAULT" ;;
  *)          SELFTEST=0; TASKS="${1:-$TASKS_DEFAULT}"; LEDGER="${2:-$LEDGER_DEFAULT}" ;;
esac

command -v python3 >/dev/null || { echo "preflight: python3 not found" >&2; exit 2; }
[ -f "$ORCH/tools/tasklist-ledger-check.py" ] || {
  echo "preflight: validator missing at $ORCH/tools/tasklist-ledger-check.py" >&2; exit 2; }
[ -x "$ORCH/tools/request-states.sh" ] || [ -f "$ORCH/tools/request-states.sh" ] || {
  echo "preflight: the state predicate is missing at $ORCH/tools/request-states.sh" >&2; exit 2; }

run_check() {
  _tasks="$1"; _ledger="$2"
  [ -f "$_tasks" ]  || { echo "preflight: no task list at $_tasks" >&2; return 2; }
  [ -f "$_ledger" ] || { echo "preflight: no ledger at $_ledger" >&2; return 2; }
  _term="$(sh "$ORCH/tools/request-states.sh" --terminal 2>/dev/null)"
  _nonterm="$(sh "$ORCH/tools/request-states.sh" --non-terminal 2>/dev/null)"
  _src="$(sh "$ORCH/tools/request-states.sh" --source 2>/dev/null)"
  # NO FALLBACK LIST. If the contract cannot be read this refuses to run rather than assuming that
  # `delivered` is the only finished state — the assumption that re-raised every dropped row.
  if [ -z "$_term" ] || [ -z "$_nonterm" ]; then
    echo "FAIL: the state vocabulary could not be read via tools/request-states.sh — refusing to" >&2
    echo "      guess which states are terminal. Fix the contract parse first." >&2
    return 2
  fi
  TLC_TERMINAL="$_term" TLC_NONTERMINAL="$_nonterm" TLC_SOURCE="$_src" \
  TLC_TASKS="$_tasks" TLC_LEDGER="$_ledger" \
    python3 "$ORCH/tools/tasklist-ledger-check.py"
}

if [ "$SELFTEST" -ne 1 ]; then
  run_check "$TASKS" "$LEDGER"
  exit $?
fi

# --selftest. A checker that has only ever passed is not evidence. Each fixture below is a
# THROWAWAY COPY in a fresh mktemp -d; the real list and the real ledger are only ever read.
d="$(mktemp -d)" || exit 2
echo "selftest: fixtures in $d (throwaway copies; the real files are only read)"

led="$d/ledger.jsonl"
{
  printf '%s\n' '{"id":"REQ-001","ts":"2026-08-20T10:00:00Z","request":"finished thing","state":"delivered","touches":[],"note":""}'
  printf '%s\n' '{"id":"REQ-002","ts":"2026-08-20T10:00:00Z","request":"owed thing","state":"open","touches":[],"note":""}'
  printf '%s\n' '{"id":"REQ-003","ts":"2026-08-20T10:00:00Z","request":"closed as dropped","state":"dropped","touches":[],"note":""}'
} > "$led"

# A list that agrees with that ledger: delivered is checked, open is not, dropped is CHECKED
# because terminal means finished business whatever the outcome.
cat > "$d/agreeing.md" <<'MD'
# fixture
- [x] **Finished thing.** Body.
      *ledger: REQ-001*
- [ ] **Owed thing.** Body.
      *ledger: REQ-002*
- [x] **Closed as dropped.** Body.
      *ledger: REQ-003*
MD

mk() { sed "$2" "$d/agreeing.md" > "$d/$1.md"; }
mk checked-while-still-owed      's/^- \[ \] \*\*Owed thing/- [x] **Owed thing/'
mk unchecked-while-terminal      's/^- \[x\] \*\*Finished thing/- [ ] **Finished thing/'
mk dropped-shown-as-live         's/^- \[x\] \*\*Closed as dropped/- [ ] **Closed as dropped/'
mk reference-to-a-missing-row    's/REQ-002/REQ-404/'
mk item-with-no-reference        '/ledger: REQ-002/d'
# An owed row with no item at all: delete the item that covers REQ-002 entirely.
sed '/Owed thing/,+1d' "$d/agreeing.md" > "$d/owed-row-with-no-item.md"

for name in checked-while-still-owed unchecked-while-terminal dropped-shown-as-live \
            reference-to-a-missing-row item-with-no-reference owed-row-with-no-item; do
  out="$(run_check "$d/$name.md" "$led" 2>&1)"; rc=$?
  if [ "$rc" -eq 0 ]; then
    echo "SELFTEST FAILED: the checker PASSED a list carrying defect class '$name'" >&2
    printf '%s\n' "$out" | sed 's/^/      /' >&2
    : > "$d/.failed"
  else
    echo "  caught  $name  (exit $rc)"
    printf '%s\n' "$out" | grep -E '^  (L[0-9]+|REQ-)' | head -1 | sed 's/^/       /'
  fi
done

if run_check "$d/agreeing.md" "$led" >/dev/null 2>&1; then
  echo "  passed  a list that agrees with its ledger (exit 0)"
else
  echo "SELFTEST FAILED: the checker rejected a list that agrees with its ledger" >&2
  run_check "$d/agreeing.md" "$led" 2>&1 | sed 's/^/      /' >&2
  : > "$d/.failed"
fi

if [ -f "$d/.failed" ]; then
  echo "SELFTEST FAILED — see above. Fixtures kept at $d for inspection." >&2
  exit 1
fi
echo "selftest: OK — every defect class above was caught, and an agreeing pair passed."
exit 0

#!/usr/bin/env python3
"""Row-by-item validator behind tools/tasklist-ledger-check.sh.

This file holds NO state vocabulary, deliberately — same rule as tools/requests-schema-check.py.
Everything it enforces arrives in the environment, resolved by the shell driver out of the charter
via tools/request-states.sh:

    TLC_TERMINAL      terminal state names, one per line
    TLC_NONTERMINAL   non-terminal state names, one per line
    TLC_LEDGER        path to the .jsonl that is the authority
    TLC_TASKS         path to the checkbox list that answers to it
    TLC_SOURCE        where the vocabulary came from, for the header

Run it directly and it exits 2, because without those it has nothing to enforce and guessing which
states mean "finished" is the exact defect this tool exists to prevent: `dropped` and `deferred` are
FINISHED BUSINESS, and a checker that reads them as pending re-raises closed work forever.

Exit codes: 0 the two files agree | 1 they disagree | 2 could not run the check.
"""

import json
import os
import re
import sys

# A checkbox item starts a list entry; its body continues on indented lines until the next entry,
# the next heading, or a horizontal rule.
ITEM_RE = re.compile(r"^\s*-\s+\[( |x|X)\]\s+(.*)$")
STOP_RE = re.compile(r"^(#{1,6}\s|---\s*$|\s*-\s+\[( |x|X)\]\s)")
TAG_RE = re.compile(r"\*ledger:\s*([^*]+)\*")
REF_RE = re.compile(r"(REQ-\d+)\s*(\((part|Part)\))?")
TITLE_RE = re.compile(r"\*\*(.+?)\*\*")


def env(name):
    v = os.environ.get(name)
    if v is None or v == "":
        sys.stderr.write(
            f"tasklist-ledger-check.py: {name} not set. This validator is driven by\n"
            f"tools/tasklist-ledger-check.sh, which resolves the state vocabulary from the charter\n"
            f"and passes it in. Run that instead; this file declares no vocabulary of its own.\n"
        )
        sys.exit(2)
    return v


def short(text, n=64):
    t = " ".join(text.split())
    m = TITLE_RE.search(t)
    if m:
        t = m.group(1)
    t = re.sub(r"[*`]", "", t)
    return t if len(t) <= n else t[: n - 1] + "…"


def parse_tasks(path):
    """Return [(line_no, checked, title, [(req_id, advisory)], had_tag)]."""
    items = []
    with open(path, "r", encoding="utf-8") as fh:
        lines = fh.readlines()
    for i, raw in enumerate(lines):
        m = ITEM_RE.match(raw)
        if not m:
            continue
        checked = m.group(1).lower() == "x"
        title = short(m.group(2))
        body = [raw]
        for nxt in lines[i + 1:]:
            if STOP_RE.match(nxt):
                break
            body.append(nxt)
        blob = "".join(body)
        tag = TAG_RE.search(blob)
        refs = []
        if tag:
            for rm in REF_RE.finditer(tag.group(1)):
                refs.append((rm.group(1), rm.group(3) is not None))
        items.append((i + 1, checked, title, refs, tag is not None))
    return items


def main():
    tasks_path = env("TLC_TASKS")
    ledger_path = env("TLC_LEDGER")
    source = env("TLC_SOURCE")
    terminal = set(env("TLC_TERMINAL").split("\n"))
    non_terminal = set(env("TLC_NONTERMINAL").split("\n"))
    known_states = terminal | non_terminal

    ledger = {}
    with open(ledger_path, "r", encoding="utf-8") as fh:
        for n, raw in enumerate(fh, 1):
            if not raw.strip():
                continue
            try:
                row = json.loads(raw)
            except Exception as exc:
                sys.stderr.write(f"tasklist-ledger-check.py: {ledger_path} line {n}: {exc}\n")
                sys.stderr.write("The ledger is unreadable, so nothing can be checked against it.\n")
                return 2
            rid, st = row.get("id"), row.get("state")
            if isinstance(rid, str):
                ledger[rid] = st

    unknown_state_rows = sorted(r for r, s in ledger.items() if s not in known_states)
    if unknown_state_rows:
        sys.stderr.write(
            "tasklist-ledger-check.py: rows carry states the charter does not declare: "
            + " ".join(unknown_state_rows)
            + "\nRun tools/requests-schema-check.sh — that is the checker that owns this.\n"
        )
        return 2

    items = parse_tasks(tasks_path)
    problems = []   # (line_no, message)
    advisory = []   # (line_no, title, req_id, state)
    referenced = set()

    for line_no, checked, title, refs, had_tag in items:
        if not had_tag or not refs:
            problems.append(
                (line_no, f"{title}: no `ledger:` reference — nothing links this item to a row, "
                          f"which is how the list went stale in the first place")
            )
            continue

        strict = []
        for rid, is_advisory in refs:
            if rid not in ledger:
                problems.append((line_no, f"{title}: references {rid}, which is not in the ledger"))
                continue
            referenced.add(rid)
            if is_advisory:
                advisory.append((line_no, title, rid, ledger[rid]))
            else:
                strict.append(rid)

        if not strict:
            continue

        live = [r for r in strict if ledger[r] in non_terminal]
        if checked and live:
            problems.append(
                (line_no, f"{title}: checked, but "
                          + ", ".join(f"{r} is {ledger[r]}" for r in live)
                          + " — still owed, so the box claims work the authority does not")
            )
        if not checked and not live:
            problems.append(
                (line_no, f"{title}: unchecked, but "
                          + ", ".join(f"{r} is {ledger[r]}" for r in strict)
                          + " — terminal means finished business, so this reads as live work when "
                            "it is not")
            )

    owed = [r for r, s in sorted(ledger.items()) if s in non_terminal and r not in referenced]

    print(f"vocabulary: {source}")
    print(f"terminal:   {' '.join(sorted(terminal))}")
    print(f"ledger:     {ledger_path} ({len(ledger)} rows, "
          f"{sum(1 for s in ledger.values() if s in non_terminal)} still owed)")
    print(f"tasks:      {tasks_path} ({len(items)} items, "
          f"{sum(1 for i in items if i[1])} checked)")

    if advisory:
        print()
        print(f"advisory references — the row's state does not decide these boxes ({len(advisory)}):")
        for line_no, title, rid, st in advisory:
            print(f"  L{line_no}: {rid} ({st}) — {title}")

    if not problems and not owed:
        print()
        print("OK — every item names a row that exists, every box agrees with its row's state, and "
              "every row still owed has an item.")
        return 0

    print()
    total = len(problems) + len(owed)
    print(f"FAIL — {total} disagreement(s):")
    for line_no, msg in problems:
        print(f"  L{line_no}: {msg}")
    for rid in owed:
        print(f"  {rid}: state '{ledger[rid]}' is still owed and no item in {os.path.basename(tasks_path)} "
              f"references it")
    return 1


if __name__ == "__main__":
    sys.exit(main())

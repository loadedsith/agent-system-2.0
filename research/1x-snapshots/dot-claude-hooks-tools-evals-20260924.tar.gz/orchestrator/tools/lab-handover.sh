#!/bin/sh
# lab-handover.sh — the wrapper the wrap-up flow invokes.
#
# THE NAME IS LOAD-BEARING. state-checks-stop.mjs discovers every executable file under
# orchestrator/tools/ whose name ends in `-check.sh` and runs it at EVERY stop. This tool must
# never be named that. Stop time is not a boundary — it fires on every turn against everything —
# and it is the placement that was rejected before this was built. Renaming this file to
# lab-handover-check.sh silently converts it into the thing it replaced.
set -e
exec python3 "$(dirname "$0")/lab-handover.py" "$@"

#!/usr/bin/env zsh
#
# publish-run.sh — run ONE publishing script detached from the turn, under a lock and a watchdog,
# and leave behind a machine-readable record of how it went.
#
#   zsh publish-run.sh <name> <script-path> [args-for-the-script...]
#
# WHO CALLS THIS. orchestrator/hooks/publish-stop.mjs spawns it detached when that hook's --check
# of <script-path> reported drift. A human can also run it by hand; it is safe from the top every
# time and assumes nothing from a previous run.
#
# WHY IT IS A SEPARATE FILE FROM THE HOOK. The hook must return in milliseconds and must never
# hold the turn open. Everything slow — network, gh, a push — happens here, in a process the hook
# has already let go of. The hook never waits on this and never reads its stdout; it reads only
# the marker files written below, on a LATER stop.
#
# WHAT IT WRITES, all inside <state>/.guard-state/, which is per-session runtime state already
# excluded from both the state mirror and the published tree:
#   publish-<name>.lock/      a directory, taken atomically with mkdir. Its presence means a run
#                             is in flight; the hook skips the publisher entirely while it is held.
#   publish-<name>.run.log    this wrapper's own transcript of the run.
#   publish-<name>.fail       written ONLY on a real failure — a watchdog kill, or an exit code
#                             that is not 0 and not one of the DECLINED codes below — and removed
#                             on success. Its existence is what makes a failure visible: the hook
#                             announces it on the next stop. Nothing else reads it.
#   publish-<name>.skipped    the current run of consecutive DECLINES: when the first one in the
#                             run happened, and how many there have been. Deleted the moment the
#                             publisher succeeds or genuinely fails. Nothing announces it; it
#                             exists so a publisher that declines forever eventually gets loud.
#
# ── A DECLINE IS NOT A FAILURE ───────────────────────────────────────────────────────────────
# A publisher can stop because it broke, or because a precondition it checks for itself was not
# met. The second is correct behaviour, clears by itself in minutes, and costs the owner nothing.
# tools/publish-exit-codes.sh is the ONE place the codes for the second case are defined, read
# from there by this file and by the publishers themselves so the two cannot disagree.
#
# On a decline this wrapper writes NO failure marker, so the Stop hook stays silent and its
# 30-minute backoff is never armed — the publisher is tried again on the very next stop, which is
# what you want for a condition that clears in ~2 minutes. Measured 2026-08-20T22:55:08Z, before
# this existed: sync-to-lintel.sh declined correctly (a file in its copy set had been written 80s
# earlier), exited 4, and the owner got "PUBLISHING IS NOT HAPPENING — 1 of 2 publisher(s)
# failed" plus a half-hour of not even checking.
#
# A decline never clears an existing failure marker and never resets a backoff. It is silence
# about ITSELF and nothing else, so a real failure sitting unannounced from an earlier run
# survives a decline intact and still speaks.
#
# IT NEVER TOUCHES A PROTECTED BRANCH, because it never runs a git command at all. It runs the
# script it was handed, and both publishers refuse protected branch names themselves.
#
# EXIT CODES (nobody waits on these; they are for a human running it by hand)
#   0  the script ran and exited 0, or another run already holds the lock
#   1  the script exited non-zero, or the watchdog killed it — publish-<name>.fail was written
#   2  this wrapper could not start (bad arguments, unwritable state directory)
#   3  REFUSED. The script's age could not be established, or its mtime is in the future, or it
#      changed underneath a run — publish-<name>.fail was written saying which. Each of those is
#      a condition nobody can promise clears by itself, so each stays loud.
#   DECLINED runs exit with A DECLINE CODE from tools/publish-exit-codes.sh — the publisher's own
#      when the publisher declined, or SCRIPT_UNSETTLED when this wrapper declined to run a script
#      that was edited moments ago. Both take the same quiet path: no failure marker, a run-log
#      line, a streak file, and escalation once the declining has gone on too long. No number is
#      written here for that case on purpose — the codes live in tools/publish-exit-codes.sh and
#      copying one into this comment block is how the two would drift apart. NO failure marker is
#      written and nothing is wrong; run log says which code and what it means.

emulate -L zsh
setopt pipe_fail

NAME="${1:-}"
SCRIPT="${2:-}"
if [[ -z "$NAME" || -z "$SCRIPT" ]]; then
  print -u2 -- "usage: publish-run.sh <name> <script-path> [args...]"
  exit 2
fi
shift 2
# Captured at top level ON PURPOSE. Inside a zsh function $* is the FUNCTION's arguments, not the
# script's, so refuse() below cannot use $* to name what it was asked to run.
SCRIPT_ARGS="$*"

STATE="${LINTEL_STATE:-/Users/jowolff/.claude/orchestrator/state}"
GUARD="$STATE/.guard-state"
LOCK="$GUARD/publish-$NAME.lock"
FAIL="$GUARD/publish-$NAME.fail"
RUNLOG="$GUARD/publish-$NAME.run.log"
SKIPPED="$GUARD/publish-$NAME.skipped"

# ── the shared "declined on purpose" codes ──────────────────────────────────────────────────
# Sourced from beside this file. The publishers source the same file, which is the only reason
# they and this wrapper cannot come to disagree about which exit codes are declines.
#
# IF IT IS MISSING, NOTHING IS A DECLINE. publish_exit_is_declined() is stubbed to false and
# every non-zero exit is treated as a failure — i.e. exactly the behaviour that existed before
# this file, which is loud. Failing the other way would turn an unreadable definition file into
# a publisher that fails silently forever, and a backup whose failure is invisible is worse than
# no backup at all.
CODES="${0:A:h}/publish-exit-codes.sh"
if [[ -r "$CODES" ]]; then
  source "$CODES"
else
  publish_exit_is_declined() { return 1; }
  publish_exit_reason() { print -r -- ""; }
  publish_exit_advice() { print -r -- ""; }
  CODES_MISSING=1
fi

# ── HOW LONG A PUBLISHER MAY GO ON DECLINING BEFORE THE OWNER IS TOLD ────────────────────────
# Silence forever is the failure mode on the far side of the one this file fixes. A file that is
# rewritten every minute, or a stuck writer, would keep sync-to-lintel.sh's quiescence gate
# declining for as long as it lasts, and quietly nothing would ever be published.
#
# So consecutive declines are counted, and once the FIRST one in an unbroken run is this old the
# next decline writes a real failure marker and gets the ordinary loud treatment. One hour is
# chosen against the two windows either side of it: the condition itself is supposed to clear in
# 120s (the quiescence window in sync-to-lintel.sh), and the Stop hook's own post-failure backoff
# is 30 minutes, so an hour is long enough that a normal burst of editing never reaches it and
# short enough that a genuinely stuck publisher is named the same working session it got stuck.
# On escalation the window restarts, so a publisher that stays stuck says so about once an hour
# rather than once ever.
SKIP_ESCALATE_SECONDS="${LINTEL_PUBLISH_SKIP_ESCALATE_SECONDS:-3600}"

# How long a run may take before the watchdog kills it. A push plus a pull request is seconds;
# ten minutes is generous enough that a slow network is not mistaken for a hang.
MAX_SECONDS="${LINTEL_PUBLISH_MAX_SECONDS:-600}"
# How old a lock must be before it is treated as abandoned rather than held. Deliberately larger
# than MAX_SECONDS: a live run under the watchdog can never reach this age.
STALE_SECONDS="${LINTEL_PUBLISH_STALE_SECONDS:-1800}"
# ── HOW LONG A SCRIPT MUST HAVE BEEN LEFT ALONE BEFORE IT IS RUN ────────────────────────────
# On 2026-08-20 the Stop hook spawned this wrapper against backup-state.sh 50 seconds after an
# agent's uncommitted edit to that file landed, and the run committed, pushed a branch and opened
# a pull request against a real private repository. It happened to be a finished version. A
# version caught between two writes would have run exactly the same way.
#
# So: a script that has been written to recently is treated as still being worked on, and is not
# run. 120s is chosen against two measurements taken from this machine, not from taste:
#   - the incident's own gap was 50s (script mtime 1787259820, run start ~1787259870), so the
#     floor has to clear 50s with room; 120s clears it 2.4x.
#   - across 777 consecutive-version intervals in ~/.claude file-history, 14% of edits to a file
#     are followed by another edit to the SAME file inside 120s, so 120s covers the burst where
#     a half-finished state actually lives. 300s would cover 36% but starts holding back edits a
#     human finished, and 60s leaves only 10s of margin over the observed incident.
# The ceiling is set by how little this costs: the hook re-checks at the end of EVERY turn, and
# measured turn-to-turn gaps today were median 410s with only 2 of 38 under 120s. So in ~95% of
# turns this threshold delays nothing at all, and when it does bite it defers by one turn.
MIN_AGE_SECONDS="${LINTEL_PUBLISH_MIN_AGE_SECONDS:-120}"

mkdir -p "$GUARD" 2>/dev/null || { print -u2 -- "cannot create $GUARD"; exit 2; }
[[ -r "$SCRIPT" ]] || { print -u2 -- "not readable: $SCRIPT"; exit 2; }

now() { date -u '+%Y-%m-%dT%H:%M:%SZ'; }

# ── the lock ────────────────────────────────────────────────────────────────────────────────
# mkdir is the atomic primitive: it either creates the directory or it does not, with no window
# between testing and taking. A pid file inside it would have one.
take_lock() { mkdir "$LOCK" 2>/dev/null; }

STALE_BROKEN=0
if ! take_lock; then
  # Someone holds it. Either a live run, or a run that died without releasing.
  LOCK_AGE=$(( $(date +%s) - $(stat -f %m "$LOCK" 2>/dev/null || date +%s) ))
  if (( LOCK_AGE >= STALE_SECONDS )); then
    rm -rf "$LOCK" 2>/dev/null
    take_lock || { print -u2 -- "could not take $LOCK even after clearing a stale one"; exit 0; }
    STALE_BROKEN=1
  else
    print -- "another $NAME run is in flight (lock held ${LOCK_AGE}s); doing nothing"
    exit 0
  fi
fi
trap 'rm -rf "$LOCK" 2>/dev/null' EXIT INT TERM HUP

print -r -- "$$ $(now)" > "$LOCK/held-by" 2>/dev/null

{
  print -- "=== publish-run $NAME: started $(now) ==="
  print -- "script : $SCRIPT $*"
  print -- "state  : $STATE"
  (( STALE_BROKEN )) && print -- "note   : cleared a lock older than ${STALE_SECONDS}s before starting"
  print -- "───────────────────────────────────────────────"
} > "$RUNLOG" 2>/dev/null

# ── the run, under a watchdog ───────────────────────────────────────────────────────────────
# There is no `timeout` binary in a stock macOS PATH, so the watchdog is written out. The script
# runs in the background, this loop polls it, and a run that outlives MAX_SECONDS is signalled
# and then killed. stdin is closed so an interactive prompt cannot wait forever on a terminal
# that is not there.
# ── the freshness gate ──────────────────────────────────────────────────────────────────────
# Deliberately the LAST thing before the exec, so the window between "this file looked settled"
# and "zsh started reading it" is as small as it can be made.
#
# IT FAILS IN THE DIRECTION OF NOT RUNNING. Unstattable file, a stat that errors, a date that
# errors, a non-numeric answer, an mtime in the future: every one of those refuses. There is no
# path here where an age that could not be established is read as "old enough".
refuse() {
  {
    print -- "$1"
    print -- "  script: $SCRIPT $SCRIPT_ARGS"
    print -- "  Nothing was lost and nothing was published; the drift is still there. This is a"
    print -- "  refusal rather than a crash — but unlike an ordinary decline it is NOT expected to"
    print -- "  clear on its own, which is why you are being told. A script whose age cannot be"
    print -- "  established, or whose mtime is in the future, means a clock moved or something is"
    print -- "  touching the file; a script that changed mid-run means part of two versions ran."
    print -- "  The ordinary \"it was just edited\" case does not come here — that is a decline."
    print -- "  run log: $RUNLOG"
    print -- "  at: $(now)"
  } > "$FAIL"
  print -- "=== $NAME: REFUSED — $1 ===" >> "$RUNLOG"
  exit 3
}

# ── THE ONE DECLINE PATH ────────────────────────────────────────────────────────────────────
# Called with a code from publish-exit-codes.sh, by whoever declined: the publisher (its own exit
# code, handled at the bottom) or this wrapper (the freshness gate above). Both get identical
# treatment, which is the point of it being a function rather than a block at the bottom.
#
# No failure marker, so the Stop hook says nothing and arms no backoff, and the next stop tries
# again — which is right for a condition that clears in about two minutes with nobody doing
# anything. An existing failure marker is left exactly as it is: a decline is silence about
# itself, not an eraser, so a real failure recorded earlier and not yet announced still speaks.
#
# Consecutive declines are counted in $SKIPPED, and once the streak is older than
# SKIP_ESCALATE_SECONDS the next one writes a real marker and gets the loud channel. That is the
# answer to "what if it never stops declining", and it covers both callers because both come
# through here.
declined() {
  local rc="$1"
  local SKIP_FIRST="" SKIP_COUNT=0 NOW_EPOCH SKIP_AGE REASON ADVICE
  if [[ -r "$SKIPPED" ]]; then
    SKIP_FIRST="$(sed -n 's/^first=//p' "$SKIPPED" 2>/dev/null | head -1)"
    SKIP_COUNT="$(sed -n 's/^count=//p' "$SKIPPED" 2>/dev/null | head -1)"
  fi
  NOW_EPOCH=$(date +%s 2>/dev/null)
  # A missing, garbled or future-dated streak file restarts the streak rather than escalating on
  # arithmetic nobody can trust.
  [[ "$SKIP_FIRST" == <-> && "$SKIP_FIRST" -le "$NOW_EPOCH" ]] || SKIP_FIRST="$NOW_EPOCH"
  [[ "$SKIP_COUNT" == <-> ]] || SKIP_COUNT=0
  SKIP_COUNT=$(( SKIP_COUNT + 1 ))
  SKIP_AGE=$(( NOW_EPOCH - SKIP_FIRST ))
  REASON="$(publish_exit_reason "$rc")"
  ADVICE="$(publish_exit_advice "$rc")"

  if (( SKIP_AGE >= SKIP_ESCALATE_SECONDS )); then
    # It has been declining, unbroken, for longer than anyone should have to guess about. This
    # one gets the loud channel — same marker, same banner, same everything a real failure gets.
    {
      print -- "$NAME: has declined to publish $SKIP_COUNT time(s) over the last $(( SKIP_AGE / 60 )) minute(s)"
      print -- "  script: $SCRIPT $SCRIPT_ARGS"
      print -- "  each time for the same reason, and the reason is a legitimate one:"
      print -- "  $REASON"
      print -- "  Individually those are correct decisions and were kept quiet on purpose. Together"
      print -- "  they mean NOTHING HAS BEEN PUBLISHED for $(( SKIP_AGE / 60 )) minutes, which is worth knowing."
      [[ -n "$ADVICE" ]] && print -- "  $ADVICE"
      print -- "  run log: $RUNLOG"
      print -- "  at: $(now)"
    } > "$FAIL"
    print -- "=== $NAME: DECLINED ($rc) and ESCALATED — ${SKIP_COUNT} declines over ${SKIP_AGE}s ===" >> "$RUNLOG"
    # Restart the window so a publisher that stays stuck speaks about once per window, instead of
    # once and then never again.
    SKIP_FIRST="$NOW_EPOCH"
  else
    print -- "=== $NAME: DECLINED ($rc) at $(now) — ${REASON:-no reason recorded} ===" >> "$RUNLOG"
    print -- "    nothing failed, no marker written; decline ${SKIP_COUNT} of this run, ${SKIP_AGE}s in, escalates at ${SKIP_ESCALATE_SECONDS}s" >> "$RUNLOG"
  fi

  { print -- "first=$SKIP_FIRST"; print -- "count=$SKIP_COUNT"; } > "$SKIPPED" 2>/dev/null
  exit "$rc"
}

MTIME_BEFORE=$(stat -f %m "$SCRIPT" 2>/dev/null)
NOW_EPOCH=$(date +%s 2>/dev/null)
if [[ "$MTIME_BEFORE" != <-> || "$NOW_EPOCH" != <-> ]]; then
  refuse "$NAME: NOT RUN — could not establish how old its script is"
fi
AGE=$(( NOW_EPOCH - MTIME_BEFORE ))
# A negative age means the mtime is in the future — a clock that moved or a deliberate touch.
# That is not evidence of settledness, so it refuses along with everything else here.
if (( AGE < 0 )); then
  refuse "$NAME: NOT RUN — its script's mtime is $(( -AGE ))s in the FUTURE, which is not evidence it is settled"
fi
# THIS ONE IS A DECLINE, NOT A FAILURE. Nothing broke, nothing was lost, and the condition clears
# by itself the moment the editing stops — which is the same three-part test everything in
# publish-exit-codes.sh has to pass. It therefore goes down the same quiet path a publisher's own
# decline does, streak and escalation included, rather than writing a failure marker whose own
# text says nothing failed. If the codes file is unreadable the code is empty, nothing is a
# decline, and this falls through to the old loud refusal — which is the safe direction.
if (( AGE < MIN_AGE_SECONDS )); then
  print -- "freshness: script last modified ${AGE}s ago (mtime $MTIME_BEFORE); needs ${MIN_AGE_SECONDS}s — declining" >> "$RUNLOG"
  publish_exit_is_declined "${PUBLISH_EXIT_SCRIPT_UNSETTLED:-}" && declined "$PUBLISH_EXIT_SCRIPT_UNSETTLED"
  refuse "$NAME: NOT RUN — its script was modified ${AGE}s ago, under the ${MIN_AGE_SECONDS}s it must be left alone"
fi
print -- "freshness: script last modified ${AGE}s ago (mtime $MTIME_BEFORE); needs ${MIN_AGE_SECONDS}s" >> "$RUNLOG"

zsh "$SCRIPT" "$@" >> "$RUNLOG" 2>&1 < /dev/null &
CHILD=$!
TIMED_OUT=0
ELAPSED=0
while kill -0 "$CHILD" 2>/dev/null; do
  sleep 2
  ELAPSED=$(( ELAPSED + 2 ))
  if (( ELAPSED >= MAX_SECONDS )); then
    TIMED_OUT=1
    kill -TERM "$CHILD" 2>/dev/null
    sleep 3
    kill -KILL "$CHILD" 2>/dev/null
    break
  fi
done
wait "$CHILD"
RC=$?

# The gate above cannot close the last millisecond, and zsh reads a script incrementally rather
# than slurping it, so a write landing DURING the run can still be executed. That cannot be
# prevented from here — but it can be made visible instead of invisible, which is the whole point
# of this file. If the script changed while it was running, the run is suspect no matter what it
# exited, and it says so.
MTIME_AFTER=$(stat -f %m "$SCRIPT" 2>/dev/null)
if [[ "$MTIME_AFTER" != "$MTIME_BEFORE" ]]; then
  rm -f "$SKIPPED" 2>/dev/null
  {
    print -- "$NAME: SUSPECT — its script was modified while it was running (exited $RC)"
    print -- "  script: $SCRIPT $*"
    print -- "  mtime went $MTIME_BEFORE -> ${MTIME_AFTER:-<unstattable>} during the run"
    print -- "  zsh reads a script as it goes, so part of the old file and part of the new one may"
    print -- "  both have been executed. Read the run log and check whatever this run pushed."
    print -- "  run log: $RUNLOG"
    print -- "  at: $(now)"
  } > "$FAIL"
  print -- "=== $NAME: SUSPECT — script changed mid-run ($MTIME_BEFORE -> ${MTIME_AFTER:-?}) ===" >> "$RUNLOG"
  exit 3
fi

# ── the record ──────────────────────────────────────────────────────────────────────────────
if (( TIMED_OUT )); then
  rm -f "$SKIPPED" 2>/dev/null
  {
    print -- "$NAME: killed by the watchdog after ${MAX_SECONDS}s"
    print -- "  script: $SCRIPT $*"
    print -- "  run log: $RUNLOG"
    print -- "  at: $(now)"
  } > "$FAIL"
  print -- "=== $NAME: WATCHDOG KILL after ${MAX_SECONDS}s ===" >> "$RUNLOG"
  exit 1
fi

if (( RC == 0 )); then
  rm -f "$FAIL" 2>/dev/null
  rm -f "$SKIPPED" 2>/dev/null          # the run of declines, if any, ended in a real publish
  print -- "=== $NAME: finished 0 at $(now) ===" >> "$RUNLOG"
  exit 0
fi

# ── DECLINED ────────────────────────────────────────────────────────────────────────────────
# The publisher stopped on purpose. declined() below is the ONE decline path — the same one the
# freshness gate takes when this wrapper is the one declining — so neither can drift into a
# second set of rules about markers, streaks and escalation.
if publish_exit_is_declined "$RC"; then
  declined "$RC"
fi

# ── genuinely failed ────────────────────────────────────────────────────────────────────────
rm -f "$SKIPPED" 2>/dev/null              # whatever run of declines there was, it is over
{
  print -- "$NAME: exited $RC"
  print -- "  script: $SCRIPT $*"
  (( ${CODES_MISSING:-0} )) && print -- "  NOTE: $CODES is missing, so no exit code could be recognised as a deliberate decline."
  print -- "  run log: $RUNLOG"
  print -- "  at: $(now)"
} > "$FAIL"
print -- "=== $NAME: FAILED with $RC at $(now) ===" >> "$RUNLOG"
exit 1

#!/usr/bin/env zsh
#
# publish-exit-codes.sh — THE ONE PLACE a publisher's "I declined on purpose" exit codes are
# defined. Sourced, never executed.
#
#   source "${0:A:h}/publish-exit-codes.sh"
#
# WHY THIS FILE EXISTS AT ALL. A publisher can stop for two completely different reasons:
#
#   it BROKE          — git failed, gh failed, the published repo is in a state it cannot handle.
#                       The owner has to do something. This must be loud.
#   it DECLINED       — a precondition it checks for itself was not met, it did exactly the right
#                       thing by stopping, nothing was lost, and the condition clears by itself
#                       within minutes. This must be quiet.
#
# The only thing separating those two at the process boundary is the exit code. tools/publish-run.sh
# is what turns an exit code into the `publish-<name>.fail` marker that orchestrator/hooks/
# publish-stop.mjs escalates into a session-blocking "PUBLISHING IS NOT HAPPENING" banner. So the
# publisher and the runner have to agree, exactly, on which numbers mean "declined".
#
# They agree by both reading THIS FILE. A number written into two files is the same class of defect
# as the one this file was created to fix: the two copies are correct on the day they are written
# and nothing tells anybody when they stop being.
#
# Measured 2026-08-20T22:55:08Z, before this file existed: sync-to-lintel.sh's quiescence gate
# declined correctly on a file modified 80s earlier and exited 4; publish-run.sh had no idea 4 was
# special, wrote a failure marker, and the owner was shown a failure banner plus a 30-minute
# backoff for a publisher that had behaved perfectly.
#
# ── ADDING A CODE ────────────────────────────────────────────────────────────────────────────
# Give it a name, give it a number nobody else here uses, and describe it in the map. A code goes
# in here ONLY if all three are true: the publisher chose to stop, nothing is broken, and the
# condition clears without a human. Anything the owner has to fix is a failure and belongs nowhere
# near this file.
#
# ── CODES ALREADY SPOKEN FOR, so a new one does not collide ──────────────────────────────────
#   0  success / nothing to do          (every publisher)
#   1  generic failure                  (every publisher)
#   2  bad arguments, missing roots     (every publisher)
#   3  reserved: was "published checkout dirty" in sync-to-lintel.sh before 2026-08-20
#   4  NOT QUIESCENT                    <- declined, defined below
#   5  SCRIPT UNSETTLED                 <- declined, defined below
#   6  NOTHING TO MERGE                 <- declined, defined below (added 2026-08-20 for
#                                          merge-backup-pr.sh's session-end trigger)
#
# ── WHAT DECLINING DOES NOT DO ───────────────────────────────────────────────────────────────
# It does not clear an existing failure marker, it does not reset a backoff, and it does not
# suppress a real failure that happens afterwards. It is silence about ITSELF, nothing more.
# A publisher that declines and declines and never gets anywhere is escalated by publish-run.sh
# after LINTEL_PUBLISH_SKIP_ESCALATE_SECONDS of unbroken declining, because silence forever is
# the failure mode on the other side of this one.

# A file in the copy set was modified so recently that it may still be half-written. Copying a
# torn file into the published tree is worse than waiting, so the run stops and the next cycle
# picks the drift up. Clears by itself once the writer stops writing.
PUBLISH_EXIT_NOT_QUIESCENT=4

# The publisher's own script was written to so recently that publish-run.sh will not run it: a
# script caught between two writes is half a script, and these publishers commit and push. The
# runner, not the publisher, exits this one. Clears by itself once the editing stops.
PUBLISH_EXIT_SCRIPT_UNSETTLED=5

# tools/merge-backup-pr.sh, run at session end, found no open backup pull request for this
# session's tag at all -- there was nothing to merge. This is the ordinary case for a session
# that made no state changes worth backing up, or one that ended before backup-state.sh's own
# Stop-triggered check ever found drift. It clears itself: the next backup run that finds drift
# opens a pull request, and the next session-end merge attempt finds it there. Added 2026-08-20
# alongside the SessionEnd trigger, per this merge tool's own report: "if that wiring happens,
# give them a decline code in publish-exit-codes.sh." Deliberately narrow -- every OTHER refusal
# check in merge-backup-pr.sh (allowlist, base, ambiguous PR count, mergeable/conflict,
# policy-paths, deletion-cap, credential-scan) still exits 1 and is treated as a real failure,
# because none of those three things is true of them: a conflicted base needs backup-state.sh's
# own fold to catch up, not nothing; and the rest are exactly the "a human decides" cases this
# tool exists to protect.
PUBLISH_EXIT_NOTHING_TO_MERGE=6

# The map every consumer reads. Key: the exit code. Value: the sentence shown to a human, written
# from the publisher's point of view, in the present tense.
typeset -gA PUBLISH_DECLINED_EXITS
PUBLISH_DECLINED_EXITS[$PUBLISH_EXIT_NOT_QUIESCENT]='a file in its copy set was still being written, so it waited rather than copy a half-written file'
PUBLISH_DECLINED_EXITS[$PUBLISH_EXIT_SCRIPT_UNSETTLED]='its own script had just been edited, so the run waited rather than execute a possibly half-written script'
PUBLISH_DECLINED_EXITS[$PUBLISH_EXIT_NOTHING_TO_MERGE]='no open backup pull request existed for this session, so there was nothing to merge'

# What to tell a human when a code has been declining for so long that it is escalated. Keyed the
# same way, and here for the same reason the sentences above are: the advice is specific to the
# code, so it belongs beside the code rather than inlined in whichever consumer prints it.
typeset -gA PUBLISH_DECLINED_ADVICE
PUBLISH_DECLINED_ADVICE[$PUBLISH_EXIT_NOT_QUIESCENT]='Most likely something is rewriting a file in the copy set continuously - a running
  job, a watcher, an editor autosaving - so it never goes quiet long enough to copy.
  Find what keeps touching it, or run the script by hand once things are still.'
PUBLISH_DECLINED_ADVICE[$PUBLISH_EXIT_SCRIPT_UNSETTLED]='Most likely the publisher script itself is being edited in a long unbroken session,
  or something is touching its mtime on a timer. Leave the script alone for a couple of
  minutes, or run it by hand once you have finished editing it.'
PUBLISH_DECLINED_ADVICE[$PUBLISH_EXIT_NOTHING_TO_MERGE]='Nothing to do. This means the session made no state changes worth backing up, or the
  session ended before backup-state.sh ever found drift to push. If backups are expected but
  this keeps happening, check backup-state.log for whether it is running and finding drift at all.'

# publish_exit_is_declined <code> — true when <code> means "declined on purpose".
# Non-numeric, empty, or unknown answers are NOT declines: this fails in the direction of
# treating something as a failure, because a real failure reported as a skip is invisible and an
# invisible failed backup is the worst outcome available here.
publish_exit_is_declined() {
  local code="$1"
  [[ "$code" == <-> ]] || return 1
  [[ -n "${PUBLISH_DECLINED_EXITS[$code]}" ]] || return 1
  return 0
}

# publish_exit_reason <code> — the sentence for a declined code; empty for anything else.
publish_exit_reason() {
  print -r -- "${PUBLISH_DECLINED_EXITS[$1]}"
}

# publish_exit_advice <code> — the escalation advice for a declined code; empty for anything else.
publish_exit_advice() {
  print -r -- "${PUBLISH_DECLINED_ADVICE[$1]}"
}

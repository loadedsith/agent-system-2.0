// lintel-fleet.jsx — what needs Jo right now, on the desktop.
//
// DURABLE SOURCE: /Users/jowolff/.claude/orchestrator/tools/fleet-widget/lintel-fleet.jsx
// The copy under ~/Library/Application Support/Übersicht/widgets/ is INSTALLED, not authored.
// Edit this file, then re-run install.sh. The Übersicht widget directory is not a repository,
// is not backed up, and a file that lives only there has already gone missing on this machine.
//
// NO MODEL CALLS. NO NETWORK. The command below is one local python read (~30ms, ~2KB out).
//
// THE FAILURE THIS IS DESIGNED AGAINST is a panel that renders, looks healthy, and shows stale
// or zero data. Three defences, all visible on the widget's own face:
//   1. STALL DETECTION — the collector stamps generated_at; if the browser clock says that
//      stamp is older than STALL_AFTER_S the whole header goes red and says how old it is.
//      A dead collector leaves the LAST GOOD output on screen, so this is the only thing that
//      can catch it.
//   2. NO SILENT EMPTIES — every lane renders one of {data, verified-empty, stale, unwired,
//      error}. A lane whose source failed says so in red; it never renders as a clean zero.
//   3. UNPARSEABLE OUTPUT is shown raw in red, not swallowed by a try/catch into an empty panel.

export const command =
  "python3 /Users/jowolff/.claude/orchestrator/tools/fleet-widget/fleet-status.py"

// WHY 60s, MEASURED NOT FELT. Median gap between consecutive REQUESTS.jsonl row timestamps is
// 264s all-time and 319s over today's 17 rows. A 60s tick oversamples the real write rate by
// roughly 4x, which bounds worst-case staleness at one minute against data that moves every
// four-and-a-bit. Anything tighter is spending wakeups on a file that has not changed.
export const refreshFrequency = 60000

// STALL_AFTER_S is three ticks. One missed refresh is a slow disk; three is a broken collector.
const STALL_AFTER_S = 180

export const className = `
  top: 10px;
  left: 20px;
  width: 320px;
  font-family: "SF Mono", Menlo, monospace;
  font-size: 11px;
  line-height: 1.5;
  background: rgba(236, 226, 204, 0.94);
  border: 1px solid rgba(35, 31, 26, 0.1);
  border-top: 2px solid rgba(210, 107, 63, 0.65);
  border-radius: 6px;
  padding: 12px 14px;
  color: #231F1A;
  -webkit-backdrop-filter: blur(16px);
  backdrop-filter: blur(16px);
  pointer-events: none;
`

const T = {
  orange: '#D26B3F', purple: '#43285C', gold: '#B08020',
  blue: '#2E6880',   olive: '#5A5E28',  red: '#A6332C',
  ink1: '#231F1A', ink2: '#5A4E3C', ink3: '#9A8E7A', ink4: '#C8BEA8',
  disp: 'Futura, "Century Gothic", "Trebuchet MS", sans-serif',
}

const HDR = {
  fontFamily: T.disp, fontSize: 11, fontWeight: 700,
  textTransform: 'uppercase', letterSpacing: '0.1em',
  color: T.orange, marginBottom: 9,
  display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8,
}

const SECTION = {
  fontFamily: T.disp, fontSize: 9, fontWeight: 700,
  textTransform: 'uppercase', letterSpacing: '0.12em',
  color: T.ink3, marginTop: 9, marginBottom: 4,
  display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 6,
}

const NOTE = { color: T.ink3, fontSize: 10, fontStyle: 'italic' }
const BAD = { color: T.red, fontSize: 10, fontWeight: 700 }

function age(seconds) {
  if (seconds === null || seconds === undefined || isNaN(seconds)) return '?'
  const s = Math.max(0, Math.floor(seconds))
  if (s < 60) return s + 's'
  if (s < 3600) return Math.floor(s / 60) + 'm'
  if (s < 86400) return Math.floor(s / 3600) + 'h'
  return Math.floor(s / 86400) + 'd'
}

function ageFromIso(iso, nowS) {
  if (!iso) return '?'
  const t = Date.parse(iso)
  if (isNaN(t)) return '?'
  return age(nowS - t / 1000)
}

// State is carried by a WORD as well as a colour — any colourblind moment mid-day still reads.
const STATE_COLOR = {
  blocked: T.red, partial: T.gold, open: T.blue,
  'in-flight': T.orange, pending: T.gold,
}

function Chip({ label, color }) {
  const c = color || T.ink2
  return (
    <span style={{
      background: c + '22', color: c,
      fontFamily: T.disp, fontSize: 8, fontWeight: 700, letterSpacing: '0.06em',
      padding: '1px 4px', borderRadius: 2, flexShrink: 0, whiteSpace: 'nowrap',
      textTransform: 'uppercase',
    }}>{label}</span>
  )
}

// The recommendation attached to a pending decision, in three states rather than two.
// A decision can honestly carry NO recommendation — one was put to Jo on 2026-08-24 with the words
// "I have not read the ticket and have no basis", and inventing one to fill the field would be
// worse than leaving it empty. So "none offered" is rendered as a deliberate fact. A row with the
// key missing entirely is a row written by a producer that predates the field, and it says that
// instead, because "nobody had a view" and "the producer is out of date" must not look the same.
function Rec({ rec }) {
  if (!rec) return null
  if (rec === 'absent') {
    return <div style={{ ...NOTE, marginTop: 1 }}>recommendation field missing — old producer</div>
  }
  if (rec === 'none') {
    return <div style={{ ...NOTE, marginTop: 1 }}>no recommendation offered</div>
  }
  return (
    <div style={{ color: T.ink2, fontSize: 10, marginTop: 1 }}>
      <span style={{ color: T.ink3 }}>rec: </span>{rec}
    </div>
  )
}

// One owed row. Jo's own words lead; the REQ id is dim and last, because an identifier only
// works for someone already holding the thing it points at.
function Row({ item, nowS, chip, chipColor }) {
  return (
    <div style={{ marginBottom: 5 }}>
      <div style={{ display: 'flex', gap: 5, alignItems: 'baseline' }}>
        <Chip label={chip} color={chipColor} />
        <span style={{ color: T.ink1, flex: 1, minWidth: 0 }}>{item.text}</span>
      </div>
      <div style={{
        display: 'flex', justifyContent: 'flex-end', gap: 7,
        color: T.ink3, fontSize: 9, marginTop: 1,
      }}>
        <span>{ageFromIso(item.ts, nowS)} old</span>
        <span>{item.id}</span>
      </div>
    </div>
  )
}

function More({ n, word }) {
  if (!n) return null
  return <div style={NOTE}>+{n} more {word}</div>
}

function Lane({ title, lane, nowS, empty, children }) {
  const l = lane || { status: 'error', err: 'lane missing from collector output' }
  const total = l.total === undefined ? null : l.total
  return (
    <div>
      <div style={SECTION}>
        <span>{title}</span>
        {total !== null && l.status === 'ok' && total > 0 && (
          <span style={{ color: T.ink3 }}>{total}</span>
        )}
      </div>
      {l.status === 'error' && (
        <div style={BAD}>⛔ unreadable — {l.err}</div>
      )}
      {l.status === 'stale' && (
        <div style={BAD}>⛔ source stale {age(l.age_s)} — not shown rather than shown wrong</div>
      )}
      {l.status === 'unwired' && (
        <div style={NOTE}>no source file — nothing records a decision the fleet is waiting on</div>
      )}
      {l.status === 'ok' && l.items.length === 0 && (
        <div style={NOTE}>{empty}</div>
      )}
      {l.status === 'ok' && l.items.length > 0 && children}
    </div>
  )
}

function Fleet({ output }) {
  const nowS = Date.now() / 1000

  let d = null
  let parseErr = null
  try {
    d = JSON.parse(output)
  } catch (e) {
    parseErr = String(output || '').slice(0, 220) || '(no output)'
  }

  // The collector never prints a traceback, so unparseable output means something else broke.
  // Show it. An empty panel here would be the exact lie this widget exists to prevent.
  if (parseErr !== null) {
    return (
      <div>
        <div style={{ ...HDR, color: T.red }}><span>Fleet — collector broken</span></div>
        <div style={{ ...BAD, fontWeight: 400, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
          {parseErr}
        </div>
      </div>
    )
  }

  if (d && d.fatal) {
    return (
      <div>
        <div style={{ ...HDR, color: T.red }}><span>Fleet — collector threw</span></div>
        <div style={{ ...BAD, fontWeight: 400 }}>{d.fatal}</div>
      </div>
    )
  }

  const lanes = (d && d.lanes) || {}
  const counts = (d && d.counts) || {}
  const sources = (d && d.sources) || []
  const vocab = (d && d.vocab) || { ok: false, err: 'missing' }

  const readAge = d && d.generated_at ? nowS - d.generated_at : null
  const stalled = readAge !== null && readAge > STALL_AFTER_S

  const blocked = lanes.blocked || {}
  const live = lanes.live || {}
  const nBlocked = blocked.status === 'ok' ? (blocked.total || 0) : null
  const nLive = live.status === 'ok' ? (live.total || 0) : null

  let pill = { text: 'no reading', color: T.red }
  if (stalled) {
    pill = { text: 'stalled ' + age(readAge), color: T.red }
  } else if (nBlocked === null || nLive === null) {
    pill = { text: 'source failed', color: T.red }
  } else if (nBlocked > 0) {
    pill = { text: nBlocked + ' blocked', color: T.red }
  } else if (nLive > 0) {
    pill = { text: nLive + ' live', color: T.orange }
  } else {
    pill = { text: 'clear', color: T.olive }
  }

  const byState = counts.by_state || {}
  const owedOrder = ['blocked', 'partial', 'open']

  return (
    <div>
      <style>{`
        @keyframes vb-alarm {
          0%, 100% { opacity: 1; }
          50%      { opacity: 0.25; }
        }
        @media (prefers-reduced-motion: reduce) {
          @keyframes vb-alarm { 0%, 100% { opacity: 0.7; } }
        }
      `}</style>

      <div style={{ ...HDR, color: stalled ? T.red : T.orange }}>
        <span>Lintel Fleet</span>
        <span style={{
          background: pill.color + '1F', color: pill.color,
          fontFamily: T.disp, fontSize: 9, fontWeight: 700, letterSpacing: '0.06em',
          padding: '1px 7px', borderRadius: 3, whiteSpace: 'nowrap',
          textTransform: 'uppercase',
          animation: stalled ? 'vb-alarm 1.6s ease-in-out infinite' : 'none',
        }}>{pill.text}</span>
      </div>

      {stalled && (
        <div style={{ ...BAD, marginBottom: 6 }}>
          ⛔ everything below was read {age(readAge)} ago and has not refreshed since
        </div>
      )}

      {!vocab.ok && (
        <div style={{ ...BAD, marginBottom: 6 }}>
          ⛔ state vocabulary unavailable — {vocab.err}
        </div>
      )}

      <Lane title="Blocked" lane={blocked} nowS={nowS}
            empty="nothing blocked — verified, not assumed">
        <div>
          {(blocked.items || []).map((it) => (
            <Row key={it.id} item={it} nowS={nowS} chip="blocked" chipColor={T.red} />
          ))}
          <More n={blocked.more} word="blocked" />
        </div>
      </Lane>

      <Lane title="Decisions for Jo" lane={lanes.decisions} nowS={nowS}
            empty="no decision waiting on you">
        <div>
          {((lanes.decisions || {}).items || []).map((it) => (
            <div key={it.id}>
              <Row item={it} nowS={nowS} chip="decide" chipColor={T.purple} />
              <Rec rec={it.rec} />
            </div>
          ))}
          <More n={(lanes.decisions || {}).more} word="decisions" />
        </div>
      </Lane>

      <Lane title="Live thread" lane={live} nowS={nowS}
            empty="nothing owed — verified, not assumed">
        <div>
          {(live.items || []).map((it) => (
            <Row key={it.id} item={it} nowS={nowS}
                 chip={it.state} chipColor={STATE_COLOR[it.state] || T.ink2} />
          ))}
          <More n={live.more} word="owed" />
        </div>
      </Lane>

      <Lane title="Dispatches in flight" lane={lanes.dispatch} nowS={nowS}
            empty="nothing dispatched and unaccounted for">
        <div>
          {((lanes.dispatch || {}).items || []).map((it) => (
            <div key={it.id} style={{ marginBottom: 5 }}>
              <div style={{ display: 'flex', gap: 5, alignItems: 'baseline' }}>
                <Chip label={it.outcome} color={STATE_COLOR[it.outcome] || T.ink2} />
                <span style={{ color: T.ink1, flex: 1, minWidth: 0 }}>{it.text}</span>
              </div>
              <div style={{
                display: 'flex', justifyContent: 'flex-end', gap: 7,
                color: T.ink3, fontSize: 9, marginTop: 1,
              }}>
                <span>{it.who}</span>
                <span>{ageFromIso(it.ts, nowS)} old</span>
              </div>
            </div>
          ))}
          <More n={(lanes.dispatch || {}).more} word="in flight" />
        </div>
      </Lane>

      {/* Footer: counts are CONTEXT, never the headline. "126 owed" changes nothing Jo does;
          "3 blocked" does. Source ages sit here so a quietly-frozen file is legible at a glance. */}
      <div style={{
        marginTop: 10, paddingTop: 7,
        borderTop: '1px solid rgba(35,31,26,0.12)',
        color: T.ink3, fontSize: 9, fontFamily: T.disp, letterSpacing: '0.04em',
      }}>
        {counts.status === 'ok' ? (
          <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap' }}>
            <span style={{ color: T.ink2 }}>{counts.owed} owed</span>
            {owedOrder.filter((s) => byState[s]).map((s) => (
              <span key={s}>{byState[s]} {s}</span>
            ))}
            {counts.bad_lines > 0 && (
              <span style={{ color: T.red }}>{counts.bad_lines} unparseable rows</span>
            )}
            {counts.unknown_state > 0 && (
              <span style={{ color: T.red }}>{counts.unknown_state} undeclared states</span>
            )}
          </div>
        ) : (
          <div style={BAD}>⛔ counts unavailable — {counts.err}</div>
        )}
        <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap', marginTop: 3 }}>
          {sources.map((s) => (
            <span key={s.name} style={{ color: s.ok ? T.ink3 : T.red }}>
              {s.name} {s.ok ? age(s.age_s) : 'FAILED'}
            </span>
          ))}
          <span style={{ color: stalled ? T.red : T.ink3 }}>read {age(readAge)} ago</span>
        </div>
      </div>
    </div>
  )
}

export const render = ({ output }) => <Fleet output={output} />

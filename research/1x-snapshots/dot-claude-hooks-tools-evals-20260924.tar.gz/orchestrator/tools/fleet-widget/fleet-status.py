#!/usr/bin/env python3
"""fleet-status.py — read-only collector for the Lintel fleet desktop widget.

WHAT THIS IS. The widget at ~/Library/Application Support/Uebersicht/widgets/lintel-fleet.jsx
runs this on a timer and renders its stdout. This file is the durable source of truth; the .jsx
in the Uebersicht directory is an installed copy (see install.sh).

WHAT IT ANSWERS. One question: what needs Jo right now. Not "how is the fleet doing" — there is
already a daily triage report nobody opens, and a second surface nobody reads is worse than none.
Blockers first, then the live thread, then dispatches in flight. Counts are footer context.

THREE THINGS IT DELIBERATELY DOES NOT DO.

1. NO MODEL CALLS, EVER. File reads and one subprocess (request-states.sh). Nothing on a timer
   costs Jo a token.
2. NO NETWORK. Not even the task tracker. The tracker needs a per-account gh token here and a
   timer is the wrong place to spend one; every lane below is derivable from local state.
3. NO KEYWORD SCANNING OF NOTES. JUDGEMENT.md records this as a measured failure (REQ-264):
   completion words appear in 70% of owed rows and 86% of delivered rows, so a note scan is a
   proxy, not a measurement. Every lane here keys off a STRUCTURAL field — `state`, `outcome`,
   `ts` — or it does not exist.

THE TERMINAL-STATE PREDICATE IS NOT DEFINED HERE. It is asked of tools/request-states.sh, which
parses contracts/request-ledger.md and owns the answer. A second copy is one contract edit away
from being wrong. If that tool cannot answer, this prints vocab.ok=false and the widget says so on
its face rather than rendering an innocent-looking zero.

EVERY LANE DISTINGUISHES THREE OUTCOMES: data, a verified empty, and unreadable. A blank lane is
never rendered for a source that failed — that is the exact failure this widget exists to catch.
"""

import json
import os
import subprocess
import sys
import time

ROOT = "/Users/jowolff/.claude/orchestrator"
STATE = os.path.join(ROOT, "state")

REQUESTS = os.path.join(STATE, "REQUESTS.jsonl")
LEDGER = os.path.join(STATE, "LEDGER.jsonl")
# FLEET_DECISIONS_PATH is a TEST INJECTION POINT, documented here so the exemption is visible
# rather than hidden — the same pattern tools/issues-ledger-check.sh uses for its issue list. It
# exists because the populated branch of this lane cannot otherwise be exercised without writing a
# file under state/, which the seat that maintains this tool is forbidden to do. A live run never
# sets it. An unexercised branch reports success by silence, which is the defect this whole widget
# was built to avoid.
DECISIONS = os.environ.get("FLEET_DECISIONS_PATH") or os.path.join(STATE, "DECISIONS.jsonl")
STANDUP = os.path.join(STATE, "STANDUP.md")
STATES_SH = os.path.join(ROOT, "tools", "request-states.sh")

# A dispatch outcome that is not one of these is finished business. Unlike the request-state
# vocabulary there is no contract file parsing this one out; dispatch-ledger.md documents the
# values in prose. Treated as a GUESS on purpose and surfaced as such: the dispatch lane is
# suppressed entirely when the ledger is stale, so a wrong member here cannot fake in-flight work.
DISPATCH_LIVE = {"in-flight", "pending", "open"}

# The dispatch ledger is only believable as "in flight" while it is being written. Past this the
# lane reports its own staleness instead of showing a two-day-old dispatch as live work.
DISPATCH_FRESH_S = 6 * 3600

BLOCKED_SHOWN = 3
LIVE_SHOWN = 4
DISPATCH_SHOWN = 3
DECISIONS_SHOWN = 3


def source_stat(name, path):
    try:
        st = os.stat(path)
    except FileNotFoundError:
        return {"name": name, "path": path, "ok": False, "missing": True,
                "age_s": None, "err": "not found"}
    except OSError as exc:
        return {"name": name, "path": path, "ok": False, "missing": False,
                "age_s": None, "err": str(exc)}
    return {"name": name, "path": path, "ok": True, "missing": False,
            "age_s": int(time.time() - st.st_mtime), "err": None}


def read_jsonl(path):
    """Return (rows, error, bad_lines). error is None on success."""
    rows = []
    bad = 0
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except ValueError:
                    bad += 1
                    continue
                if isinstance(obj, dict):
                    rows.append(obj)
                else:
                    bad += 1
    except FileNotFoundError:
        return [], "not found", 0
    except OSError as exc:
        return [], str(exc), 0
    return rows, None, bad


def vocabulary():
    """Ask request-states.sh which states are terminal. Never guess."""
    if not os.path.exists(STATES_SH):
        return {"ok": False, "terminal": [], "non_terminal": [],
                "err": "request-states.sh not found"}
    try:
        proc = subprocess.run(
            ["/bin/sh", STATES_SH, "--all"],
            capture_output=True, text=True, timeout=10,
        )
    except Exception as exc:
        return {"ok": False, "terminal": [], "non_terminal": [], "err": str(exc)}
    if proc.returncode != 0:
        return {"ok": False, "terminal": [], "non_terminal": [],
                "err": "request-states.sh exit %d" % proc.returncode}
    terminal, non_terminal = [], []
    for line in proc.stdout.splitlines():
        if "\t" not in line:
            continue
        name, kind = line.split("\t", 1)
        (terminal if kind.strip() == "terminal" else non_terminal).append(name.strip())
    if not terminal or not non_terminal:
        return {"ok": False, "terminal": [], "non_terminal": [],
                "err": "vocabulary parsed empty"}
    return {"ok": True, "terminal": terminal, "non_terminal": non_terminal, "err": None}


def clip(text, limit=88):
    text = " ".join(str(text or "").split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def build():
    now = int(time.time())
    vocab = vocabulary()
    sources = [
        source_stat("requests", REQUESTS),
        source_stat("dispatch", LEDGER),
        source_stat("savepoint", STANDUP),
    ]
    by_name = {s["name"]: s for s in sources}

    out = {
        "generated_at": now,
        "vocab": vocab,
        "sources": sources,
        "counts": {},
        "lanes": {},
    }

    # ---- request ledger -------------------------------------------------
    rows, err, bad = read_jsonl(REQUESTS)
    if err is not None:
        out["lanes"]["blocked"] = {"status": "error", "err": err, "items": [], "more": 0}
        out["lanes"]["live"] = {"status": "error", "err": err, "items": [], "more": 0}
        out["counts"] = {"status": "error", "err": err}
    elif not vocab["ok"]:
        msg = "state vocabulary unavailable: %s" % vocab["err"]
        out["lanes"]["blocked"] = {"status": "error", "err": msg, "items": [], "more": 0}
        out["lanes"]["live"] = {"status": "error", "err": msg, "items": [], "more": 0}
        out["counts"] = {"status": "error", "err": msg}
    else:
        non_terminal = set(vocab["non_terminal"])
        by_state = {}
        unknown = 0
        for r in rows:
            st = r.get("state")
            if st in non_terminal or st in set(vocab["terminal"]):
                by_state[st] = by_state.get(st, 0) + 1
            else:
                unknown += 1

        owed = [r for r in rows if r.get("state") in non_terminal]

        # Blocked: the one structural "someone outside the fleet must move" signal the ledger
        # carries. Oldest first — age IS the pressure on a blocked row.
        blocked = sorted(
            [r for r in owed if r.get("state") == "blocked"],
            key=lambda r: str(r.get("ts", "")),
        )
        out["lanes"]["blocked"] = {
            "status": "ok",
            "err": None,
            "items": [
                {"id": r.get("id", "?"), "ts": r.get("ts", ""),
                 "text": clip(r.get("request")), "state": "blocked"}
                for r in blocked[:BLOCKED_SHOWN]
            ],
            "more": max(0, len(blocked) - BLOCKED_SHOWN),
            "total": len(blocked),
        }

        # Live thread: the newest still-owed rows that are not blocked. Recency is structural
        # (the `ts` field), so this needs no interpretation of what a row says.
        live = sorted(
            [r for r in owed if r.get("state") != "blocked"],
            key=lambda r: str(r.get("ts", "")),
            reverse=True,
        )
        out["lanes"]["live"] = {
            "status": "ok",
            "err": None,
            "items": [
                {"id": r.get("id", "?"), "ts": r.get("ts", ""),
                 "text": clip(r.get("request")), "state": r.get("state", "?")}
                for r in live[:LIVE_SHOWN]
            ],
            "more": max(0, len(live) - LIVE_SHOWN),
            "total": len(live),
        }

        out["counts"] = {
            "status": "ok",
            "owed": len(owed),
            "rows": len(rows),
            "by_state": by_state,
            "unknown_state": unknown,
            "bad_lines": bad,
        }

    # ---- dispatch ledger ------------------------------------------------
    d_src = by_name["dispatch"]
    if not d_src["ok"]:
        out["lanes"]["dispatch"] = {"status": "error", "err": d_src["err"],
                                    "items": [], "more": 0}
    elif d_src["age_s"] is not None and d_src["age_s"] > DISPATCH_FRESH_S:
        out["lanes"]["dispatch"] = {
            "status": "stale", "err": None, "items": [], "more": 0,
            "age_s": d_src["age_s"],
        }
    else:
        drows, derr, _dbad = read_jsonl(LEDGER)
        if derr is not None:
            out["lanes"]["dispatch"] = {"status": "error", "err": derr,
                                        "items": [], "more": 0}
        else:
            flying = [r for r in drows if r.get("outcome") in DISPATCH_LIVE]
            flying.sort(key=lambda r: str(r.get("ts", "")), reverse=True)
            out["lanes"]["dispatch"] = {
                "status": "ok", "err": None,
                "items": [
                    {"id": r.get("id", "?"), "ts": r.get("ts", ""),
                     "text": clip(r.get("task"), 70),
                     "who": clip(r.get("dispatched_to"), 24),
                     "outcome": r.get("outcome", "?")}
                    for r in flying[:DISPATCH_SHOWN]
                ],
                "more": max(0, len(flying) - DISPATCH_SHOWN),
                "total": len(flying),
            }

    # ---- decisions waiting on Jo ----------------------------------------
    # NO STRUCTURAL SOURCE EXISTS FOR THIS YET, and the widget says so rather than inventing one.
    # The request ledger's `touches` vocabulary records a decision Jo HAS made (`decide`); nothing
    # records a decision the fleet is WAITING ON. Reading that out of note prose would be exactly
    # the proxy JUDGEMENT.md forbids. So: this lane reads state/DECISIONS.jsonl if some producer
    # ever writes one, and until then it renders "lane unwired" — one dim line that keeps the gap
    # visible on Jo's desktop instead of hiding it behind an empty section.
    # Expected row shape: {"id","ts","question","options":[...],"state":"open"}
    if not os.path.exists(DECISIONS):
        out["lanes"]["decisions"] = {"status": "unwired", "err": None,
                                     "items": [], "more": 0}
    else:
        krows, kerr, _kbad = read_jsonl(DECISIONS)
        if kerr is not None:
            out["lanes"]["decisions"] = {"status": "error", "err": kerr,
                                         "items": [], "more": 0}
        else:
            pend = [r for r in krows if r.get("state") == "open"]
            pend.sort(key=lambda r: str(r.get("ts", "")), reverse=True)
            out["lanes"]["decisions"] = {
                "status": "ok", "err": None,
                "items": [
                    {"id": r.get("id", "?"), "ts": r.get("ts", ""),
                     "text": clip(r.get("question")),
                     "options": [clip(o, 20) for o in (r.get("options") or [])][:3],
                     # THREE STATES, NOT TWO, AND THE WIDGET RENDERS ALL THREE. A recommendation
                     # can be present; it can be explicitly absent, because a decision can honestly
                     # have none — one was put to Jo today with the words "I have not read the
                     # ticket and have no basis"; or the key can be missing entirely, which means
                     # the row was written by something that did not know about this field.
                     # Collapsing the last two would make "nobody had a view" and "the producer is
                     # out of date" look identical, which is the same failure as an empty lane that
                     # might be a broken producer.
                     "rec": (clip(r["recommendation"], 60)
                             if isinstance(r.get("recommendation"), str) and r["recommendation"].strip()
                             else ("none" if "recommendation" in r else "absent"))}
                    for r in pend[:DECISIONS_SHOWN]
                ],
                "more": max(0, len(pend) - DECISIONS_SHOWN),
                "total": len(pend),
            }

    return out


def main():
    try:
        payload = build()
    except Exception as exc:  # never print a traceback into a widget
        payload = {
            "generated_at": int(time.time()),
            "fatal": "%s: %s" % (type(exc).__name__, exc),
        }
    sys.stdout.write(json.dumps(payload, ensure_ascii=False))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()

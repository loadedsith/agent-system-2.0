# Fleet widget — what needs Jo right now, on the desktop

A single Übersicht panel answering one question: **what needs Jo right now.** Blockers first,
then decisions waiting on Jo, then the live thread, then dispatches in flight. Counts are footer
context, never the headline — "136 owed" changes nothing Jo does; "8 blocked" does.

It is deliberately **not** a dashboard of everything. This fleet already produced a daily triage
report nobody opens, and a second surface nobody reads is worse than none, because it looks like
the problem is solved.

## Files

| File | What it is |
|---|---|
| `fleet-status.py` | Read-only collector. Prints one JSON object. ~30 ms, ~2 KB. |
| `lintel-fleet.jsx` | The widget. **This is the authored copy.** |
| `install.sh` | Copies the `.jsx` into Übersicht's widget directory. Also `--check`, `--uninstall`. |
| `selftest.cjs` | Compiles and renders the widget using Übersicht's own bundled Babel and React. |

## Where the source of truth lives, and why it is here

The authored source is **this directory**, not `~/Library/Application Support/Übersicht/widgets/`.

That directory is not a repository, is not backed up, and is not watched by anything. A file
living only there went missing on this machine for three days this week and nobody noticed.
This directory sits inside `orchestrator/tools/`, which the `~/.claude` git repository tracks and
which `tools/sync-to-lintel.sh` already publishes (`NEW_IN_SCOPE_DIRS` includes
`orchestrator/tools/`). Losing the installed copy costs one `install.sh`. Losing this costs work.

Edit here, then re-run `install.sh`. `install.sh --check` diffs the two and reports drift.

## Constraints it holds to

- **No model calls.** Ever, on any tick. One local `python3` read and one `sh` subprocess.
- **No network.** Not even the task tracker — a timer is the wrong place to spend a per-account
  `gh` token, and every lane is derivable from local state.
- **Read-only.** It opens files. It writes nothing anywhere.
- **No keyword scanning of note prose.** `JUDGEMENT.md` records this as a measured failure
  (REQ-264): completion words appear in 70% of owed rows and 86% of delivered ones, so a note
  scan is a proxy, not a measurement. Every lane keys off a structural field — `state`,
  `outcome`, `ts` — or it does not exist.
- **The terminal-state predicate is not copied.** It is asked of `tools/request-states.sh`, which
  parses `contracts/request-ledger.md`. If that tool cannot answer, the widget says
  "state vocabulary unavailable" on its face rather than guessing.

## The failure it is designed against

A panel that renders, looks healthy, and shows stale or zero data. Three defences, all visible:

1. **Stall detection.** The collector stamps `generated_at`; if the browser clock says that stamp
   is older than three refresh ticks, the header goes red and says how old. A dead collector
   leaves the *last good* output on screen, so this is the only thing that can catch it.
2. **No silent empties.** Every lane renders one of `{data, verified-empty, stale, unwired,
   error}`. A lane whose source failed is red and names the error. It never renders a clean zero.
   A verified empty says "verified, not assumed" so the two are not confusable.
3. **Unparseable output is shown raw**, in red, not swallowed into an empty panel.

`selftest.cjs` asserts each of these against a fixture. It has been seen to fail.

## Refresh interval

60 s, measured not felt. The median gap between consecutive `REQUESTS.jsonl` row timestamps is
264 s all-time and 319 s across today's rows. A 60 s tick oversamples the real write rate by
roughly 4×, bounding worst-case staleness at one minute against data that moves every four
minutes. Tighter would be spending wakeups on a file that has not changed.

## The lane with no source

**Decisions for Jo** has no producer. The request ledger's `touches` vocabulary records a decision
Jo *has made* (`decide`); nothing records a decision the fleet is *waiting on*. Rather than fake
it from note prose, the lane reads `state/DECISIONS.jsonl` if some producer ever writes one, and
until then renders one dim line saying no source exists — keeping the gap visible on Jo's desktop
instead of hiding it behind an empty section.

Expected row shape: `{"id","ts","question","options":[...],"state":"open"}`.

## Install / verify / remove

```
zsh install.sh              # install (runs the selftest first, refuses on failure)
zsh install.sh --check      # diff installed copy against this source
zsh install.sh --uninstall  # remove the installed copy (asks first)
node selftest.cjs           # compile + render checks, exit 0 = all pass
python3 fleet-status.py     # see the raw payload
```

Starting Übersicht is not this script's job. That command is `open -a 'Übersicht'`.

#!/usr/bin/env node
/* selftest.cjs — prove lintel-fleet.jsx compiles and renders BEFORE Übersicht ever runs.
 *
 * WHY THIS EXISTS. Übersicht is not running and starting it is Jo's act, so "it renders" could
 * not otherwise be verified at all. This compiles the widget with the EXACT transform Übersicht
 * uses (read out of /Applications/Übersicht.app/Contents/Resources/server.js, bundleWidget:
 * preset-env targets 'last 4 Safari versions' + preset-react {pragma:'html'} + object-rest-spread
 * + babel-plugin-emotion), evaluates it with `html` bound to React.createElement exactly as the
 * runtime does, and renders it against fixtures — INCLUDING the failure fixtures.
 *
 * THE POINT IS DISCONFIRMATION. Each fixture asserts a phrase that MUST appear. A widget that
 * rendered an innocent empty panel for a dead source would fail here rather than on Jo's desktop.
 *
 * Run: node /Users/jowolff/.claude/orchestrator/tools/fleet-widget/selftest.cjs
 * Exit 0 all pass, 1 any fail.
 */

const fs = require('fs');
const path = require('path');
const Module = require('module');

const APP = '/Applications/Übersicht.app/Contents/Resources/node_modules';
const HERE = __dirname;
const WIDGET = path.join(HERE, 'lintel-fleet.jsx');

function app(name) { return require(path.join(APP, name)); }

const babel = app('@babel/core');
const envPreset = app('@babel/preset-env');
const jsxTransform = app('@babel/preset-react');
const restSpread = app('@babel/plugin-proposal-object-rest-spread');
const emotion = app('babel-plugin-emotion');
const React = app('react');
const ReactDOMServer = app('react-dom/server');

const src = fs.readFileSync(WIDGET, 'utf8');

let code;
try {
  code = babel.transformSync(src, {
    filename: WIDGET,
    babelrc: false,
    configFile: false,
    presets: [
      [envPreset, { targets: 'last 4 Safari versions', modules: 'commonjs' }],
      [jsxTransform, { pragma: 'html' }],
    ],
    plugins: [restSpread, emotion],
  }).code;
} catch (e) {
  console.error('FAIL compile: ' + e.message);
  process.exit(1);
}
console.log('ok  compile — Übersicht transform succeeded (' + code.length + ' bytes out)');

// Evaluate exactly as the runtime does: `html` is a global bound to React.createElement.
global.html = React.createElement;
const m = new Module(WIDGET, null);
m.filename = WIDGET;
m.paths = Module._nodeModulePaths(HERE);
try {
  m._compile(code, WIDGET);
} catch (e) {
  console.error('FAIL evaluate: ' + e.message);
  process.exit(1);
}
const w = m.exports;

let failures = 0;
function check(name, cond, detail) {
  if (cond) { console.log('ok  ' + name); }
  else { console.log('FAIL ' + name + (detail ? ' — ' + detail : '')); failures++; }
}

// --- export shape: the #1 Übersicht footgun is a default export -------------
check('named export render', typeof w.render === 'function',
      'got ' + typeof w.render);
check('no default export shadowing render', w.default === undefined,
      'a default export makes Übersicht fall back to raw output passthrough');
check('command is a string', typeof w.command === 'string');
check('refreshFrequency is a number', typeof w.refreshFrequency === 'number');
check('className is a string', typeof w.className === 'string');
check('command references the durable collector',
      w.command.indexOf('/Users/jowolff/.claude/orchestrator/tools/fleet-widget/fleet-status.py') !== -1,
      w.command);

function draw(output) {
  return ReactDOMServer.renderToStaticMarkup(w.render({ output: output }));
}

function fixture(name, output, mustContain, mustNotContain) {
  let html;
  try { html = draw(output); }
  catch (e) { console.log('FAIL ' + name + ' — threw: ' + e.message); failures++; return; }
  let bad = [];
  (mustContain || []).forEach(function (s) {
    if (html.indexOf(s) === -1) bad.push('missing "' + s + '"');
  });
  (mustNotContain || []).forEach(function (s) {
    if (html.indexOf(s) !== -1) bad.push('unexpectedly contains "' + s + '"');
  });
  if (bad.length) { console.log('FAIL ' + name + ' — ' + bad.join('; ')); failures++; }
  else { console.log('ok  ' + name); }
}

const now = Math.floor(Date.now() / 1000);

// --- fixture 1: the real collector, right now -------------------------------
const live = require('child_process').execFileSync(
  'python3', [path.join(HERE, 'fleet-status.py')], { encoding: 'utf8' });
fixture('renders live collector output', live,
        ['Lintel Fleet', 'Blocked', 'Live thread', 'owed'], []);

function payload(over) {
  const base = {
    generated_at: now,
    vocab: { ok: true, terminal: ['delivered'], non_terminal: ['open'], err: null },
    sources: [{ name: 'requests', path: '/x', ok: true, missing: false, age_s: 30, err: null }],
    counts: { status: 'ok', owed: 0, rows: 0, by_state: {}, unknown_state: 0, bad_lines: 0 },
    lanes: {
      blocked: { status: 'ok', err: null, items: [], more: 0, total: 0 },
      live: { status: 'ok', err: null, items: [], more: 0, total: 0 },
      dispatch: { status: 'ok', err: null, items: [], more: 0, total: 0 },
      decisions: { status: 'unwired', err: null, items: [], more: 0 },
    },
  };
  return JSON.stringify(Object.assign(base, over || {}));
}

// --- the failure fixtures: each one is a lie the widget must refuse to tell --

fixture('unparseable output shows the raw text, not an empty panel',
        'Traceback (most recent call last):\n  ImportError: boom',
        ['collector broken', 'ImportError: boom'], ['Live thread']);

fixture('collector exception is shown',
        JSON.stringify({ generated_at: now, fatal: 'OSError: disk gone' }),
        ['collector threw', 'OSError: disk gone'], []);

fixture('a stalled reading turns the header red and says how old',
        payload({ generated_at: now - 4000 }),
        ['stalled', 'has not refreshed since'], ['clear']);

fixture('an unreadable request ledger is red, never a clean zero',
        payload({ lanes: {
          blocked: { status: 'error', err: 'Permission denied', items: [], more: 0 },
          live: { status: 'error', err: 'Permission denied', items: [], more: 0 },
          dispatch: { status: 'ok', err: null, items: [], more: 0, total: 0 },
          decisions: { status: 'unwired', err: null, items: [], more: 0 },
        }, counts: { status: 'error', err: 'Permission denied' } }),
        ['unreadable', 'Permission denied', 'source failed', 'counts unavailable'],
        ['nothing blocked']);

fixture('a stale dispatch ledger says stale rather than showing nothing',
        payload({ lanes: {
          blocked: { status: 'ok', err: null, items: [], more: 0, total: 0 },
          live: { status: 'ok', err: null, items: [], more: 0, total: 0 },
          dispatch: { status: 'stale', err: null, items: [], more: 0, age_s: 191831 },
          decisions: { status: 'unwired', err: null, items: [], more: 0 },
        } }),
        ['source stale 2d', 'not shown rather than shown wrong'], []);

fixture('a lost state vocabulary is announced, not guessed around',
        payload({ vocab: { ok: false, terminal: [], non_terminal: [], err: 'exit 3' } }),
        ['state vocabulary unavailable', 'exit 3'], []);

fixture('a genuinely empty ledger says verified, not assumed',
        payload({}),
        ['nothing blocked — verified, not assumed', 'clear'], ['unreadable']);

fixture('blocked rows lead with Jo’s words and dim the identifier',
        payload({ lanes: {
          blocked: { status: 'ok', err: null, total: 8, more: 5, items: [
            { id: 'REQ-024', ts: '2026-08-19T20:01:17Z', text: 'write it in bb', state: 'blocked' },
          ] },
          live: { status: 'ok', err: null, items: [], more: 0, total: 0 },
          dispatch: { status: 'ok', err: null, items: [], more: 0, total: 0 },
          decisions: { status: 'unwired', err: null, items: [], more: 0 },
        } }),
        ['write it in bb', 'REQ-024', '+5 more blocked', '8 blocked'], []);

// THE DECISIONS LANE, ADDED 2026-08-24 WITH ITS PRODUCER. Three recommendation states and the
// unwired case are four distinct renderings, and the whole point is that they never collapse into
// each other. A test that only exercised the happy path would report success by silence — which is
// the exact defect a sibling checker hit earlier the same day.
const dec = (extra) => payload({ lanes: {
  blocked:   { status: 'ok', err: null, items: [], more: 0, total: 0 },
  live:      { status: 'ok', err: null, items: [], more: 0, total: 0 },
  dispatch:  { status: 'ok', err: null, items: [], more: 0, total: 0 },
  decisions: { status: 'ok', err: null, total: 1, more: 0, items: [Object.assign(
    { id: 'DEC-001', ts: '2026-08-24T22:00:00Z',
      text: 'Close the stale-baseline ticket or rewrite it against the current guard',
      options: ['close it', 'rewrite it'] }, extra)] },
} });

fixture('a decision with a recommendation shows it',
        dec({ rec: 'rewrite, because the underlying want is still real' }),
        ['Close the stale-baseline ticket', 'rec:', 'rewrite, because the underlying want'], []);

fixture('a decision with no recommendation says so rather than showing an empty field',
        dec({ rec: 'none' }),
        ['no recommendation offered'], ['rec:']);

fixture('a decision row from a producer that predates the field says that, not "none"',
        dec({ rec: 'absent' }),
        ['recommendation field missing'], ['no recommendation offered']);

fixture('an unwired decisions lane still says no source file, not "no decisions"',
        payload({ lanes: {
          blocked:   { status: 'ok', err: null, items: [], more: 0, total: 0 },
          live:      { status: 'ok', err: null, items: [], more: 0, total: 0 },
          dispatch:  { status: 'ok', err: null, items: [], more: 0, total: 0 },
          decisions: { status: 'unwired', err: null, items: [], more: 0 },
        } }),
        ['no source file'], ['no decision waiting on you']);

fixture('a lane missing from the payload is reported, not skipped',
        JSON.stringify({ generated_at: now, vocab: { ok: true }, sources: [],
                         counts: { status: 'ok', owed: 0, by_state: {} }, lanes: {} }),
        ['lane missing from collector output'], []);

fixture('undeclared states and unparseable rows are surfaced in the footer',
        payload({ counts: { status: 'ok', owed: 2, rows: 5, by_state: { open: 2 },
                            unknown_state: 3, bad_lines: 1 } }),
        ['1 unparseable rows', '3 undeclared states'], []);

console.log(failures === 0
  ? '\nALL PASS'
  : '\n' + failures + ' FAILURE(S)');
process.exit(failures === 0 ? 0 : 1);

#!/bin/zsh
# install.sh — copy the fleet widget into Übersicht's widget directory.
#
# WHY AN INSTALLER AND NOT JUST EDITING IN PLACE. Übersicht's widget directory is not a
# repository, is not backed up, and is not watched by anything. A file that lived only there
# went missing on this machine for three days this week and nobody noticed. So the AUTHORED
# source lives here, under orchestrator/tools/, which the state publisher already carries
# (sync-to-lintel.sh NEW_IN_SCOPE_DIRS includes "orchestrator/tools/") and which the ~/.claude
# git repository already tracks. The widget directory holds a disposable copy.
#
# Losing the installed copy costs one re-run of this script. Losing this directory costs the work.
#
#   zsh install.sh              install (runs the selftest first, refuses on failure)
#   zsh install.sh --check      report drift between source and installed copy, write nothing
#   zsh install.sh --uninstall  remove the installed copy (asks first)
#
# THIS SCRIPT NEVER STARTS ÜBERSICHT. Launching it is Jo's act, same rule as launching a seat.

set -u
setopt ERR_EXIT PIPE_FAIL

HERE="${0:A:h}"
SRC="$HERE/lintel-fleet.jsx"
COLLECTOR="$HERE/fleet-status.py"
SELFTEST="$HERE/selftest.cjs"
WIDGET_DIR="$HOME/Library/Application Support/Übersicht/widgets"
DEST="$WIDGET_DIR/lintel-fleet.jsx"

say() { print -r -- "$@" }
die() { print -r -- "install.sh: $*" >&2; exit 1 }

MODE="${1:-install}"

case "$MODE" in
  --check)
    [[ -f "$DEST" ]] || { say "NOT INSTALLED — no file at $DEST"; exit 1 }
    if diff -q "$SRC" "$DEST" >/dev/null 2>&1; then
      say "IN SYNC — installed copy is byte-identical to $SRC"
      exit 0
    fi
    say "DRIFT — installed copy differs from the authored source:"
    diff "$SRC" "$DEST" || true
    exit 1
    ;;
  --uninstall)
    [[ -f "$DEST" ]] || { say "nothing to remove — no file at $DEST"; exit 0 }
    say "About to remove: $DEST"
    say "The authored source at $SRC is NOT touched; reinstall with: zsh $HERE/install.sh"
    printf 'Type REMOVE to proceed: '
    read -r REPLY
    [[ "$REPLY" == "REMOVE" ]] || { say "aborted, nothing removed"; exit 1 }
    rm -f "$DEST" || die "rm failed"
    say "removed $DEST"
    exit 0
    ;;
  install) ;;
  *) die "usage: install.sh [--check|--uninstall]" ;;
esac

[[ -f "$SRC" ]] || die "missing source $SRC"
[[ -f "$COLLECTOR" ]] || die "missing collector $COLLECTOR"
[[ -d "$WIDGET_DIR" ]] || die "Übersicht widget directory not found at $WIDGET_DIR"

say "1/4  collector runs and emits JSON"
python3 "$COLLECTOR" | python3 -c 'import json,sys; json.load(sys.stdin)' \
  || die "collector did not emit valid JSON — refusing to install"

say "2/4  widget compiles and renders under Übersicht's own transform"
if command -v node >/dev/null 2>&1; then
  node "$SELFTEST" >/dev/null 2>&1 || die "selftest failed — run: node $SELFTEST"
  say "     selftest passed"
else
  say "     SKIPPED — node not on PATH; the render was NOT verified"
fi

say "3/4  installing"
cp "$SRC" "$DEST" || die "cp failed"

say "4/4  verifying the installed copy"
diff -q "$SRC" "$DEST" >/dev/null || die "installed copy differs from source after cp"

say ""
say "installed: $DEST"
say "authored:  $SRC"
say ""
say "To reverse:  zsh $HERE/install.sh --uninstall"
say "To re-check: zsh $HERE/install.sh --check"
say ""
say "NOT DONE BY THIS SCRIPT — starting Übersicht is yours:"
say "    open -a 'Übersicht'"
